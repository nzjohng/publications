package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.beans.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * JCComponent represents a JViews component in JComposer. 
 *
 * @version     0.8, Apr97
 * @author  Rick Mugridge
 */
public class JCComponent extends Composite implements ActionListener{

  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    this.container = container;
    cornerHandle.setX(x);
    cornerHandle.setY(y); // needed?
    middleHandle.setVisible(false);
    configureText(name,originHandle,topRightHandle);
    name.setText("");
    name.setHeight(name.getPreferredSize().height+Handle.SIZE);
    configureText(parentName,name.getBottomLeftHandle(),name.getCornerHandle());
    parentName.setText("");
    lastBottomLeft = parentName.getBottomLeftHandle();
//  addButton();
// Following uses popup instead:
    MenuItem item = new MenuItem("Add Element");
    addPopupMenuItem(item);
    item.addActionListener(this);


//  setAcceptingAdditions(false);
    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewComponentEvent(jc,this));
    }
  
    protected void configureText(TextShape text, Handle topLeft, Handle topRight) {
    text.init(this,getX(),getY());
    text.setSize(getWidth(),text.getPreferredSize().height); //+Handle.SIZE);
    text.setFont(new Font("Helvetica",0,12));
    text.setHandlesVisible(false);
    text.setCompositeMember(true);
    text.setReshapeEnabled(false);
    text.getMiddleHandle().setGlueEnabled(false);
    text.addPropertyChangeListener(this);
    
    HorizontalMoveConstraint hm = new HorizontalMoveConstraint();
    hm.init(topLeft,text.getOriginHandle(),-Handle.SIZE+1);
    VerticalConstraint v = new VerticalConstraint();
    v.init(topLeft,text.getOriginHandle());
    VerticalOnResizeConstr vr = new VerticalOnResizeConstr();
    vr.init(topRight,text.getTopRightHandle());
    }

/* Dispose of composites is not needed because disposing the container
   will dispose of the elements of a container.
  public void dispose() {
    name.dispose();
    button.dispose();
    for (Enumeration en = fields.elements(); en.hasMoreElements(); )
        ((TextFieldShape)en.nextElement()).dispose();
    super.dispose();
    }
*/
    
  public Dimension getMinimumSize() {
    return new Dimension(70,70);
    }
        
  public void addElement() {
    TextFieldShape field = new TextFieldShape();
    fields.addElement(field);
    field.init(this,getX(),lastBottomLeft.getY());
    field.setSize(getWidth(),name.getPreferredSize().height);
    field.setFont(new Font("Helvetica",0,10));
    field.setHandlesVisible(false);
    field.setCompositeMember(true);
    field.setReshapeEnabled(false);
    field.getMiddleHandle().setGlueEnabled(false);
    HorizontalMoveConstraint topHorizontal = new HorizontalMoveConstraint();
    topHorizontal.init(lastBottomLeft,field.getOriginHandle(),-Handle.SIZE-1);
    VerticalConstraint leftVertical = new VerticalConstraint();
    leftVertical.init(originHandle,field.getOriginHandle());
    VerticalOnResizeConstr rightVertical = new VerticalOnResizeConstr();
    rightVertical.init(topRightHandle,field.getTopRightHandle());
    
    lastBottomLeft = field.getBottomLeftHandle();
    if (lastBottomLeft.getY() > cornerHandle.getY()) {
        Constraint.pushReason(Constraint.RESIZE);
        cornerHandle.setY(lastBottomLeft.getY() + 3);
        Constraint.popReason();
        }

    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewElementEvent(this,field));
    }

  public void addButton() {
    button.init(this,getX(),cornerHandle.getY());
    button.setSize(25,25);
    button.setHandlesVisible(false);
    button.setCompositeMember(true);
    button.setReshapeEnabled(false);
    button.getMiddleHandle().setGlueEnabled(false);
    HorizontalMoveConstraint bottomHorizontal = new HorizontalMoveConstraint();
    bottomHorizontal.init(cornerHandle,button.getCornerHandle());
    VerticalMoveConstraint leftVertical = new VerticalMoveConstraint();
    leftVertical.init(originHandle,button.getOriginHandle());
    button.addActionListener(this);
    }
        
  public void actionPerformed(ActionEvent evt) { // From button
    addElement();
    }
        
  public void paint(Graphics g) {
    super.paint(g);
    Rectangle normal = normalised();
    g.setColor(getForeground());
    g.drawRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
    g.drawRect(normal.x+1, normal.y+1, normal.width - 3, normal.height - 3);
    }

  public String getNameText() {
    return name.getText();
    }
    
  public void setNameText(String newText) {
    name.setText(newText);
    }
    
  public Font getNameFont() {
    return name.getFont();
    }
    
  public void setNameFont(Font newFont) {
    name.setFont(newFont);
    }
    
  public String getParentText() {
    return parentName.getText();
    }
    
  public void setParentText(String newText) {
    parentName.setText(newText);
    }
    
  public Font getParentFont() {
    return parentName.getFont();
    }
    
  public void setParentFont(Font newFont) {
    parentName.setFont(newFont);
    }
    
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parent
    if (evt.getSource() == name) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
        }
    else if (evt.getSource() == parentName) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("parentText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("parentFont",evt.getOldValue(),evt.getNewValue());
        }
    else
        super.propertyChange(evt);
    }

  public String getKindText() {
    return kindText;
    }
    
  public void setKindText(String kindText) {
    String old = this.kindText;
    this.kindText = kindText;
    if (firePropertyChange("kindText",old,kindText))
        repaint();
    }
    
  public String getBbwShapeText() {
    return bbwShapeText;
    }
    
  public void setBbwShapeText(String bbwShapeText) {
    String old = this.bbwShapeText;
    this.bbwShapeText = bbwShapeText;
    if (firePropertyChange("bbwShapeText",old,bbwShapeText))
        repaint();
    }
 
  public Vector getFields() {
    return fields;
    }

  public boolean isGenerateCode() {
    return generateCode;
    }
    
  public void setGenerateCode(boolean generateCode) {
    Boolean old = new Boolean(this.generateCode);
    this.generateCode = generateCode;
    firePropertyChange("generateCode",old,new Boolean(this.generateCode));
    }
 
   public String getPrefix()
    {
        return prefix;
    }
    
    public void setPrefix(String p)
    {
        String old = prefix;
        prefix = p;
        firePropertyChange("prefix",old,p);
    }
 
  public String[] getEditableProperties() {
    String[] ss = { "nameText", "nameFont", "parentText", "parentFont",
            "kindText","bbwShapeText","generateCode", "prefix" };
    return ss;
    }

  protected BBWContainer container;
  protected TextShape name = new TextShape();
  protected TextShape parentName = new TextShape();
  protected ButtonShape button = new ButtonShape();
  protected Handle lastBottomLeft;
  protected Vector fields = new Vector();
  protected String kindText = "";
  protected String bbwShapeText = "";
  protected boolean generateCode = false;
  protected String prefix = "";
  }
