package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;

public class JCRelnShadedShape extends TextShape {
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));

  	JComposerPanel jc = (JComposerPanel) getTopPanel();
  	jc.fireJCChange(new JCNewRelnShadedEvent(jc,this));
  	}

  protected void paintBackGround(Graphics g) {
	Rectangle r = normalised();
	g.setColor(Color.gray);
	g.fillOval(r.x, r.y+SHADOW_DOWN, r.width, r.height);
	g.setColor(getFillColor());
	g.fillOval(r.x, r.y, r.width, r.height);
	g.setColor(getForeground());
	g.drawOval(r.x, r.y, r.width, r.height);
	}

  public Rectangle getBorder() {
	return normalise(new Rectangle(getX(), getY(), width, height+SHADOW_DOWN+2));
  	}

  public Dimension getMinimumSize() {
	return new Dimension(60,30);
	}
    	
  public boolean isGenerateCode() {
  	return generateCode;
  	}
  	
  public void setGenerateCode(boolean generateCode) {
	Boolean old = new Boolean(this.generateCode);
	this.generateCode = generateCode;
	firePropertyChange("generateCode",old,new Boolean(this.generateCode));
  	}
 

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String value) {
		String old = parentName;
		parentName = value;
		firePropertyChange("parentName",old,value);
	}

  public String[] getEditableProperties() {
	String[] ss = { "text", "parentName", "font", "generateCode", };
	return ss;
	}

	protected String parentName = "";
  protected final static int SHADOW_DOWN = 5;
  protected boolean generateCode = false;
  }
