package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;

public class JCUsageArc extends CompositeConnector {
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
    super.init(container,x,y);
    this.from = from;
    this.to = to;

        setHandlesVisible(true);
        AbstractHandle[] handles = getHandles();
        for (int i = 0; i < handles.length; i++)
                handles[i].setVisible(false);
        getPopupHandle().setVisible(true);

    new Connector(arrow, getOriginHandle(), getCornerHandle(), this);

        name.init(this,10,10);
        name.setSize(30,20);
        name.setFont(new Font("Helvetica",0,10));
        name.setText("");
        name.setHandlesVisible(false);
        eq1.init(getMiddleHandle(),name.getLeftHandle());
        name.addPropertyChangeListener(this);

    arrow.setHandlesVisible(false);
    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewUsageArcEvent(jc,this));
    }
    
  public void paint(Graphics g)
  {
    setForeground(Color.gray);
    super.paint(g);
  }
    
  public void setForeground(Color c)
  {
    super.setForeground(c);
    arrow.setForeground(c);
  }  

  public Handle getFrom() {
    return from;
    }

  public Handle getTo() {
    return to;
    }
    
  public String getNameText() {
        return name.getText();
        }
        
  public void setNameText(String newText) {
        name.setText(newText);
        }
        
  public Font getNameFont() {
        return name.getFont();
        }
        
  public void setNameFont(Font newFont) {
        name.setFont(newFont);
        }
        
  public void propertyChange(PropertyChangeEvent evt) {
        // Map the events from text and the choices
        super.propertyChange(evt);
        if (evt.getSource() == name) {
                if (evt.getPropertyName().equals("text"))
                        firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
                else if (evt.getPropertyName().equals("font"))
                        firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
                }
        }

   public boolean isGenerateCode() {
        return generateCode;
        }
        
  public void setGenerateCode(boolean generateCode) {
        Boolean old = new Boolean(this.generateCode);
        this.generateCode = generateCode;
        firePropertyChange("generateCode",old,new Boolean(this.generateCode));
        }
 
  public boolean isCreateLinked() {
        return createLinked;
        }
        
  public void setCreateLinked(boolean createLinked) {
        Boolean old = new Boolean(this.createLinked);
        this.createLinked = createLinked;
        firePropertyChange("createLinked",old,new Boolean(this.createLinked));
        }  
        
  public String getNameIn()
  {
    return nameIn;
  }
  
  public void setNameIn(String value)
  {
    String old = nameIn;
    this.nameIn = value;
    firePropertyChange("nameIn",old,value);
  }
  
  public String getNameOut()
  {
    return nameOut;
  }
  
  public void setNameOut(String value)
  {
    String old = nameOut;
    this.nameOut = value;
    firePropertyChange("nameOut",old,value);
  }
        
    public String[] getEditableProperties() {
        String[] ss = { "nameText", "nameFont", "nameOut", "nameIn", "createLinked", "generateCode" };
            return ss;
        }

     
        
  protected TextShape name = new TextShape();
  protected EqualityMoveConstraint eq1 = new EqualityMoveConstraint();
  protected ArrowShape arrow = new ArrowShape();
  protected Handle from, to;
  protected boolean generateCode = false;
  protected boolean createLinked = false; 
  protected String nameIn = "";
  protected String nameOut = "";
  
}
