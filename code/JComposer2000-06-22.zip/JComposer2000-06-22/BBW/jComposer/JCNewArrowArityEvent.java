package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewArrowArityEvent extends JCChangeEvent{
  public JCNewArrowArityEvent(Object source, JCArrowArity arrow) {
  	super(source);
  	this.arrow = arrow;
  	}
  
  public JCArrowArity getArrowArity() {
  	return arrow;
  	}
  	
  protected JCArrowArity arrow;
  }
