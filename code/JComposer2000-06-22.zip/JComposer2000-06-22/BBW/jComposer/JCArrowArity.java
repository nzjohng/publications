package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;
import java.util.Vector;

public class JCArrowArity extends CompositeConnector{
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
        super.init(container,x,y);
        this.from = from;
        this.to = to;
                      
        setHandlesVisible(false);
        AbstractHandle[] handles = getHandles();
        for (int i = 0; i < handles.length; i++)
                handles[i].setVisible(false);
        getPopupHandle().setVisible(false);

        new Connector(arrow, getOriginHandle(), getCornerHandle(), this);
        arrow.setHandlesVisible(false);

        name.init(this,10,10);
        name.setSize(30,20);
        name.setFont(new Font("Helvetica",0,10));
        name.setText("");
        name.setHandlesVisible(false);
        eq1.init(getMiddleHandle(),name.getLeftHandle());
        name.addPropertyChangeListener(this);

        fromArity.init(this,10,10);
        fromArity.setSize(30,20);
        fromArity.setFont(new Font("Helvetica",0,12));
        fromArity.setText("0:1");
        pc1.init(getMiddleHandle(),getOriginHandle());
        eq2.init(pc1.getPin(),fromArity.getMiddleHandle());
        fromArity.addPropertyChangeListener(this);
        fromArity.setHandlesVisible(false);
        
        toArity.init(this,10,10);
        toArity.setSize(30,20);
        toArity.setFont(new Font("Helvetica",0,12));
        toArity.setText("0:1");
        pc2.init(getMiddleHandle(),getCornerHandle());
        eq3.init(pc2.getPin(),toArity.getMiddleHandle());
        toArity.addPropertyChangeListener(this);
        toArity.setHandlesVisible(false);
        
        /*
        pc1.init(getMiddleHandle(),getOriginHandle());
        choiceFrom.init(this,10,10);
        buildChoiceShape(choiceFrom);
        eq2.init(pc1.getPin(),choiceFrom.getMiddleHandle());

        pc2.init(getMiddleHandle(),getCornerHandle());
        choiceTo.init(this,10,10);
        buildChoiceShape(choiceTo);
        eq3.init(pc2.getPin(),choiceTo.getMiddleHandle());
		*/
        setAcceptingAdditions(false);
        JComposerPanel jc = (JComposerPanel) getTopPanel();
        jc.fireJCChange(new JCNewArrowArityEvent(jc,this));

//      SpyHere spy = new SpyHere();    // DEBUG
//      addPropertyChangeListener(spy); // DEBUG
        }

  protected void buildChoiceShape(ChoiceShape ch) {
        ch.setWidth(60);
        ch.setHeight(20);
        ch.addItem("0:1");
        ch.addItem("1:1");
        ch.addItem("0:n");
        ch.addItem("1:n");
        ch.addPropertyChangeListener(this);
        ch.setHandlesVisible(false);
        }
  
  public void setForeground(Color c)
  {
    super.setForeground(c);
    arrow.setForeground(c);
  }
  
  public String getNameText() {
        return name.getText();
        }
        
  public void setNameText(String newText) {
        name.setText(newText);
        }
        
  public Font getNameFont() {
        return name.getFont();
        }
        
  public void setNameFont(Font newFont) {
        name.setFont(newFont);
        }
        
  public String getChoiceFrom() {
        return fromArity.getText();
        }
        
  public void setChoiceFrom(String newText) {
        fromArity.setText(newText);
        }
        
  public String getChoiceTo() {
        return toArity.getText();
        }
        
  public void setChoiceTo(String newText) {
        toArity.setText(newText);
        }
        
  public void propertyChange(PropertyChangeEvent evt) {
        // Map the events from text and the choices
        super.propertyChange(evt);
        if (evt.getSource() == name) {
                if (evt.getPropertyName().equals("text"))
                        firePropertyChange("name",evt.getOldValue(),evt.getNewValue());
                else if (evt.getPropertyName().equals("font"))
                        firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
                }
        else if (evt.getSource() == fromArity && evt.getPropertyName().equals("text"))
                firePropertyChange("choiceFrom",evt.getOldValue(),evt.getNewValue());
        else if (evt.getSource() == toArity && evt.getPropertyName().equals("text"))
                firePropertyChange("choiceTo",evt.getOldValue(),evt.getNewValue());
        }

  public boolean isGenerateCode() {
        return generateCode;
        }
        
  public void setGenerateCode(boolean generateCode) {
        Boolean old = new Boolean(this.generateCode);
        this.generateCode = generateCode;
        firePropertyChange("generateCode",old,new Boolean(this.generateCode));
        }
 
  public boolean isCreateLinked() {
        return createLinked;
        }
        
  public void setCreateLinked(boolean createLinked) {
        Boolean old = new Boolean(this.createLinked);
        this.createLinked = createLinked;
        firePropertyChange("createLinked",old,new Boolean(this.createLinked));
        }
 
  public boolean isChildListenBefore() {
        return childListenBefore;
        }
        
  public void setChildListenBefore(boolean childListenBefore) {
        Boolean old = new Boolean(this.childListenBefore);
        this.childListenBefore = childListenBefore;
        firePropertyChange("childListenBefore",old,new Boolean(this.childListenBefore));
        }
 
  public boolean isChildListenAfter() {
        return childListenAfter;
        }
        
  public void setChildListenAfter(boolean childListenAfter) {
        Boolean old = new Boolean(this.childListenAfter);
        this.childListenAfter = childListenAfter;
        firePropertyChange("childListenAfter",old,new Boolean(this.childListenAfter));
        }

  public boolean isChildHandleBefore() {
        return childHandleBefore;
        }
        
  public void setChildHandleBefore(boolean childHandleBefore) {
        Boolean old = new Boolean(this.childHandleBefore);
        this.childHandleBefore = childHandleBefore;
        firePropertyChange("childHandleBefore",old,new Boolean(this.childHandleBefore));
        }
 
  public boolean isChildHandleAfter() {
        return childHandleAfter;
        }
        
  public void setChildHandleAfter(boolean childHandleAfter) {
        Boolean old = new Boolean(this.childHandleAfter);
        this.childHandleAfter = childHandleAfter;
        firePropertyChange("childHandleAfter",old,new Boolean(this.childHandleAfter));
        }
 
  public boolean isParentListenBefore() {
        return parentListenBefore;
        }
        
  public void setParentListenBefore(boolean parentListenBefore) {
        Boolean old = new Boolean(this.parentListenBefore);
        this.parentListenBefore = parentListenBefore;
        firePropertyChange("parentListenBefore",old,new Boolean(this.parentListenBefore));
        }
 
  public boolean isParentListenAfter() {
        return parentListenAfter;
        }
        
  public void setParentListenAfter(boolean parentListenAfter) {
        Boolean old = new Boolean(this.parentListenAfter);
        this.parentListenAfter = parentListenAfter;
        firePropertyChange("parentListenAfter",old,new Boolean(this.parentListenAfter));
        }
 
  public boolean isParentHandleBefore() {
        return parentHandleBefore;
        }
        
  public void setParentHandleBefore(boolean parentHandleBefore) {
        Boolean old = new Boolean(this.parentHandleBefore);
        this.parentHandleBefore = parentHandleBefore;
        firePropertyChange("parentHandleBefore",old,new Boolean(this.parentHandleBefore));
        }
 
  public boolean isParentHandleAfter() {
        return parentHandleAfter;
        }
        
  public void setParentHandleAfter(boolean parentHandleAfter) {
        Boolean old = new Boolean(this.parentHandleAfter);
        this.parentHandleAfter = parentHandleAfter;
        firePropertyChange("parentHandleAfter",old,new Boolean(this.parentHandleAfter));
        }
 

 public boolean isAggregate() {
        return aggregate;
        }
        
  public void setAggregate(boolean aggregate) {
        Boolean old = new Boolean(this.aggregate);
        this.aggregate = aggregate;
        firePropertyChange("aggregate",old,new Boolean(this.aggregate));
        }  
        
  public String[] getEditableProperties() {
        String[] ss = { "nameText", "nameFont", "choiceFrom", "choiceTo", "createLinked", "generateCode","aggregate", "childListenBefore", "childListenAfter", "childHandleBefore", "childHandleAfter", "parentListenBefore", "parentListenAfter", "parentHandleBefore", "parentHandleAfter" };
	return ss;
        }

  public Handle getFrom() {
        return from;
        }

  public Handle getTo() {
        return to;
        }

  protected ArrowShape arrow = new ArrowShape();
  protected TextShape name = new TextShape();
  protected EqualityMoveConstraint eq1 = new EqualityMoveConstraint();
//  protected ChoiceShape choiceFrom = new ChoiceShape();
//  protected ChoiceShape choiceTo = new ChoiceShape();

	protected TextShape fromArity = new TextShape();
	protected TextShape toArity = new TextShape();

  protected ProportionalConstraint pc1 = new ProportionalConstraint();
  protected ProportionalConstraint pc2 = new ProportionalConstraint();
  protected EqualityMoveConstraint eq2 = new EqualityMoveConstraint();
  protected EqualityMoveConstraint eq3 = new EqualityMoveConstraint();
  protected boolean generateCode = false;
  protected boolean createLinked = false;
  protected boolean childListenBefore = false;
  protected boolean childListenAfter = false;
  protected boolean childHandleBefore = false;
  protected boolean childHandleAfter = false;
  protected boolean parentListenBefore = false;  
  protected boolean parentListenAfter = false;
  protected boolean parentHandleBefore = false;
  protected boolean parentHandleAfter = false;
  protected Handle from, to;
  protected boolean aggregate = false;
  }

/*
class SpyHere implements PropertyChangeListener{
  public void propertyChange(PropertyChangeEvent evt) {
        System.out.println("Arrow Arity Change: "+evt.getPropertyName()+" = "+evt.getNewValue());
        }
  }
*/
