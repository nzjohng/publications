package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewEventOutEvent extends JCChangeEvent{
  public JCNewEventOutEvent(Object source, JCEventOut event) {
    super(source);
    this.event = event;
    }
  
  public JCEventOut getEventOut() {
    return event;
    }
    
  protected JCEventOut event;
  }
