package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewDirectedArcEvent extends JCChangeEvent{
  public JCNewDirectedArcEvent(Object source, JCDirectedArc arrow) {
  	super(source);
  	this.arrow = arrow;
  	}
  
  public JCDirectedArc getDirectedArc() {
  	return arrow;
  	}
  	
  protected JCDirectedArc arrow;
  }
