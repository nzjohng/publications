package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;

public class JCPerson extends TextShape {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    middleHandle.setVisible(false);
    setText("");
    setAlignmentY(1.0);

    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewPersonEvent(jc,this));
    }

  protected void paintBackGround(Graphics g) {
    Rectangle r = normalised();
    Rectangle o = getBounds();
    int x = o.x;
    if (o.width > FACE_DIAMETER)
        x = x + (o.width - FACE_DIAMETER)/2;
    g.drawOval(x, o.y, FACE_DIAMETER, FACE_DIAMETER);
    g.drawOval(x+EYE_OFFSET-EYE_DIAMETER/2, o.y+FACE_RADIUS-EYE_DIAMETER, EYE_DIAMETER, EYE_DIAMETER);
    g.drawOval(x+FACE_DIAMETER-EYE_OFFSET-EYE_DIAMETER/2, o.y+FACE_RADIUS-EYE_DIAMETER, EYE_DIAMETER, EYE_DIAMETER);
    g.drawArc(x+MOUTH_OFFSET_X,o.y+MOUTH_OFFSET_Y,FACE_DIAMETER-MOUTH_OFFSET_X*2,MOUTH_HEIGHT,0,-180);
    }

  public Rectangle getBorder() {
    int width2 = width;
    int x2 = getX();
    if (FACE_DIAMETER > width) {
        width = FACE_DIAMETER;
        x2 = x2 - (FACE_DIAMETER - getX())/2;
        }
    return normalise(new Rectangle(x2, getY()-FACE_DIAMETER, width2,height+FACE_DIAMETER));
    }

  public Dimension getMinimumSize() {
    return new Dimension(60,50);
    }
        
  public String[] getEditableProperties() {
    String[] ss = { "text", "font" };
    return ss;
    }

  protected final static int FACE_RADIUS = 20, FACE_DIAMETER = FACE_RADIUS*2;
  protected final static int EYE_DIAMETER = 6, EYE_OFFSET = 12;
  protected final static int MOUTH_OFFSET_Y = 17, MOUTH_OFFSET_X = 7, MOUTH_HEIGHT = 17;
  }
