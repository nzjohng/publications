package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

import bbw.*;

public class JCNewElementEvent extends JCChangeEvent{
  public JCNewElementEvent(Object source, RectangularShape element) {
  	super(source); // The source is the JCComponent
  	this.element = element;
  	}
  
  public RectangularShape getElement() {
  	return element;
  	}
  	
  protected RectangularShape element;
  }
