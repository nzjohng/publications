package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewFilterEvent extends JCChangeEvent{
  public JCNewFilterEvent(Object source, JCFilter filter) {
  	super(source);
  	this.filter = filter;
  	}
  
  public JCFilter getFilter() {
  	return filter;
  	}
  	
  protected JCFilter filter;
  }
