package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;
import java.util.Vector;

public class JCEventIn extends TextShape {
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",0,10));
  	setText("Event In");

  	JComposerPanel jc = (JComposerPanel) getTopPanel();
  	jc.fireJCChange(new JCNewEventInEvent(jc,this));
  	}

  public void paint(Graphics g) {
	super.paint(g);
	Rectangle r = normalised();
	g.drawLine(r.x, (int)(r.y+r.height/2.0), r.x+10, r.y);
	g.drawLine(r.x+r.width-10, r.y, r.x+r.width, (int)(r.y+r.height/2.0));
	g.drawLine(r.x+r.width, (int)(r.y+r.height/2.0), r.x+r.width-10, r.y+r.height);
	g.drawLine(r.x+r.width-10, r.y+r.height, r.x+10, r.y+r.height);
	g.drawLine(r.x+10, r.y+r.height, r.x, (int)(r.y+r.height/2.0));
	}

  public Dimension getMinimumSize() {
	return new Dimension(60,40);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text", "font" };
	return ss;
	}

  }
