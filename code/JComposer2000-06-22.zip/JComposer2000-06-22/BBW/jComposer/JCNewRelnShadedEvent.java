package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewRelnShadedEvent extends JCChangeEvent{
  public JCNewRelnShadedEvent(Object source, JCRelnShadedShape relation) {
  	super(source);
  	this.relation = relation;
  	}
  
  public JCRelnShadedShape getRelnShadedShape() {
  	return relation;
  	}
  	
  protected JCRelnShadedShape relation;
  }
