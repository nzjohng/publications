package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.controller.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class JComposerPanel extends BBWGeneralPanel implements ActionListener, ItemListener{
    
  public JComposerPanel() {
    setLayout(new BorderLayout());
//ScrollPane pane = new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
//pane.add(panel);
//add("Center",pane);
    add("Center", panel);
    
    controls.setLayout(new FlowLayout());
    controls.add(new Label("Shape:"));
    String[] jcPackageName = {"jComposer" };
    ToolManager.addToolPackageNames(jcPackageName);
    createTools(tools );
    controls.add(toolChoice);
    
    controls.add(debugPropagation);
    debugPropagation.addItemListener(this);
    controls.add(displayShapes);
    displayShapes.addActionListener(this);
    add("South", controls);
    panel.setController((Controller)controllers.elementAt(0));
    }
  
  protected void createTools(String[] tools) {
    PopupController[] popupControllers = {
        new HidePopupController(),
        new ShowPopupController(),
        new PropSheetPopupController(),
        new DisposePopupController()
        };
    PopupManager.defineMenuItemsOfStandardPopup(panel,popupControllers);

    for (int i = 0; i < tools.length; i++)
        addTool(tools[i]);
    addConnectorTool("JCArrowArity", "JCArrowArity");
    addConnectorTool("JCDirectedArc", "JCDirectedArc");
    addConnectorTool("JCUsageArc", "JCUsageArc");
    MoveController mover = new MoveController(panel.getTopContainer());
    panel.setMoveController(mover);
    controllers.addElement(mover);
    toolChoice.addItem("Move");
    ResizeController resizer = new ResizeController(panel.getTopContainer());
    controllers.addElement(resizer);
    panel.setResizeController(resizer);
    toolChoice.addItem("Resize");
    controllers.addElement(new AdjustController(panel.getTopContainer()));
    toolChoice.addItem("Adjust");
    }
    
  public void itemStateChanged(ItemEvent e) {
    PropertyChangeSupport2.setDebug(debugPropagation.getState());
    }

  public void actionPerformed(ActionEvent e) {
    panel.displayShapes();
    }

  public synchronized void addJCChangeListener(JCListener listener) {
    jcListeners.addElement(listener);
    }
    
  public synchronized void removeJCChangeListener(JCListener listener) {
    jcListeners.removeElement(listener);
    }
    
  public void fireJCChange(JCChangeEvent ev) {
    // This is NOT thread-safe
    Enumeration tell = jcListeners.elements();
    while (tell.hasMoreElements())
        ((JCListener) tell.nextElement()).jcChange(ev);
    }
    
  public JCComponent newComponent(int x, int y, int width, int height) {
    JCComponent s = new JCComponent();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCRelnShape newReln(int x, int y, int width, int height) {
    JCRelnShape s = new JCRelnShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCRelnShadedShape newRelnShaded(int x, int y, int width, int height) {
    JCRelnShadedShape s = new JCRelnShadedShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCEventIn newEventIn(int x, int y, int width, int height) {
    JCEventIn s = new JCEventIn();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCEventOut newEventOut(int x, int y, int width, int height) {
    JCEventOut s = new JCEventOut();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCFilter newFilter(int x, int y, int width, int height) {
    JCFilter s = new JCFilter();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCPerson newPerson(int x, int y, int width, int height) {
    JCPerson s = new JCPerson();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public JCArrowArity newArrowArity(RectangularShape from, RectangularShape to) {
    JCArrowArity shape = new JCArrowArity();
    Handle fromh = getFromHandle(from,to);
    Handle toh = getToHandle(from,to);
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }
  
  public JCDirectedArc newDirectedArc(RectangularShape from, RectangularShape to) {
    JCDirectedArc shape = new JCDirectedArc();
    Handle fromh = getFromHandle(from,to);
    Handle toh = getToHandle(from,to);
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }

  public JCUsageArc newUsageArc(RectangularShape from, RectangularShape to) {
    JCUsageArc shape = new JCUsageArc();
    Handle fromh = getFromHandle(from,to);
    Handle toh = getToHandle(from,to);
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }
    
  public JCAspectInfo newAspectInfo(int x, int y, int width, int height) {
    JCAspectInfo s = new JCAspectInfo();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
  }
  
    
  public Handle getFromHandle(RectangularShape from, RectangularShape to)
  {
    int dx = from.getRightHandle().getX() - to.getLeftHandle().getX();
    int dy = from.getBottomHandle().getY() - to.getTopHandle().getY();
    
    if(abs(dx) > abs(dy))
        if(dx < 0)
            return from.getRightHandle();
        else
            return from.getLeftHandle();
    else
        if(dy < 0)
            return from.getBottomHandle();
        else
            return from.getTopHandle();
    
  }
  
  public Handle getToHandle(RectangularShape from, RectangularShape to)
  {
    int dx = from.getX() - to.getX();
    int dy = from.getY() - to.getY();
    
    if(abs(dx) > abs(dy))
        if(dx > 0)
            return to.getRightHandle();
        else
            return to.getLeftHandle();
    else
        if(dy > 0)
            return to.getBottomHandle();
        else
            return to.getTopHandle();

  }
  
  public int abs(int n1)
  {
        if(n1 < 0)
            return -n1;
        else
            return n1;
  }
  

  
  protected static int frameCount = 1;
  protected Panel controls = new Panel();
  protected Checkbox debugPropagation = new Checkbox("Debug Propagation");
  protected Button displayShapes = new Button("Display Shapes");
  protected String[] tools = {
        "JCComponent",
        "JCRelnShape", "JCRelnShadedShape", "JCPerson",
        "JCEventIn", "JCEventOut", "JCFilter", "JCAspectInfo" /* ,

        "EqualityConstraint", "ResizeEqualityConstraint", "MoveEqualityConstraint",
        "HorizontalConstraint", "HorizontalMoveConstraint", "HorizontalResizeConstraint",
        "HorizontalOnResizeConstr",
        "VerticalConstraint", "VerticalMoveConstraint", "VerticalResizeConstraint",
        "VerticalOnResizeConstr",
        "DependentConstraint",
        "ProportionalConstraint",
        
        "RelativePinConstraint" */ };
  private Vector jcListeners = new Vector();
  }
