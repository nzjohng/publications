package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCTransactionEvent extends java.util.EventObject{
  public JCTransactionEvent(Object source, boolean beginning) {
  	super(source);
  	this.beginning = beginning;
  	}
  
  public boolean isBeginning() {
  	return beginning;
  	}
  	
  public String toString() {
  	return "JCTransactionEvent ["+beginning+"]";
  	}

  private boolean beginning;
  }
