package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

import bbw.*;

public class JCNewAspectDetailEvent extends JCChangeEvent{
  public JCNewAspectDetailEvent(Object source, RectangularShape element) {
    super(source); // The source is the JCComponent
    this.element = element;
    }
  
  public RectangularShape getAspectDetail() {
    return element;
    }
    
  protected RectangularShape element;
  }
