package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewComponentEvent extends JCChangeEvent{
  public JCNewComponentEvent(Object source, JCComponent component) {
  	super(source);
  	this.component = component;
  	}
  
  public JCComponent getComponent() {
  	return component;
  	}
  	
  protected JCComponent component;
  }
