package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;
import java.util.Vector;

public class JCFilter extends Composite {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    middleHandle.setVisible(false);
    name.init(this,10,10);
    name.setFont(new Font("Helvetica",0,10));
    name.setText("");
    name.setHandlesVisible(false);
    name.addPropertyChangeListener(this);
    eq1.init(getOriginHandle(),name.getOriginHandle(),new BBWVector(QBOX_WIDTH,0));
    eq2.init(getCornerHandle(),name.getCornerHandle());

    box.init(this,10,10);
    box.setHandlesVisible(false);
/*
    eq3.init(getOriginHandle(),box.getOriginHandle());
    eq4.init(getBottomLeftHandle(),box.getCornerHandle(),new BBWVector(QBOX_WIDTH,0));
*/
    eq3.init(getOriginHandle(),box.getOriginHandle(),new BBWVector(QBOX_WIDTH,0));
    eq4.init(getBottomLeftHandle(),box.getCornerHandle());

    borderBox.init(this,10,10);
    borderBox.setHandlesVisible(false);
    eq5.init(getOriginHandle(),borderBox.getOriginHandle());
    eq6.init(getCornerHandle(),borderBox.getCornerHandle());

    setAcceptingAdditions(false);
    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewFilterEvent(jc,this));
    }

  public void paint(Graphics g) {
    Rectangle r = normalised();
//  g.drawRect(r.x, r.y, r.width - 1, r.height - 1);
//  g.drawRect(r.x, r.y, QBOX_WIDTH, r.height - 1);
    g.drawString("?",r.x+3,r.y+r.height/2 + 4);
    g.drawString("?",r.x+4,r.y+r.height/2 + 4);
    super.paint(g);
    }

/*  public Rectangle getBorder() {
    return normalise(new Rectangle(getX()-QBOX_WIDTH, getY(), width+QBOX_WIDTH, height));
    }
*/

  public Dimension getMinimumSize() {
    return new Dimension(60,30);
    }
  
  public String getNameText() {
    return name.getText();
    }
    
  public void setNameText(String newText) {
    name.setText(newText);
    }
    
  public Font getNameFont() {
    return name.getFont();
    }
    
  public void setNameFont(Font newFont) {
    name.setFont(newFont);
    }
    
   public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parentName
    if (evt.getSource() == name) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
        }
    else
        super.propertyChange(evt);
    }

 public boolean isGenerateCode() {
    return generateCode;
    }
    
  public void setGenerateCode(boolean generateCode) {
    Boolean old = new Boolean(this.generateCode);
    this.generateCode = generateCode;
    firePropertyChange("generateCode",old,new Boolean(this.generateCode));
    }
 
    public String getParentName() {
        return parentName;
    }
   
    public void setParentName(String value) {
        String old = parentName;
        parentName = value;
        firePropertyChange("parentName",old,value);
    }
   
   public String[] getEditableProperties() {
    String[] ss = { "nameText", "parentName", "nameFont", "generateCode", };
    return ss;
    }

    protected String parentName = "";
  protected TextShape name = new TextShape();
  protected EqualityConstraint eq1 = new EqualityConstraint();
  protected EqualityOnResize eq2 = new EqualityOnResize();
  protected BoxShape box = new BoxShape();
  protected EqualityConstraint eq3 = new EqualityConstraint();
  protected EqualityOnResize eq4 = new EqualityOnResize();
  protected BoxShape borderBox = new BoxShape();
  protected EqualityConstraint eq5 = new EqualityConstraint();
  protected EqualityOnResize eq6 = new EqualityOnResize();
  protected final static int QBOX_WIDTH = 10;
  protected boolean generateCode = false;
  }
