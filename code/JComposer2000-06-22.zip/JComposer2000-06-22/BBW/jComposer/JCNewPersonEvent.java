package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewPersonEvent extends JCChangeEvent{
  public JCNewPersonEvent(Object source, JCPerson person) {
    super(source);
    this.person = person;
    }
  
  public JCPerson getPerson() {
    return person;
    }
    
  protected JCPerson person;
  }
