package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewRelnEvent extends JCChangeEvent{
  public JCNewRelnEvent(Object source, JCRelnShape relation) {
  	super(source);
  	this.relation = relation;
  	}
  
  public JCRelnShape getRelnShape() {
  	return relation;
  	}
  	
  protected JCRelnShape relation;
  }
