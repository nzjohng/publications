package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewUsageArcEvent extends JCChangeEvent{
  public JCNewUsageArcEvent(Object source, JCUsageArc arrow) {
    super(source);
    this.arrow = arrow;
    }
  
  public JCUsageArc getUsageArc() {
    return arrow;
    }
    
  protected JCUsageArc arrow;
  }
