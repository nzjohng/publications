package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewEventInEvent extends JCChangeEvent{
  public JCNewEventInEvent(Object source, JCEventIn event) {
    super(source);
    this.event = event;
    }
  
  public JCEventIn getEventIn() {
    return event;
    }
    
  protected JCEventIn event;
  }
