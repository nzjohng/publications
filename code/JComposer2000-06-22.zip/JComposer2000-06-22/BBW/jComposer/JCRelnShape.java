package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class JCRelnShape extends Composite {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    middleHandle.setVisible(false);
    name.init(this,x,y);
    name.setFont(new Font("Helvetica",2,10));
    name.setText("");
    name.setHandlesVisible(false);
    name.addPropertyChangeListener(this);
//      name.setReshapeEnabled(false);
    EqualityConstraint eq1 = new EqualityConstraint();
    eq1.init(originHandle,name.getOriginHandle());
    EqualityOnResize eq2 = new EqualityOnResize();
    eq2.init(rightHandle,name.getCornerHandle());
    parentName.init(this,x,y);
    parentName.setFont(new Font("Helvetica",2,10));
    parentName.setText("");
    parentName.setHandlesVisible(false);
    parentName.addPropertyChangeListener(this);
//      parentName.setReshapeEnabled(false);
    EqualityConstraint eq3 = new EqualityConstraint();
    eq3.init(leftHandle,parentName.getOriginHandle());
    EqualityOnResize eq4 = new EqualityOnResize();
    eq4.init(cornerHandle,parentName.getCornerHandle());

    setAcceptingAdditions(false);
    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewRelnEvent(jc,this));
    }

  public void paint(Graphics g) {
    Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillOval(r.x, r.y, r.width, r.height);
    super.paint(g);
    g.setColor(getForeground());
    g.drawOval(r.x, r.y, r.width, r.height);
    }
    

  public Dimension getMinimumSize() {
    return new Dimension(60,40);
    }
        
  public String getNameText() {
    return name.getText();
    }
    
  public void setNameText(String newText) {
    name.setText(newText);
    }
    
  public Font getNameFont() {
    return name.getFont();
    }
    
  public void setNameFont(Font newFont) {
    name.setFont(newFont);
    }
    
  public String getParentText() {
    return parentName.getText();
    }
    
  public void setParentText(String newText) {
    parentName.setText(newText);
    }
    
  public Font getParentFont() {
    return parentName.getFont();
    }
    
  public void setParentFont(Font newFont) {
    parentName.setFont(newFont);
    }
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parentName
    if (evt.getSource() == name) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
        }
    else if (evt.getSource() == parentName) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("parentText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("parentFont",evt.getOldValue(),evt.getNewValue());
        }
    else
        super.propertyChange(evt);
    }

 public String getKindText() {
    return kindText;
    }
    
  public void setKindText(String kindText) {
    String old = kindText;
    this.kindText = kindText;
    if (firePropertyChange("kindText",old,kindText))
        repaint();
    }
    
  public boolean isGenerateCode() {
    return generateCode;
    }
    
  public void setGenerateCode(boolean generateCode) {
    Boolean old = new Boolean(this.generateCode);
    this.generateCode = generateCode;
    firePropertyChange("generateCode",old,new Boolean(this.generateCode));
    }
 
  public boolean isAggregate() {
    return aggregate;
    }
    
  public void setAggregate(boolean aggregate) {
    Boolean old = new Boolean(this.aggregate);
    this.aggregate = aggregate;
    firePropertyChange("aggregate",old,new Boolean(this.aggregate));
    }
    
   public boolean isCreateLinked() {
    return createLinked;
    }
    
  public void setCreateLinked(boolean createLinked) {
    Boolean old = new Boolean(this.createLinked);
    this.createLinked = createLinked;
    firePropertyChange("createLinked",old,new Boolean(this.createLinked));
    }
 
  public String[] getEditableProperties() {
    String[] ss = { "nameText", "nameFont", "parentText", "parentFont", 
                "kindText", "generateCode", "createLinked", "aggregate" };
    return ss;
    }

  protected TextShape name = new TextShape();
  protected TextShape parentName = new TextShape();
  protected String kindText = "Kind";
  protected boolean generateCode = false;
  protected boolean createLinked = false;
  protected boolean aggregate = false;
  }
