package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

import bbw.*;

public interface JCTransactionListener extends java.util.EventListener {
  public abstract void transaction(BBWTransactionEvent evt);
  }
