package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class JCNewAspectInfoEvent extends JCChangeEvent{
  public JCNewAspectInfoEvent(Object source, JCAspectInfo component) {
    super(source);
    this.component = component;
    }
  
  public JCAspectInfo getAspectInfo() {
    return component;
    }
    
  protected JCAspectInfo component;
  }
