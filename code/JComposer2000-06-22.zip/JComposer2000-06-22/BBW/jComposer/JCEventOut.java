package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;
import java.util.Vector;

public class JCEventOut extends TextShape {
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",0,10));
  	setText("Event Out");

  	JComposerPanel jc = (JComposerPanel) getTopPanel();
  	jc.fireJCChange(new JCNewEventOutEvent(jc,this));
  	}

  public void paint(Graphics g) {
	super.paint(g);
	Rectangle r = normalised();
	g.drawLine(r.x, r.y+r.height/2, r.x+10, r.y);
	g.drawLine(r.x+10, r.y, r.x+r.width-10, r.y);
	g.drawLine(r.x+r.width-10, r.y, r.x+r.width, r.y+r.height/2);
	g.drawLine(r.x+r.width, r.y+r.height/2, r.x+r.width-10, r.y+r.height);
	g.drawLine(r.x+10, r.y+r.height, r.x, r.y+r.height/2);
	super.paint(g);
	}

  public Dimension getMinimumSize() {
	return new Dimension(60,40);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text", "font" };
	return ss;
	}

  }
