package jComposer;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.beans.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * JCComponent represents a JViews component in JComposer. 
 *
 * @version     0.8, Apr97
 * @author  Rick Mugridge
 */
public class JCAspectInfo extends Composite implements ActionListener{

  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    this.container = container;
    cornerHandle.setX(x);
    cornerHandle.setY(y); // needed?
    middleHandle.setVisible(false);
    configureText(aspectName,originHandle,topRightHandle);
    aspectName.setText("");
    aspectName.setHeight(aspectName.getPreferredSize().height+Handle.SIZE);
    configureText(aspectType,aspectName.getBottomLeftHandle(),aspectName.getCornerHandle());
    aspectName.setText("");
    lastBottomLeft = aspectName.getBottomLeftHandle();
//  addButton();
// Following uses popup instead:
    MenuItem item = new MenuItem("Add Element");
    addPopupMenuItem(item);
    item.addActionListener(this);


//  setAcceptingAdditions(false);
    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewAspectInfoEvent(jc,this));
    
    aspectName.setForeground(Color.blue);
    aspectType.setForeground(Color.blue);
    
    }
  
    protected void configureText(TextShape text, Handle topLeft, Handle topRight) {
    text.init(this,getX(),getY());
    text.setSize(getWidth(),text.getPreferredSize().height); //+Handle.SIZE);
    text.setFont(new Font("Helvetica",0,12));
    text.setHandlesVisible(false);
    text.setCompositeMember(true);
    text.setReshapeEnabled(false);
    text.getMiddleHandle().setGlueEnabled(false);
    text.addPropertyChangeListener(this);
    
    HorizontalMoveConstraint hm = new HorizontalMoveConstraint();
    hm.init(topLeft,text.getOriginHandle(),-Handle.SIZE+1);
    VerticalConstraint v = new VerticalConstraint();
    v.init(topLeft,text.getOriginHandle());
    VerticalOnResizeConstr vr = new VerticalOnResizeConstr();
    vr.init(topRight,text.getTopRightHandle());
    }

/* Dispose of composites is not needed because disposing the container
   will dispose of the elements of a container.
  public void dispose() {
    name.dispose();
    button.dispose();
    for (Enumeration en = fields.elements(); en.hasMoreElements(); )
        ((TextFieldShape)en.nextElement()).dispose();
    super.dispose();
    }
*/
    
  public Dimension getMinimumSize() {
    return new Dimension(70,70);
    }
        
  public void addElement() {
    TextFieldShape field = new TextFieldShape();
    fields.addElement(field);
    field.init(this,getX(),lastBottomLeft.getY());
    field.setSize(getWidth(),aspectName.getPreferredSize().height);
    field.setFont(new Font("Helvetica",0,10));
    field.setHandlesVisible(false);
    field.setCompositeMember(true);
    field.setReshapeEnabled(false);
    field.getMiddleHandle().setGlueEnabled(false);
    HorizontalMoveConstraint topHorizontal = new HorizontalMoveConstraint();
    topHorizontal.init(lastBottomLeft,field.getOriginHandle(),-Handle.SIZE-1);
    VerticalConstraint leftVertical = new VerticalConstraint();
    leftVertical.init(originHandle,field.getOriginHandle());
    VerticalOnResizeConstr rightVertical = new VerticalOnResizeConstr();
    rightVertical.init(topRightHandle,field.getTopRightHandle());
    
    lastBottomLeft = field.getBottomLeftHandle();
    if (lastBottomLeft.getY() > cornerHandle.getY()) {
        Constraint.pushReason(Constraint.RESIZE);
        cornerHandle.setY(lastBottomLeft.getY() + 3);
        Constraint.popReason();
        }

    JComposerPanel jc = (JComposerPanel) getTopPanel();
    jc.fireJCChange(new JCNewAspectDetailEvent(this,field));
    }

  public void addButton() {
    button.init(this,getX(),cornerHandle.getY());
    button.setSize(25,25);
    button.setHandlesVisible(false);
    button.setCompositeMember(true);
    button.setReshapeEnabled(false);
    button.getMiddleHandle().setGlueEnabled(false);
    HorizontalMoveConstraint bottomHorizontal = new HorizontalMoveConstraint();
    bottomHorizontal.init(cornerHandle,button.getCornerHandle());
    VerticalMoveConstraint leftVertical = new VerticalMoveConstraint();
    leftVertical.init(originHandle,button.getOriginHandle());
    button.addActionListener(this);
    }
        
  public void actionPerformed(ActionEvent evt) { // From button
    addElement();
    }
        
  public void paint(Graphics g) {
    super.paint(g);
    Rectangle normal = normalised();
    setForeground(Color.blue);
    g.setColor(getForeground());
    g.drawRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
    g.drawRect(normal.x+1, normal.y+1, normal.width - 3, normal.height - 3);
    }

  public String getAspectName() {
    return aspectName.getText();
    }
    
  public void setAspectName(String newText) {
    aspectName.setText(newText);
    }
    
  public String getAspectType() {
    return aspectType.getText();
    }
    
  public void setAspectType(String newText) {
    aspectType.setText(newText);
    }
    
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parent
    if (evt.getSource() == aspectName) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("aspectName",evt.getOldValue(),evt.getNewValue());
        }
    else if (evt.getSource() == aspectType) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("aspectType",evt.getOldValue(),evt.getNewValue());
        }
    else
        super.propertyChange(evt);
    }
 
  public Vector getFields() {
    return fields;
    }

  public boolean isDesignLevel() {
    return designLevel;
    }
    
  public void setDesignLevel(boolean designLevel) {
    Boolean old = new Boolean(this.designLevel);
    this.designLevel = designLevel;
    firePropertyChange("designLevel",old,new Boolean(this.designLevel));
    }
 
   public String getJviewsClass()
    {
        return jviewsClass;
    }
    
    public void setJviewsClass(String p)
    {
        String old = jviewsClass;
        jviewsClass = p;
        firePropertyChange("jviewsClass",old,p);
    }
 
  public String[] getEditableProperties() {
    String[] ss = { "aspectName", "aspectType", "designLevel", "jviewsClass" };
    return ss;
    }

  protected BBWContainer container;
  protected TextShape aspectName = new TextShape();
  protected TextShape aspectType = new TextShape();
  protected ButtonShape button = new ButtonShape();
  protected Handle lastBottomLeft;
  protected Vector fields = new Vector();
  protected boolean designLevel = false;
  protected String jviewsClass = "";
  }
