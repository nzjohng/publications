package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public interface JCListener extends java.util.EventListener {
  public abstract void jcChange(JCChangeEvent evt);
  }
