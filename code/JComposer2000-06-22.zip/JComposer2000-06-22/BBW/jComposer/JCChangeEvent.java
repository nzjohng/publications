package jComposer;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

import java.beans.*;

public abstract class JCChangeEvent extends java.util.EventObject{
  public JCChangeEvent(Object source) {
  	super(source);
  	}
  }
