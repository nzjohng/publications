package bbw;

import java.io.*;

/**
 * A Composite is a ContainerShape with hidden inside handles.
 *
 * @version 	0.8, Apr1997
 * @author 	Rick Mugridge
 */
public abstract class Composite extends ContainerShape {

	/**
	 * Initialise the Composite with hidden inside handles.
	 */
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
	insideTopLeftHandle.setVisible(false);
	insideTopRightHandle.setVisible(false);
	insideBottomLeftHandle.setVisible(false);
	insideBottomRightHandle.setVisible(false);
  	}

	/**
	 * Extend add() to set the new element to be a compositeMember.
	 */
  public synchronized BBWComponent add(BBWComponent comp, int pos) {
	comp.setCompositeMember(true);
	return super.add(comp,pos);
	}
  }