package bbw;

import java.awt.*;
import java.util.*;
import java.io.Serializable;

/**
 * A Handle is used to manipulate shapes and to be visible for certain constraints, such as ProportionalConstraint.
 * It is owned by a Shape (in the case of a RelativePin, this is the owner of the source pin).
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class PopupHandle extends AbstractHandle {
  
	/**
	 * Create a PopupHandle with the given owner, given name, and with origin (x,y). 
	 */
  public PopupHandle(BBWComponent owner, String name, int x, int y) {
	super(owner,name,x,y);
	}
	
  public PopupHandle(BBWComponent owner, String name) {
	this(owner,name,10,10);
	}
	
  public PopupHandle(BBWComponent owner, int x, int y) {
	this(owner,"<handle>",x,y);
	}

 	/**
	 *Paint the Handle.
	 */
  public void paint(Graphics g, Color color) {
	if (visible) {
		g.setColor(Color.magenta);
		g.fillOval(x-HALF_SIZE, y-HALF_SIZE, SIZE, SIZE);
		}
	}
  }

