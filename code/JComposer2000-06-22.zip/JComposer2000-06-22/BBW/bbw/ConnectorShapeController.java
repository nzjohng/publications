package bbw;

import java.awt.*;
import java.awt.event.*;

/**
 * A Controller for dragging out a shape connected back to the
 * clicked on handle.  The classes of the connector and
 * shape are provided.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ConnectorShapeController extends HandleController {

  public ConnectorShapeController(Class ConnectorClass, Class shapeClass, BBWContainer container) {
  	super(container);
  	this.ConnectorClass = ConnectorClass;
  	this.shapeClass = shapeClass;
  	}

  public void mouseDown(MouseEvent event, int x, int y) {
	mouseHandle = null;
//	dragBounds = container.getBounds(); // ie, not restricted
	Handle from  = container.getHandleAt(x,y);
	if (from != null && from.isGlueEnabled())
		makeConnectorAndShape(from,x,y);
	else {
		// It's not a pin, so try a shape with a middle handle
		BBWComponent comp = container.getComponentAt(x,y);
		if (comp instanceof Shape && !(comp instanceof BBWTopContainer)) {
			Shape shape = (Shape)comp;
			from = shape.getMiddleHandle();
			if (from.isGlueEnabled())
				makeConnectorAndShape(from,x,y);
			}
		}
	}

  public void makeConnectorAndShape(Handle from, int x, int y) {
	BBWContainer theContainer = from.getOwner().getParent().getOpenContainer();
	Shape connector, shape;
	try {
		connector = (Shape) ConnectorClass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown Connector class: "+ConnectorClass.getName());
		}
	try {
		shape = (Shape) shapeClass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown Shape class: "+shapeClass.getName());
		}
	Constraint.pushReason(Constraint.MOVE); // So it's the same as user-construction time
	shape.init(theContainer,x,y);
//System.out.println("Made new COnnector "+connector.getName()+" from "+from.getName()+" to "+shape.getName());
	new Connector(connector, from, shape.getMiddleHandle(), theContainer);
  	connector.setHandlesVisible(false);

	Constraint.popReason();
	if (container instanceof ContainerShape) // BUT this is a bit if a hack, really!!!!!
		((ContainerShape)container).addUserShape(shape);
 	mouseHandle = shape.getCornerHandle();
	Constraint.pushReason(Constraint.MOVE);
	mouseOffsetX = 0;
	mouseOffsetY = 0;
//	dragBounds = theContainer.getBounds();
	}

  public String getName() {
	return shapeClass.getName()+ConnectorClass.getName();
	}
  
  protected Class ConnectorClass, shapeClass;
  }

