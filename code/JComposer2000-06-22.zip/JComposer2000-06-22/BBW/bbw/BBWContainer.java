package bbw;

import java.awt.*;
import java.io.*;
import java.util.*;

/**
 * A BBW container object is a BBWComponent that can contain other BBWComponent's.
 * It serves a similar role to java.awt.Container.
 *
 * @version 	0.8, Apr1997
 * @author 	Rick Mugridge
 */
public abstract class BBWContainer extends RectangularShape {

	/**
	 * Extend the repaint area with the given Rectangle.
	 * (LATER: reconsider whether to use built-in repaint() or whether to double-buffer it.)
	 */
  public void addRepaintArea(Rectangle r) {
  	getParent().addRepaintArea(r);
  	}

	/** 
	 * Returns the number of components in this container.
	 * @see #getComponent
	 */
    public int countComponents() {
	return ncomponents;
	}

	/** 
	 * Gets the nth element in this container.
	 * @param n the number of the component to get
	 * @exception ArrayIndexOutOfBoundsException If the nth value does not 
	 * exist.
	 */
    public synchronized BBWComponent getComponent(int n) {
	if ((n < 0) || (n >= ncomponents))
		 throw new ArrayIndexOutOfBoundsException("No such container element: " + n);
	return component[n];
	}

	/**
	 * Gets all the components in this container.
	 */
    public synchronized BBWComponent[] getComponents() {
	BBWComponent list[] = new BBWComponent[ncomponents];
	System.arraycopy(component, 0, list, 0, ncomponents);
	return list;
	}

	/**
	 * Returns the insets of the container. The insets indicate the size of
	 * the border of the container. A Frame, for example, will have a top inset
	 * that corresponds to the height of the Frame's title bar. 
	 * (LATER: make use of the Insets to limit the location of elements of the container.)
	 * @see LayoutManager
	 */
    public Insets getInsets() {
	return new Insets(0, 0, 0, 0);
	}

	/**
	 *Add a BBWComponent to the container.
	 */
  public BBWComponent add(BBWComponent comp) {
	return add(comp, -1);
	}

	/** 
	 * Adds the specified component to this container at the given position.
	 * @param comp the component to be added 
	 * @param pos the position at which to insert the component. -1
	 * means insert at the end.
	 * @see #remove
	 */
    public synchronized BBWComponent add(BBWComponent comp, int pos) {
	if (!acceptingAdditions)
		throw new RuntimeException("Container is not accepting new elements");
	if (pos > ncomponents || (pos < 0 && pos != -1))
		throw new IllegalArgumentException("illegal component position");
	// check to see that comp isn't one of this container's parents
	if (comp instanceof BBWContainer)
	    for (BBWContainer cn = this; cn != null; cn=cn.parent)
		if (cn == comp)
		    throw new IllegalArgumentException("adding container's parent to itself");

	if (comp.parent != null)
	    comp.parent.remove(comp);
	if (ncomponents == component.length) {
		BBWComponent newcomponents[] = new BBWComponent[ncomponents * 2];
		System.arraycopy(component, 0, newcomponents, 0, ncomponents);
		component = newcomponents;
		}
	if (pos == -1 || pos==ncomponents)
	    component[ncomponents++] = comp;
	else {
		System.arraycopy(component, pos, component, pos+1, ncomponents-pos);
		component[pos] = comp;
		ncomponents++;
		}
	comp.parent = this;
	return comp;
	}

	/**
	 * Adds the specified component to this container. The component
	 * is also added to the layout manager of this container using the
	 * name specified
	.
	 * @param name the component name
	 * @param comp the component to be added
	 * @see #remove
	 * @see LayoutManager
	 */
    public synchronized BBWComponent add(String name, BBWComponent comp) {
	BBWComponent c = add(comp);
	if (layoutMgr != null)
	    layoutMgr.addLayoutComponent(name, comp);
	return c;
	}

	/** 
	 * Removes the specified component from this container.
	 * @param comp the component to be removed
	 * @see #add
	 */
    public synchronized void remove(BBWComponent comp) {
//	if (!acceptingAdditions)
//		throw new RuntimeException("Container is not able to remove elements");
	if (comp.parent == this)
	    for (int i = 0 ; i < ncomponents ; i++)
		if (component[i] == comp) {
		    comp.repaint();
		    if (layoutMgr != null)
			layoutMgr.removeLayoutComponent(comp);
		    comp.parent = null;
		    System.arraycopy(component, i + 1, component, i, ncomponents - i - 1);
		    component[--ncomponents] = null;
		    return;
		    }
	}

	/** 
	 * Removes all the components from this container.
	 * @see #add
	 * @see #remove
	 */
    public synchronized void removeAll() {
	if (!acceptingAdditions)
		throw new RuntimeException("Container is not able to remove elements");
	while (ncomponents > 0) {
	    BBWComponent comp = component[--ncomponents];
	    component[ncomponents] = null;
	    if (layoutMgr != null)
		layoutMgr.removeLayoutComponent(comp);
	    comp.parent = null;
	    }
	repaint();
	}

    /**
     * Dispose of the BBWContainer and any BBWComponents it contains.
     * Ignore acceptingAdditions in this case.
     */
  public void dispose() {
	// Careful here, because the component.dispose() call will remove
	// elements from component[].
	for (int i = ncomponents - 1; i >= 0; i--)
	    component[i].dispose();
   	super.dispose();
  	}
  
	  /**
	 * Locates the component that contains the x,y position
       * that is visible, and that is not a compositeMember.
	 * @return the component if this is satisfied;
       * return null otherwise. 
	 * @see BBWComponent#contains 
	 */
  public BBWComponent getComponentAt(int x, int y) {
	boolean compositeMemberHit = false;
	if (!visible || !contains(x, y))
		return null;
	for (int i = ncomponents - 1 ; i >= 0 ; i--)
		if (component[i] != null) {
			BBWComponent target = component[i].getComponentAt(x,y);
			if (target != null)
				if (target.isCompositeMember())
					compositeMemberHit = true;
				else
					return target;
			}
	if (compositeMemberHit || !compositeMember)
		return this;
	else
		return null;
	}

/*  protected BBWComponent getComponentAt(int x, int y) {
	if (!visible || !contains(x, y))
		return null;
	for (int i = ncomponents - 1 ; i >= 0 ; i--)
		if (component[i] != null) {
			BBWComponent target = component[i].getComponentAt(x,y);
			if (target != null && !target.isCompositeMember())
				return target;
			}
	return this;
	}
*/

	  /**
	 * Locates the Handle that contains the x,y position.
	 * @return null if a handle is not within the x and y
	 * coordinates; returns the handle otherwise. 
	 */
  public Handle getHandleAt(int x, int y) {
	if (!visible || !contains(x, y))
		return null;
	Handle handle = super.getHandleAt(x,y);
	if (handle != null)
		return handle;
	for (int i = ncomponents - 1 ; i >= 0 ; i--)
		 if (component[i] != null) {
			handle = component[i].getHandleAt(x,y);
			if (handle != null)
				return handle;
			}
	return null;
	}

	/**
	 * Return this as an open container if it's accepting additions;
	 * otherwise pass it up to the parent.
	 */
  public BBWContainer getOpenContainer() {
  	if (acceptingAdditions)
  		return this;
  	else
  		return parent.getOpenContainer();
  	}
  	
	/** 
	 * Gets the layout manager for this container.  
	 * @see #setLayout
	 */
    public BBWLayoutManager getLayout() {
	return layoutMgr;
    }

	/** 
	 * Sets the layout manager for this container.
	 * @see #getLayout
	 */
    public void setLayout(BBWLayoutManager mgr) {
	if (layoutMgr != null)
		layoutMgr.dispose(this);
	layoutMgr = mgr;
	}

	 /** 
	 * Returns the preferred size of this container.  
	 * @see #minimumSize
	 */
    public synchronized Dimension getPreferredSize() {
	return (layoutMgr != null) ? layoutMgr.preferredLayoutSize(this) : new Dimension(10,10);
    }

	/** 
	 * Returns the minimum size of this container.  
	 * @see #preferredSize
	 */
    public synchronized Dimension getMinimumSize() {
	return (layoutMgr != null) ? layoutMgr.minimumLayoutSize(this) : new Dimension(10,10);
    }

	/** 
	 * Paints the components in this container.
	 * @param g the specified Graphics window
	 * @see Component#update
	 */
    public void paint(Graphics g) {
	super.paint(g);
	for (int i = 0 ; i < ncomponents ; i++) {
		BBWComponent comp = component[i];
		if (comp != null)
			comp.update(g);
		}
	}

	  /**
	 * Print all the elements of the container.
	 */
  public void print(PrintStream out, int indent) {
	super.print(out,indent);
	for (int i = ncomponents - 1 ; i >= 0 ; i--)
		component[i].print(out,indent+1);
	}	

	  /**
	 * Get whether the container is accepting element adds and removes.
	 */
  public boolean isAcceptingAdditions() {
  	return acceptingAdditions;
  	}
 
	  /**
	 * Set whether the container is accepting element adds and removes.
	 */
  public void setAcceptingAdditions(boolean is) {
	Boolean was = new Boolean(acceptingAdditions);
	acceptingAdditions = is;
	if (firePropertyChange("acceptingAdditions", was, new Boolean(acceptingAdditions)))
		repaint();
	}
  
	/**
	 * The number of components in this container.
	 */
    int ncomponents;

	/** 
	 * The components in this container.
	 */
    BBWComponent component[] = new BBWComponent[4];

	/** 
	 * Layout manager for this container.
	 */
    BBWLayoutManager layoutMgr;
    
	/** 
	 * Property that determines whether new elements may be added;
	 * if false; an exception is thrown in an add().
	 */
    protected boolean acceptingAdditions = true;
  }

/*
 * This class has been adapted from the Standard AWT Container, Rick Mugridge 1997.
 * @(#)Container.java	1.39 96/02/28 Arthur van Hoff
 *
 * Copyright (c) 1995 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
