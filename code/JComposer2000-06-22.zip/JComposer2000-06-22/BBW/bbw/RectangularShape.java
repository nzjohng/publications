package bbw;

import java.awt.*;

/**
 * A RectangularShape is a Shape with (at least) 9 handles. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class RectangularShape extends Shape {
    
    /**
     * Initialise the RectangularShape with its extra handles.  
     */
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
	topRightHandle = new Handle(this,name+".getTopRightHandle()");
	bottomLeftHandle = new Handle(this,name+".getBottomLeftHandle()");
	new ConstraintOnHandle(topRightHandle,cornerHandle,originHandle);
	new ConstraintOnHandle(bottomLeftHandle,originHandle,cornerHandle);
	topHandle = new Handle(this,name+".getTopHandle()");
	bottomHandle = new Handle(this,name+".getBottomHandle()");
	leftHandle = new Handle(this,name+".getLeftHandle()");
	rightHandle = new Handle(this,name+".getRightHandle()");
	new ConstraintOnHandle(topHandle,middleHandle,originHandle);
	new ConstraintOnHandle(bottomHandle,middleHandle,cornerHandle);
	new ConstraintOnHandle(leftHandle,originHandle,middleHandle);
	new ConstraintOnHandle(rightHandle,cornerHandle,middleHandle);
	}
  
    /**
     * Fill in the rectangle, if necessary.  
     */
  public void paint(Graphics g) {
	Rectangle normal = normalised();
	if (getFillColor() != Color.white) {
		g.setColor(getFillColor());
		g.fillRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
		}
	g.setColor(getForeground());
	}
	
    /**
     * Get all the handles.  
     */
  public AbstractHandle[] getHandles() {
  	Handle[] extras = { topRightHandle,bottomLeftHandle, topHandle, bottomHandle, leftHandle, rightHandle };
  	return addHandles(super.getHandles(),extras);
  	}
  
    /**
     * Get the top-right handle.  
     */
  public Handle getTopRightHandle() {
  	return topRightHandle;
  	}
  
    /**
     * Get the bottom-left handle.  
     */
  public Handle getBottomLeftHandle() {
  	return bottomLeftHandle;
  	}
  
    /**
     * Get the top handle.  
     */
  public Handle getTopHandle() {
  	return topHandle;
  	}
  
    /**
     * Get thebottom handle.  
     */
  public Handle getBottomHandle() {
  	return bottomHandle;
  	}
  
    /**
     * Get the left handle.  
     */
  public Handle getLeftHandle() {
  	return leftHandle;
  	}
  
    /**
     * Get the right handle.  
     */
  public Handle getRightHandle() {
  	return rightHandle;
  	}
  
  protected Handle topRightHandle, bottomLeftHandle;
  protected Handle topHandle, bottomHandle, leftHandle, rightHandle;
  }
