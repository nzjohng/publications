package bbw;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * A BBWGeneralPanel provides some basic panel capability
 * for BBW-based tools.  It handles BBWTransactions, which wrap
 * a transaction around a user's action (such as dragging a shape)
 * so that JViews can reduce the details.  It handles setting up 
 * toolChoice and the events coming from it. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class BBWGeneralPanel extends Panel {

  public BBWGeneralPanel() {
  	toolChoice.addItemListener(new localItemListener());
	/* LATER add this again
	String[] pathNames = {"bbwEditor","editor"};
  	PropertyEditorManager.setEditorSearchPath(pathNames);
	*/
  	}

  public BBWGeneralPanel(String[] extraEditorPackageNames) {
  	toolChoice.addItemListener(new localItemListener());
  	int len = extraEditorPackageNames.length;
  	String[] packageNames = new String[len+2];
  	for (int i = 0; i < len; i++)
  		packageNames[i] = extraEditorPackageNames[i];
   	/* LATER add this again!
 	packageNames[len] = "bbwEditor";
  	packageNames[len+1] = "editor";
  	PropertyEditorManager.setEditorSearchPath(packageNames);
	*/
  	}

  public synchronized void addTransactionListener(BBWTransactionListener listener) {
  	transactionListeners.addElement(listener);
  	}
  	
  public synchronized void removeTransactionListener(BBWTransactionListener listener) {
  	transactionListeners.removeElement(listener);
  	}
  	
  public void fireTransaction(boolean begin) {
	// This is NOT thread-safe
	BBWTransactionEvent ev = new BBWTransactionEvent(this,begin);
	Enumeration tell = transactionListeners.elements();
	while (tell.hasMoreElements())
		((BBWTransactionListener) tell.nextElement()).transaction(ev);
	}

	/**
 	* Add a tool by class name to the toolChoice.  Depending on whether
 	* the class is a Shape or whatever, the appropriate (general-purpose)
 	* Controller is chosen for it.
 	*/
  public void addTool(String name) {
	Class klass = ToolManager.getClass(name);
	if (klass == null)
		throw new RuntimeException("Tool class is unknown: "+name);	
	Object object;
	try {
		object = klass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+klass.getName()+": "+e);	
		}
	if (object instanceof Shape)
		controllers.addElement(new ShapeController(klass,panel.getTopContainer()));
	else if (object instanceof DualConstraint)
		controllers.addElement(new DualPinController(klass,panel.getTopContainer()));
	else if (object instanceof MonoConstraint)
		controllers.addElement(new MonoPinController(klass,panel.getTopContainer()));
	else
		throw new RuntimeException("Tool is neither Shape nor Constraint: "+name);
	toolChoice.addItem(name);
  	}
  
	/**
 	* Add an already-built tool to the toolChoice.
 	*/
  public void addBuiltTool(String toolName, Controller controller) {
	controllers.addElement(controller);
	toolChoice.addItem(toolName);
  	}

	/**
 	* Add a tool by class name to the toolChoice.  Depending on whether
 	* the class is a Shape or whatever, the appropriate (general-purpose)
 	* Controller is chosen for it.
 	*/
  public void addShapeTool(String toolName, String className) {
	Class klass = ToolManager.getClass(className);
	if (klass == null)
		throw new RuntimeException("Tool shape class is unknown: "+className);	
	Object object;
	try {
		object = klass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+klass.getName()+": "+e);	
		}
	if (object instanceof Shape)
		controllers.addElement(new ShapeController(klass,panel.getTopContainer()));
	else
		throw new RuntimeException("Shape Tool is not Shape: "+klass.getName());
	toolChoice.addItem(toolName);
  	}
  
	/**
 	* Add a tool by class name to the toolChoice.  Depending on whether
 	* the class is a Shape or whatever, the appropriate (general-purpose)
 	* Controller is chosen for it.
 	*/
  public void addShapeTool(String toolName, Class klass) {
	Object object;
	try {
		object = klass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+klass.getName()+": "+e);	
		}
	if (object instanceof Shape)
		controllers.addElement(new ShapeController(klass,panel.getTopContainer()));
	else
		throw new RuntimeException("Shape Tool is not Shape: "+klass.getName());
	toolChoice.addItem(toolName);
  	}
  
	/**
 	* Add a connector tool of specified className to the toolChoice.
 	*/
  public void addConnectorTool(String toolName, String className) {
	Class klass = ToolManager.getClass(className);
	if (klass == null)
		throw new RuntimeException("Tool class is unknown: "+className);	
	Object object;
	try {
		object = klass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+klass.getName()+": "+e);	
		}
	if (!(object instanceof Shape))
		throw new RuntimeException("Connector tool class "+klass.getName()+" is not a Shape");	
	controllers.addElement(new ConnectorController(klass,panel.getTopContainer()));
	toolChoice.addItem(toolName);
  	}
  
	/**
 	* Add a connectorShape tool with specified class names for the connector
	* and the shape to the toolChoice.
 	*/
  public void addConnectorShapeTool(String toolName, String connectorName, String shapeName) {
	Class connectorClass = ToolManager.getClass(connectorName);
	Class shapeClass = ToolManager.getClass(shapeName);
	if (connectorClass == null)
		throw new RuntimeException("Tool class is unknown: "+connectorName);	
	if (shapeClass == null)
		throw new RuntimeException("Tool class is unknown: "+shapeName);	
	Object object;
	try {
		object = connectorClass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+connectorClass.getName()+": "+e);	
		}
	if (!(object instanceof Shape))
		throw new RuntimeException("Connector tool connector class "+connectorClass.getName()+" is not a Shape");	

	try {
		object = shapeClass.newInstance();
		}
	catch (Exception e) {
		throw new RuntimeException("Problems creating tool object of class "+shapeClass.getName()+": "+e);	
		}
	if (!(object instanceof Shape))
		throw new RuntimeException("Connector tool shape class "+shapeClass.getName()+" is not a Shape");	
	controllers.addElement(new ConnectorShapeController(connectorClass,shapeClass,panel.getTopContainer()));
	toolChoice.addItem(toolName);
  	}
  
  class localItemListener implements ItemListener {
    public void itemStateChanged(ItemEvent e) {
  	panel.setController((Controller)controllers.elementAt(toolChoice.getSelectedIndex()));
  	}
    }

  public DrawingPanel getPanel()
  {
		return panel;
  }
  
  protected DrawingPanel panel = new DrawingPanel();
  protected Choice toolChoice = new Choice();
  protected Vector controllers = new Vector();
  protected Vector transactionListeners = new Vector();
 }
