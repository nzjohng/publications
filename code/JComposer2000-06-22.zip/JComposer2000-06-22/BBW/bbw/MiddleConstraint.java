package bbw;

import bbw.shape.*;
import java.awt.*;
import java.beans.*;

/**
 * Constraint the given middleHandle so that it is in the middle of the shape.
 * 	constraint middle == origin + size/2 with (ALL=>MOVE);
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class MiddleConstraint extends Constraint {

  public MiddleConstraint(Shape shape, Handle middle, Handle origin) {
  	this.shape = shape;
  	this.middle = middle;
  	this.origin = origin;
  	middle.setX(origin.getX() + shape.getWidth()/2);
  	middle.setY(origin.getY() + shape.getHeight()/2);
  	shape.addPropertyChangeListener(this);
  	middle.addPropertyChangeListener(this);
  	origin.addPropertyChangeListener(this);
  	}
  
	/**
	 * Remove this as listeners, to allow it to be GC'd.
	 */
  public void dispose() {
  	shape.removePropertyChangeListener(this);
  	middle.removePropertyChangeListener(this);
  	origin.removePropertyChangeListener(this);
  	}
  	
	/**
	 * Propagate the change, according to the constraint.
	 */
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
  	firing = true;
  	String property = evt.getPropertyName();
  	Object source = evt.getSource();
  	if (source == middle) {
  		Constraint.pushReason(Constraint.MOVE);
  		if (property.equals("x"))
  			origin.setX(middle.getX() - shape.getWidth()/2);
  		else if (property.equals("y"))
  			origin.setY(middle.getY() - shape.getHeight()/2);
  		Constraint.popReason();
  		}
  	else if ((source == origin && property.equals("x")) || (source == shape && property.equals("width")))
  			middle.setX(origin.getX() + shape.getWidth()/2);
  	else if ((source == origin && property.equals("y")) || (source == shape && property.equals("height")))
  			middle.setY(origin.getY() + shape.getHeight()/2);
	firing = false;
  	}
  
  protected Shape shape;
  protected Handle middle, origin;
  }
