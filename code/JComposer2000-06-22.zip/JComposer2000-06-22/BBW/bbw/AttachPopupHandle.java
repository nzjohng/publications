package bbw;

import java.util.*;
import java.beans.*;

public class AttachPopupHandle implements PropertyChangeListener {
  public AttachPopupHandle(Handle origin, PopupHandle popup) {
	this.origin = origin;
	this.popup = popup;
	popup.setX(origin.getX() + X_OFFSET);
	popup.setY(origin.getY());
	origin.addPropertyChangeListener(this);
	}

  public void propertyChange(PropertyChangeEvent evt) {
	if (evt.getPropertyName().equals("x"))
		popup.setX(origin.getX() + X_OFFSET);
	else if (evt.getPropertyName().equals("y"))
		popup.setY(origin.getY());
	}

  private Handle origin;
  private PopupHandle popup;
  private static final int X_OFFSET = 10;
  }
