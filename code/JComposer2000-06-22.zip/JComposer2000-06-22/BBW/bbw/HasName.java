package bbw;

public interface HasName {
  public String getName();
  }
