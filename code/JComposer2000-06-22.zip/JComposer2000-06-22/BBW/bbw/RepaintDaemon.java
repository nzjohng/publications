package bbw;

import java.awt.*;
import java.beans.*;

/**
 * Daemon to repaint hsapes when they are moved or resized.
 * 	 daemon origin => shape.repaint();
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class RepaintDaemon extends Constraint {

  public RepaintDaemon(BBWComponent shape, Handle origin) {
  	this.shape = shape;
  	this.origin = origin;
  	origin.addPropertyChangeListener(this);
  	}
  
	/**
	 * Remove this as listener, to allow it to be GC'd.
	 */
 public void dispose() {
  	origin.removePropertyChangeListener(this);
  	}
  	
	/**
	 * Fire the daemon.
	 */
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
  	String property = evt.getPropertyName();
  	if (property.equals("x")) {
	  	firing = true;
	  	Integer oldX = (Integer) evt.getOldValue();
	 	shape.repaint(Shape.normalise(new Rectangle(oldX.intValue(), shape.getY(),shape.getWidth(),shape.getHeight())));
		shape.repaint();
		firing = false;
		}
  	else if (property.equals("y")) {
	  	firing = true;
	  	Integer oldY = (Integer) evt.getOldValue();
	 	shape.repaint(Shape.normalise(new Rectangle(shape.getX(),oldY.intValue(), shape.getWidth(),shape.getHeight())));
		shape.repaint();
		firing = false;
		}
  	}
  
  protected BBWComponent shape;
  protected Handle origin;
  }
