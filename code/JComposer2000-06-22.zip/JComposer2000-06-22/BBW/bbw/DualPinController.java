package bbw;

import bbw.shape.LineShape;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * A DualPinController handles a drag from one handle to another.  It holds
 * the name of the specific DualConstraint class and creates it if the connection
 * is successful.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class DualPinController extends PinController {
  public DualPinController(Class klass, BBWContainer container) {
  	super(klass,container);
  	}

  public void mouseUp(MouseEvent event, int x, int y) {
	if (mouseHandle == null)
		return;
	Constraint.popReason();
	arc.dispose();
	Handle to = container.getHandleAt(x,y);
	if (to != null && to.isGlueEnabled())
		buildConstraint(to);
	else {
		// It's not a pin, so try a shape with a middle handle
		BBWComponent comp = container.getComponentAt(x,y);
		if (comp instanceof Shape) {
			Shape shape = (Shape)comp;
			to = shape.getMiddleHandle();
			if (to.isGlueEnabled())
				buildConstraint(to);
			}
		}
	}
	
  protected void buildConstraint(Handle to) {
	DualConstraint constraint;
	try {
		constraint = (DualConstraint) klass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown DualConstraint class: "+getName());
		}
	constraint.init(from,to);
	if (container instanceof ContainerShape)
		((ContainerShape)container).addUserConstraint(constraint);
  	}
  }
