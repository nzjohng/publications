package bbw;

import java.awt.*;
import java.awt.event.*;

/**
 * A Controller for dragging out shapes.  The class of the
 * shape is provided.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ShapeController extends HandleController {

  public ShapeController(Class klass, BBWContainer container) {
  	super(container);
  	this.klass = klass;
  	}

  public void mouseDown(MouseEvent event, int x, int y) {
	BBWComponent comp = container.getComponentAt(x,y);
	if (comp == null)
		return;
	BBWContainer theContainer = comp.getOpenContainer();
	Shape shape;
	try {
		shape = (Shape) klass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown Shape class: "+getName());
		}
	Constraint.pushReason(Constraint.MOVE); // So it's the same as user-construction time
	shape.init(theContainer,x,y);
	Constraint.popReason();
	if (container instanceof ContainerShape) // BUT this is a bit if a hack, really!!!!!
		((ContainerShape)container).addUserShape(shape);
 	mouseHandle = shape.getCornerHandle();
	Constraint.pushReason(Constraint.RESIZE);
	mouseOffsetX = 0;
	mouseOffsetY = 0;
//	dragBounds = theContainer.getBounds();
	}

  public String getName() {
	return klass.getName();
	}
  
  protected Class klass;
  }
