package bbw;

/**
 * A HorizontalConstraint constrains two handle to have the same Y value
 * (possibly with an offset).
 * 	constraint from.y == to.y + offset;
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class HorizontalConstraint extends DualConstraint {
	// constraint to.y == from.y + offset;
  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	fromYChanged();
  	}
  
  public void init(Handle from, Handle to, int offset) {
  	this.offset = offset;
  	init(from,to);
  	}
  
  protected void fromXChanged() {
	}
	
  protected void fromYChanged() {
  	to.setY(from.getY()+offset);
	}
	
  protected void toXChanged() {
	}

  protected void toYChanged() {
  	from.setY(to.getY()-offset);
	}
  
  protected int offset = 0;
  }
