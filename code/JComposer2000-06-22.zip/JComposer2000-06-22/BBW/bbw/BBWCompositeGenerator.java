package bbw;

import java.util.*;
import java.io.*;

public class BBWCompositeGenerator {
  public BBWCompositeGenerator(ContainerShape top) {
	this.top = top;
	}

  public void generateNewShape(PrintStream out, RectangularShape outerRectangle) {
	userShapes = top.getUserShapes();
	userConstraints = top.getUserConstraints();

	out.println("import java.awt.*;");
	out.println("import java.util.Vector;");
	out.println();
	out.println("public class NewShape extends RectangularShape implements PropertyChangeListener{");

	out.println("  public void init(BBWContainer container, int x, int y) {");
	out.println("    super.init(container,x,y);");
	for (Enumeration en = userShapes.elements(); en.hasMoreElements(); ) {
		BBWComponent shape = (BBWComponent)en.nextElement();
		out.println("    "+shape.getName()+".init(container,"+shape.getX()+","+shape.getY()+");");
		}
	for (Enumeration en = userConstraints.elements(); en.hasMoreElements(); ) {
		Constraint constraint = (Constraint) en.nextElement();
		if (constraint instanceof DualConstraint) {
			DualConstraint dual = (DualConstraint)constraint;
			out.println("    "+dual.getName()+".init("+dual.getFromHandleName()+","+
				dual.getToHandleName()+");");
			}
		else if (constraint instanceof MonoConstraint) {
			MonoConstraint mono = (MonoConstraint)constraint;
			out.println("    "+mono.getName()+".init("+mono.getFromHandleName()+","+
				mono.getX()+","+mono.getY()+");");
			}
		}
	out.println("    }");
	out.println();
	
	out.println("  public void dispose() {");
	for (Enumeration en = userConstraints.elements(); en.hasMoreElements(); ) {
		Constraint constraint = (Constraint) en.nextElement();
		out.println("    "+constraint.getName()+".dispose();");
		}
	for (Enumeration en = userShapes.elements(); en.hasMoreElements(); ) {
		BBWComponent shape = (BBWComponent)en.nextElement();
		out.println("    "+shape.getName()+".dispose();");
		}
	out.println("    super.dispose();");
	out.println("    }");
	out.println();
	
	out.println("  protected RectangularShape "+outerRectangle.getName()+" = this;");
	for (Enumeration en = userShapes.elements(); en.hasMoreElements(); ) {
		BBWComponent shape = (BBWComponent)en.nextElement();
		String klass = shape.getClass().getName();
		out.println("  protected "+klass+" "+shape.getName()+" = new "+klass+"();");
		}
	for (Enumeration en = userConstraints.elements(); en.hasMoreElements(); ) {
		Constraint constraint = (Constraint) en.nextElement();
		String klass = constraint.getClass().getName();
		out.println("  protected "+klass+" "+constraint.getName()+" = new "+klass+"();");
		}
	out.println("  }");
	}
  protected ContainerShape top;
  protected Vector userShapes, userConstraints;
  }
