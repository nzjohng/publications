package bbw;

/**
 * Constrains the X value of the two handles to be the same (possibly offset).
 *	 constraint to.x == from.x + offset;
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class VerticalConstraint extends DualConstraint {
  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	fromXChanged();
  	}
 
  public void init(Handle from, Handle to, int offset) {
  	this.offset = offset;
  	init(from,to);
  	}
  
  protected void fromXChanged() {
  	to.setX(from.getX()+offset);
	}
	
  protected void fromYChanged() {
	}
	
  protected void toXChanged() {
  	from.setX(to.getX()-offset);
	}
  
  protected void toYChanged() {
	}
  
  protected int offset = 0;
  }
