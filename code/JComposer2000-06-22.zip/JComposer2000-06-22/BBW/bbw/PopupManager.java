package bbw;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**
 * A PopupManager object is associated with each BBWComponent
 * (its owner) that has a popup menu. It manages the use of a
 * standard popup as well as allowing for the addition
 * of MenuItems to a popup that is then specialised to the owner.
 *
 * @version 	0.8, May 1997
 * @author 	Rick Mugridge
 */

public class PopupManager {

	/**
	 * Create a PopupManager for the BBWComponent owner.
	 */
  public PopupManager(BBWComponent owner) {
	this.owner = owner;
	}

	/**
	 * Define the MenuItems in the standard popup menu.
	 * Changing this doesn't affect PopupManagers
	 * that have already been specialised!
	 * 
	 */
  public static void defineMenuItemsOfStandardPopup(Panel panel, PopupController[] controllers) {
	/* if (standardPopupMenu != null)
	{
System.out.println("trying to remove old standard pop-up...");
		panel.remove(standardPopupMenu); // But don't alter specialised ones.
	} */
	standardPopupMenu = new PopupMenu();
	addControllers(standardPopupMenu,controllers);
	panel.add(standardPopupMenu);
	standardControllers = new PopupController[controllers.length];
	for (int i = 0; i < controllers.length; i++)
		standardControllers[i] = controllers[i];
	}

	/**
	 * Add an extra MenuItem to the popup menu for this component.
	 * It's up to the caller to handle the events coming from the
	 * MenuItem and to associate the specific BBWComponent with the
	 * handler.
	 */
  public void addPopupMenuItem(MenuItem item) {
	if (popupMenu == null) {
		popupMenu = new PopupMenu();
		if (standardControllers != null)
			addControllers(popupMenu,standardControllers);
		owner.getPanel().add(popupMenu);
		}
	popupMenu.add(item);
	}

	/**
	 * Add an array of PopupControllers to the PopupMenu.  A PopupController
	 * specifies the menuItem and processes the menuItem selection
	 * with respect to a specific BBWComponent.
	 */
  protected static void addControllers(PopupMenu menu, PopupController[] controllers) {
	for (int i = 0; i < controllers.length; i++) {
		MenuItem item = controllers[i].getMenuItem();
		menu.add(item);
		item.addActionListener(new ActionAdaptor(controllers[i]));
		}
	}

	/**
	 * Handle the popup menu (using the standard one unless
	 * extra menu items have been added).
	 */
  public void processPopup(int x, int y) {
	poppingComponent = owner;
	if (popupMenu != null)
		popupMenu.show(owner.getPanel(),x,y);
	else // Use standard one
		standardPopupMenu.show(owner.getPanel(),x,y);
	}

	/**
	 * Dispose of the PopupManager when the owner is disposed of.
	 * (YET to be hooked up).
	 */
  public void dispose() {
	if (popupMenu != null)
		owner.getPanel().remove(popupMenu);
	// LATER: get rid of ActionAdaptors on it too!
	}

	/**
	 * The BBWComponent that owns this PopupManager (one-for-one).
	 */
  protected BBWComponent owner;

	/**
	 * The PopupMenu that is used for this BBWComponent as it has
	 * extra MenuItems.
	 */
  protected PopupMenu popupMenu = null;

	/**
	 * The standard PopupMenu, used for any BBWComponent that has no
	 * extra MenuItems.
	 */
  protected static PopupMenu standardPopupMenu = null;

	/**
	 * A copy of the current standard controllers, used to initialise
	 * a PopupManager with extended PopupMenu.
	 */
  protected static PopupController[] standardControllers = null;

	/**
	 * This "global" is needed by the ActionAdaptors that are
	 * part of the standardPopupMenu, because they aren't attached
	 * to any particular BBWComponent.
	 */
  static BBWComponent poppingComponent = null;
  }

/**
 * An ActionAdaptor is called when a MenuItem is selected from
 * a PopupMenu.  Because the standardPopupMenu is independent
 * of BBWComponents, we need to determine which particular BBWComponent
 * was involved - this is handled through the "global" static poppingComponent.
 *
 * @version 	0.8, May 1997
 * @author 	Rick Mugridge
 */

  class ActionAdaptor implements ActionListener {
	public ActionAdaptor(PopupController controller) {
		this.controller = controller;
		}
	public void actionPerformed(ActionEvent e) {
		controller.popupSelected(PopupManager.poppingComponent);
		}
	PopupController controller;
	}


