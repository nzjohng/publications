package bbw;

import java.util.*;
import java.awt.*;
import java.beans.*;

/**
 * A MonoConstraint is a constraint on a single handle (such as
 * a relative pin constraint).  It places itself as a disposeListener
 * on the owner of the handle so as to dispose itself if the handle disappears.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class MonoConstraint extends Constraint {
  public void init(Handle from, int x, int y) {
  	this.from = from;
  	from.addPropertyChangeListener(this);
  	from.getOwner().addDisposeListener(this);
  	}

  public void dispose() {
  	from.removePropertyChangeListener(this);
  	from.getOwner().removeDisposeListener(this);
  	}

  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
	firing = true;
	// pushReason(RESIZE);
  	if (evt.getSource() == from) {
  		if (evt.getPropertyName().equals("x"))
  			fromXChanged();
  		else if (evt.getPropertyName().equals("y"))
  			fromYChanged();
  		}
  	else
  		miscChanged(evt.getSource(),evt.getPropertyName());
	// popReason();
  	firing = false;
  	}

  public Panel getTopPanel() {
  	return from.getTopPanel();
  	}
  
  public DrawingPanel getPanel() {
  	return from.getPanel();
  	}

  public String getFromHandleName() {
  	return from.getName();
  	}

  public String toString() {
  	return name+"["+from.getName()+"]";
  	}

  public abstract int getX();
  public abstract int getY();
  	
  protected void fromXChanged() {
  	} // In case it's not needed
  protected void fromYChanged() {
  	} // In case it's not needed
  protected void miscChanged(Object source, String property) {
  	} // In case there are others being listened to
  
  protected Handle from;
  }
