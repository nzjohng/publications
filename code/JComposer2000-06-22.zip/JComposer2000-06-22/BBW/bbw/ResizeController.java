package bbw;

/**
 * Specialise ReshapeController to use a RESIZE reason.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ResizeController extends ReshapeController {

  public ResizeController(BBWContainer container) {
  	super(container);
  	}

  public int getReason() {
	return Constraint.RESIZE;
	}

  public String getName() {
	return "Resize Pointer";
	}
  }
  
