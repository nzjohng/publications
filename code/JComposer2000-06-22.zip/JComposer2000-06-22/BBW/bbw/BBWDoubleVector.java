package bbw;

import java.awt.*;

public class BBWDoubleVector implements Cloneable {
  public BBWDoubleVector(double x, double y) {
  	this.x = x;
  	this.y = y;
  	}
  	
  public Object clone() {
  	return new BBWDoubleVector(x,y);
  	}
  	
  public BBWDoubleVector negate() {
  	return new BBWDoubleVector(-x,-y);
  	}
  
  public boolean equals(Object other) {
  	if (other instanceof BBWDoubleVector)
  		return x == ((BBWDoubleVector)other).x && y == ((BBWDoubleVector)other).y;
  	return false;
  	}
  	
  public String toString() {
  	return "("+x+","+y+")";
  	}
  
  public double x,y;
  }