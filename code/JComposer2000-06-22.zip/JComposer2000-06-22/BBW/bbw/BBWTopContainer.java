package bbw;

import java.awt.*;
import java.util.Vector;

	/**
	 * The top-level BBWContainer that is plugged into a DrawingPanel. 
	 * This provides access to the Panel for java.awt.Component's, etc.
	 *
	 * @version 	0.8, Apr97
	 * @author 	Rick Mugridge
	 */
public class BBWTopContainer extends BBWContainer {

	/**
	 * Don't instantiate it properly as a RectangularShape, because
	 * it is a munted version,in that it doesn't act as a full RectangularShape.
	 * Eg it ignores its x,y,width,height.
	 (It also doesn't show its handles nor process them in any way.)
	 */
  public BBWTopContainer(DrawingPanel panel) {
  	this.panel = panel;
  	}
  	
	/**
	 *  Any point inside the panel is inside the top container.
	 * (I assume no clicks outside will be passed into here.)
	 */
   public boolean contains(int x, int y) {
  	return true;
  	}

    /**
     * Get all the handles: which is none in this special case.
     */
  public AbstractHandle[] getHandles() {
  	Handle[] handles = { };
  	return handles;
  	}

	/**
	 *  Allow for java.awt.Component changes to validate the panel
	 * in which they are elements, to force redrawing, etc.
	 */
  public void validate() {
//  	panel.invalidate();
//  	panel.getParent().validate();
  	panel.validate();
  	}
  	
	/**
	 *  Extend the repaint area for rerendering.
	 * (LATER: change this to either use builtin repaint() or to
	 * do double-buffering.)
	 */
 public void addRepaintArea(Rectangle r) {
  	panel.addRepaintArea(r);
  	}
  	
	/**
	 *  Extend the repaint area for rerendering.
	 */
  public void repaint(Rectangle r) {
  	addRepaintArea(r);
  	}
  	
	/**
	 * Get the DrawingPanel in which this top-level container sits.
	 */
  public DrawingPanel getPanel() {
  	return panel;
  	}
  
	/**
	 * The bounds is simply the size of the DrawingPanel.
	 */
  public Rectangle getBounds() { 
  	return new Rectangle(0,0,getSize().width,getSize().height); 
  	}

	/**
	 * It's always located at (0,0).
	 */
  public Point getLocation() { 
  	return new Point(0,0); 
  	}

    /**
     * Get the width according to the DrawingPanel.
     */
  public int getWidth() {
  	return  panel.getSize().width;
  	}
  	
    /**
     * Don't change the width.
     */
  public void setWidth(int width) {
	throw new RuntimeException("Cannot change the size of the top-level container");
  	}
  	
    /**
     * Get the height according to the DrawingPanel.
     */
  public int getHeight() {
  	return  panel.getSize().height;
  	}
  	
    /**
     * Don't change the height.
     */
  public void setHeight(int height) {
	throw new RuntimeException("Cannot change the size of the top-level container");
  	}
  	
	/**
	 * It's the same size as the DrawingPanel.  Ignore instance variables
	 * width and height - they're irrelevant here.
	 */
  public Dimension getSize() { 
  	return panel.getSize(); 
  	}

    /**
     * Get origin.x - it's always 0 for the top-level container.
     */
  public int getX() {
  	return 0;
  	}
  	
    /**
     * Don't set origin.x.
     */
  public void setX(int x) {
  	throw new RuntimeException("Can't move the top-level container");
  	}
  	
    /**
     * Get origin.y.
     */
  public int getY() {
  	return 0;
  	}
  	
    /**
     * Don't set origin.y.
     */
  public void setY(int y) {
  	throw new RuntimeException("Can't move the top-level container");
  	}
  	
	/**
	 * Return this as the top-level container.
	 */
  public BBWTopContainer getTopContainer() {
  	return this;
  	}
  	
    /**
     * Paint according to the Panel size.
     * (LATER: it doesn't show its handles (it may need to pretend it doesn't have any!!)).  
     */
  public void paint(Graphics g) {
	if (getFillColor() != Color.white) {
		g.setColor(getFillColor());
		g.fillRect(0, 0,getSize().width,getSize().height);
		}
	for (int i = 0 ; i < ncomponents ; i++) {
		BBWComponent comp = component[i];
		if (comp != null)
			comp.update(g);
		}
	}

	/**
	 * The DrawingPanel which holds the top-level container.
	 */
  protected DrawingPanel panel;
  }
