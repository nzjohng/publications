package bbw;

import java.awt.*;
import java.util.*;
import java.io.*;

/**
 * A ContainerShape provides an (abstract) visible form for container that the user may create things inside.
 * It's extended to define: (i) a rendering of the container; (ii) layout control.
 * We may later allow BBWComponents to be dragged into such containers.
 *
 * @version 	0.8, Apr1997
 * @author 	Rick Mugridge
 */
public abstract class ContainerShape extends BBWContainer {

	/**
	 * Initialise the ContainerShape with inside handles, suitable for wiring to.
	 */
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
	insideTopLeftHandle = new Handle(this,name+".getInsideTopLeftHandle()");
	coc1.init(originHandle,insideTopLeftHandle, new BBWVector(OFFSET,OFFSET));
	insideTopRightHandle = new Handle(this,name+".getInsideTopRightHandle()");
	coc2.init(topRightHandle,insideTopRightHandle, new BBWVector(-OFFSET,OFFSET));
	insideBottomLeftHandle = new Handle(this,name+".getInsideBottomLeftHandle()");
	coc3.init(bottomLeftHandle,insideBottomLeftHandle, new BBWVector(OFFSET,-OFFSET));
	insideBottomRightHandle = new Handle(this,name+".getInsideBottomRightHandle()");
	coc4.init(cornerHandle,insideBottomRightHandle, new BBWVector(-OFFSET,-OFFSET));
  	}

	/**
	 * Dispose of the ContainerShape and its handles.
	 */
  public void dispose() {
  	super.dispose();
  	insideTopLeftHandle.dispose();
  	insideTopRightHandle.dispose();
  	insideBottomLeftHandle.dispose();
  	insideBottomRightHandle.dispose();
  	coc1.dispose();
  	coc2.dispose();
  	coc3.dispose();
  	coc4.dispose();
  	}
  	
	/**
	 * Get this handle.
	 */
  public Handle getInsideTopLeftHandle() {
  	return insideTopLeftHandle;
  	}
  
	/**
	 * Get this handle.
	 */
  public Handle getInsideTopRightHandle() {
  	return insideTopRightHandle;
  	}
  
	/**
	 * Get this handle.
	 */
  public Handle getInsideBottomLeftHandle() {
  	return insideBottomLeftHandle;
  	}
  
	/**
	 * Get this handle.
	 */
  public Handle getInsideBottomRightHandle() {
  	return insideBottomRightHandle;
  	}
  
	/**
	 * Get all the handles, including those defined by superclasses.
	 */
  public AbstractHandle[] getHandles() {
  	Handle[] extras = { insideTopLeftHandle,insideTopRightHandle,insideBottomLeftHandle,insideBottomRightHandle};
  	return addHandles(super.getHandles(),extras);
  	}
  
	/**
	 * Record a shape that's been added by the user.
	 * This is used during composite construction.
	 */
  public void addUserShape(Shape shape) {
  	userShapes.addElement(shape);
	}
	
	/**
	 * Get all the shapes that've been added by the user.
	 */
  public Vector getUserShapes() {
  	return userShapes;
	}
	
	/**
	 * Record a constraint that's been added by the user.
	 * This is used during composite construction.
	 */
  public void addUserConstraint(Constraint constraint) {
  	userConstraints.addElement(constraint);
	}
	
	/**
	 * Get all the constraints that've been added by the user.
	 */
  public Vector getUserConstraints() {
  	return userConstraints;
	}
	
	  /**
	 * Print the elements of the container that have been added by the user:
	 * BBWComponents and Constraints.
	 */
  public void printUserElements(PrintStream out) {
	out.println("User Elements in Container:");
	for (Enumeration en = userShapes.elements(); en.hasMoreElements(); )
		((BBWComponent)en.nextElement()).printUserElements(out);
	for (Enumeration en = userConstraints.elements(); en.hasMoreElements(); )
		out.println(en.nextElement());
	out.println("End User Elements in Container:");
	}	
  
	/** 
	 * All the shapes that have been added by the user.  Used in composite construction.
	 */
    Vector userShapes = new Vector();

	/** 
	 * All the constraints that have been added by the user.  Used in composite construction.
	 */
    Vector userConstraints = new Vector();

	/**
	 * The inside handles.
	 */
  protected Handle insideTopLeftHandle, insideTopRightHandle, insideBottomLeftHandle, insideBottomRightHandle;

	/**
	 * Constraints for positioning the inside handles.
	 */
  protected EqualityConstraint coc1 = new EqualityConstraint();
  protected EqualityConstraint coc2 = new EqualityConstraint();
  protected EqualityConstraint coc3 = new EqualityConstraint();
  protected EqualityConstraint coc4 = new EqualityConstraint();
  protected static int OFFSET = 5;
  }
