package bbw;

/**
 * The MoveController specialises the ReshapeController to use a MOVE reason.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class MoveController extends ReshapeController {

  public MoveController(BBWContainer container) {
  	super(container);
  	}

  public int getReason() {
	return Constraint.MOVE;
	}

  public String getName() {
	return "Move Pointer";
	}
  }
