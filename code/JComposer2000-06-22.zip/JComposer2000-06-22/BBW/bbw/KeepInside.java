package bbw;

import java.awt.*;
import java.util.Vector;

/**
 * KeepInside is a BBWLayoutManager that keeps an element "inside" its container.
 * (LATER: containers should clip so elements really do have to stay inside
 * to be seen.)
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class KeepInside implements BBWLayoutManager {

  public KeepInside(BBWContainer container) {
  	this.container = container;
  	}
  
  public void addLayoutComponent(String name, BBWComponent comp) {
	DependentConstraint dc = new DependentConstraint();
	dc.init(container.getOriginHandle(),comp.getOriginHandle());
	constraints.addElement(new ElementConstraintMap(comp,dc));
	}

    public void removeLayoutComponent(BBWComponent comp) {
    	}

     public Dimension preferredLayoutSize(BBWContainer parent) {
     	return new Dimension(10,10);
     	}

     public Dimension minimumLayoutSize(BBWContainer parent) {
     	return new Dimension(10,10);
    	}

     public void dispose(BBWContainer parent) {
    }
    
    protected BBWContainer container;
    protected Vector constraints = new Vector();
}

class ElementConstraintMap {
	public ElementConstraintMap(BBWComponent shape, Constraint constraint) {
		this.shape = shape;
		this.constraint = constraint;
		}
		
	public BBWComponent shape;
	public Constraint constraint;
  }