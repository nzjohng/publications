package bbw;

import bbw.constraint.*;
import java.awt.event.*;

/**
 * A ConnectorController handles a drag from one handle to another.  
 * If the connection is successful, it creates the specified Shape
 * and then creates a Connector to glue things together and deal with
 * disposals.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ConnectorController extends PinController {
  public ConnectorController(Class klass, BBWContainer container) {
  	super(klass,container);
  	}

	/**
 	* If mouseUp occurs over a handle, build the connector.
 	*/
  public void mouseUp(MouseEvent event, int x, int y) {
	if (mouseHandle == null)
		return;
	Constraint.popReason();
	arc.dispose();
	Handle to = container.getHandleAt(x,y);
	if (to != null && to.isGlueEnabled())
		buildConnector(to);
	else {
		// It's not a pin, so try a shape with a middle handle
		BBWComponent comp = container.getComponentAt(x,y);
		if (comp instanceof Shape) {
			Shape shape = (Shape)comp;
			to = shape.getMiddleHandle();
			if (to.isGlueEnabled())
				buildConnector(to);
			}
		}
	}
	
	/**
 	* Create the new shape, glue it to the two handles,
 	* and allow for disposal of the owner of either handle.
 	*/
  protected void buildConnector(Handle to) {
	Shape shape;
	try {
		shape = (Shape) klass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown Shape class: "+getName());
		}
	new Connector(shape, from, to, from.getOwner().getParent().getOpenContainer());
	}
  }