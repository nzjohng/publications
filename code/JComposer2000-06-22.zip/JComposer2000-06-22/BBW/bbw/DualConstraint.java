package bbw;

import java.awt.*;
import java.util.*;
import java.beans.*;

/**
 * A DualConstraint is a constraint between two handles (from,to).  It manages
 * basic propagation by mapping property changes to specific method calls to be
 * provides by subclasses.  It adds disposeListeners on the two handle's owners
 * to allow subclasses to recover (eg an arc is disposed of if either end disappears).
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class DualConstraint extends Constraint {

  public void init(Handle from, Handle to) {
  	this.from = from;
  	this.to = to;
  	from.addPropertyChangeListener(this);
  	to.addPropertyChangeListener(this);
  	from.getOwner().addDisposeListener(this);
  	to.getOwner().addDisposeListener(this);
  	// from.getParent().addConstraint(this);
  	}

 public void dispose() {
  	from.removePropertyChangeListener(this);
  	to.removePropertyChangeListener(this);
  	from.getOwner().removeDisposeListener(this);
  	to.getOwner().removeDisposeListener(this);
 	}
  	
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
	firing = true;
  	if (evt.getSource() == from) {
  		if (evt.getPropertyName().equals("x"))
  			fromXChanged();
  		else if (evt.getPropertyName().equals("y"))
  			fromYChanged();
  		}
  	else if (evt.getSource() == to) {
  		if (evt.getPropertyName().equals("x"))
  			toXChanged();
  		else if (evt.getPropertyName().equals("y"))
  			toYChanged();
  		}
  	else
  		miscChanged(evt.getSource(),evt.getPropertyName());
  	firing = false;
  	}

  public Panel getTopPanel() {
  	return from.getOwner().getTopPanel();
  	}
  
  public DrawingPanel getPanel() {
  	return from.getPanel();
  	}

  public String getFromHandleName() {
  	return from.getName();
  	}

  public String getToHandleName() {
  	return to.getName();
  	}

  public String toString() {
  	return name+"[from="+from.getName()+",to="+to.getName()+"]";
  	}

  protected void miscChanged(Object source, String property) {
  	} // In case others are being listened to
  
  abstract protected void fromXChanged();
  abstract protected void fromYChanged();
  abstract protected void toXChanged();
  abstract protected void toYChanged();
  
  protected Handle from, to;
  }
