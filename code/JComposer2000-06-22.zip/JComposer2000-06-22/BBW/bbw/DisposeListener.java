package bbw;

public interface DisposeListener extends java.util.EventListener {
  public abstract void disposePerformed(DisposeEvent evt);
  }
