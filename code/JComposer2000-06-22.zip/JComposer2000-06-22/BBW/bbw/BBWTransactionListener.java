package bbw;

/**
 * A BBWTransactionListener identifies a listener for BBW Transactions
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public interface BBWTransactionListener extends java.util.EventListener {
  public abstract void transaction(BBWTransactionEvent evt);
  }
