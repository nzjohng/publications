package bbw;

import java.awt.*;
import java.util.*;

/**
 * A DependentConstraint between "from" and "to" handles ensures that "to" follows
 * "from" around, but "to" may be moved to a different position relative
 * to "from" (represented by offsetX,offsetY). This is handy for children under
 * parents in a hierarchy, as welll as keeping elements "inside" containers.
 * 		constraint offset == to - from;
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class DependentConstraint extends DualConstraint {

  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	toXChanged();
  	toYChanged();
 	}
  
  public int getOffsetX() {
  	return offsetX;
  	}
  
  public void setOffsetX(int offsetX) {
  	Integer oldOffset = new Integer(this.offsetX);
  	this.offsetX = offsetX;
	firePropertyChange("offsetX", oldOffset, new Integer(offsetX));
  	}
  
  public int getOffsetY() {
  	return offsetY;
  	}
  
  public void setOffsetY(int offsetY) {
  	Integer oldOffset = new Integer(this.offsetY);
  	this.offsetY = offsetY;
	firePropertyChange("offsetX", oldOffset, new Integer(offsetY));
  	}
  
  protected void fromXChanged() {
	pushReason(MOVE);
  	to.setX(from.getX() + offsetX);
  	popReason();
  	}

  protected void fromYChanged() {
	pushReason(MOVE);
  	to.setY(from.getY() + offsetY);
  	popReason();
  	}

  protected void toXChanged() {
	pushReason(MOVE);
	setOffsetX(to.getX() - from.getX());
  	popReason();
	}
  			
  protected void toYChanged() {
	pushReason(MOVE);
	setOffsetY(to.getY() - from.getY());
  	popReason();
	}
  			
  protected int offsetX = 0;
  protected int offsetY = 0;
  }
