package bbw;

import java.awt.*;
import java.beans.*;

/**
 * Constraint the cornerHandle so that it is offset by (width,height) from the origin.
 * 	constraint corner == origin + size with_reason(move);
 *	 constraint size == corner - origin with_reason(resize);
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
*/
public class CornerHandleConstraint extends Constraint {

  public CornerHandleConstraint(Shape shape, Handle origin, Handle corner) {
  	this.shape = shape;
  	this.origin = origin;
  	this.corner = corner;
  	corner.setX(origin.getX() + shape.getWidth());
  	corner.setY(origin.getY() + shape.getHeight());
  	shape.addPropertyChangeListener(this);
  	origin.addPropertyChangeListener(this);
  	corner.addPropertyChangeListener(this);
  	}
  
	/**
	 * Remove this as listeners, to allow it to be GC'd.
	 */
  public void dispose() {
  	shape.removePropertyChangeListener(this);
  	origin.removePropertyChangeListener(this);
  	corner.removePropertyChangeListener(this);
  	}
  	
	/**
	 * Propagate the change, according to the constraint.
	 */
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
  	firing = true;
  	String property = evt.getPropertyName();
  	Object source = evt.getSource();
  	switch (reason) {
  		case MOVE:
		  	if (source == corner) {
		  		if (property.equals("x"))
		  			origin.setX(corner.getX() - shape.getWidth());
		  		else if (property.equals("y"))
		  			origin.setY(corner.getY() - shape.getHeight());
		  		}
		  	else if (source == origin) {
		  		if (property.equals("x"))
		  			corner.setX(origin.getX() + shape.getWidth());
		  		else if (property.equals("y"))
		  			corner.setY(origin.getY() + shape.getHeight());
		  		}
		  	else { // if (source == shape) {
		  		if (property.equals("width"))
		  			corner.setX(origin.getX() + shape.getWidth());
		  		else if (property.equals("height"))
		  			corner.setY(origin.getY() + shape.getHeight());
		  		}
		  	break;
  		case RESIZE:
		  	if (source == corner || source == origin) {
		  		if (property.equals("x"))
		  			shape.setWidth(corner.getX() - origin.getX());
		  		else if (property.equals("y"))
		  			shape.setHeight(corner.getY() - origin.getY());
		  		}
		  	else { // if (source == shape) {
		  		if (property.equals("width"))
		  			corner.setX(origin.getX() + shape.getWidth());
		  		else if (property.equals("height"))
		  			corner.setY(origin.getY() + shape.getHeight());
		  		}
		  	break;
	  	}
	firing = false;
  	}
  
  protected Shape shape;
  protected Handle origin, corner;
  }
