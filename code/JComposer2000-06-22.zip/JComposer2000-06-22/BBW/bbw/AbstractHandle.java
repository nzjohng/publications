package bbw;

import java.awt.*;
import java.util.*;
import java.io.Serializable;

/**
 * A Handle is used to manipulate shapes and to be visible for certain constraints, such as ProportionalConstraint.
 * It is owned by a Shape (in the case of a RelativePin, this is the owner of the source pin).
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class AbstractHandle extends PropertyChangeSupport2 implements HasName, Serializable{
  
	/**
	 * Create a Handle in the given container with the given owner, given name, and with origin (x,y). 
	 * (The container is just needed to add it to.)
	 * (BUT once a Handle is a subpart of a Shape, the container is no longer needed.)
	 */
  public AbstractHandle(BBWComponent owner, String name, int x, int y) {
	this.owner = owner;
	this.name = name;
	this.x = x;
	this.y = y;
	}
	
  public AbstractHandle(BBWComponent owner, String name) {
	this(owner,name,10,10);
	}
	
  public AbstractHandle(BBWComponent owner, int x, int y) {
	this(owner,"<handle>",x,y);
	}

  protected void repaint() {
  	owner.repaint();
  	}
	
    /**
     * Fire off an event for a property change.
     * Ensure the owning Shape is repaint()-ed if it was a change.
     */
  public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue) {
 	boolean fired = super.firePropertyChange(propertyName,oldValue,newValue);
 	if (fired)
 		repaint();
 	return fired;
 	}

	/**
	 * Remove all Listeners on this handle
	 */
  public void dispose() {
  	removeAllPropertyChangeListeners();
  	}
  
	/**
	 * Get the Panel associated with the owner of the Handle.
	 */
  public DrawingPanel getPanel() {
  	return owner.getPanel();
  	}
  	
  public Panel getTopPanel() {
  	return owner.getTopPanel();
  	}
  
	/**
	 * Get the Shape that owns the Handle.
	 */
  public BBWComponent getOwner() {
  	return owner;
  	}
  	
	/**
	 * Get the name of the Handle.  This usually includes the name of the owning Shape,
	 * to ease code generation for composites.
	 */
  public String getName() {
  	return name;
  	}
  	
	/**
	 *Paint the Handle.
	 */
  public abstract void paint(Graphics g, Color color);
  
	/**
	 * Get the location (mid-point) of the Handle as a BBWPoint.
	 * (Here for historical reasons - Handles used to have a property BBWPoint midPt.
	 * But I needed to separate the two dimensions to be propagated separately - ie 
	 * for when reason changes occur in one dimension.)
	 */
  public BBWPoint getMidPt() {
  	return new BBWPoint(x,y);
  	}

	/**
	 * Get the x dimension of the location.
	 */
  public int getX() {
  	return x;
  	}
  	
	/**
	 * Set the x dimension of the location.
	 */
  public void setX(int x) {
	if (this.x != x) {
		repaint();
		Integer oldX = new Integer(this.x);
		this.x = x;
		firePropertyChange("x", oldX, new Integer(x));
		repaint();
		}
  	}
  	
	/**
	 * Get the y dimension of the location.
	 */
  public int getY() {
  	return y;
  	}

	/**
	 * Set the y dimension of the location.
	 */
  public void setY(int y) {
	if (this.y != y) {
		repaint();
		Integer oldY =  new Integer(this.y);
		this.y = y;
		firePropertyChange("y", oldY, new Integer(y));
		repaint();
		}
  	}
  	
	/**
	 * Return the (x,y) location as a Point.
	 */
  public Point getLocation() {
  	return new Point(x-HALF_SIZE, y-HALF_SIZE);
  	}
  
	/**
	 * Return the (fixed) size.
	 */
  public Dimension getSize() {
  	return new Dimension(SIZE, SIZE);
  	}
  
	/**
	 * Return the (fixed) width.
	 */
  public int getWidth() {
  	return SIZE;
  	}
  
	/**
	 * Return the (fixed) height.
	 */
  public int getHeight() {
  	return SIZE;
  	}
  
	/**
	 * Get the bounds of the Handle.
	 */
  public Rectangle getBounds() {
  	return new Rectangle(x-HALF_SIZE, y-HALF_SIZE, SIZE, SIZE);
  	}

	/**
	 *Is it visible and the point inside it, based on its bounds.
	 */
  public boolean contains(int x, int y) {
	return visible && getBounds().contains(x, y);
	}

	/**
	 * Gets the visible property value.
	 */
 public boolean isVisible() {
  	return visible;
  	}

	/**
	 * Sets the reshapeEnabled property value.
	 */
  public void setVisible(boolean visible) {
  	Boolean old = new Boolean(this.visible);
  	this.visible = visible;
	if (firePropertyChange("visible", old, new Boolean(visible)))
		repaint();
  	}
 	
	/**
	 * Return the Handle as a String.
	 */
  public String toString() {
  	return name+"["+x+","+y+","+visible+"]";
  	}

	/**
	 * The x property - the mid-point location of the Handle.
	 * (BUT check that there are no more listeners picking up "midPt"!!)
	 */
  protected int x;

	/**
	 * The y property - the mid-point location of the Handle.
	 */
  protected int y;

	/**
	 * The owning Shape of the Handle.
	 */
  protected BBWComponent owner;

	/**
	 * The name of the Handle.
	 * (BUT it's awkward with RelativePin, etc handles.)
	 */
  protected String name;

	/**
	 * The handle is visible
	 */
  protected  boolean visible = true;
  
	/**
	 * The built-in size of the handle
	 */
  public static final int SIZE = 6, HALF_SIZE = 3;
}

