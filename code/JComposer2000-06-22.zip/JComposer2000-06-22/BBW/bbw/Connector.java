package bbw;

import bbw.constraint.*;
import java.awt.event.*;

/**
 * A Connector glues the shape to the two handles.  It also handles disposal
 * of either end or the shape itself.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class Connector implements DisposeListener {
  public Connector(Shape shape, Handle from, Handle to, BBWContainer theContainer) {
	this.shape = shape;
	this.from = from;
	this.to = to;
	Constraint.pushReason(Constraint.MOVE); // So it's the same as user-construction time
	if (shape instanceof CompositeConnector )
		((CompositeConnector)shape).init(theContainer,10,10,from,to);
	else
		shape.init(theContainer,10,10);
	Constraint.popReason();
	EqualityResizeConstraint eq1 = new EqualityResizeConstraint();
	eq1.init(from,shape.getOriginHandle());
	EqualityResizeConstraint eq2 = new EqualityResizeConstraint();
	eq2.init(to,shape.getCornerHandle());
  	shape.addDisposeListener(this);
  	from.getOwner().addDisposeListener(this);
  	to.getOwner().addDisposeListener(this);
	}

  public void disposePerformed(DisposeEvent evt) {
	shape.dispose();
  	from.getOwner().removeDisposeListener(this);
  	to.getOwner().removeDisposeListener(this);
	}

  Shape shape;
  Handle from, to;
  }

