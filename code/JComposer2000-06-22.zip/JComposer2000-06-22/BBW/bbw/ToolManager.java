package bbw;

/**
 * This manages the various package names, which would otherwise
 * cause problems when we pass around class names as Strings.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ToolManager {

  public static Class getClass(String name) {
	Class klass;
	try { return Class.forName(name); }
	catch (Exception c) { } // Ignore
	for (int i = 0; i < toolPackageNames.length; i++) {
		try {
			return Class.forName(toolPackageNames[i]+"."+name);
			}
		catch (Exception c) { } // Ignore
		}
	return null;	
  	}
  
  public static void addToolPackageNames(String[] newNames) {
  	String[] names = new String[toolPackageNames.length + newNames.length];
  	for (int i = 0; i < newNames.length; i++)
  		names[i] = newNames[i];
  	for (int i = 0; i < toolPackageNames.length; i++)
  		names[i+newNames.length] = toolPackageNames[i];
  	toolPackageNames = names;
  	}
  	
  protected static String[] toolPackageNames = { "bbw", "bbw.shape", "bbw.constraint" };
  }
