package bbw;

import bbw.shape.LineShape;
import java.awt.*;
import java.awt.event.*;

/**
 * The PinController is an abstraction of Dual- and MonPinControllers.
 * It handles the mouseDown event in common.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class PinController extends HandleController {
  public PinController(Class klass, BBWContainer container) {
  	super(container);
  	this.klass = klass;
  	}

  public void mouseDown(MouseEvent event, int x, int y) {
	mouseHandle = null;
//	dragBounds = container.getBounds(); // ie, not restricted
	from  = container.getHandleAt(x,y);
	// System.out.println("Mouse down on handle "+from); // DEBUG
	if (from != null && from.isGlueEnabled()) {
		arc = getWire(x,y);
		mouseHandle = arc.getCornerHandle();
		Constraint.pushReason(Constraint.RESIZE);
		return;
		}
	// It's not a pin, so try a shape with a middle handle
	BBWComponent comp = container.getComponentAt(x,y);
	if (comp instanceof Shape && !(comp instanceof BBWTopContainer)) {
		Shape shape = (Shape)comp;
		from = shape.getMiddleHandle();
		if (from.isGlueEnabled()) {
			arc = getWire(x,y);
			mouseHandle = arc.getCornerHandle();
			Constraint.pushReason(Constraint.RESIZE);
			}
		}
	}

  protected LineShape getWire(int x, int y) {
	LineShape line = new LineShape();
	line.init(container,x,y);
	line.setForeground(Color.darkGray);
  	line.setHandlesVisible(false);
	return line;
	}

  public String getName() {
	return klass.getName();
	}
  
  protected Class klass;
  protected Handle from = null;
  protected LineShape arc;
}
