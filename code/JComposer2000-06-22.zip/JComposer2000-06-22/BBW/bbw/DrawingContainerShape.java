package bbw;

import java.awt.*;

/**
 * A ContainerShape with a particular rendering  for the container itself.
 */
public class DrawingContainerShape extends ContainerShape {
  	
	/**
	 * Specify the layout.
	 */
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	setLayout(new KeepInside(this));
  	}

	/**
	 * Draw the container and then the contents.
	 */
  public void paint(Graphics g) {
	Rectangle normal = normalised();
	g.setColor(getForeground());
	g.drawRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
//	g.drawRect(normal.x+3, normal.y+3, normal.width - 7, normal.height - 7);
	super.paint(g);
	}
  }