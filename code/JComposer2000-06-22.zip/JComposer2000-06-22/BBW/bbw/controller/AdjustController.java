package bbw.controller;

import java.awt.*;
import java.util.*;
import bbw.*;

public class AdjustController extends ReshapeController {

  public AdjustController(BBWContainer container) {
  	super(container);
  	}

  public int getReason() {
	return Constraint.MOVE_PIN;
	}

  public String getName() {
	return "Move Pin";
	}
  }
