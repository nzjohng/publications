package bbw.controller;

import java.beans.*;
import java.awt.*;
import java.awt.event.*;
import bbw.*;

public class PropSheetController extends ActionController{
  public PropSheetController(BBWContainer container) {
  	super(container);
  	}
  
  public void mouseUp(MouseEvent event, int x, int y) {
	BBWComponent comp = container.getComponentAt(x,y);
	if (comp != null && !(comp instanceof BBWTopContainer))
		comp.showPropertySheet();
	}
  
  public String getName() {
	return "Show Property Sheet";
	}
  }
