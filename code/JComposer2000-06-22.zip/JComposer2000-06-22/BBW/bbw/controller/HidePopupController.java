package bbw.controller;

import java.awt.*;
import bbw.*;

public class HidePopupController implements PopupController{
  
  public MenuItem getMenuItem() {
	return new MenuItem("Hide Handles");
	}

  public void popupSelected(BBWComponent component) {
	component.setHandlesVisible(false);
	}

  }
