package bbw.controller;

import java.awt.*;
import bbw.*;
import java.awt.event.*;

public class TestPopupController implements PopupController{
  
  public MenuItem getMenuItem() {
	return new MenuItem("Test");
	}

  public void popupSelected(BBWComponent component) {
	MenuItem item = new MenuItem("ExtraAction");
	component.addPopupMenuItem(item);
	item.addActionListener(new TestActionAdaptor(component));

	CheckboxMenuItem item2 = new CheckboxMenuItem("ExtraCheckbox");
	component.addPopupMenuItem(item2);
	item2.addItemListener(new TestItemAdaptor(component));
	}

  }

//--------------
class TestActionAdaptor implements ActionListener {
  public TestActionAdaptor(BBWComponent component) {
	this.component = component;
	}
  public void actionPerformed(ActionEvent e) {
	System.out.println("ExtraAction Selected");
	}
  BBWComponent component;
  }

//--------------
class TestItemAdaptor implements ItemListener {
  public TestItemAdaptor(BBWComponent component) {
	this.component = component;
	}
  public void itemStateChanged(ItemEvent e) {
	System.out.println("TestItemAdaptor Selected: "+e.getStateChange());
	}
  BBWComponent component;
  }
