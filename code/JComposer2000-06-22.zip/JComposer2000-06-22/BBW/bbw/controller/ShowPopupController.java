package bbw.controller;

import java.awt.*;
import bbw.*;

public class ShowPopupController implements PopupController{
  
  public MenuItem getMenuItem() {
	return new MenuItem("Show Handles");
	}

  public void popupSelected(BBWComponent component) {
	component.setHandlesVisible(true);
	}

  }
