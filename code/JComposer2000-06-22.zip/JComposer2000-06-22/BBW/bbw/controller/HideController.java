package bbw.controller;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import bbw.*;

public class HideController extends ActionController{
  public HideController(BBWContainer container) {
  	super(container);
  	}
  
  public void mouseUp(MouseEvent event, int x, int y) {
	Handle handle = container.getHandleAt(x,y);
	if (handle != null)
		handle.setVisible(false);
	else {
		BBWComponent shape = container.getComponentAt(x,y);
		if (!shape.isCompositeMember() && !(shape instanceof BBWTopContainer))
			shape.setHandlesVisible(false);
		}
  	}
  	
  public String getName() {
	return "Hide";
	}
  }
