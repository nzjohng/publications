package bbw.controller;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import bbw.*;

public abstract class ActionController implements Controller{
  public ActionController(BBWContainer container) {
  	this.container = container;
  	}
  
  public void mouseDown(MouseEvent event, int x, int y) {
  	}
  	
  public void mouseDrag(MouseEvent event, int x, int y) {
	}
  
  public abstract String getName();
  
  protected BBWContainer container;
  }
