package bbw.controller;

import java.awt.*;
import java.awt.event.*;
import bbw.*;

public class ShowController extends ActionController{
  public ShowController(BBWContainer container) {
  	super(container);
  	}
  
  public void mouseUp(MouseEvent event, int x, int y) {
	BBWComponent shape = container.getComponentAt(x,y);
		if (!shape.isCompositeMember() && !(shape instanceof BBWTopContainer))
			shape.setHandlesVisible(true);
  	}
  	
  public String getName() {
	return "Show";
	}
  }
