package bbw.controller;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import bbw.*;

public class DisposeController extends ActionController{
  public DisposeController(BBWContainer container) {
  	super(container);
  	}
  
  public void mouseUp(MouseEvent event, int x, int y) {
	Handle handle = container.getHandleAt(x,y);
	if (handle != null)
		handle.getOwner().dispose();
	else {
		BBWComponent shape = container.getComponentAt(x,y);
		if (shape != null && !(shape instanceof BBWTopContainer) && !shape.isCompositeMember())
			shape.dispose();
		}
  	}
  	
  public String getName() {
	return "Dispose";
	}
  }
