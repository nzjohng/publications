package bbw.controller;

import java.awt.*;
import bbw.*;

public class DisposePopupController implements PopupController{
  
  public MenuItem getMenuItem() {
	return new MenuItem("Dispose");
	}

  public void popupSelected(BBWComponent component) {
	if (!(component instanceof BBWTopContainer) && !component.isCompositeMember())
		component.dispose();
	}

  }
