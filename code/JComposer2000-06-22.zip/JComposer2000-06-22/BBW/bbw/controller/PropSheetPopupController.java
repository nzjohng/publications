package bbw.controller;

import java.awt.*;
import bbw.*;

public class PropSheetPopupController implements PopupController{
  
  public MenuItem getMenuItem() {
	return new MenuItem("Property Sheet");
	}

  public void popupSelected(BBWComponent component) {
	if (!(component instanceof BBWTopContainer))
		component.showPropertySheet();
	}

  }

