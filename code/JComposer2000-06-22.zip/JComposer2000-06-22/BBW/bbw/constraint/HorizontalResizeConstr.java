package bbw.constraint;

import bbw.*;

public class HorizontalResizeConstr extends HorizontalConstraint {
	// constraint to.y == from.y + offset;

  protected void fromYChanged() {
	pushReason(RESIZE);
  		super.fromYChanged();
	popReason();
	}
	
  protected void toYChanged() {
	pushReason(RESIZE);
  		super.toYChanged();
	popReason();
	}
  }
