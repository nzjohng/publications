package bbw.constraint;

import bbw.*;

public class HorizontalOnResizeConstr extends HorizontalConstraint {
	// constraint to.y == from.y when RESIZE;

  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	if (reason != RESIZE) {
  		pushReason(RESIZE);
  		fromYChanged();
		popReason();
		}
  	}
  
  protected void fromYChanged() {
	if (reason == RESIZE)
  		super.fromYChanged();
	}
	
  protected void toYChanged() {
	if (reason == RESIZE)
  	  	super.toYChanged();
	}
  }
