package bbw.constraint;

import bbw.*;

public class HorizontalMoveConstraint extends HorizontalConstraint {
	// constraint to.origin.y == from.origin.y + offset;

  protected void fromYChanged() {
	pushReason(MOVE);
  		super.fromYChanged();
	popReason();
	}
	
  protected void toYChanged() {
	pushReason(MOVE);
  		super.toYChanged();
	popReason();
	}
  }
