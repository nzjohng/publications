package bbw.constraint;

import bbw.*;

public class VerticalMoveConstraint extends VerticalConstraint {
	// constraint to.x == from.x + offset;

  protected void fromXChanged() {
	pushReason(MOVE);
  		super.fromXChanged();
	popReason();
	}
	
  protected void toXChanged() {
	pushReason(MOVE);
  		super.toXChanged();
	popReason();
	}
  }
