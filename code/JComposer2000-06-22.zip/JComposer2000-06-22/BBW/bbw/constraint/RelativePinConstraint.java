package bbw.constraint;

import bbw.*;

/**
 * A RelativePinConstraint is a constraint that maintains a handle at a position relative to another handle.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class RelativePinConstraint extends MonoConstraint {
	// constraint pin == offset + from with(MOVE_PIN(pin=>offset), from=>pin, pin=>from);
  public void init(Handle from, int x, int y) {
  	super.init(from,x,y);
  	shs.setName("vRelativePinConstraint"+x+y);
  	shs.init(from.getOwner().getParent(),x,y);
  	pin = shs.getOriginHandle();
  	setOffsetX(pin.getX() - from.getX());
  	setOffsetY(pin.getY() - from.getY());
   	pin.addPropertyChangeListener(this);
 	}
  
  public void dispose() {
   	shs.dispose();
 	super.dispose();
  	}
  
  public int getOffsetX() {
  	return offsetX;
  	}
  
  public void setOffsetX(int offsetX) {
  	Integer oldOffset = new Integer(this.offsetX);
  	this.offsetX = offsetX;
	firePropertyChange("offsetX", oldOffset, new Integer(offsetX));
  	}
  
  public int getOffsetY() {
  	return offsetY;
  	}
  
  public void setOffsetY(int offsetY) {
  	Integer oldOffset = new Integer(this.offsetY);
  	this.offsetY = offsetY;
	firePropertyChange("offsetY", oldOffset, new Integer(offsetY));
  	}
    
  public Handle getPin() {
  	return pin;
  	}
  
  public int getX() {
  	return pin.getX();
  	}
  	
  public int getY() {
  	return pin.getY();
  	}
	
  protected void fromXChanged() {
  	pin.setX(from.getX() + offsetX);
  	}

  protected void fromYChanged() {
  	pin.setY(from.getY() + offsetY);
  	}

  protected void miscChanged(Object source, String property) { // pin
  	if (Constraint.reason == MOVE_PIN) {
		Constraint.pushReason(MOVE);
		if (property.equals("x"))
			setOffsetX(pin.getX() - from.getX());
		if (property.equals("y"))
			setOffsetY(pin.getY() - from.getY());
		Constraint.popReason();
		}
	else {
		if (property.equals("x"))
			from.setX(pin.getX() - offsetX);
		if (property.equals("y"))
			from.setY(pin.getY() - offsetY);
		}
	}
  			
  protected SingleHandleShape shs = new SingleHandleShape();
  protected Handle pin;
  protected int offsetX = 0;
  protected int offsetY = 0;
  }
