package bbw.constraint;

import java.awt.*;
import bbw.*;

/**
 * A ProportionalConstraint is connected between two handles.  The pin associated with the constraint
 * is maintained proportionally between those 2 handles (initially at relative poisition 0.5,0.5).
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ProportionalConstraint extends DualConstraint {
	// constraint pin.x == offsetX * (to.x - from.x) + from.x
	// constraint pin.y == offsetY * (to.y - from.y) + from.y
	// When pin changes on RESIZE, to = (from * (offset-1) + pin) / offset
	// When pin changes on MOVE, move from and to by the pinChange of: pin - (from + (to-from)*offset)
  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	shs.setName("vProportionalConstraint"+(count++));
  	shs.init(from.getOwner().getParent(),10,10);
  	pin = shs.getOriginHandle();
  	fromXChanged();
  	fromYChanged();
   	pin.addPropertyChangeListener(this);
 	}
  
  public void dispose() {
  	shs.dispose();
  	super.dispose();
  	}
  
  public Handle getPin() {
  	return pin;
  	}
  
  public double getOffsetX() {
  	return offsetX;
  	}
  
  public void setOffsetX(double offsetX) {
  	Double oldOffset = new Double(this.offsetX);
  	this.offsetX = offsetX;
	firePropertyChange("offsetX", oldOffset, new Double(offsetX));
  	}
  
  public double getOffsetY() {
  	return offsetY;
  	}
  
  public void setOffsetY(double offsetY) {
  	Double oldOffset = new Double(this.offsetY);
  	this.offsetY = offsetY;
	firePropertyChange("offsetX", oldOffset, new Double(offsetY));
  	}
    
  protected void miscChanged(Object source, String property) { // pin
	if (source != pin || !(property.equals("x") || property.equals("y"))) return;
  	if (reason == MOVE_PIN) {
		if (property.equals("x") && to.getX() != from.getX())
			setOffsetX( ((double)(pin.getX() - from.getX())) / (to.getX() - from.getX()));
		if (property.equals("y") && to.getY() != from.getY())
			setOffsetY( ((double)(pin.getY() - from.getY())) / (to.getY() - from.getY()));
		}
	//else if (reason == RESIZE) {// This just confused things
	if (property.equals("x") && offsetX != 0)
		to.setX((int) Math.round((from.getX() * (offsetX-1) + pin.getX()) / offsetX));
	if (property.equals("y") && offsetY != 0)
		to.setY((int) Math.round((from.getY() * (offsetY-1) + pin.getY()) / offsetY));
	/*
		}
	else { // if (reason == MOVE) {
		BBWVector pinChange = new BBWVector((int) Math.round(pin.getX() - (from.getX() + (to.getX()-from.getX())*offset.x)),
											 (int) Math.round(pin.getY() - (from.getY() + (to.getY()-from.getY())*offset.y)));
		from.setMidPt(from.getMidPt().plus(pinChange));
		to.setMidPt(to.getMidPt().plus(pinChange));
		}
	*/
	}

  protected void fromXChanged() {
	pin.setX((int) Math.round(offsetX * (to.getX() - from.getX()) + from.getX()));
  	}

  protected void fromYChanged() {
	pin.setY((int) Math.round(offsetY * (to.getY() - from.getY()) + from.getY()));
  	}

  protected void toXChanged() {
	fromXChanged();
	}
	
  protected void toYChanged() {
	fromYChanged();
	}
	
  public String toString() {
  	return name+"[from="+from.getName()+",to="+to.getName()+",pin="+pin.getName()+"]";
  	}

  protected SingleHandleShape shs = new SingleHandleShape();
  protected Handle pin;
  protected double offsetX = 0.5;
  protected double offsetY = 0.5;
  protected static int count = 0;
  }
