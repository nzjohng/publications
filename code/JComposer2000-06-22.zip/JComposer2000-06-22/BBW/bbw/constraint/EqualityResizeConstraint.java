package bbw.constraint;

import java.awt.*;
import java.util.*;
import bbw.*;

public class EqualityResizeConstraint extends EqualityConstraint {
	// constraint from.origin == to.origin;
  public void init(Handle from, Handle to) {
  	super.init(from,to,new BBWVector(0,0));
  	}

	// constraint  to.origin == from.origin + offset;
  public void init(Handle from, Handle to, BBWVector offset) {
  	super.init(from,to,offset);
  	}
  	
  protected void fromXChanged() {
	pushReason(RESIZE);
		super.fromXChanged();
  	popReason();
	}
	
  protected void fromYChanged() {
	pushReason(RESIZE);
		super.fromYChanged();
  	popReason();
	}
	
  protected void toXChanged() {
	pushReason(RESIZE);
		super.toXChanged();
  	popReason();
	}
  
  protected void toYChanged() {
	pushReason(RESIZE);
		super.toYChanged();
  	popReason();
	}
  
  }
