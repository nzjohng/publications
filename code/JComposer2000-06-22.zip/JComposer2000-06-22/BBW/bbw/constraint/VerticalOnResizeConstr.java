package bbw.constraint;

import bbw.*;

public class VerticalOnResizeConstr extends VerticalConstraint {
	// constraint to.x == from.x + offset;

  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	if (reason != RESIZE) {
  		pushReason(RESIZE);
  		fromXChanged();
		popReason();
		}
  	}
  
  protected void fromXChanged() {
	if (reason == RESIZE)
  	  	super.fromXChanged();
	}
	
  protected void toXChanged() {
	if (reason == RESIZE)
	  	super.toXChanged();
	}
  }
