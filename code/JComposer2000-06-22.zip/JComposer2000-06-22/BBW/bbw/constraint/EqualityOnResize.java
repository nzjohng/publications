package bbw.constraint;

import bbw.*;
import java.awt.*;
import java.util.*;

public class EqualityOnResize extends EqualityConstraint {
	// constraint from == to when (RESIZE);
  public void init(Handle from, Handle to) {
  	super.init(from,to,new BBWVector(0,0));
  	if (reason != RESIZE) {
		pushReason(RESIZE);
		fromXChanged();
		fromYChanged();
		popReason();
		}
  	}

	// constraint  to.origin == from.origin + offset when (RESIZE);
  public void init(Handle from, Handle to, BBWVector offset) {
  	super.init(from,to,offset);
  	}
  
  protected void fromXChanged() {
	if (reason == RESIZE)
		super.fromXChanged();
	}
	
  protected void fromYChanged() {
	if (reason == RESIZE)
		super.fromYChanged();
	}
	
  protected void toXChanged() {
	if (reason == RESIZE)
		super.toXChanged();
	}
  
  protected void toYChanged() {
	if (reason == RESIZE)
		super.toYChanged();
	}
  }
