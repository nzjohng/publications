package bbw.constraint;

import bbw.*;

public class VerticalResizeConstraint extends VerticalConstraint {
	// constraint to.x == from.x + offset;

  protected void fromXChanged() {
	pushReason(RESIZE);
  		super.fromXChanged();
	popReason();
	}
	
  protected void toXChanged() {
	pushReason(RESIZE);
  		super.toXChanged();
	popReason();
	}
  }
