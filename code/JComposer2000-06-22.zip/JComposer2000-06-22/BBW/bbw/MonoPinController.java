package bbw;

import bbw.shape.LineShape;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * A MonoPinController controls the dragging of a monoConstraint from a handle
 * into space.
 * It uses a line to show where the drag occurs, LATER could generate the
 * MonoConstraint directly and drag its rendering instead.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class MonoPinController extends PinController {
  public MonoPinController(Class klass, BBWContainer container) {
  	super(klass,container);
  	}

  public void mouseUp(MouseEvent event, int x, int y) {
	if (mouseHandle == null)
		return;
	Constraint.popReason();
	arc.dispose();
	MonoConstraint constraint;
	try {
		constraint = (MonoConstraint) klass.newInstance();
		}
	catch (Exception c) {
		throw new RuntimeException("Unknown MonoConstraint class: "+getName());
		}
	constraint.init(from,x,y);
	if (container instanceof ContainerShape)
		((ContainerShape)container).addUserConstraint(constraint);
	}
  }
