package bbw;

/**
 * A BBWTransactionEvent is fired for BBW Transactions.
 * This is wrapped around a user action, and is used by JViews.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class BBWTransactionEvent extends java.util.EventObject{
  public BBWTransactionEvent(Object source, boolean beginning) {
  	super(source);
  	this.beginning = beginning;
  	}
  
  public boolean isBeginning() {
  	return beginning;
  	}
  	
  public String toString() {
  	return "BBWTransactionEvent ["+beginning+"]";
  	}

  private boolean beginning;
  }
