package bbw;

import java.awt.*;

/**
 * Ensure that the given handle remains vertically-aligned to one handle and horizontally-aligned to the other.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ConstraintOnHandle extends VerticalConstraint {

	/**
	 * Align handle vertically to xHandle and horizontally to yHandle
	 */
  public ConstraintOnHandle(Handle handle, Handle xHandle, Handle yHandle) {
  	super.init(xHandle,handle);
  	horizontal.init(yHandle,handle);
  	}

	/**
	 * Dispose of the two constraints imposed.
	 */
 public void dispose() {
  	super.dispose();
  	horizontal.dispose();
  	}
  
  protected HorizontalConstraint horizontal = new HorizontalConstraint();
  }
