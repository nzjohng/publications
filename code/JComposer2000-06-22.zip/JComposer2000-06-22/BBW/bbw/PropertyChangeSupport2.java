package bbw;

import java.beans.*;
import java.util.*;

/**
 * A variation of PropertyChangeSupport that does what I want.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class PropertyChangeSupport2 {

  public synchronized void addPropertyChangeListener(
				PropertyChangeListener listener) {
	if (listeners == null)
		listeners = new java.util.Vector();
	listeners.addElement(listener);
	}
	
  public synchronized void removePropertyChangeListener(
				PropertyChangeListener listener) {
	if (listeners == null)
		return;
	listeners.removeElement(listener);
	}
	
  public synchronized void removeAllPropertyChangeListeners() {
	listeners = null;
	}
	
  public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	// This is NOT thread-safe

	if (oldValue != null && oldValue.equals(newValue))
		return false;
	java.beans.PropertyChangeEvent ev = new java.beans.PropertyChangeEvent(this,propertyName,oldValue,newValue);
	if (debugging)
		System.out.println("PropertyChangeEvent("+this+",'"+propertyName+":',"+oldValue+"->"+newValue+"),reason="+Constraint.reason);
	if (listeners != null) {
		Enumeration tell = listeners.elements();
		while (tell.hasMoreElements())
			((PropertyChangeListener) tell.nextElement()).propertyChange(ev);
		}
	return true;
	}
	
  public static void setDebug(boolean debug) {
  	debugging = debug;
  	}
  
  private java.util.Vector listeners;
  protected static boolean debugging = false;
  }