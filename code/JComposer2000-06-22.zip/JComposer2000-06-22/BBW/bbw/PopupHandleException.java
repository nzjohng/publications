package bbw;

public class PopupHandleException extends RuntimeException {
  public PopupHandleException(PopupHandle popup) {
	super("Popup handle selected");
	this.popup = popup;
	}

  public PopupHandle getPopup() {
	return popup;
	}

  private PopupHandle popup;
  }
