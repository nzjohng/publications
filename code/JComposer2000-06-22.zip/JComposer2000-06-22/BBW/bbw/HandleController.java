package bbw;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public abstract class HandleController implements Controller{

  public HandleController(BBWContainer container) {
  	this.container = container;
  	}
  	
  public void mouseDrag(MouseEvent event, int x, int y) {
	if (mouseHandle != null) { //  && getBounds.contains(x,y)) {
		mouseHandle.setX(x-mouseOffsetX);
		mouseHandle.setY(y-mouseOffsetY);
		}
	}

  public void mouseUp(MouseEvent event, int x, int y) {
	if (mouseHandle != null) { // && getBounds.contains(x,y)) {
		mouseHandle.setX(x-mouseOffsetX);
		mouseHandle.setY(y-mouseOffsetY);
		Constraint.popReason();
		}
	mouseHandle = null;
	}

  protected BBWContainer container;
  protected Handle mouseHandle = null;
  protected int mouseOffsetX = 0;
  protected int mouseOffsetY = 0;
//  protected Rectangle dragBounds = null;
  }
