package bbw.shape;

import java.beans.*;
import bbw.*;

/**
 * Daemon to recompute the polygon of the diamond on a change.
 * 	daemon(x,y,width,height) recomputePolygon();
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
class DiamondConstraint extends Constraint {
  public DiamondConstraint(DiamondShape diamond, Handle origin) {
  	this.diamond = diamond;
  	this.origin = origin;
  	diamond.addPropertyChangeListener(this);
  	origin.addPropertyChangeListener(this);
  	diamond.recomputePolygon();
  	}
  
	/**
	 * Remove this as listeners, to allow it to be GC'd.
	 */
  public void dispose() {
  	diamond.removePropertyChangeListener(this);
  	origin.removePropertyChangeListener(this);
  	}
  
	/**
	 * Fire the daemon.
	 */
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
  	String property = evt.getPropertyName();
  	if (evt.getSource() instanceof Handle || property.equals("width") || property.equals("height")) {
  		firing = true;
	  	diamond.recomputePolygon();
	  	firing = false;
	  	}
  	}
  
  protected DiamondShape diamond;
  protected Handle origin;
  }
