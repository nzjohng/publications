package bbw.shape;

import java.awt.*;
import bbw.*;

/**
 * A line with an arrow head. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ArrowShape extends LineShape {

  public void paint(Graphics g) {
	super.paint(g);
	paintArrowHead(g,originHandle.getMidPt(),cornerHandle.getMidPt());
	}

  protected void paintArrowHead(Graphics g, BBWPoint start, BBWPoint finish) {
	// Draws an arrow head with its point on finish and its tail towards start.	
	// An arrow is a 3 sided polygon. Allow for zero-length arc.
	Polygon arrowPoly = new Polygon();
	double basePtX, basePtY;	// The point at the middle of the base of the arrowhead.
	double a, b, lineLength;
	int ArrowLength = 10, ArrowWidth = 5;
	// a,b,c are the coefficients in the equation of the line through the two points start and finish.
	// This equation is ax + by + c = 0. We then use these to get direction vectors for the arc and
	// a perpendicular to the arc. These direction vectors are used to find the other two	points
	// of the arrowhead by first going back along the arc, and then shooting out either side.

	a = finish.y - start.y;
	b = start.x - finish.x;
	if (a == 0 && b == 0)
		return;		// Don't draw an arrow head on a zero-length arc.
	lineLength = Math.sqrt(a * a + b * b);
	a = a / lineLength;	// Normalise a and b to pixel units.
	b = b / lineLength;

	// Go back (ArrowLength) pixels along the arc.
	basePtX = finish.x + b * ArrowLength;
	basePtY = finish.y - a * ArrowLength;

	arrowPoly.addPoint(finish.x, finish.y);
	// And go out (ArrowWidth) pixels from the arc on each side:
		arrowPoly.addPoint((int)Math.round(basePtX + a * ArrowWidth), (int)Math.round(basePtY + b * ArrowWidth));
		arrowPoly.addPoint((int)Math.round(basePtX - a * ArrowWidth), (int)Math.round(basePtY - b * ArrowWidth));
		arrowPoly.addPoint(finish.x, finish.y);
	g.fillPolygon(arrowPoly);
	}
  }
  
