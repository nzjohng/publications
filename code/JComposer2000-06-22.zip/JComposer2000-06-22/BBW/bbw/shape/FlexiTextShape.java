package bbw.shape;

import java.awt.*;
import java.util.Vector;
import bbw.*;

/**
 * A FlexiTextShape is an AbstractTextShape with text that sizes to fit the space available. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class FlexiTextShape extends AbstractTextShape {

	/**
	 * Paint the text, sizing it to take up the space as well as possible.
	 */
  public void paint(Graphics g) {
	super.paint(g);
	Rectangle normal = normalised();
	String name = font.getName();
	FontMetrics fm = getPanel().getFontMetrics(font); // initialisation here was forced by compiler
	int width;
	for (int i = 0; i < sizes.length; i++) {
		Font adjustedFont = new Font(name,font.getStyle(),sizes[i]);
		g.setFont(adjustedFont);
		fm = g.getFontMetrics(adjustedFont);
		width = fm.stringWidth(text);
		if (width <= normal.width && fm.getHeight() <= normal.height) {
			g.drawString(text,(normal.x + (normal.width - width) / 2),
								(normal.y + (normal.height + fm.getHeight())/2)); // + fm.getMaxDescent()));
			return;
			}		
		}
	if (fm.getHeight() <= normal.height)
		for (int i = text.length() - 1; i > 0; i--) {
			String shorter = text.substring(0,i);
			width = fm.stringWidth(shorter);
			if (width <= normal.width) {
				g.drawString(shorter,(normal.x + (normal.width - width) / 2),
									 (normal.y + (normal.height + fm.getHeight())/2)); // + fm.getMaxDescent()));
				return;
				}		
			}
	}
	
	/**
	 * Possible font sizes to use.
	 */
  private static final int sizes[] = {64, 48, 24, 18, 16, 14, 12, 8};
  }
