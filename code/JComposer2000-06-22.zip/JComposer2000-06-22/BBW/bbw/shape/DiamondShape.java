package bbw.shape;

import java.awt.*;
import java.util.Vector;
import bbw.*;

/**
 * A DiamondShape is a RectangularShape drawn as a diamond. 
 * Its state includes the Polygon used to draw it.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class DiamondShape extends RectangularShape {

  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	new DiamondConstraint(this,originHandle);
  	recomputePolygon();
  	}

  public void paint(Graphics g) {
	super.paint(g);
	g.drawPolygon(poly);
	}

/**
 * Is the point inside the diamond?
 * (CHECK - shouldn't check visible as well???)
 */
   public boolean contains(int x, int y) {
  	return visible && poly.contains(x,y);
  	}

  void recomputePolygon() {
	poly = new Polygon(); // Add clockwise from origin:
	poly.addPoint(leftHandle.getX(),leftHandle.getY());
	poly.addPoint(topHandle.getX(),topHandle.getY());
	poly.addPoint(rightHandle.getX(),rightHandle.getY());
	poly.addPoint(bottomHandle.getX(),bottomHandle.getY());
	poly.addPoint(leftHandle.getX(),leftHandle.getY());
	repaint();
  	}
  	
  protected Polygon poly = new Polygon();
  }
