package bbw.shape;

import java.awt.*;
import java.beans.*;
import bbw.*;

/**
 * An AWTShape is used to manage shapes with java.awt.Component's inside them.
 * (LATER: change to make generic to handle any JavaBean in Java1.1.)
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class AWTShape extends RectangularShape {

	/**
	 * Initialise an AWTShape.  Keep track of the added Component, which is also
	 * added to the Panel as an AWT Component.
	 * A constraint is attached to this and  the originHandle to track location and size
	 * changes.
	 * (LATER: Consider picking up such changes from the java.awt.Component itself
	 * to apply to the BBW level?)
	 */
  public void init(BBWContainer container, int x, int y, Component component) {
  	super.init(container,x,y);
  	this.component = component;
  	getPanel().add(component);
  	new AWTConstraint(this, originHandle);
  	}
  	
	/**
	 * Define repaint() to repaint the whole Panel for AWTShapes
	 * due to a bug in Windows95, which doesn't handle moving
	 * java.awt.Components around dynamically.
	 */
  public void repaint() {
  	if (parent != null)
		getPanel().repaint();
  	}
  	
	/**
	 * Carefully dispose.  Need to validate() the Panel because the Component has been
	 * removed from the Panel.  Dispose the AWTShape itself last.
	 */
  public void dispose() {
  	getPanel().remove(component);
  	validate(); // Need to do this before super.dispose(), which nulls parent.
  	super.dispose();
  	}

	/**
	 * Set the visibility of the AWTShape and the Component.
	 * We assume that the visibility of the Component is not altered by
	 * anything else.
	 */
  public void setVisible(boolean visible) {
  	component.setVisible(visible);
  	super.setVisible(visible);
  	}

	/**
	 * Set the enabled-ness of the AWTShape.
	 * We assume that the enabled-ness of the Component is not altered by
	 * anything else.
	 */
  public void setEnabled(boolean enabled) {
  	component.setEnabled(enabled);
  	}

//  public void validate() {
//	component.validate();
//	super.validate();
//  	}
  	
	/**
	 * Reshape the Component according to the current location/size of the AWTShape.
	 * (BUT isn't protected sufficient here?) 
	 */
  protected void reshape() {
  	Rectangle normal = normalised();
  	component.setBounds(normal.x+INSET,normal.y+INSET,normal.width-INSET-INSET,normal.height-INSET-INSET);
  	validate();
  	}

	/**
	 * Wrap AWT changes into a transaction.
	 */
  protected void fireTransactionPropertyChange(String propertyName, Object oldValue, Object newValue) {
	BBWGeneralPanel topPanel = (BBWGeneralPanel)getTopPanel();
	topPanel.fireTransaction(true);
	firePropertyChange(propertyName,oldValue,newValue);
	topPanel.fireTransaction(false);
  	}
  
  protected final static int INSET = 3;

	/**
	 * The java.awt.Component managed by this AWTShape.
	 */
  protected Component component;
  }
  
//----------
class AWTConstraint extends Constraint {
  public AWTConstraint(AWTShape awt, Handle originHandle) {
  	this.awt = awt;
  	this.originHandle = originHandle;
  	awt.addPropertyChangeListener(this);
  	originHandle.addPropertyChangeListener(this);
  	}
  
  public void dispose() {
  	awt.removePropertyChangeListener(this);
  	originHandle.removePropertyChangeListener(this);
  	}
  
  public void propertyChange(PropertyChangeEvent evt) {
  	if (firing) return;
  	String property = evt.getPropertyName();
  	if (evt.getSource() instanceof Handle || property.equals("width") || property.equals("height")) {
  		firing = true;
	  	awt.reshape();
	  	firing = false;
	  	}
  	}
  
  protected AWTShape awt;
  protected Handle originHandle;
  }

