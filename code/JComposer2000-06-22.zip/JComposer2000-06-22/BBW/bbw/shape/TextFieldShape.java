package bbw.shape;

import java.awt.*;
import java.awt.event.*;
import bbw.*;

public class TextFieldShape extends AWTShape implements ActionListener{

  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y,text);
    text.addActionListener(this);
    text.requestFocus();
    }
  
  public void actionPerformed(ActionEvent ae) {
    if (!text.getText().equals(previousText)) {
        firePropertyChange("text", previousText, getText());        
        previousText = getText();
        }
    }
  
  public String getText() {
    return text.getText();
    }
    
  public void setText(String newText) {
    if (!text.getText().equals(newText)) {
        previousText = getText();
        text.setText(newText);
        validate();
        fireTransactionPropertyChange("text", previousText, newText);       
        }
    }
    
  public Font getFont() {
    return text.getFont();
    }
    
  public void setFont(Font newFont) {
    if (getFont() == null || !getFont().equals(newFont)) {
        Font previousFont = getFont();
        text.setFont(newFont);
        validate();
        firePropertyChange("font", previousFont, newFont); 
        repaint();      
        }
    }
    
  protected TextField text = new TextField(10);
  protected String previousText = "";
  }
