package bbw.shape;

import java.awt.*;
import bbw.*;

/**
 * An OvalShape is a simple RectangularShape drawn as an Oval. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class OvalShape extends RectangularShape {

  public void paint(Graphics g) {
	super.paint(g);
	Rectangle r = normalised();
	g.drawOval(r.x, r.y, r.width, r.height);
	}

  }
