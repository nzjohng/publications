package bbw.shape;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import bbw.*;

public class ChoiceShape extends AWTShape implements ItemListener{

  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y,choice);
  	choice.addItemListener(this);
  	}
  	
  public void itemStateChanged(ItemEvent ev) {
  	if (!getSelectedItem().equals(previousSelectedItem)) {
		fireTransactionPropertyChange("selectedItem", previousSelectedItem, getSelectedItem());  		
  		previousSelectedItem = getSelectedItem();
  		}
  	}

  public String getItems() {
  	String items = "";
  	int count = choice.getItemCount();
  	for (int i = 0; i < count; i++) {
  		items += choice.getItem(i);
  		if (i < count-1)
  			items += ",";
  		}
  	return items;
  	}
  	
  public void setItems(String items) {
   	getPanel().remove(choice);
 	choice = new Choice();
  	int index = 0;
  	while (true) {
  		int oldIndex = index;
  		index = items.indexOf(',',oldIndex);
	  	if (index < 0) {
	  		choice.addItem(items.substring(oldIndex));
	  		break;
	  		}
	  	choice.addItem(items.substring(oldIndex,index));
	  	index++; // skip over ","
	  	}
  	getPanel().add(choice);
// 	choice.validate();
	choice.addNotify();
  	reshape();
	}
  	
   public String getSelectedItem() {
  	return choice.getSelectedItem();
  	}
  	
  public void setSelectedItem(String item) {
  	if (!item.equals(previousSelectedItem)) {
  		choice.select(item);
		firePropertyChange("selectedItem", previousSelectedItem, getSelectedItem());  		
  		previousSelectedItem = getSelectedItem();
  		}
  	}
  	
  public void addItem(String item) {
  	choice.addItem(item);
  	validate();
  	}
  	
  protected Choice choice = new Choice();
  protected String previousSelectedItem = "";
  }
  
