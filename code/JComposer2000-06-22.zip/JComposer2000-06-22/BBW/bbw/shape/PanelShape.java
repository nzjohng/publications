package bbw.shape;

import java.awt.*;
import bbw.*;

public class PanelShape extends AWTShape {

  public void init(Panel panel,BBWContainer container, int x, int y) {
  	super.init(container,x,y,panel);
  	Dimension dim = panel.getMinimumSize();
  	setSize(dim.width,dim.height);
  	}
  	
  public void paint(Graphics g) {
	super.paint(g);
	Rectangle normal = normalised();
	g.drawRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
	}

   protected Panel panel;
  }
