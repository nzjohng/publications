package bbw.shape;

import java.awt.*;
import java.util.Vector;
import bbw.*;

/**
 * An AbstractTextShape is a RectangularShape with text inside it (as defined in subclasses). 
 * It has no border, but may be filled.
 *
 * @version     0.8, Apr97
 * @author  Rick Mugridge
 */
public abstract class AbstractTextShape extends RectangularShape {

    /**
     * Initialise it and hide the middle handle, as it obscures the text.
     */
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    font = new Font("Helvetica",0, 10);
    middleHandle.setVisible(false);
    }

  public String getText() {
    return text;
    }
    
  public void setText(String newText) {
    String previousText = text;
    text = newText;
    if (firePropertyChange("text", previousText, newText))      
        repaint();      
    }
    
  public Font getFont() {
    return font;
    }
    
  public void setFont(Font newFont) {
    Font previousFont = font;
    font = newFont;
    if (firePropertyChange("font", previousFont, newFont))
        repaint();      
    }
    
    /**
     * Paint the text, ensuring that it's clipped if necessary, to avoid going beyond the outline.
     */
  public void paint(Graphics g) {
    super.paint(g);
    }
    
    /**
     * Presumably provided to allow it to be overridden??
     * (CHECK - is this needed? Is it effective? Wouldn't update() do as well?)
     */
  protected void paintBackGround(Graphics g) {
    }

    /**
     * Property text - the text displayed.
     */
  protected String text = "";

    /**
     * Property font - the font of the text displayed.
     */
  protected Font font;
  }
