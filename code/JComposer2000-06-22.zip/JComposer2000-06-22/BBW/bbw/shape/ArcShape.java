package bbw.shape;

import java.awt.*;
import java.util.Vector;
import bbw.*;

/**
 * An arc with a start and arc angle, based on Graphics.drawArc(). 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class ArcShape extends RectangularShape {

    /**
     * Paint an arc using Graphics.drawArc().  
     */
  public void paint(Graphics g) {
	super.paint(g);
	Rectangle normal = normalised();
	g.drawArc(normal.x,normal.y,normal.width - 1,normal.height - 1,startAngle,arcAngle);
	}

  public int getStartAngle() {
  	return startAngle;
  	}
  	
  public void setStartAngle(int startAngle) {
	int previousAngle = this.startAngle;
	this.startAngle = startAngle;
	if (firePropertyChange("startAngle",new Integer(previousAngle),new Integer(startAngle)))  		
  		repaint();
  	}
  	
  public int getArcAngle() {
  	return arcAngle;
  	}
  	
  public void setArcAngle(int arcAngle) {
	int previousAngle = this.arcAngle;
	this.arcAngle = arcAngle;
	if (firePropertyChange("arcAngle", new Integer(previousAngle), new Integer(arcAngle)))  		
  		repaint();
  	}
  	
    /**
     * Property startAngle.  See Graphics.drawArc().  
     */
   protected int startAngle = 0;

    /**
     * Property arcAngle.  See Graphics.drawArc().  
     */
   protected int arcAngle = -180;
  }
