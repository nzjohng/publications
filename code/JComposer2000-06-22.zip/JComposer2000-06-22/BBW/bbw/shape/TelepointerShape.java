package bbw.shape;

import java.awt.*;
import bbw.*;

/**
 * A TextShape is an AbstractTextShape with fixed-size text inside it. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class TelepointerShape extends AbstractTextShape {

	/**
	 * Paint the text, ensuring that it's clipped if necessary, to avoid going beyond the outline.
	 */
  public void paint(Graphics g) {
	super.paint(g);
	paintBackGround(g);
	Rectangle normal = normalised();
	FontMetrics fm = g.getFontMetrics(font);
	Graphics clipped = g;
	boolean wasClipped = false;
	int sWidth = fm.stringWidth(text);
	int sHeight = fm.getMaxAscent() + fm.getMaxDescent();
/*	if (sHeight > normal.height || sWidth > normal.width) { // Too big to display it all
		clipped = getPanel().getGraphics();
		clipped.clipRect(normal.x,normal.y,normal.width,normal.height);
		wasClipped = true;
		}
*/
	clipped.setFont(font);
	clipped.drawString(text, (int)(normal.x + (normal.width - sWidth) * alignmentX)+8,
				       (int)(normal.y + (normal.height - sHeight) * alignmentY) + fm.getMaxAscent());
/*	if (wasClipped)
		clipped.dispose();
*/

	// draw cross-hair...

	int sx  = (int)(normal.x + (normal.width - sWidth) * alignmentX);
	int sy = (int)(normal.y + (normal.height - sHeight) * alignmentY) + fm.getMaxAscent();

	clipped.drawLine(sx,sy-4,sx+7,sy-4);
	clipped.drawLine(sx+4,sy,sx+4,sy-7);

	}
  
	/**
	 * Gets the alignmentX property value.
	 */
  public double getAlignmentX() {
  	return alignmentX;
  	}

	/**
	 * Sets the alignmentX property value.
	 */
  public void setAlignmentX(double alignmentX) {
  	Double old = new Double(this.alignmentX);
  	this.alignmentX = alignmentX;
	if (firePropertyChange("alignmentX", old, new Double(alignmentX)))
		repaint();
  	}
  	
	/**
	 * Gets the alignmentY property value.
	 */
  public double getAlignmentY() {
  	return alignmentY;
  	}

	/**
	 * Sets the alignmentY property value.
	 */
  public void setAlignmentY(double alignmentY) {
  	Double old = new Double(this.alignmentY);
  	this.alignmentY = alignmentY;
	if (firePropertyChange("alignmentY", old, new Double(alignmentY)))
		repaint();
  	}
  	
  protected double alignmentX = 0.5;
  protected double alignmentY = 0.5;
  }
