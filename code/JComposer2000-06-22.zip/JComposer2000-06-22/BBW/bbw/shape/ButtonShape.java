package bbw.shape;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import bbw.*;

public class ButtonShape extends AWTShape {

  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y,button);
  	}
  	
  public synchronized void addActionListener(ActionListener listener) {
  	button.addActionListener(listener);
  	}
  	
  public synchronized void removeActionListener(ActionListener listener) {
  	button.removeActionListener(listener);
  	}
  	
  public String getLabel() {
  	return button.getLabel();
  	}
  	
  public void setLabel(String newLabel) {
  	String oldLabel = getLabel();
  	if (!oldLabel.equals(newLabel)) {
  		button.setLabel(newLabel);
  		validate();
		fireTransactionPropertyChange("label", oldLabel, newLabel);  		
  		}
  	}
  	
  public void setForeground(Color c) {
 	super.setForeground(c);
  	button.setForeground(c);
   	validate();
  	}
  	
  public Font getFont() {
  	return button.getFont();
  	}
  	
  public void setFont(Font newFont) {
  	if (!getFont().equals(newFont)) {
  		Font previousFont = getFont();
  		button.setFont(newFont);
  		validate();
		firePropertyChange("font", previousFont, newFont);  		
  		}
  	}
  	
   protected Button button = new Button(" ");
  }
