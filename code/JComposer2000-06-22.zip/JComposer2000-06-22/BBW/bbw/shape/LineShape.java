package bbw.shape;

import bbw.Shape;
import bbw.Handle;
import bbw.BBWPoint;
import bbw.BBWVector;
import java.awt.*;

/**
 * A Line is drawn between the origin and corner handles. 
 *
 * @version     0.8, Apr97
 * @author  Rick Mugridge
 */
public class LineShape extends Shape {

  public void paint(Graphics g) {
    super.paint(g);
    g.setColor(getForeground());
    g.drawLine(getX(), getY(), cornerHandle.getX(), cornerHandle.getY());
    }

  public Rectangle getBounds() {
    return originHandle.getBounds().union(cornerHandle.getBounds());
    }

  static double distanceToOrigin(double x, double y) {
    return Math.sqrt(x * x + y * y);
    }

  public boolean contains(int x, int y) {
    // Adapted from code written by Shane Henderson for 230.
    // To determine whether a point is "on" an the line we work out the distance from the point
    // to the line.  If that is below some threshhold, we return true.
    // Allow for a zero-length line.
    double minDistance;     // Minimum distance from line to pt.
    double intersectionX, intersectionY;    // Closest pt on the line through the arc to the point.
    BBWPoint start = originHandle.getMidPt();
    BBWPoint finish = cornerHandle.getMidPt();
    if (start.equals(finish))
        return false;       // Point is not on a zero-length arc.
    start = start.minus(new BBWVector(x,y));    // Translate the problem so that pt is at the origin.
    finish = finish.minus(new BBWVector(x,y));
    minDistance = distanceToOrigin(start.x, start.y);
    if (distanceToOrigin(finish.x, finish.y) < minDistance)
        minDistance = distanceToOrigin(finish.x, finish.y);
    if (minDistance <= ArcThreshhold) //No need to go further since pt is close enough to an endpoint
        return true;
    else {
        // The line through start and finish has equation ax + by + c = 0, where a, b, c are found as follows:  
        double a, b, c;         // Coefficients of line
        a = finish.y - start.y;
        b = start.x - finish.x;
        c = Math.round(start.y * finish.x - start.x * finish.y);

        // A line perpendicular to the above, through the origin has equation ay - bx = 0.
        // Substituting this into the above gives the point of intersection of the 2 lines. 
        // This pt of intersection is the closest point on the line to the origin.

        intersectionX = -a * c / (a * a + b * b);
        intersectionY = -b * c / (a * a + b * b);
        // We have to check that BOTH x and y are in the right range because of a nasty special case.
        // Suppose the arc is vertical and pt lies directly below the lower endpoint by 20 pixels say.
        // Then the intersection point will be calculated as the pt itself.                                     }
        // Then the xInRange check will be successful but the yInRange check will not (as hoped).
        // If the arc is horizontal and the pt lies to the right of the line then the yInRange check will
        // return true but the xInRange check will not. So neither check is sufficient by itself.
        boolean xInRange = (intersectionX >= Math.min(start.x,finish.x)) && (intersectionX <= Math.max(start.x,finish.x));
        boolean yInRange = (intersectionY >= Math.min(start.y,finish.y)) && (intersectionY <= Math.max(start.y,finish.y));
        if (xInRange && yInRange)   // If the point of intersection is on the arc, then
            if (distanceToOrigin(intersectionX,intersectionY) < ArcThreshhold)
                return true;
        }
    return false;
    }
    
//  protected double orientation = 0.0; // in radians
  final double ArcThreshhold = 5.0;
  }
  
