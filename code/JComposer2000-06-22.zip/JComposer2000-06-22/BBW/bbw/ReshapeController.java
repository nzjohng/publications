package bbw;

import java.awt.*;
import java.awt.event.*;

/**
 * An abstraction of Move- and ResizeController.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class ReshapeController extends HandleController {

  public ReshapeController(BBWContainer container) {
  	super(container);
  	}

  public void mouseDown(MouseEvent event, int x, int y) {
	Handle handle  = container.getHandleAt(x,y);
	if (handle != null && handle.isReshapeEnabled()) {
		if (!event.isShiftDown())
			container.getPanel().deselectShapes();
		mouseHandle = handle;
		Constraint.pushReason(getReason());
		mouseOffsetX = x - handle.getX();
		mouseOffsetY = y - handle.getY();
//		dragBounds = handle.getParent().getBounds();
		return;
		}
	BBWComponent comp = container.getComponentAt(x,y);
	if (comp instanceof BBWTopContainer)
		return; // Can't drag top container
	if (comp instanceof Shape && comp.isReshapeEnabled()) {
		Shape shape = (Shape)comp;
		if (!event.isShiftDown())
			container.getPanel().deselectShapes();
		shape.setSelected(true);
		mouseHandle = shape.getCornerHandle();
		Constraint.pushReason(getReason());
		mouseOffsetX = x - mouseHandle.getX();
		mouseOffsetY = y - mouseHandle.getY();
//		dragBounds = shape.getParent().getBounds();
		}
  	}

  abstract public int getReason();

  public String getName() {
	return "Move Pointer";
	}
  }
