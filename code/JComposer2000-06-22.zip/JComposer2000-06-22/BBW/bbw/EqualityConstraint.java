package bbw;

import java.awt.*;
import java.util.*;

/**
 * A EqualityConstraint constrains two handle to have the same X and Y value.
 * 	constraint from.origin == to.origin;
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class EqualityConstraint extends DualConstraint {

  public void init(Handle from, Handle to) {
  	init(from,to,new BBWVector(0,0));
  	}

	// constraint  to == from + offset;
  public void init(Handle from, Handle to, BBWVector offset) {
  	super.init(from,to);
  	this.offset = (BBWVector)offset.clone();
	fromXChanged();
	fromYChanged();
  	}
  
  protected void fromXChanged() {
	to.setX(from.getX() + offset.x);
	}
	
  protected void fromYChanged() {
	to.setY(from.getY() + offset.y);
	}
	
  protected void toXChanged() {
	from.setX(to.getX() - offset.x);
	}
  
  protected void toYChanged() {
	from.setY(to.getY() - offset.y);
	}
  
  protected BBWVector offset;
  }
