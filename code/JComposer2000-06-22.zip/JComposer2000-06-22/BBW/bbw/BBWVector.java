package bbw;

import java.awt.*;

/**
 * A BBWVector extends Point with some extra methods.
 * Some of these may be redundant now that the X and Y
 * dimensions are handled independently.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class BBWVector extends Point implements Cloneable {
  public BBWVector(int x, int y) {
  	super(x,y);
  	}
  	
  public Object clone() {
  	return new BBWVector(x,y);
  	}
  	
  public BBWVector half() {
  	return new BBWVector((int)Math.round(x*0.5),(int)(y*0.5));
  	}
  	
  public BBWVector negate() {
  	return new BBWVector(-x,-y);
  	}
  
  public boolean equals(Object other) {
  	if (other instanceof BBWVector)
  		return x == ((BBWVector)other).x && y == ((BBWVector)other).y;
  	return false;
  	}
  	
  public String toString() {
  	return "("+x+","+y+")";
  	}
  }
