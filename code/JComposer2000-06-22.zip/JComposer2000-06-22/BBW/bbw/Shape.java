package bbw;

import bbw.constraint.*;
import java.awt.*;

/**
 * A Shape is a BBWComponent with (at least) 3 handles. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class Shape extends BBWComponent {
    
    /**
     * Initialise the BBWComponent with its three handles.  
     * Size it according to the specified minimumSize.
     * Add it to the given container.
     */
  public void init(BBWContainer container, int x, int y) {
	Dimension min = getMinimumSize();
	width = min.width;
	height = min.height;  //	setSize(min.width,min.height);
	super.init(x-width,y-height);
	
	popupHandle = new PopupHandle(this,name+"-popup");
	new AttachPopupHandle(originHandle,popupHandle);

	cornerHandle = new Handle(this,name+".getCornerHandle()");
	middleHandle = new Handle(this,name+".getMiddleHandle()");
	new CornerHandleConstraint(this,originHandle,cornerHandle);
	setMiddleConstraint();
	new RepaintDaemon(this,originHandle);
	container.add("here",this);
	repaint();
	}

    /**
     * Return the rectangular bounds of the BBWComponent.
     */
  public Rectangle getBounds() {
  	return originHandle.getBounds().union(cornerHandle.getBounds());
  	}
  
    /**
     * Get a reference to the popup handle.
     */
  public PopupHandle getPopupHandle() {
  	return popupHandle;
  	}

    /**
     * Get a reference to the corner handle.
     */
  public Handle getCornerHandle() {
  	return cornerHandle;
  	}

    /**
     * Get a reference to the middle handle.
     */
   public Handle getMiddleHandle() {
  	return middleHandle;
  	}

    /**
     * Get the width.
     */
  public int getWidth() {
  	return width;
  	}
  	
    /**
     * Set the width and fire property change.
     */
  public void setWidth(int width) {
	if (this.width != width) {
		repaint();
		Integer oldWidth = new Integer(this.width);
		this.width = width;
		firePropertyChange("width",oldWidth, new Integer(width));
		repaint();
		}
  	}
  	
    /**
     * Get the height.
     */
  public int getHeight() {
  	return height;
  	}
  	
    /**
     * Set the height and fire property change.
     */
  public void setHeight(int height) {
	if (this.height != height) {
		repaint();
		Integer oldHeight = new Integer( this.height);
		this.height = height;
		firePropertyChange("height",oldHeight, new Integer(height));
		repaint();
		}
  	}
  	
    /**
     * Get all the handles.
     */
  public AbstractHandle[] getHandles() {
  	AbstractHandle[] extras = { popupHandle, cornerHandle, middleHandle };
  	return addHandles(super.getHandles(),extras);
  	}
  	
    /**
     * Get the preferred size of such a shape.
     * (BUT is this used/needed?)
     */
  public Dimension getPreferredSize() {
	if (width == 0 && height == 0)
		return new Dimension(25,25);
	else
		return getSize();
	}

    /**
     * To enable overriding in subclasses.
     * (CHECK is this still needed?)
     */
  protected void setMiddleConstraint() {
	new MiddleConstraint(this,middleHandle,originHandle);
  	}
  
    /**
     * Return a normalised Rectangle of the Shape
     */
  protected Rectangle normalised() {
	return normalise(new Rectangle(getX(), getY(), width, height));
  	}

    /**
     * The popup handle.
     */
  protected PopupHandle popupHandle;

    /**
     * The bottom-right handle.
     */
  protected Handle cornerHandle;

    /**
     * The handle midway between the origin and corner handles.
     */  
  protected Handle middleHandle;

    /**
     * The width property.
     * (MUST look in subpackages for references to the "size" property and change them to "width" and "height".)
     */  
  protected int width = 0;

    /**
     * The height property.
     */  
  protected int height = 0;
  }
