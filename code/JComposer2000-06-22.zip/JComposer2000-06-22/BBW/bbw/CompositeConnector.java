package bbw;

/**
 * A CompositeConnector is a Composite with all handles invisible.
 * It must define another init() which also takes as asrguments the two handles it's connected to.
 *
 * @version 	0.8, Apr1997
 * @author 	Rick Mugridge
 */
public abstract class CompositeConnector extends Composite {

	/**
	 * Initialise the CompositeConnector with all handles invisible.
	 */
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
	setHandlesVisible(false);
	}
 
  abstract public void init(BBWContainer container, int x, int y, Handle from, Handle to);
 }

