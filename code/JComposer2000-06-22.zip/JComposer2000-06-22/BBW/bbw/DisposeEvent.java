package bbw;

public class DisposeEvent extends java.util.EventObject {
  public DisposeEvent(Object source) {
	super(source);
	}
  }
