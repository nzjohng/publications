package bbw;

import java.awt.*;
import java.util.*;
import java.io.Serializable;

/**
 * A GrabHandle is used to manipulate shapes and to be visible for certain constraints, such as ProportionalConstraint.
 * It is owned by a Shape (in the case of a RelativePin, this is the owner of the source pin).
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class GrabHandle extends Handle {
  
	/**
	 * Create a Handle in the given container with the given owner, given name, and with origin (x,y). 
	 * (The container is just needed to add it to.)
	 * (BUT once a Handle is a subpart of a Shape, the container is no longer needed.)
	 */
  public GrabHandle(BBWComponent owner, String name, int x, int y) {
	super(owner,name,x,y);
	}
	
  public GrabHandle(BBWComponent owner, String name) {
	this(owner,name,10,10);
	}
	
  public GrabHandle(BBWComponent owner, int x, int y) {
	this(owner,"<handle>",x,y);
	}
  	
	/**
	 *Paint the Handle.
	 */
  public void paint(Graphics g, Color color) {
	if (visible && (reshapeEnabled || glueEnabled)) {
		Color fillColor = Color.white;
		if (reshapeEnabled && glueEnabled) fillColor = Color.black;
		else if (reshapeEnabled) fillColor = Color.green;
		else if (glueEnabled) fillColor = Color.blue;
		g.setColor(fillColor);
		g.fillRect(x-HALF_SIZE, y-HALF_SIZE, SIZE, SIZE);
		g.setColor(color);
		g.drawRect(x-HALF_SIZE, y-HALF_SIZE, SIZE, SIZE);
		}
	}
  
	/**
	 * Gets the reshapeEnabled property value.
	 */
 public boolean isReshapeEnabled() {
  	return reshapeEnabled;
  	}

	/**
	 * Sets the reshapeEnabled property value.
	 */
  public void setReshapeEnabled(boolean reshapeEnabled) {
  	Boolean old = new Boolean(this.reshapeEnabled);
  	this.reshapeEnabled = reshapeEnabled;
	if (firePropertyChange("reshapeEnabled", old, new Boolean(reshapeEnabled)))
		repaint();
  	}
  	
	/**
	 * Gets the glueEnabled property value.
	 */
 public boolean isGlueEnabled() {
  	return glueEnabled;
  	}

	/**
	 * Sets the glueEnabled property value.
	 */
  public void setGlueEnabled(boolean glueEnabled) {
  	Boolean old = new Boolean(this.glueEnabled);
  	this.glueEnabled = glueEnabled;
	if (firePropertyChange("glueEnabled", old, new Boolean(glueEnabled)))
		repaint();
  	}
  	
	/**
	 * Return the Handle as a String.
	 */
  public String toString() {
  	return name+"["+x+","+y+","+visible+","+reshapeEnabled+","+glueEnabled+"]";
  	}
	/**
	 * The handle can be MOVE's and RESIZE'd
	 */
  protected  boolean reshapeEnabled = true;
  
	/**
	 * The handle can have constraints attached to it
	 */
  protected  boolean glueEnabled = true;

  }

