package bbw;

import java.awt.*;

/**
 * A PopupController has a MenuItem and acts as an (indirect) listener
 * on it. When its MenuItem is selected from some Menu (or PopupMenu),
 * its popupSelected() method is called (by a ActionListener) with the
 * BBWComponent holding the popup (or the one selected if we wished to
 * use Menus on selected BBWComponents).
 *
 * @version 	0.8, May 1997
 * @author 	Rick Mugridge
 */
public interface PopupController {
	public MenuItem getMenuItem();
	public void popupSelected(BBWComponent component);
	}

