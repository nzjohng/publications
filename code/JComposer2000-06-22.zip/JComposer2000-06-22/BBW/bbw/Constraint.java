package bbw;

import java.awt.*;
import java.beans.*;
import java.util.*;
import java.io.Serializable;

/**
 * A Constraint is an abstract class for constraint handling.   This class represents the current reason and provides a stack of reasons.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class Constraint extends PropertyChangeSupport2 implements HasName, PropertyChangeListener, DisposeListener, Serializable {
  
	/**
	 * Get the name of the constraint - for debugging displays
	 */
  public String getName() {
  	return name;
  	}

  // Statics:
  
	/**
	 * Push a new reason (ie save the current one on the stack).
	 */
  public static void pushReason(int p_reason) {
  	stack.push(new Integer(reason));
  	reason = p_reason;
  	}
  
	/**
	 * Pop off the current reason (ie restore from the stack).
	 */
  public static int popReason() {
  	reason = ((Integer)stack.pop()).intValue();
  	return reason;
  	}
    	
	/**
	 * This will only be called if the constraint actually puts itself as a DisposeListener onto something else.
	 * That's when the constraint needs to dispose of itself when something else is disposed of (eg ArcConstraint)
	 */
  public void disposePerformed(DisposeEvent evt) {
  	dispose();
  	}

	/**
	 * Method to dispose to be supplied by concrete subclasses.
	 */
  public abstract void dispose();
  
	/**
	 * Is constraint propagation occuring for this constraint currently?
	 * Used to avoid cycles.
	 */
  protected boolean firing = false;

	/**
	 * The current reason (the top-of-stack).
	 */
  public static int reason = Constraint.MOVE;

	/**
	 * Possible reasons in BuildByWire.
	 */
  public static final int MOVE = 0, RESIZE = 1, MOVE_PIN = 2;

	/**
	 * The (rest of the) reason stack.
	 */
  protected static Stack stack = new Stack();

	/**
	 * The name of the Constraint object.
	 */
  protected String name = "v"+getClass().getName()+(_id++);
  protected static int _id = 1;
  }
