package bbw;

import java.awt.*;

/**
 * A SingleHandleShape provides for constraints which introduce a single handle.
 * Eg ProportionalConstraint.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class SingleHandleShape extends BBWComponent {

    /**
     * Initialise the SingleHandleShape with its single handle.  
     * Add it to the given container.
     */
  public void init(BBWContainer container, int x, int y) {
	super.init(x,y);
	new RepaintDaemon(this,originHandle);
	container.add("here",this);
	repaint();
	}

  public Rectangle getBounds() {
  	return originHandle.getBounds();
  	}

  public Point getLocation() {
  	return originHandle.getLocation();
  	}

  public int getWidth() {
  	return originHandle.getWidth();
  	}

  public void setWidth(int width) {
  	throw new RuntimeException("Cannot change the size of handles!");
  	}
  	
  public int getHeight() {
  	return originHandle.getHeight();
  	}

  public void setHeight(int height) {
  	throw new RuntimeException("Cannot change the size of handles!");
  	}

  public String toString() {
  	return name+"["+getX()+","+getY()+"]";
	}
  }
