package bbw;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

/**
 * A DrawingPanel holds the BBW shapes and is the panel for all java.awt.Components.
 * It passes on mouse events to the current Controller.  It has no layoutManager.
 * It contains a BBWTopContainer, which in turn contains all BBWComponents.
 * It maintains a stack to allow for shift-clicks (which may well go once popups
 * are used).
 * It used to support selected shapes - this has been taken out for now, to be
 * put in again sometime.
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class DrawingPanel extends Panel implements MouseListener, MouseMotionListener{
  
  public DrawingPanel() {
  	setLayout(null);
	addMouseListener(this);
	addMouseMotionListener(this);
  	}
  
  public BBWTopContainer getTopContainer() {
  	return top;
  	}
  	
  public Dimension getPreferredSize() {
  	return new Dimension(500,300);
  	}
  
  public void fireTransaction(boolean begin) {
  	((BBWGeneralPanel) getParent()).fireTransaction(begin);
  	}
  
  public void mousePressed(MouseEvent event) {
    if((event.getModifiers() & event.BUTTON3_MASK) != 0) {
        // handle right-click to activate pop-up menu
        return;
    }
    
	fireTransaction(true);
	if (stackedController != null) { // In case we didn't get a mouseUp()
		controller = stackedController;
		stackedController = null;
		}
	if (event.isShiftDown()) {
		stackedController = controller;
		controller = moveController;
		}
	else if (event.isControlDown()) {
		stackedController = controller;
		controller = resizeController;
		}
	else
		stackedController = null;
	currentPopup = null; // in case we miss the mouseReleased!
	try {
		top.getHandleAt(event.getX(),event.getY()); // popup??
		controller.mouseDown(event,event.getX(),event.getY());
		}
	catch (PopupHandleException pe) {
		currentPopup = pe.getPopup();
		}
	}
	
  public void mouseDragged(MouseEvent event) {
	controller.mouseDrag(event,event.getX(),event.getY());
	}

  public void mouseReleased(MouseEvent event) {
    if((event.getModifiers() & event.BUTTON3_MASK) != 0) {
        // right-click on icon => show pop-up menu
        BBWComponent c = getTopContainer().getComponentAt(event.getX(),event.getY());
        c.processPopup(null,event.getX(),event.getY());
        return;
    }
    
	if (currentPopup != null) {
		if (currentPopup.contains(event.getX(),event.getY()))
			currentPopup.getOwner().processPopup(currentPopup,event.getX(),event.getY());
		currentPopup = null;
		}
	else {
		controller.mouseUp(event,event.getX(),event.getY());
		if (stackedController != null) {
			controller = stackedController;
			stackedController = null;
			}
		}
	fireTransaction(false);
	}

  public void mouseClicked(MouseEvent event) {
	}

  public void mouseEntered(MouseEvent event) {
	// Ignore
	}

  public void mouseExited(MouseEvent event) {
	// Ignore
	}

  public void mouseMoved(MouseEvent event) {
	// Ignore
	}

  public void paint(Graphics g) {
	g.drawRect(0, 0, getSize().width - 1, getSize().height - 1);
	top.paint(g);
	}

  public void displayShapes() {
	top.print(System.out,0);
	}

  public void printUserElements() {
	top.printUserElements(System.out);
	}

  public void setController(Controller controller) {
  	this.controller = controller;
  	}
  
  public void setMoveController(MoveController moveController) {
  	this.moveController = moveController;
  	}
  
  public void setResizeController(ResizeController resizeController) {
  	this.resizeController = resizeController;
  	}
  
  public void addRepaintArea(Rectangle r) {
  	// repaints.addElement(r); (DONE: temporarily removed my own repaint control.)
  	repaint(100,r.x,r.y,r.width,r.height);
  	}
  
  public void selectShape(Shape shape) {
	selectedShapes.addElement(shape);
  	}
  
  public void deselectShapes() {
	Enumeration iterator = selectedShapes.elements();
	while (iterator.hasMoreElements())
		((BBWComponent)iterator.nextElement()).setSelected(false);
	selectedShapes.removeAllElements();
  	}
  
  protected BBWTopContainer top = new BBWTopContainer(this);
  protected Controller controller;
  protected Controller stackedController;// Holds current controller for temporary MOVE/RESIZE; null if none stacked
  protected MoveController moveController;
  protected ResizeController resizeController;
  protected Vector repaints = new Vector();
  protected Vector selectedShapes = new Vector();
  protected Color debugBackground = Color.blue;
  protected PopupHandle currentPopup = null;
  }
