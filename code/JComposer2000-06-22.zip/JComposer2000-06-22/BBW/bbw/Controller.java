package bbw;

import java.awt.*;
import java.awt.event.*;

/**
 * A Controller is responsible for handling mouse actions of the user.
 * When the user selects a tool (such as BoxShape or EqualityCOnstraint),
 * the DrawingPanel refers to a corresponding Controller (ShapeController
 * for BoxShape - which creates a BoxShape object from the name of the class.  
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public interface Controller {
  public void mouseDown(MouseEvent event, int x, int y);
  public void mouseDrag(MouseEvent event, int x, int y);
  public void mouseUp(MouseEvent event, int x, int y);
  public String getName();
  }
