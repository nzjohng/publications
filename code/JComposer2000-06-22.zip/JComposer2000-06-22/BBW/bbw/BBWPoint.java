package bbw;

import java.awt.*;

public class BBWPoint extends Point implements Cloneable {
  public BBWPoint(int x, int y) {
  	super(x,y);
  	}
  
  public Object clone() {
  	return new BBWPoint(x,y);
  	}
  	
  public BBWPoint plus(BBWVector vector) {
  	return new BBWPoint(x+vector.x,y+vector.y);
  	}
  
  public BBWPoint plus(int delta) {
  	BBWPoint result = new BBWPoint(x,y);
  	result.translate(delta, delta);
  	return result;
  	}
  
  public BBWPoint minus(BBWVector vector) {
  	return new BBWPoint(x-vector.x,y-vector.y);
  	}
  
  public BBWPoint minus(int delta) {
  	return plus(-delta);
  	}
  
  public BBWVector minus(BBWPoint point2) {
  	BBWVector result = new BBWVector(x,y);
  	result.translate(-point2.x, -point2.y);
  	return result;
  	}
  
  public boolean equals(Object other) {
  	if (other instanceof BBWPoint)
  		return x == ((BBWPoint)other).x && y == ((BBWPoint)other).y;
  	return false;
  	}
  	
  public String toString() {
  	return "("+x+","+y+")";
  	}
  }
