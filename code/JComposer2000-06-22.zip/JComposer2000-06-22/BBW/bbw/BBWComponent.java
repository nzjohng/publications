package bbw;

import java.beans.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import beanbox.*;

/**
 * A BBWComponent is similar to a java,awt.Component, except that it fits
 * within BuildByWire, a constraint-based graph drawing system. 
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public abstract class BBWComponent extends PropertyChangeSupport2 implements HasName, Serializable, PropertyChangeListener{

	/**
	 * Initialise the Shape with its origin handle.  
	 */
  public void init(int x, int y) {
	originHandle = new Handle(this,name+".getOriginHandle()",x,y);
  	originHandle.addPropertyChangeListener(this);
	}

    /**
     * Get a reference to the origin handle.
     */
  public Handle getOriginHandle() {
  	return originHandle;
  	}

    /**
     * Get a reference to the middle handle.
     * By default, this is the same as the origin handle (BUT may cause troublke later!!)
  public Handle getMiddleHandle() {
  	return originHandle;
  	}
     */

    /**
     * Get the origin as a BBWPoint.
     * (CHECK - is this still needed?)
     */
  public BBWPoint getOrigin() {
  	return new BBWPoint(getX(),getY());
  	}
  	
    /**
     * Set the origin as a BBWPoint.
     * (CHECK - is this still needed?)
     */
  public void setOrigin(BBWPoint p) {
	setX(p.x);
	setY(p.y);
  	}
  	
    /**
     * Get origin.x.
     */
  public int getX() {
  	return originHandle.getX();
  	}
  	
    /**
     * Set origin.x.
     */
  public void setX(int x) {
	originHandle.setX(x);
  	}
  	
    /**
     * Get origin.y.
     */
  public int getY() {
  	return originHandle.getY();
  	}
  	
    /**
     * Set origin.y.
     */
  public void setY(int y) {
	originHandle.setY(y);
  	}
  	
    /**
     * Check whether it is selected.
     */
  public boolean isSelected() {
  	return selected;
  	}

    /**
     * Set the value of selected.
     */
  public void setSelected(boolean selected) {
  	Boolean oldSelected = new Boolean(this.selected);
  	this.selected = selected;
	if (firePropertyChange("selected", oldSelected, new Boolean(selected)))
		repaint();
  	}

    /**
     * Get all the handles.
     */
  public AbstractHandle[] getHandles() {
  	AbstractHandle[] handles = { originHandle };
  	return handles;
  	}

    /**
     * Accumulate the handles together.
     * This avoids having to also mention all the superclass handles in a subclass.  
     */
  protected static AbstractHandle[] addHandles(AbstractHandle[] handles, AbstractHandle[] extras) {
  	int length = handles.length;
  	int eLength = extras.length;
  	AbstractHandle[] handles2 = new AbstractHandle[length+eLength];
  	for (int i = 0; i < length; i++)
  		handles2[i] = handles[i];
  	for (int i = 0; i < eLength; i++)
  		handles2[length+i] = extras[i];
  	return handles2;
  	}
  	
    /**
     * Return a handle for the BBWComponent if possible.
     */
  public Handle getHandleAt(int x, int y) {
	if (visible && handlesVisible) {
		AbstractHandle[] handles = getHandles();
  		for (int i = 0; i < handles.length; i++) {
  			if (handles[i].contains(x,y))
  				if (handles[i] instanceof Handle)
					return (Handle)handles[i];
				else
					throw new PopupHandleException((PopupHandle)handles[i]);
  			}
		}
  	return null;
	}

    /**
     * Dispose of the BBWComponent and any handles it contains.
     * Remove it from its BBWContainer.
     */
  public void dispose() {
  	AbstractHandle[] handles = getHandles();
  	for (int i = 0; i < handles.length; i++)
  		handles[i].dispose();
   	repaint();
	popupManager.dispose();
  	parent.remove(this);
 	fireDisposeEvent();
  	}
  
    /**
     * As in java.awt.Component, fill with the background color and call paint()
     */
  public void update(Graphics g) {
	if (visible) {
		//g.setColor(getBackground());
		//Rectangle outline = getBounds();
		//g.fillRect(outline.x, outline.y, outline.width, outline.height);
		g.setColor(getForeground());
		paint(g);
		paintHandles(g);
		}
	}

	/**
	 *Paint the shape by doing nothing, usually overridden.
	 */
  protected void paint(Graphics g) {
  	}
  	
	/**
	 *Paint the handles of the shape, if needed.
	 */
  protected void paintHandles(Graphics g) {
  	if (handlesVisible) {
  		Color color = Color.black;
  		if (selected) color = Color.red;
  		AbstractHandle[] handles = getHandles();
  		for (int i = 0; i < handles.length; i++)
  			handles[i].paint(g,color);
  		}
  	}
  	
	/**
	 *Changes to originHandle.x & y are passed on as changes to property "origin".
	 */
  public void propertyChange(PropertyChangeEvent evt) {
	// Pass the origin event on with a new source and property name
	if (evt.getSource() == originHandle)
		if (evt.getPropertyName().equals("x"))
			firePropertyChange("x",evt.getOldValue(),evt.getNewValue());
		else if (evt.getPropertyName().equals("y"))
			firePropertyChange("y",evt.getOldValue(),evt.getNewValue());
  	}

	/**
	 * Gets the string name of the shape.
	 */
  public String getName() {
  	return name;
  	}
  	
	/**
	 * Sets the string name of the shape.
	 */
  public void setName(String name) {
  	String old = this.name;
  	this.name = name;
	firePropertyChange("name", old, name);
  	}
  	
	/**
	 * Check whether the handles of the shape are visible.
	 */
  public boolean isHandlesVisible() {
  	return handlesVisible;
  	}

    /**
     * Set the value of whether the handles of the shape are visible.
     */
  public void setHandlesVisible(boolean handlesVisible) {
  	Boolean old = new Boolean(this.handlesVisible);
  	this.handlesVisible = handlesVisible;
	if (firePropertyChange("handlesVisible", old, new Boolean(handlesVisible)))
		repaint();
  	}

	/**
	 * Gets the simple name of the shape (ie without prefix "Shape", where it's used).
	 */
 public String getToolName() {
 	String name = getClass().getName();
 	int index  = name.indexOf("Shape");
 	if (index < 0) return name;
 	else return name.substring(0,index);
 	}
 
    /**
     * Gets the parent container of the BBWComponent
     * (is null if the BBWComponent is the BBWTopContainer).
     */
  public BBWContainer getParent() {
  	return parent;
  	}
  	
    /**
     * Gets the first parent that's an open container.
     * Overridden by a BBWComponent that's also an OpenContainer.
     */
  public BBWContainer getOpenContainer() {
  	return parent.getOpenContainer();
  	}

  	
    /**
     * Gets the BBWTopContainer.
     */
  public BBWTopContainer getTopContainer() {
  	return parent.getTopContainer();
  	}
  
    /**
     * Gets the foreground property value.
     */
  public Color getForeground() {
	return foreground;
	}
	
    /**
     * Sets the foreground property value.
     */
  public void setForeground(Color foreground) {
	Color oldForeground= this.foreground;
	this.foreground = foreground;
	if (firePropertyChange("foreground", oldForeground, foreground))
		repaint();
	}
	
    /**
     * Gets the background property value.
     */
   public Color getBackground() {
	return background;
	}
	
    /**
     * Sets the background property value.
     */
  public void setBackground(Color background) {
	Color oldBackground= this.background;
	this.background = background;
	if (firePropertyChange("background", oldBackground, background))
		repaint();
	}
	
    /**
     * Gets the fillColor property value.
     */
   public Color getFillColor() {
	return fillColor;
	}
	
    /**
     * Sets the fillColor property value.
     */
  public void setFillColor(Color fillColor) {
	Color oldFillColor= this.fillColor;
	this.fillColor = fillColor;
	if (firePropertyChange("fillColor", oldFillColor, fillColor))
		repaint();
	}
	
    /**
     * Gets the visible property value.
     */
 public boolean isVisible() {
  	return visible;
  	}

    /**
     * Sets the visible property value.
     */
  public void setVisible(boolean visible) {
  	Boolean oldVisible = new Boolean(this.visible);
  	this.visible = visible;
	if (firePropertyChange("visible", oldVisible, new Boolean(visible)))
		repaint();
  	}
  	
    /**
     * Tests whether the BBWComponent is currently painted.
     * A BBWComponent is only rendered if it's visible and so is its parent.
     */
  public boolean isShowing() {
	return visible && parent != null && parent.isShowing();
	}
    
    /**
     * Handle clipping of areas of the Panel that have been changed.
     */
  public void repaint(Rectangle r) {
  	if (parent != null) {
  		r.grow(2,2);
  		parent.addRepaintArea(r);
  		}
  	}
  	
  public void repaint() {
  	if (parent != null)
  		repaint(getBounds());
  	}
  	
    /**
     * Return the BBWComponent if the point is inside it and it is visible.
     * Overridden in BBWContainer to check its elements.
     */
  public BBWComponent getComponentAt(int x, int y) {
	return visible && contains(x, y) ? this : null;
	}

    /**
     *Is the point inside it, based on its bounds.  Overridden in some subclasses.
     */
  public boolean contains(int x, int y) {
  	return getBounds().contains(x,y);
  	}

    /**
     * Return a rectangle with non-negative width and height
     */
  public static Rectangle normalise(Rectangle r) {
	if (r.width < 0) {
		r.width = - r.width;
	    r.x = r.x - r.width + 1;
		}
	if (r.height < 0) {
	    r.height = - r.height;
	    r.y = r.y - r.height + 1;
		}
	return r;
  	}

    /**
     * Return the Panel in which the BBWComponent is drawn.
     */
  public DrawingPanel getPanel() {
  	return getParent().getPanel();
  	}
  
    /**
     * Return the parent of the Panel in which the BBWComponent is drawn.
     * (BADLY NAMED)
     */
  public Panel getTopPanel() {
  	return (Panel)getPanel().getParent();
  	}
  
    /**
     * Resize the BBWComponent to have width and height.
     */
  public void setSize(int width, int height) {
	setWidth(width);
	setHeight(height);
	}
 
    /**
     * Resize the BBWComponent to the given Dimension.
     */
  public void setSize(Dimension d) {
	setSize(d.width,d.height);
	}

    /**
     * The preferred size of the BBWComponent (used when creating new ones).
     * By default, the current size.
     */
  public Dimension getPreferredSize() {
	return getSize();
	}

    /**
     * The minmum size of the BBWComponent (used when creating new ones).
     * By default, the current size. (Is this used at all???)
     */
  public Dimension getMinimumSize() {
	return getSize();
	}
    	
    /**
     * Validate the panel in which the BBWComponent is drawn, to cause
     * embedded java.awt.Component's to be re-rendered.
     * Used by a BBWComponent holding a subclass of java.awt.Component after
     * a change to one of their properties.
     */
  public void validate() {
  	getParent().validate();
  	repaint();
  	}
  	
    /**
     * Print the BBWComponent to the PrintStream.
     */
  public void print(PrintStream out, int indent) {
	if (compositeMember)
		return;
	for (int i = 0; i < indent; i++)
		out.print(" ");
	out.println(this);
	}	
  
    /**
     * Print the BBWComponent to the PrintStream, plus sub-elements
     * in the case of a BBWContainer.
     */
  public void printUserElements(PrintStream out) {
	out.println(this);
	}	

    /**
     * Return the rectangular bounds of the BBWComponent.
     */
  public Rectangle getBounds() {
  	return new Rectangle(getX(),getY(),getWidth(),getHeight());
  	}
  
    /**
     * Change the bounds of the BBWComponent
     */
  public void setBounds(int x, int y, int width, int height) {
  	setX(x);
  	setY(y);
  	setWidth(width);
  	setHeight(height);
  	}
 
    /**
     * Return the origin of the BBWComponent.
     */
  public Point getLocation() {
  	return new Point(getX(),getY());
  	}

    /**
     * Get the width of the BBWComponent
     */
  public abstract int getWidth();

    /**
     * Set the width of the BBWComponent
     */
  public abstract void setWidth(int width);

    /**
     * Get the height of the BBWComponent
     */
  public abstract int getHeight();

    /**
     * Set the height of the BBWComponent
     */
  public abstract void setHeight(int height);
  	

    /**
     * Return the size (width & height) of the BBWComponent
     */
  public Dimension getSize() {
  	return new Dimension(getWidth(),getHeight());
  	}

    /**
     * Fire off an event for a property change.
     * Ensure the BBWComponent is repaint()-ed if it was a change.
     */
  public boolean firePropertyChange(String propertyName, Object oldValue, Object newValue) {
 	boolean fired = super.firePropertyChange(propertyName,oldValue,newValue);
 	if (fired)
 		repaint();
 	return fired;
 	}

    /**
     * Add/Register a listener interested in the disposal of this BBWComponent
     */
  public synchronized void addDisposeListener(DisposeListener listener) {
	if (disposeListeners == null)
		disposeListeners = new java.util.Vector();
	disposeListeners.addElement(listener);
	}
	
    /**
     * Remove a listener (no longer) interested in the disposal of this BBWComponent
     */
  public synchronized void removeDisposeListener(DisposeListener listener) {
	if (disposeListeners == null)
		return;
	disposeListeners.removeElement(listener);
	}
	
    /**
     * Inform all listeners of the disposal of this BBWComponent
     */
  public void fireDisposeEvent() {
	// This is NOT thread-safe
	DisposeEvent ev = new DisposeEvent(this);
	if (debugging)
		System.out.println(ev);
	if (disposeListeners != null)
		for (Enumeration tell = disposeListeners.elements(); tell.hasMoreElements(); )
			((DisposeListener) tell.nextElement()).disposePerformed(ev);
	}
	
	/**
	 * Show a property sheet with the properties of this BBWComponent.
	 */
  public void showPropertySheet() {
    
	new PropSheetAdaptor(new BBWPropertySheet(name,this,getEditableProperties(),10,10));
	}

	/**
	 * An inner class listener adaptor, which passes BBWComponent property
	 * changes through to the PropertySheet.  If the property sheet is
	 * invisible (when it's disposed of???), the adaptor finishes.
	 */
  class PropSheetAdaptor implements PropertyChangeListener {
	PropSheetAdaptor(BBWPropertySheet propertySheet) {
		this.propertySheet = propertySheet;
		BBWComponent.this.addPropertyChangeListener(this);
		}

	public void propertyChange(PropertyChangeEvent pce) {
		if (propertySheet.isVisible())
			propertySheet.wasModified(pce);
		else
			BBWComponent.this.removePropertyChangeListener(this);
		}

	private BBWPropertySheet propertySheet;
	}

	/**
	 * Handle the popup menu (it's passed as argument in case we want to
	 * have several popupHandles later).
	 */
  public void processPopup(PopupHandle currentPopup, int x, int y) {
	popupManager.processPopup(x,y);
	}

	/**
	 * Add extra MenuItems to the popup menu.
	 */
  public void addPopupMenuItem(MenuItem item) {
	popupManager.addPopupMenuItem(item);
	}

	/**
	 * Gets the reshapeEnabled property value.
	 */
 public boolean isReshapeEnabled() {
  	return reshapeEnabled;
  	}

	/**
	 * Sets the reshapeEnabled property value.
	 */
  public void setReshapeEnabled(boolean reshapeEnabled) {
  	Boolean old = new Boolean(this.reshapeEnabled);
  	this.reshapeEnabled = reshapeEnabled;
	if (firePropertyChange("reshapeEnabled", old, new Boolean(reshapeEnabled)))
		repaint();
  	}
  	
	/**
	 * Gets the compositeMember property value.
	 */
 public boolean isCompositeMember() {
  	return compositeMember;
  	}

	/**
	 * Sets the compositeMember property value.
	 */
  public void setCompositeMember(boolean compositeMember) {
	Boolean old = new Boolean(this.compositeMember);
  	this.compositeMember = compositeMember;
	if (firePropertyChange("compositeMember", old, new Boolean(compositeMember)))
		repaint();
  	}
  
  public String[] getEditableProperties() {
	return null; // If it's not overridden, all will be shown
	}

     /**
     * Convert to a String.
     */
  public String toString() {
  	return name+"["+getX()+","+getY()+","+getWidth()+","+getHeight()+"]";
  	}

   /**
     * The listeners interested in the disposal of this BBWComponent
     */
  private java.util.Vector disposeListeners;

    /**
     * The parent of the BBWComponent. It is null only for a BBWTopContainer.
     * @see #getParent
     */
  protected BBWContainer parent = null;
  
	/**
	 * The foreground color property for this BBWComponent.
	 */
  protected Color foreground = Color.black;
  
	/**
	 * The background color property for this BBWComponent, used in update().
	 */
  protected Color background = Color.white;
  
	/**
	 * The fill color property for this BBWComponent.  Only used
	 * by those BBWComponents that can be filled.
	 */
  protected Color fillColor = Color.white;
  
	/**
	 * A BBWComponent is shown on the screen only if it's visible (a property)
	 * and its parent is shown.
	 */
  protected boolean visible = true;
  
	/**
	 * The shape can be MOVE's and RESIZE'd
	 */
  protected  boolean reshapeEnabled = true;
  
     /**
	* A composite member is dependent on a Composite.  A BBWComponent
	* should only be a compositeMember if it is an element of a Composite;
	* this is assumed in getComponentAt().
	* A composite member can't be disposed of, hidden, etc.
	*/
  protected  boolean compositeMember = false;

	/**
	 * The top-left handle.
	 */  
  protected Handle originHandle;

	    /**
	     * True if the handles of the shape are to be displayed
	     */  
  protected boolean handlesVisible = true;

	/**
	 * True if the shape is currently selected.
	 */  
  protected boolean selected = true;

	/**
	 * This manages the messiness of shared and specialised popup menus.
	 */
  protected PopupManager popupManager = new PopupManager(this);

	/**
	 *An internal name for a shape - used for debugging displays.
	 */
  protected String name = "v"+getClass().getName()+(_id++);
  protected static int _id = 1;
  }
