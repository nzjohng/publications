/* 	Borrowed from sun.beanbox.
	Support for a PropertyEditor that uses text.
	CHANGED: to only act on ActionEvents from the TextField.
*/

package beanbox;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;

class PropertyText extends TextField implements ActionListener {

    PropertyText(PropertyEditor pe) {
	super(pe.getAsText());
	editor = pe;
	addActionListener(this);
    }

    public void repaint() {
	setText(editor.getAsText());
    }

    //----------------------------------------------------------------------
    // Action listener methods.

    public void actionPerformed(ActionEvent e) {
        try {
	    editor.setAsText(getText());
	} catch (IllegalArgumentException ex) {
	    // Quietly ignore.
	}
    }

    //----------------------------------------------------------------------
    private PropertyEditor editor;
}
