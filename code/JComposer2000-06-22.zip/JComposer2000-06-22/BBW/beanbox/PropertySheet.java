/*  Adapted from the same class in sun.beanbox, which has a package-local

    constructor.
    CHANGES:
    (1) Made constructor public;
    (2) Added adapter for window closing
    (3) Made wasModified() public, to allow propertySheet to be informed of
          changes to the spied object
    (4) Changed the PropertyText to only act on an ActionEvent.
    (5) Extended the panel to check for a BBWCOmponent and, if so, to call
        getVisibleProperties() to limit the properties that are to be
        displayed in the property sheet (to avoid generating a BeanInfo class).
*/

package beanbox;

import java.beans.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;
import java.util.Vector;

public class PropertySheet extends Frame {
    protected PropertySheetPanel panel;
    private boolean started;

    public PropertySheet(Object target)
    {
        panel = new PropertySheetPanel(this);
        panel.setTarget(target);
    }

    public PropertySheet(String title, Object target, int x, int y) {
    super(title);
    setLayout(null);
    setBackground(Color.lightGray); 
    setBounds(x,y, 100, 100);

    panel = new PropertySheetPanel(this);

    show();
    panel.setTarget(target);
    panel.initLayout();

    started = true;
    addWindowListener(new JCFrameAdapter());
    }
  
  class JCFrameAdapter extends WindowAdapter{
    public void windowClosing(WindowEvent e) {
        dispose();
        }
    }

    void setTarget(Object targ) {
    panel.setTarget(targ);
    }

    public void doLayout() {
    // Normally we get called when propertySheetPanel.setTarget
    // has changed the size of the ScrollPane and of us.
    if (!started) {
        return;
    }
    panel.stretch();
    }

    void setCustomizer(Customizer c) {
    panel.setCustomizer(c);
    }

    public void wasModified(PropertyChangeEvent evt) {
    panel.wasModified(evt);
    }
}


