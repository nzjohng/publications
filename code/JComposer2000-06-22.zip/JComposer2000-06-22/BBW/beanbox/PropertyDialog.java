// Borrowed from sun.beanbox
// Support for PropertyEditor with custom editors.

package beanbox;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;

class PropertyDialog extends Dialog implements ActionListener {

    PropertyDialog(Frame frame, PropertyEditor pe, int x, int y) {
	super(frame, pe.getClass().getName(), true);
	new WindowCloser(this);
	setLayout(null);
	Component body = pe.getCustomEditor();
	add(body);

	int top = 28;
	int width = body.getPreferredSize().width + 8;
	int height = body.getPreferredSize().height;

        body.setBounds(4, top, width, height+2);

	doneButton = new Button("Done");
	doneButton.addActionListener(this);
	add(doneButton);
	doneButton.setBounds((width-50)/2, top+height+4, 50, 30);

	setBounds(x, y, width+10, top + height + 44);

	show();
    }

    public void actionPerformed(ActionEvent evt) {
        // Button down.
	dispose();
    }

    Button doneButton;
}

