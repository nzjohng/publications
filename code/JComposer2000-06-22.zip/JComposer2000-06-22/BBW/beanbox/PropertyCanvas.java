// Borrowed from sun.beanbox
// Support for drawing a property value in a Canvas.

package beanbox;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;

class PropertyCanvas extends Canvas implements MouseListener {

    PropertyCanvas(Frame frame, PropertyEditor pe) {
	this.frame = frame;
	editor = pe;
	addMouseListener(this);
    }

    public void paint(Graphics g) {
	Rectangle box = new Rectangle(2, 2, getSize().width, getSize().height);
	editor.paintValue(g, box);
    }


    public void mouseClicked(MouseEvent evt) {
	int x = frame.getLocation().x - 30;
	int y = frame.getLocation().y + 50;
	new PropertyDialog(frame, editor, x, y);
    }

    public void mousePressed(MouseEvent evt) {
    }

    public void mouseReleased(MouseEvent evt) {
    }

    public void mouseEntered(MouseEvent evt) {
    }

    public void mouseExited(MouseEvent evt) {
    }

    private Frame frame;
    private PropertyEditor editor;
}
