/*  Adapted from the class PropertySheet in sun.beanbox, by Rick Mugridge Apr 1997.
    CHANGES:
    (1) Made constructor public
    (2) Added adapter for window closing
    (3) Made wasModified() public, to allow propertySheet to be informed of
          changes to the spied object
    (4) Changed the PropertyText to only act on an ActionEvent.
    (5) Extended the constructor arguments to include editableProperties to order
        and limit the properties to be displayed in the property sheet.  This
        is null if it's not to apply, while if it's zero length, no properties are shown.
    (6) Added the target to the constructor arguments.
    (7) Included EditedAdaptor as an inner class.
*/

package beanbox;

import java.beans.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;
import java.util.Vector;

public class BBWPropertySheet extends Frame {
    private BBWPropertySheetPanel panel;
    private boolean started;

    public BBWPropertySheet(Object target, String[] editableProperties)
    {
       panel = new BBWPropertySheetPanel(this,editableProperties);
       panel.setTarget(target);  
    }
    
    public BBWPropertySheet(String title, Object target, String[] editableProperties, int x, int y) {
    super(title);
    setLayout(null);
    setBackground(Color.lightGray); 
    setBounds(x,y, 100, 100);

    panel = new BBWPropertySheetPanel(this,editableProperties);

    show();
    panel.setTarget(target);
    panel.initLayout();

    started = true;
    addWindowListener(new JCFrameAdapter());
    }

    public BBWPropertySheetPanel getPanel()
    {
        return panel;
    }
  
  class JCFrameAdapter extends WindowAdapter{
    public void windowClosing(WindowEvent e) {
        dispose();
        }
    }

    void setTarget(Object targ) {
    panel.setTarget(targ);
    }

    public void doLayout() {
    // Normally we get called when propertySheetPanel.setTarget
    // has changed the size of the ScrollPane and of us.
    if (!started) {
        return;
    }
    panel.stretch();
    }

    void setCustomizer(Customizer c) {
    panel.setCustomizer(c);
    }

    public void wasModified(PropertyChangeEvent evt) {
    panel.wasModified(evt);
    }
}


