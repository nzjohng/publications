

package beanbox;

import java.beans.*;
import java.lang.reflect.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Hashtable;
import java.util.Vector;


public class PropertySheetPanel extends Panel {

    PropertySheetPanel(PropertySheet frame) {
    this.frame = frame;
    setLayout(null);
    }

    int height;
    int width;

    synchronized void setTarget(Object targ) {
    
    frame.removeAll();

    target = targ;  
    removeAll();

        try {
        BeanInfo bi = Introspector.getBeanInfo(target.getClass());
        properties = bi.getPropertyDescriptors();
    } catch (IntrospectionException ex) {
        error("PropertySheet: Couldn't introspect", ex);
        return;
    }

    // BBW-specific code follows.  Select and order the properties according to
    // getEditableProperties().
    if (targ instanceof bbw.BBWComponent) {
       String[] editableProperties = ((bbw.BBWComponent)targ).getEditableProperties();
       if (editableProperties.length > 0) {
        PropertyDescriptor[] newProperties = new PropertyDescriptor[editableProperties.length];
        for (int i = 0; i < editableProperties.length; i++) {
            String ep = editableProperties[i];
            for (int j = 0; j < properties.length; j++)
                if (ep.equals(properties[j].getName())) {
                    newProperties[i] = properties[j];
                    break;
                    }
            if (newProperties[i] == null) {
                System.out.println("Actual property names:");
                for (int k = 0; k < properties.length; k++)
                    System.out.println(properties[k].getName());
                throw new RuntimeException("Unknown property name included in getEditableProperties(): "+ep);
                }
            }
        properties = newProperties;
        }
       }
    // end addition

    editors = new PropertyEditor[properties.length];
    values = new Object[properties.length];
    views = new Component[properties.length];
    labels = new Label[properties.length];

    // Create an event adaptor.
    EditedAdaptor adaptor = new EditedAdaptor(frame);

    labelWidth = 100;
    viewWidth = 120;
    height = 35;

    for (int i = 0; i < properties.length; i++) {

        // Don't display hidden or expert properties.
        if (properties[i].isHidden() || properties[i].isExpert()) {
        continue;
        }

        String name = properties[i].getDisplayName();
        Class type = properties[i].getPropertyType();
        Method getter = properties[i].getReadMethod();
        Method setter = properties[i].getWriteMethod();

        // Only display read/write properties.
        if (getter == null || setter == null) {
        continue;
        }
    
        Component view = null;

        try {
        Object args[] = { };
        Object value = getter.invoke(target, args);
            values[i] = value;

            PropertyEditor editor = null;
            Class pec = properties[i].getPropertyEditorClass();
        if (pec != null) {
            try {
            editor = (PropertyEditor)pec.newInstance();
            } catch (Exception ex) {
            // Drop through.
            }
        }
        if (editor == null) {
            editor = PropertyEditorManager.findEditor(type);
        }
            editors[i] = editor;

            // If we can't edit this component, skip it.
            if (editor == null) {
            continue;
            }

        // Don't try to set null values:
        if (value == null) {
            continue;
        }

            editor.setValue(value);
            editor.addPropertyChangeListener(adaptor);

        // Now figure out how to display it...
        if (editor.isPaintable() && editor.supportsCustomEditor()) {
            view = new PropertyCanvas(frame, editor);
        } else if (editor.getTags() != null) {
            view = new PropertySelector(editor);
        } else if (editor.getAsText() != null) {
            String init = editor.getAsText();
            view = new PropertyText(editor);
        } else {
            System.err.println("Skipping non-displayable property " + name);
            continue;
        }

        } catch (Exception ex) {
        System.err.println("Skipping property " + name + " : " + ex);
        ex.printStackTrace();
        continue;
        }

        labels[i] = new Label(name, Label.RIGHT);
        add(labels[i]);
        int w = labels[i].getPreferredSize().width;
        if (w > labelWidth) {
        labelWidth = w;
        }

        views[i] = view;
        add(views[i]);

        w = view.getPreferredSize().width;
        if (w > viewWidth) {
        viewWidth = w;
        }
        int h = view.getPreferredSize().height;
        if (h < 30) {
        h = 30;
        }

        height += (h + hpad);
    }
    height = height - 20;
    width = labelWidth + viewWidth + 10;

    // Set our size to display all the properties.
    setSize(width, height);

    doLayout();
    processEvents = true;

     }

    public void initLayout() {


    Insets ins = frame.getInsets();
    int frameWidth = width + ins.left + ins.right;
    int frameHeight = height + ins.top + ins.bottom;

    // Do we need to add a scrollpane ?
    boolean needPane = false;
    if (frameWidth > maxWidth) {
        needPane = true;
        frameWidth = maxWidth;
    }
    if (frameHeight > maxHeight) {
        needPane = true;
        frameHeight = maxHeight;
    }

    if (needPane) {
        // Put us in a ScrollPane.

        // Note that the exact ordering of this code is
        // very important in order to get correct behaviour
        // on win32.  Don't modify unless you have a lot of
        // spare time to test/debug it.

        frameWidth = frameWidth + 30;
        if (frameWidth > maxWidth) {
        frameWidth = maxWidth;
        }
        frameHeight = frameHeight + 30;
        if (frameHeight > maxHeight) {
        frameHeight = maxHeight;
        }

        ScrollPane pane = new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
        pane.setBounds(ins.left, ins.top,
                frameWidth - (ins.left + ins.right),
                frameHeight - (ins.top + ins.bottom));

        frame.setSize(frameWidth,frameHeight);  
        pane.add(this);
        frame.add(pane);

        pane.doLayout();

    } else {
        frame.setSize(frameWidth,frameHeight);  
        //We don't need a ScrollPane.
        setLocation(ins.left, ins.top);
        frame.add(this);
    }

 repaint();
    
    }

    void stretch() {
    // This gets called when a user explicitly resizes the frame.

    Component child = null;
    try {
        child = frame.getComponent(0);
    } catch (Exception ex) {
        // frame has no active children;
        return;
    }
    Dimension childSize = child.getSize();
    Dimension frameSize = frame.getSize();
    Insets ins = frame.getInsets();
    int hpad = ins.top + ins.bottom;
    int wpad = ins.left + ins.right;

    // If the frame size hasn't changed, do nothing.
    if (frameSize.width == (childSize.width + wpad) &&
        frameSize.height == (childSize.height + hpad)) {
        return;
    }

    // We treat the new frame sizes as a future maximum for our own
    // voluntary size changes.
    maxHeight = frameSize.height;
    maxWidth = frameSize.width;

    // If we've gotten smaller, force new layout.
    if (frameSize.width < (childSize.width + wpad) ||
        frameSize.height < (childSize.height + hpad)) {
        // frame has shrunk in at least one dimension.
        setTarget(target);
    } else {
       // Simply resize the contents.  Note that this won't make
       // any ScrollPane go away, that will happen on the next
       // focus change.
       child.setSize(frameSize.width - (ins.left + ins.right),
            frameSize.height - (ins.top + ins.bottom));
        
    }


 repaint();
    
    }


    public void doLayout() {

    int width = getSize().width;

    int y = 10;

    if (views == null || labels == null) {
        return;
    }

    for (int i = 0; i < properties.length; i++) {
        if (labels[i] == null || views[i] == null) {
        continue;
        }

        labels[i].setBounds(0, y+5, labelWidth-8, 25);

        int h = views[i].getPreferredSize().height;
        if (h < 30) {
        h = 30;
        }
        int w = views[i].getPreferredSize().width;
        if (w < 105) {
        w = 105;
        }
        if (w > viewWidth) {
        w = viewWidth;
        }
        views[i].setBounds(labelWidth, y, viewWidth, h);
        y += (h + hpad);
    }

    y += 5;
    }


    synchronized void setCustomizer(Customizer c) {
    if (c != null) {
        c.addPropertyChangeListener(new EditedAdaptor(frame));
    }
    }

    synchronized void wasModified(PropertyChangeEvent evt) {

    if (!processEvents) {
        return;
    }

    if (evt.getSource() instanceof PropertyEditor) {
        PropertyEditor editor = (PropertyEditor) evt.getSource();
        for (int i = 0 ; i < editors.length; i++) {
            if (editors[i] == editor) {
            PropertyDescriptor property = properties[i];
                Object value = editor.getValue();
                values[i] = value;
            Method setter = property.getWriteMethod();
            try {
                Object args[] = { value };
                args[0] = value;
                setter.invoke(target, args);
            } catch (java.lang.reflect.InvocationTargetException ex) {
              if (ex.getTargetException() instanceof PropertyVetoException) {
            warning("Vetoed; reason is: " + ex.getTargetException().getMessage());
              }
              else
                error("InvocationTargetException while updating " + 
                            property.getName(), ex);
      ex.printStackTrace();      
            } catch (Exception ex) {
                error("Unexpected exception while updating " + 
                    property.getName(), ex);
                }
                if (views[i] != null && views[i] instanceof PropertyCanvas) {
                views[i].repaint();
                }
            break;
        }
        }
    }

    // Now re-read all the properties and update the editors
    // for any other properties that have changed.
    for (int i = 0; i < properties.length; i++) {
        Object o;
        try {
            Method getter = properties[i].getReadMethod();
            Object args[] = { };
            o = getter.invoke(target, args);
        } catch (Exception ex) {
        o = null;
        }
        if (o == values[i] || (o != null && o.equals(values[i]))) {
            // The property is equal to its old value.
        continue;
        }
        values[i] = o;
        // Make sure we have an editor for this property...
        if (editors[i] == null) {
        continue;
        }
        // The property has changed!  Update the editor.
        editors[i].setValue(o);
        if (views[i] != null) {
        views[i].repaint();
        }
    }

    // Make sure the target bean gets repainted.
    if (Beans.isInstanceOf(target, Component.class)) {
        ((Component)(Beans.getInstanceOf(target, Component.class))).repaint();
    }
    }

    private void warning(String s) {
    new ErrorDialog(frame, "Warning: " + s);
    }

    //----------------------------------------------------------------------
    // Log an error.

    private void error(String message, Exception ex) {
    String mess = message + ":\n" + ex;
    System.err.println(message);
    ex.printStackTrace();
    // Popup an ErrorDialog with the given error message.
    new ErrorDialog(frame, mess);

    }

    //----------------------------------------------------------------------
    private PropertySheet frame;

    private Object target;
    private PropertyDescriptor properties[];
    private PropertyEditor editors[];
    private Object values[];
    private Component views[];
    private Label labels[];

    private boolean processEvents;
    private static int hpad = 4;
    private int labelWidth = 100;
    private int viewWidth = 110;
    private int maxHeight = 500;
    private int maxWidth = 300;
}


