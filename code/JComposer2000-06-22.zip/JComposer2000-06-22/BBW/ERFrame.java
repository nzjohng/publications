import erTool.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;

public class ERFrame extends Frame implements ActionListener, ItemListener{
  public ERFrame() {
	setTitle("ERDiagrammer"+(frameCount++));
	setLayout(new BorderLayout());
	add("Center", panel);
	add("North",spyingCheckbox);
	spyingCheckbox.addItemListener(this);
	panel.addTransactionListener(spy);
	panel.addERChangeListener(spy);
	
	MenuBar menuBar = new MenuBar();
	Menu viewMenu = new Menu("View");
	viewMenu.add(newView);
	newView.addActionListener(this);
	viewMenu.add(demoRequest);
	demoRequest.addActionListener(this);
	menuBar.add(viewMenu);
	setMenuBar(menuBar);
	addWindowListener(new JCFrameAdapter());
	}
  
  class JCFrameAdapter extends WindowAdapter{
  	public void windowClosing(WindowEvent e) {
  		dispose();
		}
  	}

  public void actionPerformed(ActionEvent e) {
  	if (e.getSource() == newView) {
		Frame frame = new ERFrame();
		frame.pack();
		frame.show();
		}
	else if (e.getSource() == demoRequest)
		demonstrateCreation();
	}

  public void itemStateChanged(ItemEvent e) {
  	spy.setSpying(spyingCheckbox.getState());
  	}

  private void demonstrateCreation() {
  	EREntity student = panel.newEntity(30,30,60,40);
  	student.setText("Student");
 	student.setForeground(Color.red);
   	ERAttribute name = panel.newAttribute(150,25,student); 
   	name.setText("Name");  	
   	EREntity course = panel.newEntity(260,30,60,40);
  	course.setText("Course");
 	course.setForeground(Color.red);
 	ERRelationship enrolled = panel.newRelationship(140,160,60,40);
 	enrolled.setText("Enrolled");
 	enrolled.setForeground(Color.green);
 	ERLink  link1 = panel.newLink(student,enrolled);
 	ERLink link2 = panel.newLink(enrolled,course);
 	panel.addTransactionListener(spy);
  	}
  
  private ERPanel panel = new ERPanel();
  private Checkbox spyingCheckbox = new Checkbox("spy");
  private ERSpy spy = new ERSpy();
  private static int frameCount = 1;
  private MenuItem newView = new MenuItem("New ER View");
  private MenuItem demoRequest = new MenuItem("Demo");

  }
