package erTool;

import bbw.*;
import bbw.shape.*;
import java.awt.Dimension;

public class ERAttribute extends TextFieldShape {

  public String[] getEditableProperties() {
	String[] ss = { "font" };
	return ss;
	}
  public Dimension getMinimumSize() {
	return new Dimension(60,30);
	}
  }
