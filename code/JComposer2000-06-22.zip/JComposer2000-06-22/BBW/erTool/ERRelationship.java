package erTool;

import java.beans.*;
import bbw.*;
import bbw.constraint.*;
import bbw.shape.*;
import java.awt.*;
import java.util.Vector;

public class ERRelationship extends DiamondShape implements PropertyChangeListener{
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y); // This fails with NullPointer if we define preferredSize()
  	text.init(container,x,y);
  	text.setHandlesVisible(false);
  	text.addPropertyChangeListener(this);
  	pc1.init(leftHandle,topHandle);
  	pc1.getPin().setVisible(false);
  	pc2.init(bottomHandle,rightHandle);
  	pc2.getPin().setVisible(false);
	eqLeft.init(pc1.getPin(),text.getOriginHandle());
 	eqRight.init(pc2.getPin(),text.getCornerHandle());
  	ERPanel er = (ERPanel) getTopPanel();
  	er.fireERChange(new ERNewRelationshipEvent(er,this));
  	}

  public void propertyChange(PropertyChangeEvent evt) {
	// Simply pass the event on with a new source
	firePropertyChange(evt.getPropertyName(),evt.getOldValue(),evt.getNewValue());
  	}

  public void dispose() {
  	text.dispose();
  	pc1.dispose();
  	pc2.dispose();
  	// eqLeft.dispose(); No need, as just reference things that are also disposed of
  	// eqRight.dispose();
  	super.dispose();
  	}
  
  public String getText() {
  	return text.getText();
  	}
  
  public void setText(String t) {
  	text.setText(t);
  	}
  
  public String[] getEditableProperties() {
	String[] ss = { "text" };
	return ss;
	}

  protected TextFieldShape text = new TextFieldShape();
  protected ProportionalConstraint pc1 = new ProportionalConstraint();
  protected ProportionalConstraint pc2 = new ProportionalConstraint();
  protected EqualityConstraint eqLeft = new EqualityConstraint();
  protected EqualityOnResize eqRight = new EqualityOnResize();
  }
