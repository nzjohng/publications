package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

public class ERNewRelationshipEvent extends ERChangeEvent{
  public ERNewRelationshipEvent(Object source, ERRelationship relationship) {
  	super(source);
  	this.relationship = relationship;
  	}
  
  public ERRelationship getRelationship() {
  	return relationship;
  	}
  	
  protected ERRelationship relationship;
  }
