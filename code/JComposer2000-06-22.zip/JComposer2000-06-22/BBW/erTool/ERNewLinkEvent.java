package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

import bbw.*;

public class ERNewLinkEvent extends ERChangeEvent{
  public ERNewLinkEvent(Object source, ERLink link, Handle from, Handle to) {
  	super(source);
  	this.link = link;
  	this.from = from;
  	this.to = to;
  	}
  
  public ERLink getLink() {
  	return link;
  	}
  	
  public Handle getFrom() {
  	return from;
  	}
  	
  public Handle getTo() {
  	return to;
  	}
  	
  protected ERLink link;
  protected Handle from, to;
  }
