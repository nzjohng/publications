package erTool;

import java.beans.*;
import bbw.*;
import bbw.constraint.*;
import bbw.shape.*;
import java.awt.*;

public class ERLink extends CompositeConnector {
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
  	super.init(container,x,y);
	line.init(this,x,y);
  	line.setHandlesVisible(false);
  	eq1.init(getOriginHandle(),line.getOriginHandle());
  	eq2.init(getCornerHandle(),line.getCornerHandle());

  	text.init(this,10,10);
  	text.setText("Role");
  	text.setWidth(60);
  	text.setHeight(20);
  	text.setHandlesVisible(false);
  	text.addPropertyChangeListener(this);
  	eq3.init(getMiddleHandle(),text.getTopRightHandle());

	choice.init(this,10,10);
  	buildChoiceShape(choice);
  	choice.setHandlesVisible(false);
  	choice.addPropertyChangeListener(this);
  	eq4.init(getMiddleHandle(),choice.getOriginHandle());

  	ERPanel er = (ERPanel) getTopPanel();
  	er.fireERChange(new ERNewLinkEvent(er,this,from,to));
  	}
  	
  public String getArity() {
  	return choice.getSelectedItem();
  	}
  	
  public void setArity(String item) {
  	choice.setSelectedItem(item);
  	}
  	
  public String getText() {
  	return text.getText();
  	}
  	
  public void setText(String t) {
  	text.setText(t);
  	}
  	
  protected void buildChoiceShape(ChoiceShape ch) {
  	ch.setWidth(60);
  	ch.setHeight(20);
	ch.addItem("0:1");
	ch.addItem("1:1");
	ch.addItem("0:n");
	ch.addItem("1:n");
  	}
  
  public void propertyChange(PropertyChangeEvent evt) {
	// Map the events from the choice to "arity"
	if (evt.getSource() == choice)
		firePropertyChange("arity",evt.getOldValue(),evt.getNewValue());
	else
		firePropertyChange(evt.getPropertyName(),evt.getOldValue(),evt.getNewValue());
 	}

  public String[] getEditableProperties() {
	String[] ss = { "text", "arity" };
	return ss;
	}

  protected LineShape line = new LineShape();
  protected ChoiceShape choice = new ChoiceShape();
  protected TextShape text = new TextShape();
  protected EqualityConstraint eq1 = new EqualityConstraint();
  protected EqualityOnResize eq2 = new EqualityOnResize();
  protected EqualityMoveConstraint eq3 = new EqualityMoveConstraint();
  protected EqualityMoveConstraint eq4 = new EqualityMoveConstraint();
  }