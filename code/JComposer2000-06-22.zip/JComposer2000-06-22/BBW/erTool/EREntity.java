package erTool;

import java.beans.*;
import bbw.*;
import bbw.constraint.*;
import bbw.shape.*;
import java.awt.*;
import java.util.Vector;

public class EREntity extends BoxShape implements PropertyChangeListener{
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	text.init(container,x,y);
  	text.setCompositeMember(true);
  	text.setReshapeEnabled(false);
  	text.setHandlesVisible(false);
  	text.addPropertyChangeListener(this);
  	coc1.init(originHandle,text.getOriginHandle(),new BBWVector(OFFSET,OFFSET));
  	coc2.init(cornerHandle,text.getCornerHandle(),new BBWVector(-OFFSET,-OFFSET));
  	//setSelected(true);

  	ERPanel er = (ERPanel) getTopPanel();
  	er.fireERChange(new ERNewEntityEvent(er,this));
  	}
  
  public void propertyChange(PropertyChangeEvent evt) {
	// Simply pass the event on with a new source
	firePropertyChange(evt.getPropertyName(),evt.getOldValue(),evt.getNewValue());
  	}

  public void dispose() {
  	text.dispose();
  	// coc1.dispose(); - No need, as only reference this anyway
   	// coc2.dispose();
   	super.dispose();
	}
  
  public String getText() {
  	return text.getText();
  	}
  
  public void setText(String t) {
  	text.setText(t);
  	}
  
  public Dimension minimumSize() {
	return new Dimension(40,30);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text" };
	return ss;
	}

  protected TextFieldShape text = new TextFieldShape();
  protected EqualityConstraint coc1 = new EqualityConstraint();
  protected EqualityOnResize coc2 = new EqualityOnResize();
  protected static final int OFFSET = 5;
  }
