package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

public abstract class ERChangeEvent extends java.util.EventObject{
  public ERChangeEvent(Object source) {
  	super(source);
  	}
  }
