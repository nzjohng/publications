package erTool;

import bbw.*;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.controller.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ERPanel extends BBWGeneralPanel implements ActionListener, ItemListener{
	
  public ERPanel() {
	setLayout(new BorderLayout());
	add("Center", panel);
	
	Panel controls = new Panel();
	controls.setLayout(new FlowLayout());
	controls.add(new Label("ER Element:"));

	String[] jcPackageName = {"erTool" };
	ToolManager.addToolPackageNames(jcPackageName);
	createTools();
	controls.add(toolChoice);
/*	controls.add(debugPropagation);
	debugPropagation.addItemListener(this);
	controls.add(displayShapes);
	displayShapes.addActionListener(this);
*/
	add("South", controls);
	panel.setController((Controller)controllers.elementAt(0));
	}
  
 protected void createTools() {
	PopupController[] popupControllers = {
		new HidePopupController(),
		new ShowPopupController(),
		new PropSheetPopupController(),
		new DisposePopupController()
		};
	PopupManager.defineMenuItemsOfStandardPopup(panel,popupControllers);

	addShapeTool("Entity", "EREntity");
	addConnectorShapeTool("Attribute","LineShape","ERAttribute");
	addShapeTool("Relationship","ERRelationship");
	addConnectorTool("Link", "ERLink");
	MoveController mover = new MoveController(panel.getTopContainer());
	panel.setMoveController(mover);
	addBuiltTool("Move", mover);
	ResizeController resizer = new ResizeController(panel.getTopContainer());
  	addBuiltTool("Resize",resizer);
	panel.setResizeController(resizer);
	}
  	
  public EREntity newEntity(int x, int y, int width, int height) {
  	EREntity entity = new EREntity();
  	entity.init(panel.getTopContainer(),x,y);
  	entity.setSize(width,height);
  	return entity;
  	}
  
  public ERRelationship newRelationship(int x, int y, int width, int height) {
  	ERRelationship reln = new ERRelationship();
  	reln.init(panel.getTopContainer(),x,y);
  	reln.setSize(width,height);
  	return reln;
  	}
  
  public ERAttribute newAttribute(int x, int y, RectangularShape entityOrRelationship) {
  	BBWContainer container = panel.getTopContainer();
	ERAttribute attribute = new ERAttribute();
  	attribute.init(container,x,y);
	LineShape line = new LineShape();
	line.init(container,x,y);
	new Connector(line,entityOrRelationship.getMiddleHandle(),attribute.getMiddleHandle(),container);
  	return attribute;
  	}
  
  public ERLink newLink(RectangularShape entityOrRelationship1,RectangularShape entityOrRelationship2) {
  	ERLink link = new ERLink();
  	new Connector(link,entityOrRelationship1.getMiddleHandle(),entityOrRelationship2.getMiddleHandle(),panel.getTopContainer());
  	return link;
  	}
  
  public void itemStateChanged(ItemEvent e) {
  	PropertyChangeSupport2.setDebug(debugPropagation.getState());
  	}

  public void actionPerformed(ActionEvent e) {
  	panel.displayShapes();
  	}

  public synchronized void addERChangeListener(ERListener listener) {
  	erListeners.addElement(listener);
  	}
  	
  public synchronized void removeERChangeListener(ERListener listener) {
  	erListeners.removeElement(listener);
  	}
  	
  public void fireERChange(ERChangeEvent ev) {
	// This is NOT thread-safe
	Enumeration tell = erListeners.elements();
	while (tell.hasMoreElements())
		((ERListener) tell.nextElement()).erChange(ev);
	}
	
  private Checkbox debugPropagation = new Checkbox("Debug Propagation");
  private Button displayShapes = new Button("Display Shapes");
  private Vector erListeners = new Vector();
  }
