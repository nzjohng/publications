package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

import bbw.*;

public class ERNewAttributeEvent extends ERChangeEvent{
  public ERNewAttributeEvent(Object source, ERAttribute attribute, Handle from) {
  	super(source);
  	this.attribute = attribute;
  	this.from = from;
  	}
  
  public ERAttribute getAttribute() {
  	return attribute;
  	}
  	
  public Handle getFrom() {
  	return from;
  	}
  	
  protected ERAttribute attribute;
  protected Handle from;
  }
