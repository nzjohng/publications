package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

public class ERNewEntityEvent extends ERChangeEvent{
  public ERNewEntityEvent(Object source, EREntity entity) {
  	super(source);
  	this.entity = entity;
  	}
  
  public EREntity getEntity() {
  	return entity;
  	}
  	
  protected EREntity entity;
  }
