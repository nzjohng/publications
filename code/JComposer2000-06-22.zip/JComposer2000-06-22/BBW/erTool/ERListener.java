package erTool;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/ER.
*/

public interface ERListener extends java.util.EventListener {
  public abstract void erChange(ERChangeEvent evt);
  }
