import erTool.*;
import java.beans.*;
import bbw.*;
import java.awt.*;

class ERSpy implements BBWTransactionListener, ERListener, PropertyChangeListener {
  // Demonstrates grabbing events from BBW/ER
  public void setSpying(boolean spying) {
  	this.spying = spying;
  	}
  
  public void transaction(BBWTransactionEvent evt) {
  	if (spying)
  		System.out.println(evt);
  	}
  
  public void erChange(ERChangeEvent evt) {
   	if (spying)
  		System.out.println(evt);
 	if (evt instanceof ERNewEntityEvent)
 		((ERNewEntityEvent) evt).getEntity().addPropertyChangeListener(this);
  	else if (evt instanceof ERNewRelationshipEvent)
 		((ERNewRelationshipEvent) evt).getRelationship().addPropertyChangeListener(this);
  	else if (evt instanceof ERNewAttributeEvent)
 		((ERNewAttributeEvent) evt).getAttribute().addPropertyChangeListener(this);
  	else if (evt instanceof ERNewLinkEvent)
 		((ERNewLinkEvent) evt).getLink().addPropertyChangeListener(this);
 	}

  public void propertyChange(PropertyChangeEvent evt) {
  	if (spying)
  		System.out.println(evt);
  	}

  private boolean spying = false;
  }
