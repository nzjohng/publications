import Uml.*;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;

public class UMLFrame extends Frame implements ActionListener{
  public UMLFrame() {
	setTitle("UMLTool"+(frameCount++));
	setLayout(new BorderLayout());
	add("Center", panel);
	MenuBar menuBar = new MenuBar();
	Menu viewMenu = new Menu("View");
	MenuItem mItem = new MenuItem("New UMLTool View");
	viewMenu.add(mItem);
	mItem.addActionListener(this);
	menuBar.add(viewMenu);
	setMenuBar(menuBar);
	addWindowListener(new JCFrameAdapter());
	}
  
  class JCFrameAdapter extends WindowAdapter{
  	public void windowClosing(WindowEvent e) {
  		dispose();
		liveFrames--;
		if (liveFrames <= 0)
			System.exit(0);
		}
  	}

  public void actionPerformed(ActionEvent e) {
  	Frame frame = new UMLFrame();
	frame.pack();
	frame.show();
	liveFrames++;
  	}

  protected static int frameCount = 1;
  protected static int liveFrames = 1;
  protected UMLPanel panel = new UMLPanel();
  }
