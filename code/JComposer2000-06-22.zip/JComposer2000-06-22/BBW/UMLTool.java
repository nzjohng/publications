import Uml.*;
import bbw.*;
import java.awt.*;

public class UMLTool extends java.applet.Applet {
  public void init() {
	Frame frame = new UMLFrame();
	frame.pack();
	frame.show();
	}
  public static void main(String argv[]) {
	Frame frame = new UMLFrame();
	frame.pack();
	frame.show();
	}
  }
