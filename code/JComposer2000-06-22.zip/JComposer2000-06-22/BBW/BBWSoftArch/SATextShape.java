package BBWSoftArch;

import bbw.Composite;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class SATextShape extends TextShape {
  public void init(BBWContainer container, int x, int y) {
 	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));

    BBWSoftArchPanel jc = (BBWSoftArchPanel) getTopPanel();
    jc.fireSAChange(new SANewTextEvent(jc,this));
    }

  public Dimension getMinimumSize() {
    return new Dimension(50,20);
    }             	    
 
  public String[] getEditableProperties() {
    String[] ss = { "text" };
    return ss;
    }

  }
