package BBWSoftArch;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;

public class SAAssocInfoLink extends CompositeConnector {
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
    super.init(container,x,y);
    this.from = from;
    this.to = to;

        setHandlesVisible(false);
        AbstractHandle[] handles = getHandles();
        for (int i = 0; i < handles.length; i++)
                handles[i].setVisible(false);
        getPopupHandle().setVisible(false);

    BBWSoftArchPanel sa = (BBWSoftArchPanel) getTopPanel();
    sa.fireSAChange(new SANewAssocInfoLinkEvent(sa,this));
    }

  public Handle getFrom() {
    return from;
    }

  public Handle getTo() {
    return to;
    }

  int[] points;

  public void paint(Graphics g)
  {
    super.paint(g);
    points = BBWSoftArchPanel.calcLinePoints(getFrom(),getTo());
  }

  public boolean contains(int x, int y)
  {
    boolean in = true;
    
  	if(points[0] > points[2]) {
  		if(!(x > points[2] && x < points[0]))
  			in = false;
  	} else {
  		if(!(x > points[0] && x < points[2]))
  			in = false;
  	}
  	
  	if(points[1] > points[3]) {
  		if(!(y > points[3] && y < points[1]))
  			in = false;
  	} else {
  		if(!(y > points[1] && y < points[3]))
  			in = false;
	}
	
  	return in;
  }

    
  protected Handle from, to;
  
}
