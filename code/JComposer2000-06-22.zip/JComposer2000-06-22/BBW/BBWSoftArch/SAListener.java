package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public interface SAListener extends java.util.EventListener {
  public abstract void saChange(SAChangeEvent evt);
  }
