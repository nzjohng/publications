package BBWSoftArch;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;

public class SARefinementLink extends CompositeConnector {
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
    super.init(container,x,y);
    this.from = from;
    this.to = to;

        setHandlesVisible(true);
        AbstractHandle[] handles = getHandles();
        for (int i = 0; i < handles.length; i++)
                handles[i].setVisible(false);
        getPopupHandle().setVisible(true);


        annotation.init(this,10,10);
        annotation.setSize(30,20);
        annotation.setFont(new Font("Helvetica",0,10));
        annotation.setText("");
        annotation.setHandlesVisible(false);
        eq1.init(getMiddleHandle(),annotation.getLeftHandle());
        annotation.addPropertyChangeListener(this);

    BBWSoftArchPanel sa = (BBWSoftArchPanel) getTopPanel();
    sa.fireSAChange(new SANewRefinementLinkEvent(sa,this));
    }


  public Handle getFrom() {
    return from;
    }

  public Handle getTo() {
    return to;
    }

	int[] points;

	public void paint(Graphics g)
	{
		points = BBWSoftArchPanel.calcLinePoints(getFrom(),getTo());
		int a = points[2]-points[0];
		int b = points[3]-points[1];
		
		g.setColor(getForeground());

        // draw dashed line...
        double len = Math.sqrt(a * a + b * b);

        double dx = (points[2]-points[0]) / len;
        double dy = (points[3]-points[1]) / len;

        double x = (double) points[0];
        double y = (double) points[1];

        double step = 5.0;
        double count = 0;

        while(count <= len) {
            double nx = x + dx * step;
            double ny = y + dy * step;
		    g.drawLine((int) x, (int) y, (int) nx, (int) ny);
            x = nx + dx * step;
            y = ny + dy * step;
            count += step*2;		    
        }

        // draw arrow
		int points2[] = BBWSoftArchPanel.calcArrowPoints(points[0],points[1],points[2],points[3]);
		g.drawLine(points[2],points[3],points2[0],points2[1]);
		g.drawLine(points[2],points[3],points2[2],points2[3]);	
	}

  public boolean contains(int x, int y)
  {
    boolean in = true;
    
  	if(points[0] > points[2]) {
  		if(!(x > points[2] && x < points[0]))
  			in = false;
  	} else {
  		if(!(x > points[0] && x < points[2]))
  			in = false;
  	}
  	
  	if(points[1] > points[3]) {
  		if(!(y > points[3] && y < points[1]))
  			in = false;
  	} else {
  		if(!(y > points[1] && y < points[3]))
  			in = false;
	}
	
  	return in;
  }

  int abs(int a)
  {
	if(a < 0)
		return -a;
	else
		return a;
  }
  
  public String getAnnotation() {
        return annotation.getText();
        }
        
  public void setAnnotation(String newText) {
        annotation.setText(newText);
        }
        
  public void propertyChange(PropertyChangeEvent evt) {
        // Map the events from text and the choices
        super.propertyChange(evt);
        if (evt.getSource() == name) {
                if (evt.getPropertyName().equals("text"))
                        firePropertyChange("annotation",evt.getOldValue(),evt.getNewValue());
                }
        }


  public String getId()
  {
    return id;
  }
  
  public void setId(String value)
  {
    String old = id;
    this.id = value;
    firePropertyChange("id",old,value);
  }
  
  public String getRationale()
  {
    return rationale;
  }
  
  public void setRationale(String value)
  {
    String old = rationale;
    this.rationale = value;
    firePropertyChange("rationale",old,value);
  }
        
    public String[] getEditableProperties() {
        String[] ss = { "id", "annotation", "rationale" };
            return ss;
        }

     
        
  protected TextShape annotation = new TextShape();
  protected EqualityMoveConstraint eq1 = new EqualityMoveConstraint();
  protected Handle from, to;
  protected String id = "";
  protected String rationale = "";
  
}
