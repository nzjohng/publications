package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewTextEvent extends SAChangeEvent {
  public SANewTextEvent(Object source, SATextShape shape) {
  	super(source);
  	this.shape = shape;
  	}
  
  public SATextShape getTextShape() {
  	return shape;
  	}
  	
  protected SATextShape shape;
  }
