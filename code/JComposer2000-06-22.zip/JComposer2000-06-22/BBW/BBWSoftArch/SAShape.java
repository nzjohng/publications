package BBWSoftArch;

public interface SAShape
{
  public String[] getAppearanceProperties();
  
  public String getAppearanceValue(int index); 
  public void setAppearanceValue(int index, String value);
  public String[] getAppearanceValues(int index);
}
