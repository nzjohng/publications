package BBWSoftArch;

import bbw.Composite;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class SAAssocInfoShape extends TextShape implements SAShape {
  public void init(BBWContainer container, int x, int y) {
 	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));

    setAppearanceValue(ENTITY_SHAPE,getAppearanceValues(ENTITY_SHAPE)[0]); 
    setAppearanceValue(MULTIPLE_ENTITIES,getAppearanceValues(MULTIPLE_ENTITIES)[0]);

    BBWSoftArchPanel jc = (BBWSoftArchPanel) getTopPanel();
    jc.fireSAChange(new SANewAssocInfoEvent(jc,this));
    }

  public void paintBackGround(Graphics g) {
    if(getEntityShape().equals("event"))
        paintEvent(g);
    else if(getEntityShape().equals("data"))
        paintData(g);
    else if(getEntityShape().equals("control"))
        paintControl(g);
    else if(getEntityShape().equals("cache"))
        paintCache(g);
        
  }

  public void paintEvent(Graphics g)
  {
    Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    g.setColor(getForeground());
    g.drawLine(r.x+r.width-5, r.y, r.x+r.width-5, r.y+r.height-6);
    int points2[] = BBWSoftArchPanel.calcArrowPoints(r.x+width-5,r.y+r.height,r.x+width-5,r.y);
	g.drawLine(r.x+width-5,r.y,points2[0],points2[1]);
	g.drawLine(r.x+width-5,r.y,points2[2],points2[3]);
    g.drawOval(r.x+r.width-8,r.y+r.height-6,6,6);    
    }

  public void paintData(Graphics g)
  {
    Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    g.setColor(getForeground());
    g.drawLine(r.x+r.width-5, r.y, r.x+r.width-5, r.y+r.height-6);
    int points2[] = BBWSoftArchPanel.calcArrowPoints(r.x+width-5,r.y+r.height,r.x+width-5,r.y);
	g.drawLine(r.x+width-5,r.y,points2[0],points2[1]);
	g.drawLine(r.x+width-5,r.y,points2[2],points2[3]);
    g.fillOval(r.x+r.width-8,r.y+r.height-6,6,6);    
  }

  public void paintControl(Graphics g)
  {
 
  }

  public void paintCache(Graphics g)
  {
   Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    g.setColor(getForeground());
    int size = r.height-4;
    int offset = (int) (size/4);
    g.fillRect(r.x+r.width-size,r.y+r.height-size,size,size);
    g.setColor(getFillColor());
    g.fillRect(r.x+r.width-size-offset,r.y+r.height-size-offset,size,size);
    g.setColor(getForeground());
    g.drawRect(r.x+r.width-size-offset,r.y+r.height-size-offset,size,size);
  }

  public Dimension getMinimumSize() {
    return new Dimension(60,40);
    }
        
  public String getId() {
    return id;
    }
    
  public void setId(String newText) {
    String old = id;
    this.id = newText;
    if (firePropertyChange("id",old,id))
        repaint();
    }
    
  public String getAnnotation() {
    return getText();
    }

  public void setAnnotation(String newText) {
	setText(newText);
  }
  	  
  public String getType() {
    return type;
    }
    
  public void setType(String newText) {
    String old = type;
    this.type = newText;
    if (firePropertyChange("type",old,type))
        repaint();
    }
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parentName
    if (evt.getPropertyName().equals("text"))
            firePropertyChange("annotation",evt.getOldValue(),evt.getNewValue());

    else
        super.propertyChange(evt);
    }

    static final int ENTITY_SHAPE = 0;
  static final int MULTIPLE_ENTITIES = 1;

  public String getEntityShape()
  {
	return entity_shape;
  }

  public void setEntityShape(String value)
  {
    String old = entity_shape;
	entity_shape = value;
	firePropertyChange("entityShape",old,value);
  }

  public String getMultipleEntities()
  {
	return multiple;
  }

  public void setMultipleEntities(String value)
  {
    String old = multiple;
	multiple = value;
	firePropertyChange("multipleEntities",old,value);
  }  

  static String[] names = { "Assoc Info kind", "Multiple exchange" };

  public String[] getAppearanceProperties()
  {
     return names;
  }
  
  public String getAppearanceValue(int index) {
    switch(index) {
    case ENTITY_SHAPE : return getEntityShape();
    case MULTIPLE_ENTITIES : return getMultipleEntities();
    }

    return "";
  }
  
  public void setAppearanceValue(int index, String value) {
   switch(index) {
	case ENTITY_SHAPE : setEntityShape(value); return;
	case MULTIPLE_ENTITIES : setMultipleEntities(value); return;
   }
  }
  
  public String[] getAppearanceValues(int index) {
   switch(index) {
   case ENTITY_SHAPE :
    String ss0[] = { "data", "control", "event", "cache" };
    return ss0;
   case MULTIPLE_ENTITIES :
    String ss1[] = { "single", "multiple" };
    return ss1;
  }
   return new String[0];
  }
 
  public String[] getEditableProperties() {
    String[] ss = { "id", "annotation", "type" };
    return ss;
    }

  protected String id = "";
  protected String type = "";

  protected String entity_shape;
  protected String multiple;

  }
