package BBWSoftArch;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.controller.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class BBWSoftArchPanel extends BBWGeneralPanel implements ActionListener, ItemListener{
    
  public BBWSoftArchPanel() {
    setLayout(new BorderLayout());
//ScrollPane pane = new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
//pane.add(panel);
//add("Center",pane);
    add("Center", panel);
    
    controls.setLayout(new FlowLayout());
    controls.add(new Label("Shape:"));
    String[] saPackageName = {"BBWSoftArch" };
    ToolManager.addToolPackageNames(saPackageName);
    createTools(tools );
    controls.add(toolChoice);
    
    controls.add(debugPropagation);
    debugPropagation.addItemListener(this);
    controls.add(displayShapes);
    displayShapes.addActionListener(this);
    add("South", controls);
    panel.setController((Controller)controllers.elementAt(0));
    }
  
  protected void createTools(String[] tools) {
    PopupController[] popupControllers = {
        new HidePopupController(),
        new ShowPopupController(),
        new PropSheetPopupController(),
        new DisposePopupController()
        };
    PopupManager.defineMenuItemsOfStandardPopup(panel,popupControllers);

    for (int i = 0; i < tools.length; i++)
        addTool(tools[i]);
    addConnectorTool("SAAssocLink", "SAAssocLink");
    addConnectorTool("SARefinementLink", "SARefinementLink");
    addConnectorTool("SAAssocInfoLink", "SAAssocInfoLink");
    MoveController mover = new MoveController(panel.getTopContainer());
    panel.setMoveController(mover);
    controllers.addElement(mover);
    toolChoice.addItem("Move");
    ResizeController resizer = new ResizeController(panel.getTopContainer());
    controllers.addElement(resizer);
    panel.setResizeController(resizer);
    toolChoice.addItem("Resize");
    controllers.addElement(new AdjustController(panel.getTopContainer()));
    toolChoice.addItem("Adjust");
    }
    
  public void itemStateChanged(ItemEvent e) {
    PropertyChangeSupport2.setDebug(debugPropagation.getState());
    }

  public void actionPerformed(ActionEvent e) {
    panel.displayShapes();
    }

  public synchronized void addSAChangeListener(SAListener listener) {
    saListeners.addElement(listener);
    }
    
  public synchronized void removeSAChangeListener(SAListener listener) {
    saListeners.removeElement(listener);
    }
    
  public void fireSAChange(SAChangeEvent ev) {
    // This is NOT thread-safe
    Enumeration tell = saListeners.elements();
    while (tell.hasMoreElements())
        ((SAListener) tell.nextElement()).saChange(ev);
    }
      
  public SACompShape newComp(int x, int y, int width, int height) {
    SACompShape s = new SACompShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }

  public SAEnclosingShape newEnclosing(int x, int y, int width, int height) {
    SAEnclosingShape s = new SAEnclosingShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }

  public SAAssocShape newAssoc(int x, int y, int width, int height) {
    SAAssocShape s = new SAAssocShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }

  public SAAssocInfoShape newAssocInfo(int x, int y, int width, int height) {
    SAAssocInfoShape s = new SAAssocInfoShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }

  public SATextShape newText(int x, int y, int width, int height) {
    SATextShape s = new SATextShape();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }

  public SAAssocLink newAssocLink(RectangularShape from, RectangularShape to) {
    SAAssocLink shape = new SAAssocLink();
    Handle fromh = from.getMiddleHandle();
    Handle toh = to.getMiddleHandle();
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }

   public SARefinementLink newRefinementLink(RectangularShape from, RectangularShape to) {
    SARefinementLink shape = new SARefinementLink();
    Handle fromh = from.getMiddleHandle();
    Handle toh = to.getMiddleHandle();
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }

   public SAAssocInfoLink newAssocInfoLink(RectangularShape from, RectangularShape to) {
    SAAssocInfoLink shape = new SAAssocInfoLink();
    Handle fromh = from.getMiddleHandle();
    Handle toh = to.getMiddleHandle();
    new Connector(shape,fromh,toh,from.getParent());
    return shape;
    }

	public static int[] calcLinePoints(Handle from, Handle to)
	{
 	Rectangle sr = ((RectangularShape) from.getOwner()).getBounds();
	Rectangle er = ((RectangularShape) to.getOwner()).getBounds();

	int sx = (int) (sr.getX()+sr.getWidth()/2);
	int sy = (int) (sr.getY()+sr.getHeight()/2);
	int ex = (int) (er.getX()+er.getWidth()/2);
	int ey = (int) (er.getY()+er.getHeight()/2);

	int dx = ex - sx;
	int dy = ey - sy;
	
		double y = (double) sy;
		double x = (double) sx;
		double inc_y = 2.0;
		double inc_x = 2.0;
		int steps = 0;
		
		if(abs(dx) > abs(dy)) {
			inc_y = ((double) abs(dy))/((double) abs(dx))*2.0;
			steps = abs(dx)/2;
			if(sx > ex)
				inc_x = -2.0;
			if(sy > ey)
				inc_y = -inc_y;
		} else {
			inc_x = ((double) abs(dx))/((double) abs(dy))*2.0;
			steps = abs(dy)/2;
			if(sy > ey)
				inc_y = -2.0;
			if(sx > ex)
				inc_x = -inc_x;
		}

		int s = steps;
		while(s > 0) {
			if(!from.getOwner().contains((int) x,(int) y))
				break;
			y += inc_y;
			x += inc_x;
			s--;
		}
		int dx1 = (int) x; int dy1 = (int) y;

		x = (double) ex;
		y = (double) ey;
		s = steps;
		while(s > 0) {
			if(!to.getOwner().contains((int) x, (int) y))
				break;
			x -= inc_x;
			y -= inc_y;
			s--;
		}

		int points[] = new int[4];

		// line start/end
		points[0] = (int) dx1;
		points[1] = (int) dy1;
		points[2] = (int) x;
		points[3] = (int) y;		

		return points;
	}

	 static int abs(int a) {
		if(a > 0)
			return a;
		else
			return -a;
	}


	public static int[] calcHorizontalFromLinePoints(Handle from, Handle to)
	{
 		Rectangle sr = ((RectangularShape) from.getOwner()).getBounds();
		Rectangle er = ((RectangularShape) to.getOwner()).getBounds();

		int points[] = new int[4];

    	points[1] = points[3] = (int) (sr.getY()+sr.getHeight()/2);

		if(sr.getX() > er.getX()) {
			points[0] = (int) sr.getX();
			points[2] = (int) (er.getX()+er.getWidth());
		} else {
			points[0] = (int) (sr.getX()+sr.getWidth());
			points[2] = (int) er.getX();
		}	

		return points;
    
    }

	public static int[] calcHorizontalToLinePoints(Handle from, Handle to)
	{
 		Rectangle sr = ((RectangularShape) from.getOwner()).getBounds();
		Rectangle er = ((RectangularShape) to.getOwner()).getBounds();

		int points[] = new int[4];

    	points[1] = points[3] = (int) (er.getY()+er.getHeight()/2);

		if(sr.getX() > er.getX()) {
			points[0] = (int) sr.getX();
			points[2] = (int) (er.getX()+er.getWidth());
		} else {
			points[0] = (int) (sr.getX()+sr.getWidth());
			points[2] = (int) er.getX();
		}	

		return points;
    
    }

	public static int[] calcVerticalFromLinePoints(Handle from, Handle to)
	{
 		Rectangle sr = ((RectangularShape) from.getOwner()).getBounds();
		Rectangle er = ((RectangularShape) to.getOwner()).getBounds();

		int points[] = new int[4];

    	points[0] = points[2] = (int) (sr.getX()+sr.getWidth()/2);

		if(sr.getY() > er.getY()) {
			points[1] = (int) sr.getY();
			points[3] = (int) (er.getY()+er.getHeight());
		} else {
			points[1] = (int) (sr.getY()+sr.getHeight());
			points[3] = (int) er.getY();
		}	

		return points;
    
    }

	public static int[] calcVerticalToLinePoints(Handle from, Handle to)
	{
 		Rectangle sr = ((RectangularShape) from.getOwner()).getBounds();
		Rectangle er = ((RectangularShape) to.getOwner()).getBounds();

		int points[] = new int[4];

    	points[0] = points[2] = (int) (er.getX()+er.getWidth()/2);

		if(sr.getY() > er.getY()) {
			points[1] = (int) sr.getY();
			points[3] = (int) (er.getY()+er.getHeight());
		} else {
			points[1] = (int) (sr.getY()+sr.getHeight());
			points[3] = (int) er.getY();
		}	

		return points;
    
    }

	public static int[] calcArrowPoints(int sx, int sy, int ex, int ey)
	{
	double basePtX, basePtY;	// The point at the middle of the base of the arrowhead.
	double a, b, lineLength;
	int ArrowLength = 10, ArrowWidth = 5;
	// a,b,c are the coefficients in the equation of the line through the two points start and finish.
	// This equation is ax + by + c = 0. We then use these to get direction vectors for the arc and
	// a perpendicular to the arc. These direction vectors are used to find the other two	points
	// of the arrowhead by first going back along the arc, and then shooting out either side.

	a = ey - sy;
	b = sx - ex;

	lineLength = Math.sqrt(a * a + b * b);
	a = a / lineLength;	// Normalise a and b to pixel units.
	b = b / lineLength;

	// Go back (ArrowLength) pixels along the arc.
	basePtX = ex + b * ArrowLength;
	basePtY = ey - a * ArrowLength;
	int points[] = new int[4];
	points[0] = (int)Math.round(basePtX + a * ArrowWidth);
	points[1] = (int)Math.round(basePtY + b * ArrowWidth);
	points[2] = (int)Math.round(basePtX - a * ArrowWidth);
	points[3] = (int)Math.round(basePtY - b * ArrowWidth);

	return points;
	}

	
  protected static int frameCount = 1;
  protected Panel controls = new Panel();
  protected Checkbox debugPropagation = new Checkbox("Debug Propagation");
  protected Button displayShapes = new Button("Display Shapes");
  protected String[] tools = {
        "SACompShape",
        "SAAssocShape",
        "SAAssocInfoShape",
        "SAEnclosingShape" };
  private Vector saListeners = new Vector();
  }

  
