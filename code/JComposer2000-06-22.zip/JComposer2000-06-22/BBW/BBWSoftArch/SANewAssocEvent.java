package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewAssocEvent extends SAChangeEvent {
  public SANewAssocEvent(Object source, SAAssocShape shape) {
  	super(source);
  	this.shape = shape;
  	}
  
  public SAAssocShape getAssocShape() {
  	return shape;
  	}
  	
  protected SAAssocShape shape;
  }
