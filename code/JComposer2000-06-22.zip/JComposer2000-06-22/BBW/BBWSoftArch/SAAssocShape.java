package BBWSoftArch;

import bbw.Composite;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class SAAssocShape extends TextShape implements SAShape {
  public void init(BBWContainer container, int x, int y) {
 	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));

  	setAppearanceValue(ENTITY_SHAPE,getAppearanceValues(ENTITY_SHAPE)[0]);

    BBWSoftArchPanel jc = (BBWSoftArchPanel) getTopPanel();
    jc.fireSAChange(new SANewAssocEvent(jc,this));
    }

  public void paintBackGround(Graphics g) {
    if(getAppearanceValue(ENTITY_SHAPE).equals("node"))
        paintNode(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("horizontal bus"))
        paintHorizontalBus(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("vertical bus"))
        paintVerticalBus(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("network"))
        paintNetwork(g);
  }

  public void paintNode(Graphics g) {
    // filled oval, possibly shadded
    Rectangle r = normalised();

    
        g.setColor(getFillColor());
        g.fillOval(r.x, r.y, r.width, r.height);
        //super.paint(g);
        g.setColor(getForeground());
        g.drawOval(r.x, r.y, r.width, r.height);
    } 

  public void paintHorizontalBus(Graphics g) {
    // two horizontal lines
    Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    g.setColor(getForeground());
    g.drawLine(r.x, r.y, r.x+r.width, r.y);
    g.drawLine(r.x, r.y+r.height, r.x+r.width, r.y+r.height);
    }

   public void paintVerticalBus(Graphics g) {
    // two vertical lines
    Rectangle r = normalised();
    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    g.setColor(getForeground());
    g.drawLine(r.x, r.y, r.x, r.y+r.height);
    g.drawLine(r.x+r.width, r.y, r.x+r.width, r.y+r.height);
    }

  public void paintNetwork(Graphics g) {
    // "network" blob...
    Rectangle r = normalised();

    Polygon poly = new Polygon();
    poly.addPoint(r.x,r.y);
    poly.addPoint(r.x+(int) (r.width*0.33),r.y+(int) (r.height*0.15));
    poly.addPoint(r.x+(int) (r.width*0.6),r.y+(int) (r.height*0.1));
    poly.addPoint(r.x+(int) (r.width*0.75),r.y+(int) (r.height*0.2));
    poly.addPoint(r.x+(int) (r.width*0.9),r.y+(int) (r.height*0.05));
    poly.addPoint(r.x+(int) (r.width*0.85),r.y+(int) (r.height*0.35));
    poly.addPoint(r.x+(int) (r.width*0.99),r.y+(int) (r.height*0.5));
    poly.addPoint(r.x+(int) (r.width*0.8),r.y+(int) (r.height*0.6));
    poly.addPoint(r.x+(int) (r.width*0.99),r.y+(int) (r.height*0.99));
    poly.addPoint(r.x+(int) (r.width*0.55),r.y+(int) (r.height*0.85));
    poly.addPoint(r.x+(int) (r.width*0.3),r.y+(int) (r.height*0.95));
    poly.addPoint(r.x+(int) (r.width*0.1),r.y+(int) (r.height*0.85));
    poly.addPoint(r.x+(int) (r.width*0.3),r.y+(int) (r.height*0.75));
    poly.addPoint(r.x+(int) (r.width*0.05),r.y+(int) (r.height*0.55));
    poly.addPoint(r.x+(int) (r.width*0.25),r.y+(int) (r.height*0.37));
    poly.addPoint(r.x,r.y);
    
    g.setColor(getFillColor());
    g.fillPolygon(poly);
    g.setColor(getForeground());
    g.drawPolygon(poly);
  }


  public Dimension getMinimumSize() {
    return new Dimension(60,40);
    }
        
  public String getId() {
    return id;
    }
    
  public void setId(String newText) {
    String old = id;
    this.id = newText;
    if (firePropertyChange("id",old,id))
        repaint();
    }
    
  public String getAnnotation() {
    return getText();
    }

  public void setAnnotation(String newText) {
	setText(newText);
  }
  	  
  public String getType() {
    return type;
    }
    
  public void setType(String newText) {
    String old = type;
    this.type = newText;
    if (firePropertyChange("type",old,type))
        repaint();
    }
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parentName
    if (evt.getPropertyName().equals("text"))
         firePropertyChange("annotation",evt.getOldValue(),evt.getNewValue());
    else
        super.propertyChange(evt);
    }

  static final int ENTITY_SHAPE = 0;
  
  public String getEntityShape()
  {
	return entity_shape;
  }

  public void setEntityShape(String value)
  {
    String old = entity_shape;
	entity_shape = value;
	firePropertyChange("entityShape",old,value);
  }

  static String[] names = { "Assoc kind" };

  public String[] getAppearanceProperties()
  {
     return names;
  }
  
  public String getAppearanceValue(int index) {
    switch(index) {
    case ENTITY_SHAPE : return getEntityShape();
    }

    return "";
  }
  
  public void setAppearanceValue(int index, String value) {
   switch(index) {
	case ENTITY_SHAPE : setEntityShape(value); return;
   }
  }
  
  public String[] getAppearanceValues(int index) {
   switch(index) {
   case ENTITY_SHAPE :
    String ss0[] = { "node", "horizontal bus", "vertical bus", "network" };
    return ss0;
   }

   return new String[0];
  }
 
  public String[] getEditableProperties() {
    String[] ss = { "id", "annotation", "type" };
    return ss;
    }

  protected String id = "";
  protected String type = "";
  
    protected String entity_shape;
  }
