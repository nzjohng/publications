package BBWSoftArch;

import bbw.constraint.*;
import bbw.shape.*;
import java.beans.*;
import bbw.*;
import java.awt.*;

public class SAAssocLink extends CompositeConnector implements SAShape {
  public void init(BBWContainer container, int x, int y, Handle from, Handle to) {
    super.init(container,x,y);
    this.from = from;
    this.to = to;

        setHandlesVisible(false);
        AbstractHandle[] handles = getHandles();
        for (int i = 0; i < handles.length; i++)
                handles[i].setVisible(false);
        getPopupHandle().setVisible(false);

        annotation.init(this,10,10);
        annotation.setSize(30,20);
        annotation.setFont(new Font("Helvetica",0,10));
        annotation.setText("");
        annotation.setHandlesVisible(false);
        eq1.init(getMiddleHandle(),annotation.getLeftHandle());
        annotation.addPropertyChangeListener(this);

    setAppearanceValue(ARROW_START,getAppearanceValues(ARROW_START)[0]); 
    setAppearanceValue(ARROW_END,getAppearanceValues(ARROW_END)[0]);
    setAppearanceValue(LINE_TYPE,getAppearanceValues(LINE_TYPE)[0]); 
    setAppearanceValue(ORIENTATION,getAppearanceValues(ORIENTATION)[0]);
    setAppearanceValue(LINE_THICKNESS,getAppearanceValues(LINE_THICKNESS)[0]);

    BBWSoftArchPanel sa = (BBWSoftArchPanel) getTopPanel();
    sa.fireSAChange(new SANewAssocLinkEvent(sa,this));
    }

  int[] points;
 
  public void paint(Graphics g)
  {
        super.paint(g);


       if(getOrientation().equals("normal"))
		    points = BBWSoftArchPanel.calcLinePoints(getFrom(),getTo());
       else if(getOrientation().equals("horizontal from"))
		    points = BBWSoftArchPanel.calcHorizontalFromLinePoints(getFrom(),getTo());
       else if(getOrientation().equals("horizontal to"))
		    points = BBWSoftArchPanel.calcHorizontalToLinePoints(getFrom(),getTo());
	   else if(getOrientation().equals("vertical from"))
		    points = BBWSoftArchPanel.calcVerticalFromLinePoints(getFrom(),getTo());
	   else if(getOrientation().equals("vertical to"))
		    points = BBWSoftArchPanel.calcVerticalToLinePoints(getFrom(),getTo());
		    
		g.setColor(getForeground());
		
		g.drawLine(points[0],points[1],points[2],points[3]);

        if(!getArrowEnd().equals("none")) {
		    int points2[] = BBWSoftArchPanel.calcArrowPoints(points[0],points[1],points[2],points[3]);
		    g.drawLine(points[2],points[3],points2[0],points2[1]);
		    g.drawLine(points[2],points[3],points2[2],points2[3]);
		}

        if(!getArrowStart().equals("none")) {
		    int points2[] = BBWSoftArchPanel.calcArrowPoints(points[2],points[3],points[0],points[1]);
		    g.drawLine(points[0],points[1],points2[0],points2[1]);
		    g.drawLine(points[0],points[1],points2[2],points2[3]);
		}

		// line thickness etc.
	

  }

  public boolean contains(int x, int y)
  {
    boolean in = true;

    if(getOrientation().equals("normal"))
		    points = BBWSoftArchPanel.calcLinePoints(getFrom(),getTo());
       else if(getOrientation().equals("horizontal from")) {
		    points = BBWSoftArchPanel.calcHorizontalFromLinePoints(getFrom(),getTo());
		    points[1] -= 5;
		    points[3] += 5;
       } else if(getOrientation().equals("horizontal to")) {
		    points = BBWSoftArchPanel.calcHorizontalToLinePoints(getFrom(),getTo());
		    points[1] -= 5;
		    points[3] += 5;
	   } else if(getOrientation().equals("vertical from")) {
		    points = BBWSoftArchPanel.calcVerticalFromLinePoints(getFrom(),getTo());
		    points[0] -= 5;
		    points[2] += 5;
	   } else if(getOrientation().equals("vertical to")) {
		    points = BBWSoftArchPanel.calcVerticalToLinePoints(getFrom(),getTo());
		    points[0] -= 5;
		    points[2] += 5;
       }
       
  	if(points[0] > points[2]) {
  		if(!(x > points[2] && x < points[0]))
  			in = false;
  	} else {
  		if(!(x > points[0] && x < points[2]))
  			in = false;
  	}
  	
  	if(points[1] > points[3]) {
  		if(!(y > points[3] && y < points[1]))
  			in = false;
  	} else {
  		if(!(y > points[1] && y < points[3]))
  			in = false;
	}
	
  	return in;
  }

  int abs(int a)
  {
	if(a < 0)
		return -a;
	else
		return a;
  }
	
  public Handle getFrom() {
    return from;
    }

  public Handle getTo() {
    return to;
    }
    
  public String getAnnotation() {
        return annotation.getText();
        }
        
  public void setAnnotation(String newText) {
        annotation.setText(newText);
        }
        
  public void propertyChange(PropertyChangeEvent evt) {
        // Map the events from text and the choices
        super.propertyChange(evt);
        if (evt.getSource() == annotation) {
                if (evt.getPropertyName().equals("text"))
                        firePropertyChange("annotation",evt.getOldValue(),evt.getNewValue());
                }
        }


  public String getId()
  {
    return id;
  }
  
  public void setId(String value)
  {
    String old = id;
    this.id = value;
    firePropertyChange("id",old,value);
  }
  
  public String getType()
  {
    return type;
  }
  
  public void setType(String value)
  {
    String old = type;
    this.type = value;
    firePropertyChange("type",old,value);
  }


  static final int ARROW_START = 0;
  static final int ARROW_END = 1;
  static final int ORIENTATION = 2;
  static final int LINE_TYPE = 3;
  static final int LINE_THICKNESS = 4;

  public String getArrowStart()
  {
	return arrow_start;
  }

  public void setArrowStart(String value)
  {
	String old = arrow_start;
	arrow_start = value;
	firePropertyChange("arrowStart",old,value);
  }

  public String getArrowEnd()
  {
	return arrow_end;
  }

  public void setArrowEnd(String value)
  {
	String old = arrow_end;
	arrow_end = value;
	firePropertyChange("arrowEnd",old,value);
  }

  public String getOrientation()
  {
	return orientation;
  }

  public void setOrientation(String value)
  {
	String old = orientation;
	orientation = value;
	firePropertyChange("orientation",old,value);
  }

  public String getLineType()
  {
	return line_type;
  }

  public void setLineType(String value)
  {
	String old = line_type;
	line_type = value;
	firePropertyChange("lineType",old,value);
  }

  public int getLineThickness()
  {
	return thickness;
  }

  public void setLineThickness(int value)
  {
    int old = thickness;
	thickness = value;
	firePropertyChange("entityShape",new Integer(old), new Integer(value));
  }
  
  static String[] names = { "Arrow at start", "Arrow at end", "Line orientation", "Line type", "Line Thickness" };

  public String[] getAppearanceProperties()
  {
     return names;
  }
  
  public String getAppearanceValue(int index) {
    switch(index) {
	case ARROW_START : return getArrowStart();
	case ARROW_END : return getArrowEnd();
	case ORIENTATION : return getOrientation();
	case LINE_TYPE : return getLineType();
	case LINE_THICKNESS : return ""+getLineThickness();
    }
    return "";
  }
  
  public void setAppearanceValue(int index, String value) {
   switch(index) {
	case ARROW_START : setArrowStart(value); return;
	case ARROW_END : setArrowEnd(value); return;
	case ORIENTATION : setOrientation(value); return;
	case LINE_TYPE : setLineType(value); return;
	case LINE_THICKNESS :  setLineThickness(Integer.parseInt(value)); return;
   }
  }
  
  public String[] getAppearanceValues(int index) {
   switch(index) {
   case ARROW_START :
    String ss0[] = { "none", "simple" };
    return ss0;
   case ARROW_END :
    String ss1[] = { "none", "simple" };
    return ss1;
   case ORIENTATION :
    String ss2[] = { "normal", "horizontal from", "horizontal to", "vertical from", "vertical to" };
    return ss2;
   case LINE_TYPE :
    String ss3[] = { "simple" };
    return ss3;
   case LINE_THICKNESS :
    String ss4[] = { "1", "2", "3", "4" };
    return ss4;
  }
    return new String[0];
  }
   
    public String[] getEditableProperties() {
        String[] ss = { "id", "annotation", "type" };
            return ss;
        }

     
        
  protected TextShape annotation = new TextShape();
  protected EqualityMoveConstraint eq1 = new EqualityMoveConstraint();
  protected Handle from, to;
  protected String id = "";
  protected String type = "";
  protected String arrow_start;
  protected String arrow_end;
  protected String orientation;
  protected String line_type;
  protected int thickness;
}
