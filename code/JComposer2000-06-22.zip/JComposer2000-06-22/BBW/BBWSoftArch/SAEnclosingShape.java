package BBWSoftArch;

import bbw.Composite;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class SAEnclosingShape extends Composite implements SAShape {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    container.add(this,0); // force to background so other comps on top of it
    middleHandle.setVisible(false);
    
    setAppearanceValue(ENTITY_SHAPE,getAppearanceValues(ENTITY_SHAPE)[0]); 
    setAppearanceValue(MULTIPLE_ENTITIES,getAppearanceValues(MULTIPLE_ENTITIES)[0]);

    BBWSoftArchPanel jc = (BBWSoftArchPanel) getTopPanel();
    jc.fireSAChange(new SANewEnclosingEvent(jc,this));
    }

  public void paint(Graphics g) {
    // erase background
    Rectangle r = normalised();

    //g.setColor(getFillColor());
    //g.fillOval(r.x, r.y, r.width, r.height);

    if(getAppearanceValue(ENTITY_SHAPE).equals("process entity"))
        paintProcessEntity(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("data entity"))
        paintDataEntity(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("data store"))
        paintDataStore(g);
    else if(getAppearanceValue(ENTITY_SHAPE).equals("ooa class"))
        paintOOAClass(g);
  }
  
  public void paintProcessEntity(Graphics g) {
    // filled oval, possibly shadded
    Rectangle r = normalised();

    if(getAppearanceValue(MULTIPLE_ENTITIES).equals("multiple")) {
        g.setColor(Color.gray);
        g.fillOval(r.x+SHADDOW_SIZE,r.y+SHADDOW_SIZE,r.width-SHADDOW_SIZE,r.height-SHADDOW_SIZE);
        g.setColor(getFillColor());
        g.fillOval(r.x, r.y, r.width-SHADDOW_SIZE, r.height-SHADDOW_SIZE);
        super.paint(g);
        g.setColor(getForeground());
        g.drawOval(r.x, r.y, r.width-SHADDOW_SIZE, r.height-SHADDOW_SIZE);
    } else {
 		g.setColor(getFillColor());
        g.fillOval(r.x, r.y, r.width, r.height);
        
        g.setColor(getForeground());
        g.drawOval(r.x, r.y, r.width, r.height);
    }
  }

  public void paintDataEntity(Graphics g) {
    // filled rectangle, possibly shadded
    Rectangle r = normalised();

    if(getAppearanceValue(MULTIPLE_ENTITIES).equals("multiple")) {
        g.setColor(Color.gray);
        g.fillRect(r.x+SHADDOW_SIZE,r.y+SHADDOW_SIZE,r.width-SHADDOW_SIZE,r.height-SHADDOW_SIZE);
        g.setColor(getFillColor());
        g.fillRect(r.x, r.y, r.width-SHADDOW_SIZE, r.height-SHADDOW_SIZE);
        //super.paint(g);
        g.setColor(getForeground());
        g.drawRect(r.x, r.y, r.width-SHADDOW_SIZE, r.height-SHADDOW_SIZE);
    } else {
        g.setColor(getFillColor());
        g.fillRect(r.x, r.y, r.width, r.height);
        //super.paint(g);
        g.setColor(getForeground());
        g.drawRect(r.x, r.y, r.width, r.height);
    }
  }

  public void paintDataStore(Graphics g) {
    // sphere shape

    Rectangle r = normalised();

    g.setColor(getFillColor());
    g.fillOval(r.x, r.y, r.width, (int) (r.height*STORE_SIZE));
    g.setColor(getForeground());
    g.drawOval(r.x, r.y, r.width, (int) (r.height*STORE_SIZE));
    g.setColor(getFillColor());
    g.fillOval(r.x, r.y+r.height-(int) (r.height*STORE_SIZE), r.width, (int) (r.height*STORE_SIZE));
    g.setColor(getForeground());
    g.drawOval(r.x, r.y+r.height-(int) (r.height*STORE_SIZE), r.width, (int) (r.height*STORE_SIZE));
    g.setColor(getFillColor());
    g.fillRect(r.x+1,r.y+r.height-(int) (r.height*STORE_SIZE), r.width-2, (int) (r.height*STORE_SIZE*0.5));
    //super.paint(g);
    g.setColor(getForeground());
    g.drawLine(r.x, r.y+(int) (r.height*STORE_SIZE*0.5), r.x, r.y+r.height - (int) (r.height*STORE_SIZE*0.5));
    g.drawLine(r.x+r.width, r.y+(int) (r.height*STORE_SIZE*0.5), r.x+r.width, r.y+r.height-(int) (r.height*STORE_SIZE*0.5));
  }

  public void paintOOAClass(Graphics g) {
    // UMLish class icon
    Rectangle r = normalised();

    g.setColor(getFillColor());
    g.fillRect(r.x, r.y, r.width, r.height);
    //super.paint(g);
    g.setColor(getForeground());
    g.drawRect(r.x, r.y, r.width, r.height);
    g.drawLine(r.x, r.y + r.height - (int) (r.height*0.1), r.x+r.width, r.y + r.height - (int) (r.height*0.1));
    g.drawLine(r.x, r.y + r.height - (int) (r.height*0.05), r.x+r.width, r.y + r.height - (int) (r.height*0.05));

  }

  public Dimension getMinimumSize() {
    return new Dimension(60,40);
    }
        
  public String getId() {
    return id;
    }
    
  public void setId(String newText) {
    String old = id;
    this.id = newText;
    if (firePropertyChange("id",old,id))
        repaint();
    }
      	  
  public String getType() {
    return type;
    }
    
  public void setType(String newText) {
    String old = type;
    this.type = newText;
    if (firePropertyChange("type",old,type))
        repaint();
    }
    
  public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from name and parentName
      super.propertyChange(evt);
    }

  public String getEntityShape()
  {
	return entity_shape;
  }

  public void setEntityShape(String value)
  {
    String old = entity_shape;
	entity_shape = value;
	firePropertyChange("entityShape",old,value);
  }

  public String getMultipleEntities()
  {
	return multiple;
  }

  public void setMultipleEntities(String value)
  {
    String old = multiple;
	multiple = value;
	firePropertyChange("multipleEntities",old,value);
  }  

  static final int ENTITY_SHAPE = 0;
  static final int MULTIPLE_ENTITIES = 1;

  static String[] names = { "Entity Shape", "Multiple Entities" };

  public String[] getAppearanceProperties()
  {
     return names;
  }
  
  public String getAppearanceValue(int index) {
    switch(index) {
    case ENTITY_SHAPE : return getEntityShape();
    case MULTIPLE_ENTITIES : return getMultipleEntities();
    }

    return "";
  }
  
  public void setAppearanceValue(int index, String value) {
   switch(index) {
	case ENTITY_SHAPE : setEntityShape(value); return;
	case MULTIPLE_ENTITIES : setMultipleEntities(value); return;
   }
  }
  
  public String[] getAppearanceValues(int index) {
   switch(index) {
   case ENTITY_SHAPE :
    String ss0[] = { "process entity", "data entity", "data store", "ooa class" };
    return ss0;
   case MULTIPLE_ENTITIES :
    String ss1[] = { "single", "multiple" };
    return ss1;
    }

    return new String[0];
  }
    
  public String[] getEditableProperties() {
    String[] ss = { "id", "annotation", "type" };
    return ss;
    }

  protected String id = "";
  protected String type = "";

  protected String entity_shape;
  protected String multiple;

  protected static final int SHADDOW_SIZE = 4;
  protected static final double STORE_SIZE = 0.15;
  
  }
