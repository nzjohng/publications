package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewEnclosingEvent extends SAChangeEvent {
  public SANewEnclosingEvent(Object source, SAEnclosingShape shape) {
  	super(source);
  	this.shape = shape;
  	}
  
  public SAEnclosingShape getEnclosingShape() {
  	return shape;
  	}
  	
  protected SAEnclosingShape shape;
  }
