package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewAssocInfoEvent extends SAChangeEvent {
  public SANewAssocInfoEvent(Object source, SAAssocInfoShape shape) {
  	super(source);
  	this.shape = shape;
  	}
  
  public SAAssocInfoShape getAssocInfoShape() {
  	return shape;
  	}
  	
  protected SAAssocInfoShape shape;
  }
