package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewCompEvent extends SAChangeEvent {
  public SANewCompEvent(Object source, SACompShape shape) {
  	super(source);
  	this.shape = shape;
  	}
  
  public SACompShape getCompShape() {
  	return shape;
  	}
  	
  protected SACompShape shape;
  }
