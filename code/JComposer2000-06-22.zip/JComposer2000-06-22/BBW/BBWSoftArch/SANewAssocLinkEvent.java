package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewAssocLinkEvent extends SAChangeEvent {
  public SANewAssocLinkEvent(Object source, SAAssocLink rel) {
  	super(source);
  	this.rel = rel;
  	}
  
  public SAAssocLink getAssocLink() {
  	return rel;
  	}
  	
  protected SAAssocLink rel;
  }
