package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewRefinementLinkEvent extends SAChangeEvent {
  public SANewRefinementLinkEvent(Object source, SARefinementLink rel) {
  	super(source);
  	this.rel = rel;
  	}
  
  public SARefinementLink getRefinementLink() {
  	return rel;
  	}
  	
  protected SARefinementLink rel;
  }
