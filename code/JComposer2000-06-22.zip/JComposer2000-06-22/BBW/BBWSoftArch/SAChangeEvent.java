package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

import java.beans.*;

public abstract class SAChangeEvent extends java.util.EventObject{
  public SAChangeEvent(Object source) {
  	super(source);
  	}
  }
