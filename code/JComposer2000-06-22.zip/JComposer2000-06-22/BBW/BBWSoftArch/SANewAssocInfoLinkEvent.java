package BBWSoftArch;

/*
Define various events and their associated listeners for communicating 
JavaBean events from BBW/JComposer.
*/

public class SANewAssocInfoLinkEvent extends SAChangeEvent {
  public SANewAssocInfoLinkEvent(Object source, SAAssocInfoLink rel) {
  	super(source);
  	this.rel = rel;
  	}
  
  public SAAssocInfoLink getAssocInfoLink() {
  	return rel;
  	}
  	
  protected SAAssocInfoLink rel;
  }
