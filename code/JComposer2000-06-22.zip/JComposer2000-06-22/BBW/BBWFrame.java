import bbwTool.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;

public class BBWFrame extends Frame implements ActionListener{
  public BBWFrame() {
	setTitle("BBW"+(frameCount++));
	setLayout(new BorderLayout());
	add("Center", panel);
//	add("South", new GenerationPanel(panel));
	MenuBar menuBar = new MenuBar();
	Menu viewMenu = new Menu("View");
	viewMenu.add(new MenuItem("New BBW View"));
	menuBar.add(viewMenu);
//	Menu composeMenu = new Menu("Compose");
//	composeMenu.add(new MenuItem("New Shape"));
//	composeMenu.add(new MenuItem("New DualConstraint"));
//	composeMenu.add(new MenuItem("New MonoConstraint"));
//	menuBar.add(composeMenu);
	setMenuBar(menuBar);
	addWindowListener(new JCFrameAdapter());
	}
  
  class JCFrameAdapter extends WindowAdapter{
  	public void windowClosing(WindowEvent e) {
  		dispose();
		}
  	}

  public void actionPerformed(ActionEvent e) {
  	BBWFrame frame = new BBWFrame();
	frame.pack();
	frame.show();
  	}

  protected static int frameCount = 1;
  protected BBWPanel panel = new BBWPanel();
  }
