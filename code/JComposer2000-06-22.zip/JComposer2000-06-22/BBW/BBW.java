import bbwTool.*;
import bbw.*;

import java.awt.*;
import java.applet.Applet;

public class BBW extends Applet {
  public void init() {
	Frame frame = new BBWFrame();
	frame.pack();
	frame.show();
	}
  public static void main(String argv[]) {
	Frame frame = new BBWFrame();
	frame.pack();
	frame.show();
	}
  }
