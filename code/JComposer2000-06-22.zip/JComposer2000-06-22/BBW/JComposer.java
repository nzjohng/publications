import jComposer.*;
import bbw.*;
import java.awt.*;

public class JComposer extends java.applet.Applet {
  public void init() {
	Frame frame = new JComposerFrame();
	frame.pack();
	frame.show();
	}
  public static void main(String argv[]) {
	Frame frame = new JComposerFrame();
	frame.pack();
	frame.show();
	}
  }
