package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;

public class UMLUseCase extends TextShape {
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));
  	setText("Use Case");
  	}

  protected void paintBackGround(Graphics g) {
	Rectangle r = normalised();
	g.drawOval(r.x, r.y, r.width, r.height);
	}

  public Rectangle getBorder() {
	return normalise(new Rectangle(getX(), getY(), width, height));
  	}

  public Dimension getMinimumSize() {
	return new Dimension(60,30);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text", "font" };
	return ss;
	}

  }
