package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;

public class UMLAnchorNoteToItem extends CompositeConnector {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    new Connector(line, getOriginHandle(), getCornerHandle(), this);
    line.setHandlesVisible(false);
    line.setDashLength(2);
    line.setGapLength(6);
    }  
    
public void init(BBWContainer container,int x, int y,Handle from, Handle to) {
 init(container,x,y);
}
  
  public void showPropertySheet() {
    // ignore it, as there are none
    }

  protected DottedLineShape line = new DottedLineShape();
  }
