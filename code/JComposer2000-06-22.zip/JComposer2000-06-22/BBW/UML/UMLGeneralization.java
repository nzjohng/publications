package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;
import java.beans.*;

public class UMLGeneralization extends CompositeConnector {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    new Connector(arrow, getOriginHandle(), getCornerHandle(), this);
    arrow.setHandlesVisible(false);

    name.init(this,10,10);
    name.setSize(30,20);
    name.setFont(new Font("Helvetica",0,10));
    name.setText("<<Extends>>");
//      name.setHandlesVisible(false);
    eq.init(getMiddleHandle(),name.getBottomLeftHandle());
    name.addPropertyChangeListener(this);
    }  
    
public void init(BBWContainer container,int x, int y,Handle from, Handle to) {
 init(container,x,y);
}
  
  public String getNameText() {
    return name.getText();
    }
    
  public void setNameText(String newText) {
    name.setText(newText);
    }
    
  public Font getNameFont() {
    return name.getFont();
    }
    
  public void setNameFont(Font newFont) {
    name.setFont(newFont);
    }
  
   public void propertyChange(PropertyChangeEvent evt) {
    // Map the events from text and the choices
    super.propertyChange(evt);
    if (evt.getSource() == name) {
        if (evt.getPropertyName().equals("text"))
            firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
        else if (evt.getPropertyName().equals("font"))
            firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
        }
    }

  public String[] getEditableProperties() {
    String[] ss = { "nameText", "nameFont" };
    return ss;
    }

  protected OpenArrowShape arrow = new OpenArrowShape();
  protected TextShape name = new TextShape();
  protected EqualityMoveConstraint eq = new EqualityMoveConstraint();
  }
