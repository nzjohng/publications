package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.controller.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class UMLPanel extends BBWGeneralPanel implements ActionListener, ItemListener{
    
  public UMLPanel() {
    setLayout(new BorderLayout());
    add("Center", panel);
    
    controls.setLayout(new FlowLayout());
    controls.add(new Label("Shape:"));
    String[] packageName = {"Uml" };
    ToolManager.addToolPackageNames(packageName);
    createTools(tools );
    controls.add(toolChoice);
    
    controls.add(debugPropagation);
    debugPropagation.addItemListener(this);
    controls.add(displayShapes);
    displayShapes.addActionListener(this);
    add("South", controls);
    panel.setController((Controller)controllers.elementAt(0));
    }
  
  protected void createTools(String[] tools) {
    PopupController[] popupControllers = {
        new HidePopupController(),
        new ShowPopupController(),
        new PropSheetPopupController(),
        new DisposePopupController()
        };
    PopupManager.defineMenuItemsOfStandardPopup(panel,popupControllers);

    for (int i = 0; i < tools.length; i++)
        addTool(tools[i]);
    addConnectorTool("UnidirectionalAssociation", "UMLUnidirectionalAssociation");
    addConnectorTool("Generalization", "UMLGeneralization");
    addConnectorTool("AnchorNoteToItem", "UMLAnchorNoteToItem");
    MoveController mover = new MoveController(panel.getTopContainer());
    panel.setMoveController(mover);
    controllers.addElement(mover);
    toolChoice.addItem("Move");
    ResizeController resizer = new ResizeController(panel.getTopContainer());
    controllers.addElement(resizer);
    panel.setResizeController(resizer);
    toolChoice.addItem("Resize");
    controllers.addElement(new AdjustController(panel.getTopContainer()));
    toolChoice.addItem("Adjust");
    controllers.addElement(new ShowController(panel.getTopContainer()));
    toolChoice.addItem("Show Handles");
    }
    
  public void itemStateChanged(ItemEvent e) {
    PropertyChangeSupport2.setDebug(debugPropagation.getState());
    }

  public void actionPerformed(ActionEvent e) {
    panel.displayShapes();
    }

  public UMLActor newActor(int x, int y, int width, int height) {
    UMLActor s = new UMLActor();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public UMLUseCase newUseCase(int x, int y, int width, int height) {
    UMLUseCase s = new UMLUseCase();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public UMLNote newNote(int x, int y, int width, int height) {
    UMLNote s = new UMLNote();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
  
  public UMLTextBox newTextBox(int x, int y, int width, int height) {
    UMLTextBox s = new UMLTextBox();
    s.init(panel.getTopContainer(),x,y);
    s.setSize(width,height);
    return s;
    }
    
  public UMLUnidirectionalAssociation newUnidirectionalAssociation(RectangularShape from, RectangularShape to) {
    UMLUnidirectionalAssociation shape = new UMLUnidirectionalAssociation();
    new Connector(shape,from.getMiddleHandle(),to.getMiddleHandle(),from.getParent());
    return shape;
    }
  
  public UMLGeneralization newGeneralization(RectangularShape from, RectangularShape to) {
    UMLGeneralization shape = new UMLGeneralization();
    new Connector(shape,from.getMiddleHandle(),to.getMiddleHandle(),from.getParent());
    return shape;
    }

  public UMLAnchorNoteToItem newAnchorNoteToItem(RectangularShape from, RectangularShape to) {
    UMLAnchorNoteToItem shape = new UMLAnchorNoteToItem();
    new Connector(shape,from.getMiddleHandle(),to.getMiddleHandle(),from.getParent());
    return shape;
    }
        

  protected static int frameCount = 1;
  protected Panel controls = new Panel();
  protected Checkbox debugPropagation = new Checkbox("Debug Propagation");
  protected Button displayShapes = new Button("Display Shapes");
  protected String[] tools = {
        "UMLActor", "UMLUseCase", "UMLNote", "UMLTextBox"
        };
  }
