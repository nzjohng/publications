package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;

public class UMLActor extends TextShape {
  public void init(BBWContainer container, int x, int y) {
	super.init(container,x,y);
	middleHandle.setVisible(false);
	setText("Actor");
	setAlignmentY(1.0);
    }

  protected void paintBackGround(Graphics g) {
	Rectangle r = normalised();
	Rectangle o = getBounds();
	r.height -= 20;
	int quarter = r.height/4;
	int half = r.height/2;
	g.drawOval(r.x + r.width/2 - quarter/2, r.y, quarter, quarter);
	g.drawLine(r.x + r.width/2, r.y + quarter, r.x + r.width/2, r.y + r.height - quarter); // Body
	g.drawLine(r.x + ARM_OFFSET, r.y + half, r.x + r.width - ARM_OFFSET, r.y + half); // Arms
	g.drawLine(r.x + r.width/2, r.y + r.height - quarter, r.x + LEG_OFFSET, r.y + r.height); // Left Leg
	g.drawLine(r.x + r.width/2, r.y + r.height - quarter, r.x + r.width - LEG_OFFSET, r.y + r.height); // Right Leg
	}

  public Rectangle getBorder() {
	return normalise(new Rectangle(getX(), getY(), width,height));
  	}

  public Dimension getMinimumSize() {
	return new Dimension(50,70);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text", "font" };
	return ss;
	}

  protected final static int ARM_OFFSET = 6, LEG_OFFSET = 2;
  }
