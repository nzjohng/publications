package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;

public class UMLUnidirectionalAssociation extends CompositeConnector {
  public void init(BBWContainer container, int x, int y) {
    super.init(container,x,y);
    new Connector(arrow, getOriginHandle(), getCornerHandle(), this);
    arrow.setHandlesVisible(false);
    }  
   
public void init(BBWContainer container, int x, int y,
    Handle from, Handle to) {
    init(container,x,y);   
}

  
  public void showPropertySheet() {
    // ignore it, as there are none
    }

  protected ArrowShape arrow = new ArrowShape();
  }
