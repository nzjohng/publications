package Uml;

import bbw.constraint.*;
import bbw.shape.*;
import bbw.*;
import java.awt.*;

public class UMLNote extends TextShape {
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	middleHandle.setVisible(false);
  	setFont(new Font("Helvetica",2,10));
  	setAlignmentX(0.15);
  	setAlignmentY(0.15);
  	}

  protected void paintBackGround(Graphics g) {
	Rectangle r = normalised();
	g.drawLine(r.x, r.y, r.x + r.width - CORNER, r.y);
	g.drawLine(r.x + r.width - CORNER, r.y, r.x + r.width, r.y + CORNER);
	g.drawLine(r.x + r.width - CORNER, r.y, r.x + r.width - CORNER, r.y + CORNER);
	g.drawLine(r.x + r.width - CORNER, r.y + CORNER, r.x + r.width, r.y + CORNER);
	g.drawLine(r.x + r.width, r.y + CORNER,r.x + r.width, r.y + r.height);
	g.drawLine(r.x + r.width, r.y + r.height, r.x, r.y + r.height);
	g.drawLine(r.x, r.y + r.height, r.x, r.y);
	}

  public Rectangle getBorder() {
	return normalise(new Rectangle(getX(), getY(), width, height));
  	}

  public Dimension getMinimumSize() {
	return new Dimension(60,30);
	}
    	
  public String[] getEditableProperties() {
	String[] ss = { "text", "font" };
	return ss;
	}

  protected static int CORNER = 20;
  }
