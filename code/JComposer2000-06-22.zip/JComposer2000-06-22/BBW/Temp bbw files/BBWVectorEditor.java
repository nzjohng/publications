package bbw;

import java.beans.*;
import bbw.*;
import java.awt.*;

/**
 * A BBWVectorEditor provides a GUI-based property editor
 *
 * @version 	0.8, Apr97
 * @author 	Rick Mugridge
 */
public class BBWVectorEditor extends Panel implements PropertyEditor {
  public BBWVectorEditor() {
  	add(xField);
  	add(yField);
  	}
  
  public boolean action(Event evt, Object arg) {
  	if (evt.target==xField) {
  		x = Integer.valueOf(xField.getText()).intValue();
  		support.firePropertyChange("", null, null);
  		}
    	else if (evt.target==yField) {
  		y = Integer.valueOf(yField.getText()).intValue();
  		support.firePropertyChange("", null, null);
  		}
	return true;
  	}
  	
    public Object getValue() {
	return new BBWVector(x,y);
	}
  
  public void setValue(Object value) {
  	BBWVector p = (BBWVector)value;
  	x = p.x;
  	xField.setText(""+x);
  	y = p.y;
    	yField.setText(""+y);
	}
  
  public String getAsText() { return null; }
    
  public void setAsText(String text) throws IllegalArgumentException {
	throw new IllegalArgumentException();
    	}
    
  public boolean isPaintable() { return false; }
  public void paintValue(Graphics gfx, java.awt.Rectangle box) {}

  public String[] getTags() { return null; }
  
  public boolean supportsCustomEditor() { return true; }
  public Component getCustomEditor() { return this; }
 
 public String getJavaInitializationString() { return "new BBWVector("+x+","+y+")"; }

  public void addPropertyChangeListener(PropertyChangeListener listener) {
  	support.addPropertyChangeListener(listener);
  	}

  public void removePropertyChangeListener(PropertyChangeListener listener) {
  	support.removePropertyChangeListener(listener);
  	}

  protected TextField xField = new TextField("0",5);
  protected TextField yField = new TextField("0",5);
  protected int x = 0, y = 0;
  protected PropertyChangeSupport support = new PropertyChangeSupport(this);
  }