package bbw;

import java.beans.*;
import java.util.*;
import java.io.*;

public class PropertySheetGenerator {

  public static void generate(String className,String packageName) {
  	generate(className, className+"Editor",packageName);
  	}

  public static void generate(String[] toolNames,String packageName) {
	Class klass;
	Object object;
	for (int i = 0; i < toolNames.length; i++) {
		String className = toolNames[i];
		try {
			klass = Class.forName(className);
			object = klass.newInstance();
			}
		catch (Exception c) {
			throw new RuntimeException("Unknown controller class: "+className);
			}
		if (object instanceof PseudoReflection)
			generate(className,packageName);
		}
  	}
  	
  public static void generate(String className, String propertySheetClassName,String packageName) {
   	String home = System.getProperty("user.dir");
   	String separator = System.getProperty("file.separator");
//   	String fileName = home + separator + " Generated" + separator + className+"Editor.java";
//   	String fileName = className+"Editor.java";
   	String fileName = home + separator + className+"Editor.java22";
   	System.out.println("File name for generate is '"+fileName+"'");
   	PropertyDescriptor[] properties = getPropertyDescriptors(className);
 	//PrintStream out = System.out;
 	FileOutputStream fileOut;
 	try { fileOut = new FileOutputStream(fileName); }
 	catch (IOException e) { throw new RuntimeException("Problem opening file "+className+"Editor.java:"+e); }
 	PrintStream out = new PrintStream(fileOut);
 	
	if (packageName != "")
		out.println("package "+packageName+".*;");
	out.println("import javaBeans.*;");
 	out.println("import bbw.*;");
  	out.println("import java.awt.*;");
  	out.println();
  	out.println("class "+propertySheetClassName+" extends BBWPropertyEditor {");
  	generateGetSet(out,className,propertySheetClassName,properties);
	generateListener(out,properties);
	generatePrivates(out,className,properties);
 	out.println("  }");
 	out.close();
	}
  
  private static PropertyDescriptor[] getPropertyDescriptors(String className) {
  	// Prior to 1.1, we'll use our own pseudo-reflection
  	Class klass = ToolManager.getClass(className);
  	if (klass == null)
  		throw new RuntimeException("Unable to find class  '"+className+"' for Pseudo-reflection in PropertySheetGenerator");
  	PseudoReflection reflect;
  	try {
  		reflect = (PseudoReflection) klass.newInstance();
  		}
  	catch (Exception e) {
  		throw new RuntimeException("Unable to create an object of class  '"+className+"' for Pseudo-reflection in PropertySheetGenerator: "+e);
  		}
  	return reflect.getPropertyDescriptors();
  	// In 1.1, this will be changed to:
  	// BeanInfo bi = Introspector.getBeanInfo(className);
  	// return bi.getPropertyDescriptors();
  	}
 
  private static void generateGetSet(PrintStream out, String className, String propertySheetClassName, PropertyDescriptor[] properties) {
  	out.println("  public Object getValue() {");
  	out.println("	return target;");
  	out.println("	}");
  	
  	out.println("  public void setValue(Object theTarget) {");
  	out.println("	target = ("+className+")theTarget;");
  	out.println("	target.addPropertyChangeListener(this);");
  	out.println("	setLayout(new GridLayout(0,1));");
  	out.println("	Panel panel;");
	for (int i = 0; i < properties.length; i++ ) {
 		PropertyDescriptor prop =properties[i];
   		String name = prop.getName();
    		String editorString = name+"Editor";
   		String type = prop.getPropertyType().getName();
		if (type.equals("java.lang.Boolean"))
   			out.println("	"+editorString+".setValue(new Boolean(target."+prop.getGetterName()+"()));");
		else if (type.equals("java.lang.Integer"))
   			out.println("	"+editorString+".setValue(new Integer(target."+prop.getGetterName()+"()));");
		else
   			out.println("	"+editorString+".setValue(target."+prop.getGetterName()+"());");
   		out.println("	"+editorString+".addPropertyChangeListener(this);");
  		out.println("	panel = new Panel();");
  		out.println("	panel.setLayout(new BorderLayout());");
   		out.println("	panel.add(\"West\",new Label(\""+name+"\"));");
   		PropertyEditor editor = PropertyEditorManager.findEditor(prop.getPropertyType());
 		if (editor == null)
 			throw new RuntimeException("No editor for "+prop.getPropertyType());
  		out.print("	panel.add(\"Center\",");
   		if (editor.isPaintable() && editor.supportsCustomEditor())
			out.println("new PropertyCanvas2("+editorString+"));");
		else if (!editor.isPaintable() && editor.supportsCustomEditor())
			out.println(editorString+".getCustomEditor());");
		else if (editor.getTags() != null)
			out.println(" new PropertySelector("+editorString+"));");
		else if (type.equals("java.lang.String") || editor.getAsText() != null)
			// The above test is inadequate, because the value of the editor has not been set.
			// And we can't do that here without reflection to get a suitable value.
			// There really needs to be another way to ask the editor about text which doesn't require a value.
			out.println(" new PropertyText("+editorString+"));");
		else
			throw new RuntimeException("No editor available for property "+prop.getName()+"of type "+type+" in class "+className);
    		out.println("	add(panel);");
		}
  	out.println("	}");
	}
  
  private static void generateListener(PrintStream out, PropertyDescriptor[] properties) {
   	out.println("  public void propertyChange(PropertyChangeEvent evt) {");
	out.println("	if (firing) return;");
	out.println("	firing = true;");
	out.println("	if (evt.getSource() == target) {");
	out.println("		String property = evt.getPropertyName();");
	for (int i = 0; i < properties.length; i++ ) {
		String name = properties[i].getName();
  		String editorString = name+"Editor";
		out.println("		if (property.equals(\""+name+"\"))");
  		out.println("			"+editorString+".setValue(evt.getNewValue());");
		}
	out.println("		}");
	for (int i = 0; i < properties.length; i++ ) {
		String name = properties[i].getName();
  		String editorString = name+"Editor";
		String type = properties[i].getPropertyType().getName();
		out.println("	else if (evt.getSource() == "+editorString+")");
		String getValue = "("+type+")"+editorString+".getValue()";
		if (type.equals("java.lang.Boolean"))
			getValue = "("+getValue+").booleanValue()";
		else if (type.equals("java.lang.Integer"))
			getValue = "("+getValue+").intValue()";
		out.println("		target.set"+capitalize(name)+"("+getValue+");");
		}
	out.println("	target.getPanel().repaint();"); // Need for transaction here too!
	out.println("	firing = false;");
  	out.println("	}");
	}
  
    private static String capitalize(String s) {
	char chars[] = s.toCharArray();
	chars[0] = Character.toUpperCase(chars[0]);
	return new String(chars);
	}

    private static void generatePrivates(PrintStream out, String className, PropertyDescriptor[] properties) {
 	out.println("  private "+className+ "  target;");
 	out.println("  private boolean firing = false;");
	for (int i = 0; i < properties.length; i++ ) {
 		PropertyDescriptor prop =properties[i];
 		out.println("  private PropertyEditor  "+prop.getName()+"Editor = PropertyEditorManager.findEditor(\""+prop.getPropertyType().getName()+"\");");
		}
	}
  }
 