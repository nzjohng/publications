package bbw.constraint;

import bbw.*;
import bbw.shape.LineShape;
import java.awt.*;
import java.util.*;

public class ArcConstraint extends DualConstraint{
	// constraint  from.origin == line.origin;
	// constraint  to.origin == line.corner;
  public void init(Handle from, Handle to) {
  	super.init(from,to);
  	 // Don't want listeners for this!
  	from.removePropertyChangeListener(this);
  	to.removePropertyChangeListener(this);

	line.init(from.getOwner().getTopContainer(),from.getX(),from.getY());
  	line.addDisposeListener(this);
	eq1.init(from,line.getOriginHandle());
	eq2.init(to,line.getCornerHandle());
  	}
 
 public void dispose() {
   	line.dispose();
   	eq1.dispose();
   	eq2.dispose();
  	super.dispose();
  	}
  
  public LineShape getLine() {
  	return line;
  	}
  	
  protected void fromXChanged() {
	} // Nothing to do in here!
	
  protected void fromYChanged() {
	} // Nothing to do in here!
	
  protected void toXChanged() {
	}// Nothing to do in here!
  	
  protected void toYChanged() {
	}// Nothing to do in here!
  	
  protected LineShape line = new LineShape();
  protected EqualityResizeConstraint eq1 = new EqualityResizeConstraint();
  protected EqualityResizeConstraint eq2 = new EqualityResizeConstraint();
  }
