package bbw;

import java.beans.*;
import java.awt.*;

public class PropSheet2Controller extends PropSheetController{
  public PropSheet2Controller(BBWContainer container) {
  	super(container);
  	}
  
  protected void showPropertySheet(Shape shape,int x, int y) {
	String editorName = shape.getClass().getName();
	PropertyEditor editor = PropertyEditorManager.findEditor(editorName);
	if (editor == null)
		throw new RuntimeException("No Property Sheet for "+editorName);
	if (!editor.supportsCustomEditor())
		throw new RuntimeException("No Custom Editor for "+editorName);
		
	editor.setValue(shape);	
	PanelShape frame = new PanelShape();
	frame.init((Panel)editor.getCustomEditor(),container,x,y);	
  	}
  
  public String getName() {
	return "Show Property Sheet Inside";
	}
  }
