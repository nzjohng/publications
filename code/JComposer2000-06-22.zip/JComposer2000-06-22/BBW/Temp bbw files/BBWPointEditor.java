package bbw;

import java.beans.*;
import java.awt.*;

public class BBWPointEditor extends Panel implements PropertyEditor {
  public BBWPointEditor() {
  	add(xField);
  	add(yField);
  	}
  
  public boolean action(Event evt, Object arg) {
  	if (evt.target==xField) {
  		x = Integer.valueOf(xField.getText()).intValue();
  		support.firePropertyChange("", null, null);
  		}
    	else if (evt.target==yField) {
  		y = Integer.valueOf(yField.getText()).intValue();
  		support.firePropertyChange("", null, null);
  		}
	return true;
  	}
  	
    public Object getValue() {
	return new BBWPoint(x,y);
	}
  
  public void setValue(Object value) {
  	BBWPoint p = (BBWPoint)value;
  	x = p.x;
  	xField.setText(""+x);
  	y = p.y;
    	yField.setText(""+y);
    	support.firePropertyChange("", null, null);
	}
  
  public String getAsText() { return null; }
    
  public void setAsText(String text) throws IllegalArgumentException {
	throw new IllegalArgumentException();
    	}
    
  public boolean isPaintable() { return false; }
  public void paintValue(java.awt.Graphics gfx, java.awt.Rectangle box) {}

  public String[] getTags() { return null; }
  
  public boolean supportsCustomEditor() { return true; }
  public Component getCustomEditor() { return this; }
 
 public String getJavaInitializationString() { return "new BBWPoint("+x+","+y+")"; }

  public void addPropertyChangeListener(PropertyChangeListener listener) {
  	support.addPropertyChangeListener(listener);
  	}

  public void removePropertyChangeListener(PropertyChangeListener listener) {
  	support.removePropertyChangeListener(listener);
  	}

  protected TextField xField = new TextField("0",5);
  protected TextField yField = new TextField("0",5);
  protected int x = 0, y = 0;
  protected PropertyChangeSupport support = new PropertyChangeSupport(this);
  }