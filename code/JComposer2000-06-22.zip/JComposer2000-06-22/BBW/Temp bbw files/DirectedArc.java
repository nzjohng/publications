package bbw.constraint;

import bbw.*;
import bbw.shape.*;

public class DirectedArc extends ArcConstraint {
	// constraint  from.origin == line.origin;
	// constraint  to.origin == line.corner;
  public void init(Handle from, Handle to) {
  	line = new ArrowShape();
  	super.init(from,to);
  	}
  }
