package bbw;

import java.awt.*;

public class GenerationPanel extends Panel {
  
  public GenerationPanel(BBWGeneralPanel panel) {
  	this.panel = panel;
  	add(new Label("Class Name"));
  	add(className);
  	add(new Label("Editor package Name"));
  	add(packageName);
  	add(new Button("Generate Editors"));
  	}
  	
   public boolean action(Event e, Object arg) {
 	if (e.target instanceof Button || e.target == className)
 		if (className.getText().equals(""))
 			PropertySheetGenerator.generate(panel.getToolNames(),packageName.getText());
 		else
 			PropertySheetGenerator.generate(className.getText(),packageName.getText());
 	else return super.action(e,arg);
 	return true;
 	}
 	
  protected TextField className = new TextField("",10);
  protected TextField packageName = new TextField("",10);
  protected BBWGeneralPanel panel;
  }
