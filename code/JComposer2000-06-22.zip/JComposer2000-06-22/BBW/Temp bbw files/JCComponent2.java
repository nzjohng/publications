import javaBeans.*;
import bbw.*;
import java.awt.*;
import java.util.*;

class JCComponent2 extends Composite implements ActionListener{

  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	this.container = container;
  	cornerHandle.setMidPt(x,y); // needed?
  	middleHandle.setVisible(false);
  	configureText(name,originHandle,topRightHandle);
  	name.setText("Name");
  	configureText(parentName,name.getBottomLeftHandle(),name.getCornerHandle());
  	parentName.setText("parent");
	lastBottomLeft = parentName.getBottomLeftHandle();
	addButton();

  	JComposerPanel jc = (JComposerPanel) getTopPanel();
  	jc.fireJCChange(new JCNewComponentEvent(jc,this));
  	}
  
    protected void configureText(TextShape text, Handle topLeft, Handle topRight) {
  	text.init(this,getX(),getY());
  	text.setSize(getWidth(),text.preferredSize().height+Handle.SIZE);
  	text.setFont(new Font("Helvetica",0,12));
  	text.setEnabledOfHandles(false);
  	text.addPropertyChangeListener(this);
  	
  	HorizontalMoveConstraint hm = new HorizontalMoveConstraint();
	hm.init(topLeft,text.getOriginHandle(),-Handle.SIZE+1);
	VerticalConstraint v = new VerticalConstraint();
	v.init(topLeft,text.getOriginHandle());
	VerticalOnResizeConstr vr = new VerticalOnResizeConstr();
	vr.init(topRight,text.getTopRightHandle());
	}

  public void dispose() {
  	super.dispose();
  	name.dispose();
  	button.dispose();
  	for (Enumeration en = fields.elements(); en.hasMoreElements(); )
  		((TextFieldShape)en.nextElement()).dispose();
  	}
  	
  public Dimension minimumSize() {
	return new Dimension(70,70);
	}
    	
  public void addElement() {
	TextFieldShape field = new TextFieldShape();
	fields.addElement(field);
  	field.init(this,getX(),lastBottomLeft.getY());
  	field.setSize(getWidth(),name.preferredSize().height);
  	field.setFont(new Font("Helvetica",0,10));
  	field.setEnabledOfHandles(false);
	HorizontalMoveConstraint topHorizontal = new HorizontalMoveConstraint();
  	topHorizontal.init(lastBottomLeft,field.getOriginHandle(),-Handle.SIZE-1);
	VerticalConstraint leftVertical = new VerticalConstraint();
  	leftVertical.init(originHandle,field.getOriginHandle());
	VerticalOnResizeConstr rightVertical = new VerticalOnResizeConstr();
  	rightVertical.init(topRightHandle,field.getTopRightHandle());
  	
  	lastBottomLeft = field.getBottomLeftHandle();
  	if (lastBottomLeft.getY() > cornerHandle.getY()) {
  		Constraint.pushReason(Constraint.RESIZE);
  		cornerHandle.setY(lastBottomLeft.getY() + 3);
  		Constraint.popReason();
  		}

  	JComposerPanel jc = (JComposerPanel) getTopPanel();
  	jc.fireJCChange(new JCNewElementEvent(this,field));
	}

  public void addButton() {
  	button.init(this,getX(),cornerHandle.getY());
  	button.setSize(25,25);
  	button.setEnabledOfHandles(false);
	HorizontalMoveConstraint bottomHorizontal = new HorizontalMoveConstraint();
  	bottomHorizontal.init(cornerHandle,button.getCornerHandle());
	VerticalMoveConstraint leftVertical = new VerticalMoveConstraint();
  	leftVertical.init(originHandle,button.getOriginHandle());
  	button.addActionListener(this);
	}
		
  public void actionPerformed(ActionEvent evt) { // From button
	addElement();
	}
		
  public void paint(Graphics g) {
	Rectangle normal = normalised();
	g.setColor(getForeground());
	g.drawRect(normal.x, normal.y, normal.width - 1, normal.height - 1);
	g.drawRect(normal.x+1, normal.y+1, normal.width - 3, normal.height - 3);
	super.paint(g);
	}

  public String getNameText() {
  	return name.getText();
  	}
  	
  public void setNameText(String newText) {
  	name.setText(newText);
  	}
  	
  public Font getNameFont() {
  	return name.getFont();
  	}
  	
  public void setNameFont(Font newFont) {
  	name.setFont(newFont);
  	}
  	
  public String getParentText() {
  	return parentName.getText();
  	}
  	
  public void setParentText(String newText) {
  	parentName.setText(newText);
  	}
  	
  public Font getParentFont() {
  	return parentName.getFont();
  	}
  	
  public void setParentFont(Font newFont) {
  	parentName.setFont(newFont);
  	}
  	
  public void propertyChange(PropertyChangeEvent evt) {
	super.propertyChange(evt);
	// Map the events from name and parent
 	if (evt.getSource() == name) {
 		if (evt.getPropertyName().equals("text"))
			firePropertyChange("nameText",evt.getOldValue(),evt.getNewValue());
 		else if (evt.getPropertyName().equals("font"))
			firePropertyChange("nameFont",evt.getOldValue(),evt.getNewValue());
		}
 	else if (evt.getSource() == parentName) {
 		if (evt.getPropertyName().equals("text"))
			firePropertyChange("parentText",evt.getOldValue(),evt.getNewValue());
 		else if (evt.getPropertyName().equals("font"))
			firePropertyChange("parentFont",evt.getOldValue(),evt.getNewValue());
		}
	}

  public String getKindText() {
  	return kindName;
  	}
  	
  public void setKindText(String newText) {
	String oldText = kindName;
	kindName = newText;
	if (firePropertyChange("kindName",oldText,newText))
		repaint();
  	}
  	
  public String getBbwShapeText() {
  	return bbwShape;
  	}
  	
  public void setBbwShapeText(String newText) {
	String oldText = bbwShape;
	bbwShape = newText;
	if (firePropertyChange("bbwShape",oldText,newText))
		repaint();
  	}
  	
  protected Vector getPropertyInfo() {
  	Vector v = super.getPropertyInfo();
  	v.addElement(new PropertyInfo("nameText","java.lang.String"));
  	v.addElement(new PropertyInfo("nameFont","java.awt.Font"));
  	v.addElement(new PropertyInfo("parentText","java.lang.String"));
  	v.addElement(new PropertyInfo("parentFont","java.awt.Font"));
  	v.addElement(new PropertyInfo("kindText","java.lang.String"));
  	v.addElement(new PropertyInfo("bbwShapeText","java.lang.String"));
 	return v;
 	 }

  protected BBWContainer container;
  protected TextShape name = new TextShape();
  protected TextShape parentName = new TextShape();
  protected ButtonShape button = new ButtonShape();
  protected Handle lastBottomLeft;
  protected Vector fields = new Vector();
  protected String kindName = "Kind";
  protected String bbwShape = "BBWShape";
  }
