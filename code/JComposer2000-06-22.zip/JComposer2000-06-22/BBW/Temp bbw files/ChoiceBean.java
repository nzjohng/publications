package bbw;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ChoiceBean extends Choice {
  public boolean action(Event e, Object arg) {
	ItemEvent ev = new ItemEvent(this,ItemEvent.ITEM_STATE_CHANGED,arg,ItemEvent.SELECTED);
	Enumeration tell = listeners.elements();
	// NOT thread-safe!
	while (tell.hasMoreElements())
		((ItemListener) tell.nextElement()).itemStateChanged(ev);
	return true;
	}

  public synchronized void addItemListener(ItemListener listener) {
  	listeners.addElement(listener);
  	}
  	
  public synchronized void removeItemListener(ItemListener listener) {
  	listeners.removeElement(listener);
  	}
  	
  private Vector listeners = new Vector();
  }
