package bbw;

import java.util.Vector;

public class VerticalListLayout implements BBWLayoutManager {

  public VerticalListLayout(BBWContainer container) {
  	if (!(container instanceof ContainerShape))
  		throw new RuntimeException("VerticalListLayout requires a ContainerShape");
  	this.container = container;
  	lastLeft = ((ContainerShape)container).getInsideTopLeftHandle();
  	lastRight = ((ContainerShape)container).getInsideTopRightHandle();
  	}
  
  public void addLayoutComponent(String name, BBWComponent comp) {
	if (!(comp instanceof RectangularShape)) return;
	RectangularShape shape = (RectangularShape)comp;
	Constraint.pushReason(Constraint.RESIZE);
	VerticalConstraint v1 = new VerticalConstraint();
	v1.init(lastLeft,shape.getOriginHandle());
	VerticalConstraint v2 = new VerticalConstraint();
	v2.init(lastRight,shape.getCornerHandle());
	Constraint.popReason();
	HorizontalMoveConstraint horiz = new HorizontalMoveConstraint();
	horiz.init(lastLeft,shape.getOriginHandle());
  	lastLeft = shape.getBottomLeftHandle();
  	lastRight = shape.getCornerHandle();
	// constraints.addElement(new ElementConstraintMap(shape,dc));
	}

  public void removeLayoutComponent(BBWComponent comp) {
	}

  public Dimension preferredLayoutSize(BBWContainer parent) {
	return new Dimension(10,10);
	}

  public Dimension minimumLayoutSize(BBWContainer parent) {
	return new Dimension(10,10);
	}

  public void dispose(BBWContainer parent) {
    }
    
  protected BBWContainer container;
  protected Handle lastLeft, lastRight;
  // protected Vector constraints = new Vector();
  }
