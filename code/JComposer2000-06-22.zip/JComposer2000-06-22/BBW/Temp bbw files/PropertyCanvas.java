
// Support for drawing a property value in a Canvas.
// Changed by Rick to get the frame when needed

package bbw;

import java.awt.*;
import java.beans.*;

class PropertyCanvas extends Canvas {

    public PropertyCanvas(PropertyEditor pe) {
	editor = pe;
    }

    public void paint(Graphics g) {
	Rectangle box = new Rectangle(2, 2, size().width, size().height);
	editor.paintValue(g, box);
    }

    public boolean handleEvent(Event evt) {
	if (evt.id == Event.MOUSE_DOWN && evt.target == this) {
	    Frame frame = getFrame();
	    int x = frame.location().x - 30;
	    int y = frame.location().y + 50;
	    new PropertyDialog(frame, editor, x, y);
	}
	return false;
    }

    private Frame getFrame() {
	Container up = getParent();
	while (!(up instanceof Frame))
		up = up.getParent();
	return (Frame)up;
	}
    	
    private PropertyEditor editor;
}
