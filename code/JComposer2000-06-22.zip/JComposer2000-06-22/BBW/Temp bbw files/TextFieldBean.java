package bbw;

// This file extends several AWT Components so that they are JavaBeans,
// as in JDK 1.1.  However, they do not respond to the whole range of events, such
// as mouseEnter, etc.  They just respond to basic changes, such as ACTION, ITEM_CHANGE.

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class TextFieldBean extends TextField {
  public TextFieldBean(int cols) {
  	super(cols);
  	}
  
  public TextFieldBean(String text) {
  	super(text);
  	}
  
  public TextFieldBean(String text, int cols) {
  	super(text,cols);
  	}
  
  public boolean action(Event e, Object arg) {
	ActionEvent ev = new ActionEvent(this,ActionEvent.ACTION_PERFORMED,"TextEntered");

	Enumeration tell = listeners.elements();
	// NOT thread-safe!
	while (tell.hasMoreElements())
		((ActionListener) tell.nextElement()).actionPerformed(ev);
	return true;
	}

  public synchronized void addActionListener(ActionListener listener) {
  	listeners.addElement(listener);
  	}
  	
  public synchronized void removeActionListener(ActionListener listener) {
  	listeners.removeElement(listener);
  	}
  	
  private Vector listeners = new Vector();
  }
