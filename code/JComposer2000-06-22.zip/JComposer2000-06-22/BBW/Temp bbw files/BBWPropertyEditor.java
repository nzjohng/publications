package bbw;

import java.beans.*;
import java.awt.*;

public abstract class BBWPropertyEditor extends Panel implements PropertyEditor, PropertyChangeListener {

  public boolean isPaintable() {
  	return false;
  	}
  	
  public void paintValue(java.awt.Graphics gfx, java.awt.Rectangle box) {
  	}
  	
  public String getJavaInitializationString() {
  	return "initialisation";
  	}
  
  public String getAsText() {
  	return null;
  	}
  
  public void setAsText(String text) throws java.lang.IllegalArgumentException {
  	throw new IllegalArgumentException();
  	}
  
  public String[] getTags() {
  	return null;
  	}
  
  public java.awt.Component getCustomEditor() {
  	return this;
  	}
  	
  public boolean supportsCustomEditor() {
  	return true;
  	}
  
  public void addPropertyChangeListener(PropertyChangeListener listener) {
  	}
  
  public void removePropertyChangeListener(PropertyChangeListener listener) {
  	}
  
  }