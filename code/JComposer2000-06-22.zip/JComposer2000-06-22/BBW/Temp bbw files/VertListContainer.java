package bbw;

public class VertListContainer extends ContainerShape {
  	
  public void init(BBWContainer container, int x, int y) {
  	super.init(container,x,y);
  	}

  }
