package bbw;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class TextAreaBean extends TextArea {
  public TextAreaBean(int rows, int cols) {
  	super(rows,cols);
  	}
  
  public TextAreaBean(String text) {
  	super(text);
  	}
  
  public TextAreaBean(String text, int rows, int cols) {
  	super(text,rows,cols);
  	}
  
  public boolean action(Event e, Object arg) {
	ActionEvent ev = new ActionEvent(this,ActionEvent.ACTION_PERFORMED,"TextEntered");
	Enumeration tell = listeners.elements();
	// NOT thread-safe!
	while (tell.hasMoreElements())
		((ActionListener) tell.nextElement()).actionPerformed(ev);
	return true;
	}

  public synchronized void addActionListener(ActionListener listener) {
  	listeners.addElement(listener);
  	}
  	
  public synchronized void removeActionListener(ActionListener listener) {
  	listeners.removeElement(listener);
  	}
  	
  private Vector listeners = new Vector();
  }
