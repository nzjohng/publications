import erTool.*;
import bbw.*;
import erTool.*;
import java.awt.*;

public class ER extends java.applet.Applet {
  public void init() {
	Frame frame = new ERFrame();
	frame.pack();
	frame.show();
	}
  public static void main(String argv[]) {
	Frame frame = new ERFrame();
	frame.pack();
	frame.show();
	}
  }
