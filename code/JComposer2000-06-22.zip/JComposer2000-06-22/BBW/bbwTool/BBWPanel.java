package bbwTool;

import bbw.*;
import bbw.constraint.*;
import bbw.shape.*;
import bbw.controller.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class BBWPanel extends BBWGeneralPanel implements ActionListener, ItemListener{
	
  public BBWPanel() {
	setLayout(new BorderLayout());
	add("Center", panel);
	
	Panel controls = new Panel();
	controls.setLayout(new FlowLayout());
	controls.add(debugPropagation);
	debugPropagation.addItemListener(this);
	controls.add(displayShapes);
	displayShapes.addActionListener(this);
	controls.add(displayUserShapes);
	displayUserShapes.addActionListener(this);
	add("North", controls);

	controls = new Panel();
	controls.setLayout(new FlowLayout());
	controls.add(new Label("Shape:"));

	String[] bbwPackageName = { "bbw.shape","bbw.constraint","bbw.controller" };
	ToolManager.addToolPackageNames(bbwPackageName);
	createTools(tools );
	controls.add(toolChoice);
//	controls.add(compositeClassName);
//	controls.add(generateButton);
	add("South", controls);
	
	panel.setController((Controller)controllers.elementAt(0));
//  	generator = new BBWCompositeGenerator(panel.getTopContainer()); // FIX this later....
	}
  
  protected void createTools(String[] tools) {
	PopupController[] popupControllers = {
//		new TestPopupController(),
		new HidePopupController(),
		new ShowPopupController(),
		new PropSheetPopupController(),
		new DisposePopupController()
		};
	PopupManager.defineMenuItemsOfStandardPopup(panel,popupControllers);

	for (int i = 0; i < tools.length; i++)
		addTool(tools[i]);
	addConnectorTool("ConnectingLine", "LineShape");

	MoveController mover = new MoveController(panel.getTopContainer());
	panel.setMoveController(mover);
	addBuiltTool("Move",mover);

	ResizeController resizer = new ResizeController(panel.getTopContainer());
 	panel.setResizeController(resizer);
	addBuiltTool("Resize",resizer);

	addBuiltTool("Adjust",new AdjustController(panel.getTopContainer()));
	}
  	
  public void itemStateChanged(ItemEvent e) {
  	PropertyChangeSupport2.setDebug(debugPropagation.getState());
  	}

  public void actionPerformed(ActionEvent e) {
  	if (e.getSource() == displayShapes)
  		panel.displayShapes();
  	else if (e.getSource() == displayUserShapes)
  		panel.printUserElements();
  	}

  void makeNewShape() {
  	generating = SHAPE;
  	BBWContainer top = panel.getTopContainer();
  	outerRectangle = new RectangularShape();
  	outerRectangle.init(top,20,20);
  	outerRectangle.setSize(100,100);
  	}
  
  void generateNewShape(String className) {
   	PrintStream out = getFile(className);
  	generator.generateNewShape(out,outerRectangle);
 	out.close();
  	}
  
  PrintStream getFile(String className) {
   	PrintStream out;
   	if (className.equals(""))
   		out = System.out;
   	else {
	   	String home = System.getProperty("user.dir");
	   	String separator = System.getProperty("file.separator");
	   	String fileName = home + separator + " Generated" + separator + className+".java";
	   	System.out.println("File name for generate is '"+fileName+"'");
	 	FileOutputStream fileOut;
	 	try { fileOut = new FileOutputStream(fileName); }
	 	catch (IOException e) { throw new RuntimeException("Problem opening file "+className+".java:"+e); }
	 	out = new PrintStream(fileOut);
	 	}
	return out;
	}
  
  void makeNewDualConstraint() {
  	generating = DUAL;
  	}
  
  void generateDualConstraint(String className) {
  	}
  	
  void makeNewMonoConstraint() {
  	generating = MONO;
  	}
  
  void generateMonoConstraint(String className) {
  	}
  
  protected static int frameCount = 1;
  protected Checkbox debugPropagation = new Checkbox("Debug Propagation");
  protected Button displayShapes = new Button("Display Shapes");
  protected Button displayUserShapes = new Button("Display User Shapes");
//  protected TextField compositeClassName = new TextField(6);
//  protected Button generateButton = new Button("Generate");
  protected String[] tools = {
  		"RectangularShape", "BoxShape", "OvalShape", "DiamondShape",
  		"LineShape", "ArrowShape",
  		"TextShape", "FlexiTextShape", "ArcShape",
  		
 		"TextFieldShape", "ChoiceShape", "ButtonShape",
 		"DrawingContainerShape",

  		// "ArcConstraint",
  		"EqualityConstraint", "EqualityOnResize",
  		"EqualityResizeConstraint", "EqualityMoveConstraint",
  		"HorizontalConstraint", "HorizontalMoveConstraint", "HorizontalResizeConstr",
  		"HorizontalOnResizeConstr",
  		"VerticalConstraint", "VerticalMoveConstraint", "VerticalResizeConstraint",
  		"VerticalOnResizeConstr",
  		"DependentConstraint",
  		"ProportionalConstraint",
  		
  		"RelativePinConstraint" };
  private final static int NONE = 0, SHAPE = 1, DUAL = 2, MONO = 3;
  protected int generating = NONE;
  protected RectangularShape outerRectangle;
  protected BBWCompositeGenerator generator;
  }
