
package CIG;

import JViews.*;

public class CIGChatMessage extends MVChangeDescr
{

    public CIGChatMessage()
    {
        super();
    }

    public CIGChatMessage(MVComponent target, String user, String mesg)
    {
        super(target);
        setUser(user);
        setMessage(mesg);   
    }

    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public void setUser(String user)
    {
        setAnnotation("chat_user",user);
    }
  
    public String getUser()
    {   
        return getAnnotation("chat_user");
    }
    
    public void setMessage(String message)
    {
        setAnnotation("chat_mesg",message);
    }
    
    public String getMessage()
    {
        return getAnnotation("chat_mesg");
    }
  
    public String toString()
    {
        return "CIGChatMessage: "+getMessage();
    }
}
