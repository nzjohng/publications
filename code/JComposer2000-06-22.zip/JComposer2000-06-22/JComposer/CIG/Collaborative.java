/** This interface is implemented by all events that are 
        collaborative.  Such an event provides an execute method
        which takes a collaborativeBean as argument and which will
        have the same affect on the bean as on the one that originated
        the event.
*/
package CIG;

public interface Collaborative {
    void execute(Object collaborativeBean);
    }
