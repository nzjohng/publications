package CIG;

import JViews.*;
import java.net.URL;
import java.sql.*;

public class CIGmSQLInterface extends MVListener {

    public CIGmSQLInterface() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        
        propagateEvent(event);
        return event;
    }
    
    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    
    public boolean runSelect(String query)
    {

  try {
      Class.forName("com.imaginary.sql.msql.MsqlDriver");
      String url = "jdbc:msql://lucy.cs.waikato.ac.nz:4333/test";
      con = DriverManager.getConnection(url, "borg", "");
      stmt = con.createStatement();
      rs = stmt.executeQuery(query);
      return true;
    }
    catch( Exception e ) {
      System.out.println(e.getMessage());
      e.printStackTrace();
      return false;
    }
  }            
  
  public int getInt(String name)
  {
    if(rs == null)
        return -1;
        
    try {
        return rs.getInt(name);
    } catch(Exception e) {
        System.err.println(e);
        return -1;
    }
        
  }
    
  public String getString(String name)
  {
    if(rs == null)
        return null;
        
    try {
        return rs.getString(name);
    } catch(Exception e) {
        System.err.println(e);
        return null;
    }
        
  }
  
  public float getFloat(String name)
  {
    if(rs == null)
        return (float) -1.00;
        
    try {
        return rs.getFloat(name);
    } catch(Exception e) {
        System.err.println(e);
        return (float) -1.00;
    }  
  }
    
  public boolean hasMoreElements()
  {
    if(rs == null)
        return false;
        
    try {
        boolean n = rs.next();
        return n;
    } catch (Exception e) {
        System.err.println(e);
        return false;
    }
  }
    
  public void doneQuery() {
    if(rs == null)
        return;
        
    try {
      stmt.close();
      con.close();
    } catch (Exception e) {
        System.err.println(e);
    }
    
    rs = null;
  }
  
  public boolean runCommand(String command)
  {
    CIGSQLEvent c = new CIGSQLEvent(this,command);
    recordUpdate(c);
    
    return c.getDone();
  }
  
  public boolean doCommand(String command)
  {
    try {
      Class.forName("com.imaginary.sql.msql.MsqlDriver");
      String url = "jdbc:msql://lucy.cs.waikato.ac.nz:4333/test";
        con = DriverManager.getConnection(url, "borg", "");
        stmt = con.createStatement();   
        stmt.executeUpdate(command);
        stmt.close();
        con.close();
        return true;
    }
    catch( Exception e ) {
        e.printStackTrace();
        return false;
    }
  }

}

