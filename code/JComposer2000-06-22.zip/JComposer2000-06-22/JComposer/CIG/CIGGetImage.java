package CIG;

import java.beans.*;

public class CIGGetImage extends SimpleBeanInfo
{

    public CIGGetImage()
    {
        super();
    }

}
