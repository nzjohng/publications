package CIG;

import JViews.*;
import java.awt.*;
import java.awt.event.*;

public class CIGJobsEntry extends MVListener {

    public CIGJobsEntry() {
        super();
    }
    
    public MVComponent getcDBServer()
    {
        return getInputComp("dBServer");
    }

    public void showPropertySheet()
    {
        JCJobsFrame jf = new JCJobsFrame("Main Job Data Entry",this);
          
    }
    
    /*public MVChangeDescr afterChange(MVChangeDescr event, MVComponent from, String rel)
    {
        if(from == this && rel == "this")
            propagateEvent(event);
        
        return super.afterChange(event,from,rel);
    }            */

}

class JCJobsFrame extends Frame implements ActionListener
{
    CIGJobsEntry comp;
    
    Panel p1 = new Panel();
    
    Label l1 = new Label("Job ID:");
    TextField t1 = new TextField();
    Label l2 = new Label("Description:");
    TextField t2 = new TextField();
    Label l3 = new Label("Client ID:");
    TextField t3 = new TextField();
    Label l4 = new Label("Client Name:");
    Label t4 = new Label(); // i.e. read-only field...
    Label l5 = new Label("Est. cost:");
    TextField t5 = new TextField();
    Label l6 = new Label("Act. cost to date:");
    TextField t6 = new TextField();
    Label l7 = new Label("Completion date:");
    TextField t7 = new TextField();
    
    Panel p2 = new Panel();
    List budgetItems = new List();
    
    Panel p3 = new Panel();
    
    Button b1 = new Button("Close");
    Button b2 = new Button("Find Job");
    Button b3 = new Button("New Job");
    Button b4 = new Button("Update Job");
    Button b5 = new Button("Delete Job");
    Button b6 = new Button("New Budget");
    Button b7 = new Button("Update Budget");
    Button b8 = new Button("Delete Budget");
    Button b9 = new Button("Show Actuals");
    Button b10 = new Button("Show Resources");
    
    
    public JCJobsFrame(String name, CIGJobsEntry comp)
    {
        super(name);
        this.comp = comp;
        
        setLayout(new GridLayout(3,1));
        
        p1.setLayout(new GridLayout(7,2));
        p1.add(l1);
        p1.add(t1);
        p1.add(l2);
        p1.add(t2);
        p1.add(l3);
        p1.add(t3);
        p1.add(l4);
        p1.add(t4);
        p1.add(l5);
        p1.add(t5);
        p1.add(l6);
        p1.add(t6);
        p1.add(l7);
        p1.add(t7);
        
        p2.setLayout(new GridLayout(1,1));
        p2.add(budgetItems);
        
        p3.setLayout(new GridLayout(5,2));
        p3.add(b1);
        b1.addActionListener(this);
        p3.add(b2);
        b2.addActionListener(this);
        p3.add(b3);
        b3.addActionListener(this);
        p3.add(b4);
        b4.addActionListener(this);
        p3.add(b5);
        b5.addActionListener(this);
        p3.add(b6);
        b6.addActionListener(this);
        p3.add(b7);
        b7.addActionListener(this);
        p3.add(b8);
        b8.addActionListener(this);
        p3.add(b9);
        b9.addActionListener(this);
        p3.add(b10);
        b10.addActionListener(this);
        
        add(p1);
        add(p2);
        add(p3);
        
        
        setSize(400,500);
        pack();
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == b1) {
            setVisible(false);
        } else if(e.getSource() == b2) {
            int id = Integer.parseInt(t1.getText());
            System.out.println("Looking for job #"+id);
            
            // *** change to use MVMessage() to send/receive data...
            
            CIGmSQLInterface server = (CIGmSQLInterface) comp.getcDBServer();
            String str = "SELECT jc_job.id, jc_job.name, jc_job.client_id, jc_client.name, jc_job.est_cost, jc_job.act_cost, jc_job.completion FROM jc_job, jc_client WHERE jc_job.id = "+id+" AND jc_client.id = jc_job.client_id";
          System.out.println("'"+str+"'");
            if(server.runSelect(str)) {
                if(server.hasMoreElements()) {
                    int job_id = server.getInt("jc_job.id");
                    String descr  = server.getString("jc_job.name");
                    int client = server.getInt("jc_job.client_id");
                    String name = server.getString("jc_client.name");
                    float ecost = server.getFloat("jc_job.est_cost");
                    float acost = server.getFloat("jc_job.act_cost");
                    String date = server.getString("jc_job.completion");
                    
                    t1.setText(""+job_id);
                    t2.setText(descr);
                    t3.setText(""+client);
                    t4.setText(name);
                    t5.setText(""+ecost);
                    t6.setText(""+acost);
                    t7.setText(date);
                    
                    // get budgets...
                    server.doneQuery(); 
                     
                    str = "SELECT * from jc_budget WHERE id = "+id;
                    if(server.runSelect(str)) {
                        budgetItems.removeAll();
                        while(server.hasMoreElements()) {
                            int jid = server.getInt("id");
                            int num = server.getInt("num");
                            String bname = server.getString("name");
                            int start = server.getInt("start");
                            int end = server.getInt("end");
                            String res = server.getString("resource"); 
                            float amt = server.getFloat("amount");
                            
                            String item = ""+num+" "+bname+" "+start+" "+end+" "+res+" "+amt;
                            budgetItems.addItem(item);   
                        }
                    }
                    server.doneQuery();
                    
                    // broadcast new job selected event here...
                    
                    CIGJobSelected js = new CIGJobSelected(comp,job_id);
                    comp.propagateEvent(js);
                }
                
            }           
            
        }
        else if(e.getSource() == b3) {
            if(t1.getText() != "") {
                int id = Integer.parseInt(t1.getText());
                String name = t2.getText();
                int client = Integer.parseInt(t3.getText());
                float est_cost = Float.valueOf(t5.getText()).floatValue();
                float act_cost = Float.valueOf(t6.getText()).floatValue();
                String compl = t7.getText();
                
                CIGmSQLInterface server = (CIGmSQLInterface) comp.getcDBServer();
                String str = "INSERT INTO jc_job (id,name,client_id,est_cost,act_cost,completion) VALUES ("+id+",'"+name+"',"+client+","+est_cost+","+act_cost+",'"+compl+"')";
                
          System.out.println("'"+str+"'");
                if(server.runCommand(str))
                    System.out.println("Added job record");
            }        
        } else if(e.getSource() == b4) {
            if(t1.getText() != "") {
                int id = Integer.parseInt(t1.getText());
                String name = t2.getText();
                int client = Integer.parseInt(t3.getText());
                float est_cost = Float.valueOf(t5.getText()).floatValue();
                float act_cost = Float.valueOf(t6.getText()).floatValue();
                String compl = t7.getText();
                
                CIGmSQLInterface server = (CIGmSQLInterface) comp.getcDBServer();
                String str = "UPDATE jc_job SET name = '"+name+"', client_id = "+client+", est_cost = "+est_cost+", act_cost = "+act_cost+", completion = '"+compl+"' WHERE id = "+id;
                
          System.out.println("'"+str+"'");
                if(server.runCommand(str))
                    System.out.println("Updated job record");
            }
        } else if(e.getSource() == b5) {
            if(t1.getText() != "") {
                int id = Integer.parseInt(t1.getText());
                
                CIGmSQLInterface server = (CIGmSQLInterface) comp.getcDBServer();
                String str = "DELETE FROM jc_job WHERE id = "+id;
                
          System.out.println("'"+str+"'");
                if(server.runCommand(str))
                    System.out.println("Deleted job record");
            }
        }
    }
}

