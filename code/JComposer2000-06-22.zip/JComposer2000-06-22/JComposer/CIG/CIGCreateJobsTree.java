package CIG;

import JViews.*;
import java.net.URL;
import java.sql.*;

public class CIGCreateJobsTree extends MVListener {

    public CIGCreateJobsTree() {
        super();
    }
    
    int last = -1;

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof CIGJobSelected) {
            if(((CIGJobSelected) event).getId() != last) {
                last = ((CIGJobSelected) event).getId();
                makeJobs(last);
            }    
        }
        return event;
    }
 
    public MVComponent getcDBServer()
    {
        return getInputComp("dBServer");
    }
    
    public void makeJobs(int id)
    {

      CIGmSQLInterface server = (CIGmSQLInterface) getcDBServer();
      
      String s ="SELECT client_id FROM jc_job WHERE id = "+id;
      if(server.runSelect(s)) {
System.out.println(s);
        if(server.hasMoreElements()) {
        int client_id = server.getInt("client_id");
        server.doneQuery();
        s = "SELECT jc_job.id, jc_job.name, jc_budget.num, jc_budget.name, jc_budget.amount FROM jc_job, jc_budget WHERE jc_job.client_id = "+client_id+" AND jc_budget.id = jc_job.id ORDER BY jc_job.id, jc_budget.num";
        if(server.runSelect(s))  {
System.out.println(s);
            int last_job = -1;
            while(server.hasMoreElements()) {
                int jid = server.getInt("jc_job.id");
                String name = server.getString("jc_job.name");
                int num = server.getInt("jc_budget.num");
                String bname = server.getString("jc_budget.name");
                float amt = server.getFloat("jc_budget.amount");
                
              if(id != last_job) {
                System.out.println("Job "+jid+" "+name);
                last_job = id;
              } 
              
              System.out.println("Budget "+num+" "+name+" $"+amt);   
            }
            server.doneQuery();
         }
      }
      } 
   
    }           

}

