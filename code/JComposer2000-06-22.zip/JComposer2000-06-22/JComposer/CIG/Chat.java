package CIG;

import java.awt.*;
import java.awt.event.*;

    /**
    Chat is a collaborative bean because the event that it fires implements
    interface Collaborative, which defines method execute().
    It's a trivial chat bean.  A user types their name in the top TextField.
    After typing in the bottom TextField and hitting ENTER, the name and text is
    appended to the textHistory.
    
    Collaborators who clone this bean on their own machine simply enter their
    own name and start using it.  Events are managed by the collaborative
    framework to pass between them.  In this case, there is one event, fired
    when a user pressesd ENTER on the bottom (textEntry) TextField.

    This Panel was made into a bean by the steps:
    (1) Manage ActionListeners.
    (2) Introduce the addText() method.
    
    To make it collaborative, we extended ActionEvent to CollaborativeActionEvent
    with an execute() method that can be used to addText() to other Chat beans.
            
    I have included a local property historyFont, which is the font property of
    the textHistory.  This is local because no PropertyChangeEvent is fired
    when it is changed and so collaborators are not updated.
    */
public class Chat extends Panel {
    public Chat() {
        setLayout(new BorderLayout());
        add(name,BorderLayout.NORTH);
        add(textHistory,BorderLayout.CENTER);
        textHistory.setEnabled(false);
        add(textEntry,BorderLayout.SOUTH);
        textEntry.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae) {
                String namedText = name.getText()+": "+textEntry.getText();
                addText(namedText);
                if (listeners != null)
                    listeners.actionPerformed(new CollaborativeActionEvent(
                        this,ActionEvent.ACTION_PERFORMED, "Text Entry",namedText));
                textEntry.setText("");
                }
            });

        }

    public void addActionListener(ActionListener al) {
        listeners = AWTEventMulticaster.add(listeners,al);
        }

    public void removeActionListener(ActionListener al) {
        listeners = AWTEventMulticaster.remove(listeners,al);
        }

    public void addText(String text) {
        textHistory.append(text);
        textHistory.append("\n");
        }

    public Font getHistoryFont() {
        return textHistory.getFont();
        }
    
    public void setHistoryFont(Font font) {
        textHistory.setFont(font);
        }
        
    public String getName()
    {
        return name.getText();
    }
        
    protected TextField name = new TextField(60);
    protected TextArea textHistory = new TextArea(10,60);
    protected TextField textEntry = new TextField(60);
    protected ActionListener listeners = null;
    }
