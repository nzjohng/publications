
package CIG;

import JViews.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
import java.io.*;

public class CIGMap extends MVListener
{

    CIGMapCanvas map = new CIGMapCanvas();

    public CIGMap()
    {
        super();
        Frame f = new Frame(userName());
        f.setSize(400,350);
        
        f.add(map);
        f.setVisible(true); 
    }
    
    public String userName()
    {
        return "map visualisation";
    }
    
    public String getName()
    {
        return getStringValue("name");
    }

    public void setName(String name)
    {
        setValue("name",name);
    }

    public String getRoute()
    {
        return getStringValue("cities");
    }
   
    public void setRoute(String cities)
    {
        setValue("cities",cities);
        map.setRoute(cities);
    }

    public int getWidth()
    {
        return getIntValue("width");
    }

    public void setWidth(int width)
    {
        setValue("width",width);
    }

    public int getHeight()
    {
        return getIntValue("height");
    }

    public void setHeight(int height)
    {
        setValue("height",height);
    }

    public String getUpdate()
    {
        return getStringValue("update");
    }

    public void setUpdate(String update)
    {
        setValue("update",update);
    }

    public String getPersistency()
    {
        return getStringValue("persistency");
    }

    public void setPersistency(String persistency)
    {
        setValue("persistency",persistency);
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"name","route","width","height","update","persistency"};

        return ss;
    }
    
    String last_route = "";
    
    public MVChangeDescr afterChange(MVChangeDescr event, MVComponent from, String rel)
    {
        
 System.out.println("CIGMap got "+event+" from "+from.userName()+ " via "+rel);       
        if(event instanceof MVSetStringValue)
            if(((MVSetStringValue) event).getPropertyName().equals("cities"))
                if(from == this)
                    if(rel.equals("this")) 
                        if(!getRoute().equals(last_route))  {
                            last_route = getRoute();
                  System.out.println("last_route = "+last_route);
                            propagateEvent(event);
                        }
                    
        return super.afterChange(event,from,rel);
    }

}

class CIGMapCanvas extends Canvas
{

    Image map_image;

    public CIGMapCanvas()
    {
        super();
        CIGGetImage im = new CIGGetImage();
        map_image = im.loadImage("australia4.gif");
        readCities();
    }
    
    public Vector cities = new Vector();
    
    public void readCities()
    {
        try {
            FileReader file = new FileReader("cigmap.txt");
            StreamTokenizer input = new StreamTokenizer(file);
            input.eolIsSignificant(false);
            input.whitespaceChars(0,32);
            input.wordChars(33,127);
            input.quoteChar('"');
            
            int token = input.nextToken();
            while(!(token == input.TT_EOF))
            {
                String name = input.sval;
                token = input.nextToken();
                int x = (int) input.nval;
                token = input.nextToken();
                int y = (int) input.nval;
              System.out.println("added "+name+x+y);
                token = input.nextToken();
                CIGMapCity city = new CIGMapCity(name,x,y);
                cities.addElement(city);
                
            }
            file.close();
        } catch(FileNotFoundException e) {
            System.out.println("No map cities file!");
            System.exit(1);
        } catch(IOException e) {
            System.out.println("Got IO exception: "+e);
            System.exit(1);
        }
    }
    
    public CIGMapCity findCity(String name)
    {
        Enumeration e = cities.elements();
        while(e.hasMoreElements()) {
            CIGMapCity city = (CIGMapCity) e.nextElement();
            if(city.getName().equals(name))
                return city;
        }
        
        return null;
    }
    
    public void paint(Graphics g)
    {
        g.drawImage(map_image,0,0,500,425,0,0,map_image.getWidth(null),map_image.getHeight(null),null);
        
        
        int last_x = 0;
        int last_y = 0;
        
        StringTokenizer e = new StringTokenizer(route);
        while(e.hasMoreTokens())
        {
            String city = e.nextToken();
            int loc_x = getXCoord(city);
            int loc_y = getYCoord(city);
            g.setColor(Color.yellow);
            g.fillOval(loc_x-2,loc_y-2,4,4);
            g.drawString(city,loc_x+6,loc_y-4);
            if(last_x > 0) {
                g.drawLine(last_x,last_y,loc_x,loc_y);
            }
            last_x = loc_x;
            last_y = loc_y;
        }
    }
    
    protected String route = "";
    
    public void setRoute(String cities)
    {
        this.route = cities;
        repaint();
    }
    
    public String getRoute()
    {
        return route;
    } 
    
    public int getXCoord(String city)
    {
        CIGMapCity c = findCity(city);
        if(c == null)
            return -1;
        return c.getX();
    }
    
    public int getYCoord(String city)
    {
        CIGMapCity c =findCity(city);
        if(c == null)
            return -1;
        return c.getY();
    }
    
}

class CIGMapCity
{

    String name;
    int x;
    int y;
    
    public CIGMapCity(String name, int x, int y)
    {
        this.name = name;
        this.x = x;
        this.y = y;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getX()
    {
        return x;
    }
    
    public int getY()
    {
        return y;
    }

}
