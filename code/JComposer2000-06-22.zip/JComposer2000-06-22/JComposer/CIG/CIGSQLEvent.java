package CIG;

import JViews.*;

public class CIGSQLEvent extends MVChangeDescr
{
    public CIGSQLEvent()
    {
        super();
    }
    
    public CIGSQLEvent(CIGmSQLInterface target, String command)
    {
        super(target);
        setCommand(command);    
    }
    
    public String getCommand()
    {
        return getAnnotation("command");
    }
    
    public void setCommand(String command)
    {
        setAnnotation("command",command);
    }
    
    public String toString()
    {
        return "SQL Command: "+getCommand();
    }
    
    public void execute()
    {
        done = ((CIGmSQLInterface) target).doCommand(getCommand());            
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }

}
