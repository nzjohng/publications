package CIG;

import JViews.*;
import CIG.ItenaryClient.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class CIGItenaryVisualiser extends MVListener
{

    String route = "";
    Vector cities = new Vector();

    public CIGItenaryVisualiser()
    {
        super();
        
        // load city names...
        
        readCityNames(); 
    }
    
    public void readCityNames()
    {
        try {
            FileReader file = new FileReader("cigmap.txt");
            StreamTokenizer input = new StreamTokenizer(file);
            input.eolIsSignificant(false);
            input.whitespaceChars(0,32);
            input.wordChars(33,127);
            input.quoteChar('"');
            
            int token = input.nextToken();
            while(!(token == input.TT_EOF))
            {
                String name = input.sval;
                token = input.nextToken();
                int x = (int) input.nval;
                token = input.nextToken();
                int y = (int) input.nval;
              System.out.println("added "+name);
                token = input.nextToken();
                cities.addElement(name);
                
            }
            file.close();
        } catch(FileNotFoundException e) {
            System.out.println("No map cities file!");
            System.exit(1);
        } catch(IOException e) {
            System.out.println("Got IO exception: "+e);
            System.exit(1);
        }
    }
    
    // uses 1:1 link called "itenary" to find itenary component
    // this is an "event flow" link
    
    public CIGItenary getpItenary()
    {
        return (CIGItenary) getInputComp("itenary");
    }
    
    // use 1:1 link called "map" to get map visualiser
    // this is a "usage" link
    
    public MVComponent getpMap()
    {
        // return MVComp as might be "remote" comp...
        return getInputComp("map");
    }

    public void showPropertySheet()
    {
    // want composite of this component props+itinerary+map
    //

        Panel p1 = getPropertySheetPanel();
        Panel p2 = getpItenary().getPropertySheetPanel();
        Panel p3 = getpMap().getPropertySheetPanel();
        Panel p4 = new Panel();
        p4.setLayout(new GridLayout(1,2,2,2));
        p4.add(p2);
        p4.add(p3);
        

        Frame f = new Frame("Visulisation properties");

        f.addWindowListener( new CIGVisWindowAdapter(f));

        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;       
        
        f.setLayout(gbl);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.gridheight = 1;
        gbl.setConstraints(p1,gbc);
        f.add(p1);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2; gbc.gridheight = 2;
        gbl.setConstraints(p4,gbc);
        f.add(p4);
        f.pack();
        f.show();
    }

    private class CIGVisWindowAdapter extends WindowAdapter {
        Frame f;

        public CIGVisWindowAdapter(Frame f) { this.f = f; }

        public void windowClosing(WindowEvent e) {f.setVisible(false);}
    }

    public String getName()
    {
        return getStringValue("name");
    }

    public void setName(String n)
    {
        setValue("name",n);
    }

    public boolean getStoreEvents()
    {
        return getBooleanValue("storeEvents");
    }

    public void setStoreEvents(boolean s)
    {
        setValue("storeEvents",s);
    }

    public String getUpdate()
    {
        return getStringValue("update");
    }

    public void setUpdate(String u)
    {
        setValue("update",u);
    }

    public String [] getEditableProperties() {
        String ss[] = {"name","storeEvents","update"};

        return ss;
    }
    
    // when get ItenaryChangeEvent, recalculate route and if this
    // has changed, feed it into the map visualisation...
    
    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        
        if(event instanceof CIGItenaryChangeEvent) {
        
        System.out.println("Visualiser got "+event);
        
            String data = getpItenary().getItenaryData();
        System.out.println("Data = "+data);
            String new_route = extractRoute(data);
        System.out.println("new route = "+new_route);
            if(!new_route.equals(route)) {
                route = new_route;
                // getpMap().setRoute(new_route);
                // remote method invocation:
                MVMessage mesg = new MVMessage(getpMap(),"setRoute",new_route);
                mesg.execute();

            }
            propagateEvent(event);
        }
        return event;
    }
    
    // extract city names from given String (itenary data)
    
    public String extractRoute(String data)
    {
        String route = "";
        StringTokenizer tokens = new StringTokenizer(data,"\n "+'"');
        
        while(tokens.hasMoreTokens()) {
            String token = tokens.nextToken();
     System.out.println("got token '"+token+"'");
            if(findCity(token))
                route = route+token+" ";
        }
        
        return route;    
    }
    
    public boolean findCity(String name)
    {
        Enumeration e = cities.elements();
        while(e.hasMoreElements())
        {
            String city = (String) e.nextElement();
            if(city.equals(name))
                return true;
        }
        
        return false;
    }

}
