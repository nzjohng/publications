package CIG;

import JViews.*;
import java.awt.*;
import java.awt.event.*;

public class CIGChat extends MVListener implements ActionListener
{

    Chat ch = new Chat();      

    public CIGChat()
    {
        Frame f = new Frame(userName());
        f.setSize(150,200);
        f.add(ch);
        ch.addActionListener(this);
        f.setVisible(true);        
        
    }
    
    public String userName()
    {
        return "collaborative chat";
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e instanceof CollaborativeActionEvent) {
            CIGChatMessage mesg = new CIGChatMessage(this,
                ch.getName(),
                ((CollaborativeActionEvent) e).getEnteredText());
            propagateEvent(mesg);
          System.out.println(mesg);
        }
    }
    
    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
    {
    
System.out.println("CIGChat got: "+c);    
        if(c instanceof CIGChatMessage) {
            String user = ((CIGChatMessage) c).getUser();
            String mesg = ((CIGChatMessage) c).getMessage();
            
            if(!user.equals(ch.getName()))
                ch.addText(mesg);
        }
        
       
        return super.afterChange(c,from,rel); 
    }

}
