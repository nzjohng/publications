
package CIG.ItenaryClient;

import JViews.*;

public class CIGItenaryRemoveEvent extends MVChangeDescr
{
    String index;
    String name;

    public CIGItenaryRemoveEvent()
    {
        super();
    }
    
    public CIGItenaryRemoveEvent(CIGItenary itenary, String index, String name)
    {
        super(itenary);
        setIndex(index);
        setName(name);
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString()
    {
        return "ItenaryRemove: "+getIndex()+" '"+getName()+"'";
    }
    
    public void setIndex(String value)
    {
        setAnnotation("index",value);
    }
    
    public String getIndex()
    {
        return getAnnotation("index");
    }
    
    public void setName(String value)
    {
        setAnnotation("name",value);
    }
    
    public String getName()
    {
        return getAnnotation("name");
    }
}
