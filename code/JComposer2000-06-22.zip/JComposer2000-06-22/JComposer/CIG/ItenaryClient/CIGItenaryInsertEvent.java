
package CIG.ItenaryClient;

import JViews.*;

public class CIGItenaryInsertEvent extends MVChangeDescr
{

    public CIGItenaryInsertEvent()
    {
        super();
    }
    
    public CIGItenaryInsertEvent(CIGItenary itenary, String index, String name)
    {
        super(itenary);
        setIndex(index);
        setName(name);
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString()
    {
        return "ItenaryInsert: "+getIndex()+" '"+getName()+"'";
    }
    
    public void setIndex(String value)
    {
        setAnnotation("index",value);
    }
    
    public String getIndex()
    {
        return getAnnotation("index");
    }
    
    public void setName(String value)
    {
        setAnnotation("name",value);
    }
    
    public String getName()
    {
        return getAnnotation("name");
    }

}
