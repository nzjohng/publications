
package CIG.ItenaryClient;

import JViews.*;

public class CIGItenaryEvent extends MVChangeDescr
{
    String index;
    String name;

    public CIGItenaryEvent()
    {
        super();
    }
    
    public CIGItenaryEvent(CIGItenary itenary, String index, String name)
    {
        super(itenary);
        this.index = index;
        this.name = name;
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString()
    {
    
    }

}
