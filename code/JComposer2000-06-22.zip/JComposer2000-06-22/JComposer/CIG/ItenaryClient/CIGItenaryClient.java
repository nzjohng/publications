
package CIG.ItenaryClient;

import com.sun.java.swing.*;
import com.sun.java.swing.event.*;
import java.awt.event.*;
import java.awt.*;
import com.sun.java.swing.tree.*;
import java.io.*;
import java.util.*;
import CIG.*;
import JViews.*;

/**
  * A demo for illustrating how to do different things with JTree.
  * The data that this displays is rather boring, that is each node will
  * have 7 children that have random names based on the fonts.  Each node
  * is then drawn with that font and in a different color.
  * While the data isn't interesting the example illustrates a number
  * of things:
  *
  * For an example of dynamicaly loading children refer to DynamicTreeNode.
  * For an example of adding/removing/inserting/reloading refer to the inner
  *     classes of this class, AddAction, RemovAction, InsertAction and
  *     ReloadAction.
  * For an example of creating your own cell renderer refer to
  *     SampleTreeCellRenderer.
  * For an example of subclassing JTreeModel for editing refer to
  *     SampleTreeModel.
  *
  * @version 1.13 05/20/98
  * @author Scott Violet
  */

public class CIGItenaryClient implements ItenaryListener
{
    /** Window for showing Tree. */
    protected JFrame            frame;
    /** Tree used for the example. */
    protected JTree             tree;
    /** Tree model. */
    protected DefaultTreeModel        treeModel;

    /**
      * Constructs a new instance of SampleTree.
      */
    public CIGItenaryClient() {
    // Force SampleTree to come up in the Cross Platform L&F
    try {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        // If you want the System L&F instead, comment out the above line and
        // uncomment the following:
        // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception exc) {
        System.err.println("Error loading L&F: " + exc);
    }


    JMenuBar         menuBar = constructMenuBar();
    JPanel           panel = new JPanel(true);

    frame = new JFrame("Itenary");
    frame.getContentPane().add("Center", panel);
    frame.setJMenuBar(menuBar);
    frame.setBackground(Color.lightGray);

// frame.getContentPane().add("South",new Chat());

    /* Create the JTreeModel. */
    DefaultMutableTreeNode root = createNewNode("Root");
    treeModel = new CIGItenaryModel(root);

    /* Create the tree. */
    tree = new JTree(treeModel);

    /* Enable tool tips for the tree, without this tool tips will not
       be picked up. */
    ToolTipManager.sharedInstance().registerComponent(tree);

    /* Make the tree use an instance of SampleTreeCellRenderer for
       drawing. */
    tree.setCellRenderer(new CIGItenaryCellRenderer());

    /* Make tree ask for the height of each row. */
    tree.setRowHeight(-1);
    
    tree.setShowsRootHandles(true);

    tree.setRootVisible(true);
    
    tree.setEditable(true);

    /* Put the Tree in a scroller. */
    JScrollPane        sp = new JScrollPane();
    sp.setPreferredSize(new Dimension(300, 300));
    sp.getViewport().add(tree);

    /* And show it. */
    panel.setLayout(new BorderLayout());
    panel.add("Center", sp);
    panel.add("South", basicDetailsPanel());

    frame.addWindowListener( new WindowAdapter() {
        public void windowClosing(WindowEvent e) {System.exit(0);}});

    frame.pack();
    frame.show();
    
    }
    
    private JPanel basicDetailsPanel()
    {
        JPanel options = new JPanel(false);
     
        JLabel l1 = new JLabel("Itenary for:");
        JTextField t1 = new JTextField("<name>");
        
        options.setLayout(new GridLayout(2,1));
        options.add(l1);
        options.add(t1);
     
        return options;
    }

    /** Constructs a JPanel containing check boxes for the different
      * options that tree supports. 
    private JPanel constructOptionsPanel() {
    JCheckBox               aCheckbox;
    JPanel           retPanel = new JPanel(false);
    JPanel           borderPane = new JPanel(false);

    borderPane.setLayout(new BorderLayout());
    retPanel.setLayout(new FlowLayout());

    aCheckbox = new JCheckBox("show handles");
    aCheckbox.setSelected(tree.getShowsRootHandles());
    aCheckbox.addChangeListener(new ShowHandlesChangeListener());
    retPanel.add(aCheckbox);

    aCheckbox = new JCheckBox("show root");
    aCheckbox.setSelected(tree.isRootVisible());
    aCheckbox.addChangeListener(new ShowRootChangeListener());
    retPanel.add(aCheckbox);

    aCheckbox = new JCheckBox("editable");
    aCheckbox.setSelected(tree.isEditable());
    aCheckbox.addChangeListener(new TreeEditableChangeListener());
    aCheckbox.setToolTipText("Triple click to edit");
    retPanel.add(aCheckbox);

    borderPane.add(retPanel, "North");

    ButtonGroup           group = new ButtonGroup();
    JPanel         buttonPane = new JPanel(false);
    JRadioButton          button;

    buttonPane.setLayout(new FlowLayout());
    button = new JRadioButton("Single");
    button.addActionListener(new AbstractAction() {
        public boolean isEnabled() { return true; }
        public void actionPerformed(ActionEvent e) {
        tree.getSelectionModel().setSelectionMode
            (TreeSelectionModel.SINGLE_TREE_SELECTION);
        }
    });
    group.add(button);
    buttonPane.add(button);
    button = new JRadioButton("Contiguous");
    button.addActionListener(new AbstractAction() {
        public boolean isEnabled() { return true; }
        public void actionPerformed(ActionEvent e) {
        tree.getSelectionModel().setSelectionMode
            (TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
        }
    });
    group.add(button);
    buttonPane.add(button);
    button = new JRadioButton("Discontiguous");
    button.addActionListener(new AbstractAction() {
        public boolean isEnabled() { return true; }
        public void actionPerformed(ActionEvent e) {
        tree.getSelectionModel().setSelectionMode
            (TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);
        }
    });
    button.setSelected(true);
    group.add(button);
    buttonPane.add(button);

    borderPane.add(buttonPane, "South");
    return borderPane;
    }
    */
    
    /** Construct a menu. */
    private JMenuBar constructMenuBar() {
    JMenu            menu;
    JMenuBar         menuBar = new JMenuBar();
    JMenuItem        menuItem;

    /* Good ol exit. */
    menu = new JMenu("File");
    menuBar.add(menu);

    menuItem = menu.add(new JMenuItem("Save"));
    menuItem.addActionListener(new SaveAction());

    menuItem = menu.add(new JMenuItem("Exit"));
    menuItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        System.exit(0);
        }});
        
    /* Tree related stuff. */
    menu = new JMenu("Tree");
    menuBar.add(menu);

    menuItem = menu.add(new JMenuItem("Add"));
    menuItem.addActionListener(new AddAction());

    menuItem = menu.add(new JMenuItem("Insert"));
    menuItem.addActionListener(new InsertAction());
    
    menuItem = menu.add(new JMenuItem("Add Subitem"));
    menuItem.addActionListener(new SubItemAction());

    menuItem = menu.add(new JMenuItem("Reload"));
    menuItem.addActionListener(new ReloadAction());

    menuItem = menu.add(new JMenuItem("Remove"));
    menuItem.addActionListener(new RemoveAction());

    menuItem = menu.add(new JMenuItem("-"));

    menuItem = menu.add(new JMenuItem("Add Flight"));
    menuItem.addActionListener(new AddFlightAction());

    menuItem = menu.add(new JMenuItem("Add Hotel"));
    menuItem.addActionListener(new AddHotelAction());

    menuItem = menu.add(new JMenuItem("Add Rental Car"));
    menuItem.addActionListener(new AddRentalAction());

    menuItem = menu.add(new JMenuItem("Add Stop"));
    menuItem.addActionListener(new AddStopAction());

    menu = new JMenu("Collaboration");
    menuBar.add(menu);


    return menuBar;
    }



    /**
      * Returns the TreeNode instance that is selected in the tree.
      * If nothing is selected, null is returned.
      */
    protected DefaultMutableTreeNode getSelectedNode() {
    TreePath   selPath = tree.getSelectionPath();

    if(selPath != null)
        return (DefaultMutableTreeNode)selPath.getLastPathComponent();
    return null;
    }

    protected CIGItenaryDynamicNode createNewNode(String name) {
    CIGItenaryData data = new CIGItenaryData(null, Color.black, name);
    CIGItenaryDynamicNode node = new CIGItenaryDynamicNode(this,data);
    data.setParent(node);
    return node;
    }

    /**
      * AddAction is used to add a new item after the selected item.
      */
    class AddAction extends Object implements ActionListener
    {
    /** Number of nodes that have been added. */
    public int               addCount;

    /**
      * Messaged when the user clicks on the Add menu item.
      * Determines the selection from the Tree and adds an item
      * after that.  If nothing is selected, an item is added to
      * the root.
      */
    public void actionPerformed(ActionEvent e) {
        int               newIndex;
        DefaultMutableTreeNode          lastItem = getSelectedNode();
        DefaultMutableTreeNode          parent;

        /* Determine where to create the new node. */
        if(lastItem != null) {
        parent = (DefaultMutableTreeNode)lastItem.getParent();
        if(parent == null) {
            parent = (DefaultMutableTreeNode)treeModel.getRoot();
            lastItem = null;
        }
        }
        else
        parent = (DefaultMutableTreeNode)treeModel.getRoot();
        if(lastItem == null)
        newIndex = treeModel.getChildCount(parent);
        else
        newIndex = parent.getIndex(lastItem) + 1;

        /* Let the treemodel know. */
        CIGItenaryDynamicNode node = createNewNode("New node");
        treeModel.insertNodeInto(node, parent, newIndex);
        fireAddedNode(node);
        
    }
    } // End of SampleTree.AddAction


    /**
      * InsertAction is used to insert a new item before the selected item.
      */
    class InsertAction extends Object implements ActionListener
    {
    /** Number of nodes that have been added. */
    public int               insertCount;

    /**
      * Messaged when the user clicks on the Insert menu item.
      * Determines the selection from the Tree and inserts an item
      * after that.  If nothing is selected, an item is added to
      * the root.
      */
    public void actionPerformed(ActionEvent e) {
        int               newIndex;
        DefaultMutableTreeNode          lastItem = getSelectedNode();
        DefaultMutableTreeNode          parent;

        /* Determine where to create the new node. */
        if(lastItem != null) {
        parent = (DefaultMutableTreeNode)lastItem.getParent();
        if(parent == null) {
            parent = (DefaultMutableTreeNode)treeModel.getRoot();
            lastItem = null;
        }
        }
        else
        parent = (DefaultMutableTreeNode)treeModel.getRoot();
        if(lastItem == null)
        newIndex = treeModel.getChildCount(parent);
        else
        newIndex = parent.getIndex(lastItem);

        /* Let the treemodel know. */
        CIGItenaryDynamicNode node = createNewNode("New node");
        treeModel.insertNodeInto(node, parent, newIndex);
        fireAddedNode(node);
    }
    } // End of SampleTree.InsertAction


    class SubItemAction extends Object implements ActionListener
    {
    /**
      * Messaged when the user clicks on the Add Subitem menu item.
      * Determines the selection from the Tree and asks the treemodel
      * to reload from that node.
      */
    public void actionPerformed(ActionEvent e) {
        int               newIndex;
        //DefaultMutableTreeNode          lastItem = getSelectedNode();
        DefaultMutableTreeNode  parent =        getSelectedNode();

        /* Determine where to create the new node. */
        if(parent != null) {
        
            /* Let the treemodel know. */
            CIGItenaryDynamicNode node = createNewNode("New node");
            treeModel.insertNodeInto(node, parent, 0);
            fireAddedNode(node);
        }
    }
    } // End of SampleTree.SubItemAction



    /**
      * ReloadAction is used to reload from the selected node.  If nothing
      * is selected, reload is not issued.
      */
    class ReloadAction extends Object implements ActionListener
    {
    /**
      * Messaged when the user clicks on the Reload menu item.
      * Determines the selection from the Tree and asks the treemodel
      * to reload from that node.
      */
    public void actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode          lastItem = getSelectedNode();

        if(lastItem != null)
        treeModel.reload(lastItem);
    }
    } // End of SampleTree.ReloadAction

    /**
      * RemoveAction removes the selected node from the tree.  If
      * The root or nothing is selected nothing is removed.
      */
    class RemoveAction extends Object implements ActionListener
    {
    /**
      * Removes the selected item as long as it isn't root.
      */
    public void actionPerformed(ActionEvent e) {
        DefaultMutableTreeNode          lastItem = getSelectedNode();

        if(lastItem != null && lastItem != (DefaultMutableTreeNode)treeModel.getRoot()) {
            fireRemovedNode((CIGItenaryDynamicNode) lastItem);        
            treeModel.removeNodeFromParent(lastItem);
        }
    }
    } // End of SampleTree.RemoveAction

    class AddFlightAction extends Object implements ActionListener
    {
    
    public void actionPerformed(ActionEvent e) {
        Frame f = new Frame("Client flight details");
        f.setLayout(new GridLayout(1,1));
        Panel p = new Panel();
        f.add(p);
        p.setLayout(new GridLayout(4,2));
        Label l1 = new Label("Date");
        TextField t1 = new TextField("");
 l1.setForeground(Color.red);
 t1.setForeground(Color.red);
        p.add(l1);
        p.add(t1);
        Label l2 = new Label("Time");
        TextField t2 = new TextField("");
        p.add(l2);
        p.add(t2);
        Label l3 = new Label("Flight");
        TextField t3 = new TextField("");
        p.add(l3);
        p.add(t3);
        Label l4 = new Label("Details");
        TextField t4 = new TextField("");
        p.add(l4);
        p.add(t4);
        
        f.pack();
        f.addWindowListener( new CIGItWindowAdapter(f));
        f.show();
        }
    }

    class AddRentalAction extends Object implements ActionListener
    {
    
        public void actionPerformed(ActionEvent e) {
            MVUIConfigInfo info = new MVUIConfigInfo();
            info.configure();
        }

    }



    class AddStopAction extends Object implements ActionListener
    {
    
        public void actionPerformed(ActionEvent e) {
            DefaultMutableTreeNode          lastItem = getSelectedNode();
            ((CIGItenaryData) lastItem.getUserObject()).setColor(Color.red);
        }

    }

     class CIGItWindowAdapter extends WindowAdapter {
        Frame f;

        public CIGItWindowAdapter(Frame f) { this.f = f; }

        public void windowClosing(WindowEvent e) {f.setVisible(false);}
    }


    class AddHotelAction extends Object implements ActionListener
    {
    
    public void actionPerformed(ActionEvent e) {
        Frame f = new Frame("Agent flight details");
        f.setLayout(new GridLayout(1,1));
        Panel p = new Panel();
        f.add(p);
        p.setLayout(new GridLayout(6,2));
        Label l1 = new Label("Date");
        TextField t1 = new TextField("");
        p.add(l1);
        p.add(t1);
        Label l2 = new Label("Time");
        TextField t2 = new TextField("");
        p.add(l2);
        p.add(t2);
        Label l3 = new Label("Flight");
        TextField t3 = new TextField("");
        p.add(l3);
        p.add(t3);
        Label l4 = new Label("Details");
        TextField t4 = new TextField("");
        p.add(l4);
        p.add(t4);
 
        Label l5 = new Label("Stops");
        TextField t5 = new TextField("");
        p.add(l5);
        p.add(t5);
        Label l6 = new Label("Fare Code");
        TextField t6 = new TextField("");
        p.add(l6);
        p.add(t6);

        f.pack();
        f.addWindowListener( new CIGItWindowAdapter(f));
        f.show();
        }
    }
    
    class SaveAction extends Object implements ActionListener
    {
    /**
      * Messaged when the user clicks on the Reload menu item.
      * Determines the selection from the Tree and asks the treemodel
      * to reload from that node.
      */
    public void actionPerformed(ActionEvent e) {
        PrintWriter out = new PrintWriter(System.out); // for now...
        ((CIGItenaryDynamicNode) (treeModel.getRoot())).writeNodes(out);
        out.flush();              
    }
    } // End of SampleTree.SaveAction


    /**
      * ShowHandlesChangeListener implements the ChangeListener interface
      * to toggle the state of showing the handles in the tree.
      */
    class ShowHandlesChangeListener extends Object implements ChangeListener
    {
    public void stateChanged(ChangeEvent e) {
        tree.setShowsRootHandles(((JCheckBox)e.getSource()).isSelected());
    }

    } // End of class SampleTree.ShowHandlesChangeListener


    /**
      * ShowRootChangeListener implements the ChangeListener interface
      * to toggle the state of showing the root node in the tree.
      */
    class ShowRootChangeListener extends Object implements ChangeListener
    {
    public void stateChanged(ChangeEvent e) {
        tree.setRootVisible(((JCheckBox)e.getSource()).isSelected());
    }

    } // End of class SampleTree.ShowRootChangeListener


    /**
      * TreeEditableChangeListener implements the ChangeListener interface
      * to toggle between allowing editing and now allowing editing in
      * the tree.
      */
    class TreeEditableChangeListener extends Object implements ChangeListener
    {
    public void stateChanged(ChangeEvent e) {
        tree.setEditable(((JCheckBox)e.getSource()).isSelected());
    }

    } // End of class SampleTree.TreeEditableChangeListener
    
     public void addItenaryListener(ItenaryListener al) {
        listeners.addElement(al);
        }

    public void removeItenaryListener(ItenaryListener al) {
        listeners.removeElement(al);
        }

    protected Vector listeners = new Vector();   
    
    protected void fireAddedNode(CIGItenaryDynamicNode node)
    {
        Enumeration e = listeners.elements();
        while(e.hasMoreElements()) {
            ((ItenaryListener) e.nextElement()).itemAdded(new ItenaryEvent(this,ItenaryEvent.ITEM_ADDED,node));
        }
    }

    protected void fireRemovedNode(CIGItenaryDynamicNode node)
    {
        Enumeration e = listeners.elements();
        while(e.hasMoreElements()) {
            ((ItenaryListener) e.nextElement()).itemRemoved(new ItenaryEvent(this,ItenaryEvent.ITEM_REMOVED,node));
        }
    }
    
    protected void fireItemChanged(CIGItenaryDynamicNode node, String oldValue, String newValue)
    {
        Enumeration e = listeners.elements();
        while(e.hasMoreElements()) {
            ((ItenaryListener) e.nextElement()).itemChanged(new ItenaryEvent(this,ItenaryEvent.ITEM_CHANGED,node,oldValue,newValue));
        }    }
    
public void itemAdded(ItenaryEvent e)
{
    System.out.println("Added: "+e);
}

public void itemRemoved(ItenaryEvent e)
{
    System.out.println("Removed: "+e);
}

public void itemChanged(ItenaryEvent e)
{
    System.out.println("Changed: "+e);
}

    public String getItenaryData()
    {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        PrintWriter out = new PrintWriter(buf);
        try {
            ((CIGItenaryDynamicNode) (treeModel.getRoot())).writeNodes(out);
            out.flush();
            buf.flush();
            return buf.toString();
        } catch (IOException e) {
            System.out.println("IOException: "+e);
            return "";
        }  
    }

    static public void main(String args[]) {
    new CIGItenaryClient();
    }

}


