
package CIG.ItenaryClient;

public interface ItenaryListener
{

    public void itemAdded(ItenaryEvent e);
    
    public void itemRemoved(ItenaryEvent e);
    
    public void itemChanged(ItenaryEvent e);

}
