package CIG.ItenaryClient;

import JViews.*;

public class CIGItenary extends MVListener implements ItenaryListener
{

    CIGItenaryClient client;


    public CIGItenary()
    {
        super();
        client = new CIGItenaryClient();
        client.addItenaryListener(this);
    }
    
    public void itemAdded(ItenaryEvent e)
    {
        CIGItenaryInsertEvent c = new CIGItenaryInsertEvent(this,e.getNode().getIndex(),e.getNode().getLabel());
      System.out.println(c);  
        propagateEvent(c);
    }

    public void itemRemoved(ItenaryEvent e)
    {
       CIGItenaryRemoveEvent c = new CIGItenaryRemoveEvent(this,e.getNode().getIndex(),e.getNode().getLabel());
      System.out.println(c); 
       propagateEvent(c);
    }

    public void itemChanged(ItenaryEvent e)
    {
        CIGItenaryChangeEvent c = new CIGItenaryChangeEvent(this,e.getNode().getIndex(),e.getNewName(),e.getOldName());
      System.out.println(c);
        propagateEvent(c);
    }
    
    public String getItenaryData()
    {
        return client.getItenaryData();
    }

    public void setName(String n)
    {
        setValue("name",n);
    }

    public String getName()
    {
        return getStringValue("name");
    }

    public void setUser(String u)
    {
        setValue("user",u);
    }

    public String getUser()
    {
        return getStringValue("user");
    }

    public void setExpand(String e)
    {
        setValue("expand",e);
    }

    public String getExpand()
    {
        return getStringValue("expand");
    }

   public String [] getEditableProperties() {
        String ss[] = {"name","user","expand"};

        return ss;
    }
   
     
}
