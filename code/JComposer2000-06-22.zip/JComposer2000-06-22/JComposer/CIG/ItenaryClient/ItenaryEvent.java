
package CIG.ItenaryClient;

import java.util.EventObject;
import com.sun.java.swing.tree.*;


public class ItenaryEvent extends EventObject
{

    int kind;
    CIGItenaryDynamicNode node;
    
    public final static int ITEM_ADDED = 1;
    public final static int ITEM_REMOVED = 2;
    public final static int ITEM_CHANGED = 3;
    
    protected String oldValue;
    protected String newValue;

    public ItenaryEvent(CIGItenaryClient client, int kind, CIGItenaryDynamicNode  node)
    {
        super(client);
        this.kind = kind;
        this.node = node;
    }
    
    public ItenaryEvent(CIGItenaryClient client, int kind, CIGItenaryDynamicNode  node, String oldVal, String newVal)
    {
        super(client);
        this.kind = kind;
        this.node = node;
        oldValue = oldVal;
        newValue = newVal;
    }
    
    public String toString()
    {
        String mesg = "";
        
        switch(kind)
        {
        case 1 : mesg = "Added "; break;
        case 2 : mesg = "Removed "; break;
        case 3 : mesg = "Changed "; break;
        }
        
        mesg = mesg+((CIGItenaryDynamicNode) node).getIndex()+" "+((CIGItenaryDynamicNode) node).getLabel();
        
        if(oldValue != null) {
            mesg = mesg+": "+oldValue+" to "+newValue;
        }
        
        return mesg;
    }
    
    public CIGItenaryDynamicNode getNode()
    {
        return node;
    }
    
    public String getOldName()
    {
        return oldValue;
    }
    
    public String getNewName()
    {
         return newValue;
    }

}


