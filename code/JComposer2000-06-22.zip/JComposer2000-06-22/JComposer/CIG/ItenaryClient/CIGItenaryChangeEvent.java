
package CIG.ItenaryClient;

import JViews.*;

public class CIGItenaryChangeEvent extends MVChangeDescr
{
    public CIGItenaryChangeEvent()
    {
        super();
    }
    
    public CIGItenaryChangeEvent(CIGItenary itenary, String index, String name, String old_name)
    {
        super(itenary);
        setIndex(index);
        setName(name);
        setOldName(old_name);
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString()
    {
        return "ItenaryChange: "+getIndex()+" '"+getOldName()+"' to '"+getName()+"'";
    }

    public void setIndex(String value)
    {
        setAnnotation("index",value);
    }
    
    public String getIndex()
    {
        return getAnnotation("index");
    }
    
    public void setName(String value)
    {
        setAnnotation("name",value);
    }
    
    public String getName()
    {
        return getAnnotation("name");
    }

    public void setOldName(String value)
    {
        setAnnotation("old_name",value);
    }
    
    public String getOldName()
    {
        return getAnnotation("old_name");
    }

}
