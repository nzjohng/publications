package CIG;

import java.awt.*;
import java.awt.event.*;

public class CollaborativeActionEvent extends ActionEvent implements Collaborative{
    public CollaborativeActionEvent(Object source, int id, String command, String enteredText) {
        super(source,id,command);
        this.enteredText = enteredText;
        }
    
    public void execute(Object chat) {
        ((Chat)chat).addText(enteredText);
        }
        
    public String getEnteredText()
    {
        return enteredText;
    }
    
    
    protected String enteredText;
    }
