package CIG;

import JViews.*;

public class CIGJobSelected extends MVChangeDescr
{
    int id;
    
    public CIGJobSelected()
    {
    
    }

    public CIGJobSelected(CIGJobsEntry comp, int id)
    {
        super(comp);
        this.id = id;
    }
    
    public int getId()
    {
        return id;
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString()
    {
        return "Job Selected: "+getId();
    }

}
