package CIG;

import JViews.*;

public class CIGASendChatMessage extends MVListener {

    public CIGASendChatMessage() {
        super();
    }
    
    public String getFrom()
    {
        return getStringValue("from");
    }
    
    public void setFrom(String value)
    {
        setValue("from",value);
    }
        
    public String getMessage()
    {
        return getStringValue("message");   
    }
    
    public void setMessage(String value)
    {
        setValue("message",value);
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"from","message"};

        return ss;
    } 
    
    public MVComponent getpChat()
    {
        return getInputComp("chat");
    }   

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        CIGChatMessage mesg = new CIGChatMessage(getpChat(),getFrom(),
                getFrom()+": "+getMessage());
        propagateEvent(mesg);
        return event;
    }

    public MVAspects getAspects()
    {
        MVAspects aspects = super.getAspects();
        
        // attributes
        
        MVPropertyAspect pas = aspects.getPropertyAspect();
        pas.addPropertyInfo(new MVPropertyInfo("from","String","Name of user/agent sending message"));
        pas.addPropertyInfo(new MVPropertyInfo("message","String","Message to send'"));
                
        // relationships
        
        MVRelationshipAspect ras = aspects.getRelationshipAspect();
        ras.addRelationshipInfo(new MVRelationshipInfo("Chat","1:1",MVOneToMany,true,"Component used to broadcast chat message"));
         
        // how about comp to forward "errors" to? Ok sends to??
            // "error" & "ok" ??
        
        // configuration info - what required to work etc.??
          // info this case ALL properties and at least one input comp's rel
      
        MVConfigurationAspect cas = aspects.getConfigurationAspect();
        String config_names[] = {"Chat"};
        cas.addConfigurationInfo(new MVConfigurationInfo("required rels",MVConfigurationInfo.MVRequiredSettings,config_names,"Need a chat message component"));
        String config_names2[] = {"from","message"};
        cas.addConfigurationInfo(new MVConfigurationInfo("required attributes",MVConfigurationInfo.MVRequiredSettings,config_names2,"Must set all these attributes."));
        
        // human interface provision/requirements
        
        MVHumanInterfaceAspect hias = aspects.getHumanInterfaceAspect();
        hias .addHumanInterfaceInfo(new MVHumanInterfaceInfo("property sheet",true,false,MVHumanInterfaceInfo.MVPropertySheetHIAspect,"Simple property sheet provided to set chat message details"));
        
        return aspects;
    }  

}

