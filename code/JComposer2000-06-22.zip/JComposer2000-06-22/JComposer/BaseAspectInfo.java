package ;

import JViews.*;

public class BaseAspectInfo extends BaseAspectInfoG {

  public BaseAspectInfo() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

