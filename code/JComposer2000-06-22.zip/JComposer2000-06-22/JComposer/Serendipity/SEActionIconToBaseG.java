package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEActionIconToBaseG extends MVViewRel
 {

  public SEActionIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("id")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEActionIcon)e.nextElement()).setText(((SEBaseAction)c.target).getId());
        }
      }
            else if(isChild(c.target) && name.equals("text")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseAction)e.nextElement()).setId(((SEActionIcon)c.target).getText());
        }
      }
      if(isParent(c.target) && name.equals("classname")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEActionIcon)e.nextElement()).setParentName(((SEBaseAction)c.target).getClassname());
        }
      }
            else if(isChild(c.target) && name.equals("parentName")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseAction)e.nextElement()).setClassname(((SEActionIcon)c.target).getParentName());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "SEActionIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEActionIcon)vc).setText(((SEBaseAction)bc).getId());
  ((SEActionIcon)vc).setParentName(((SEBaseAction)bc).getClassname());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEBaseAction)bc).setId(((SEActionIcon)vc).getText());
  ((SEBaseAction)bc).setClassname(((SEActionIcon)vc).getParentName());
  }

  public MVViewRel newViewRel() {
    return new SEActionIconToBase();
  }

  public String getViewRelKind() {
    return "SEActionIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

