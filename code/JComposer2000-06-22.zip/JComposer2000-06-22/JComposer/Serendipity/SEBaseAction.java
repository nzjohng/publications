package Serendipity;

import JViews.*;

public class SEBaseAction extends SEBaseActionG {

  public SEBaseAction() {
    super();
  }


  public String userName() {
    return getId();
  }

}

