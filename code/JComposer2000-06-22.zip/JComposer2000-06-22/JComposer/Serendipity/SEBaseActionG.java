package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEBaseActionG extends SEBaseListener
 {

  public SEBaseActionG() {
    super();
  }

  public String kindName() {
    return "Base Action";
  }

  public abstract String userName();


  public SEActionIconToBase getcrActionIconToBase() {
    return (SEActionIconToBase) getOneRelated("MVViewRel",MVChildRelComps);
  }

  public void establishActionIconToBase(SEActionIcon comp) {
    getcrActionIconToBase().establish(this,comp);
  }

  public void dissolveActionIconToBase(SEActionIcon comp) {
    getcrActionIconToBase().dissolve(this,comp);
  }

  public SEActionIcon getcActionIconToBase() {
    return (SEActionIcon) getOneRelated("MVViewRel",MVChildren);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

