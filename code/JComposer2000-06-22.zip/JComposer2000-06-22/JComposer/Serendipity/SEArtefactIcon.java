package Serendipity;

import JViews.*;
import bbw.*;
import java.awt.*;
import java.awt.event.*;

public class SEArtefactIcon extends SEArtefactIconG {

  public SEArtefactIcon() {
    super();
  }

  public String userName() {
    return getNameText();
  }
  
  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
  {
    if(from == this && c instanceof MVSetStringValue &&
        ((MVSetStringValue) c).getPropertyName().equals("nameText") &&
        getBaseComp() == null)
        mapComponent(true);
    
    return super.afterChange(c,from,rel);
  }
  
  public MVBaseComp mapComponent(boolean do_map)
  {

System.out.println("in SEArtefactIcon::mapComponent()");

        if(getNameText().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getNameText() = '"+getNameText()+"'");

        SEBaseLayer base_layer = (SEBaseLayer) view().getBaseLayer();
        SEBaseStage base_comp = base_layer.findBaseStage(getNameText());

if(base_comp != null)
    System.out.println("Base artefact found = "+ base_comp);
else
    System.out.println("No base artefact found");
    
    if(base_comp != null && !(base_comp instanceof SEBaseArtefact)) {
        System.out.println("Base stage not an Artefact!");
        return null;
    }
        
        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = new SEBaseArtefact();
                mapToCreatedBase(base_comp);
                base_comp.init(base_layer);
                base_layer.establishBaseStages(base_comp);
                
                // Does this make any sense for an artefact: ???
                //
                // if view is a substage defn, then make new stage
                // a substage of view owner
                //SEBaseStage base_stage = ((SEDiagram) view()).getpSubviews();
                //if(base_stage != null)
                //    base_stage.establishSubstages(base_comp);
                
                return base_comp;
            }
        }
            else return base_comp;

    }
   
    //MenuItem newSubView = new MenuItem("New Substage View");
    MenuItem attrs = new MenuItem("Edit Artefact Attributes");
    MenuItem create = new MenuItem("Create Artefact Comp");
    MenuItem propSheet = new MenuItem("Show Artefact Property Sheet");
    MenuItem aspectInfo = new MenuItem("Show Aspect Info");

    public void addJViewsPopups(BBWComponent shape)
    {
        super.addJViewsPopups(shape);
        shape.addPopupMenuItem(new MenuItem("-"));
        //shape.addPopupMenuItem(newSubView);
        //newSubView.addActionListener(this);
        shape.addPopupMenuItem(attrs);
        attrs.addActionListener(this);
        shape.addPopupMenuItem(create);
        create.addActionListener(this);
        shape.addPopupMenuItem(propSheet);
        propSheet.addActionListener(this);
        shape.addPopupMenuItem(aspectInfo);
        aspectInfo.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        super.actionPerformed(e);
        
        //if(e.getSource() == newSubView)
        //     addNewSubview();
        // else
        if(e.getSource() == attrs) {
            if(getBaseComp() != null)
                ((SEBaseArtefact) getBaseComp()).editUserAttributes();
        } else if(e.getSource() == propSheet) {
            if(getBaseComp() != null)
                ((SEBaseArtefact) getBaseComp()).showListenerPropertySheet();
        }  else if(e.getSource() == create)  {
            if(getBaseComp() != null)
                if(((SEBaseArtefact) getBaseComp()).getListener() == null)
                    ((SEBaseArtefact) getBaseComp()).addListener(((SEBaseArtefact) getBaseComp()).getClassname());    
        } else if(e.getSource() == aspectInfo) {
            if(getBaseComp() != null)
                ((SEBaseArtefact) getBaseComp()).showAspectInfo();
        }   
    }

}

