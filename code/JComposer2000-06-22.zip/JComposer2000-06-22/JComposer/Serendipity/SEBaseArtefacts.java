package Serendipity;

import JViews.*;

public class SEBaseArtefacts extends SEBaseArtefactsG {

  public SEBaseArtefacts() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

