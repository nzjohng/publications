package Serendipity;

import JViews.*;

public class SEBaseEndStage extends SEBaseEndStageG {

  public SEBaseEndStage() {
    super();
  }


  public String userName() {
    if(getOneRelatedOrNull("substages",MVParents) != null)
        return getpSubstages().userName()+":"+getName();
    else
        return ":"+getName();
  }
    
  public SEBaseLayer getpBaseStages()
  {
    return getpSubstages().getpBaseStages();
  }
 
  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
    {
    
        // end stages finish themselves and their owning base stages
        // with the end stage name the end value for the finish
        // enactment event
        if(c instanceof SEEnactStage && c.getTarget() == this) {
            SEEnactStage es = (SEEnactStage) c;
            getpBaseStages().doFinishStage(this,es.getUser(),es.getFrom(),"end stage reached",getName());    
            if(getpSubstages() instanceof SEBaseListener)
                getpSubstages().afterChange(c,this,getName());
            else
                getpBaseStages().doFinishStage(getpSubstages(),es.getUser(),getName(),"end stage reached",getName());
        }
    
        return super.afterChange(c,from,rel);
    }

}

