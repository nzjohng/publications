package Serendipity;

import JViews.*;

public class SEBaseArtefact extends SEBaseArtefactG {

  public SEBaseArtefact() {
    super();
  }


  public String userName() {
    return getId();
  }
  
 
}

