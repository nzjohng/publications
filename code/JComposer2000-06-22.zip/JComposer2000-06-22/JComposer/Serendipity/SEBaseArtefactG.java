package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEBaseArtefactG extends SEBaseListener
 {

  public SEBaseArtefactG() {
    super();
  }

  public String kindName() {
    return "Base Artefact";
  }

  public abstract String userName();


  public SEArtefactIconToBase getcrArtefactIconToBase() {
    return (SEArtefactIconToBase) getOneRelated("MVViewRel",MVChildRelComps);
  }

  public void establishArtefactIconToBase(SEArtefactIcon comp) {
    getcrArtefactIconToBase().establish(this,comp);
  }

  public void dissolveArtefactIconToBase(SEArtefactIcon comp) {
    getcrArtefactIconToBase().dissolve(this,comp);
  }

  public SEArtefactIcon getcArtefactIconToBase() {
    return (SEArtefactIcon) getOneRelated("MVViewRel",MVChildren);
  }

  public SEBaseArtefacts getprBaseArtefacts() {
    return (SEBaseArtefacts) getOneRelated("SEBaseArtefacts",MVParentRelComps);
  }

  public void establishBaseArtefacts(SEBaseLayer comp) {
    comp.establishBaseArtefacts((SEBaseArtefact) this);
  }

  public void dissolveBaseArtefacts(SEBaseLayer comp) {
    comp.dissolveBaseArtefacts((SEBaseArtefact) this);
  }

  public SEBaseLayer getpBaseArtefacts() {
    return (SEBaseLayer) getOneRelated("SEBaseArtefacts",MVParents);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

