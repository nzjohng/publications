package Serendipity;

import JViews.*;

public class SEActionIconToBase extends SEActionIconToBaseG {

  public SEActionIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

