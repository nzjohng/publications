package Serendipity;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class SEArtefactIconG extends MVViewComp
 {

  public SEArtefactIconG() {
    super();
  }

  public String kindName() {
    return "Artefact Icon";
  }

  public abstract String userName();


  public String getNameText() {
    return getStringValue("nameText");
  }

  public void setNameText(String value) {
    setValue("nameText",value);
  }


  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
    setValue("width",value);
  }


  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
    setValue("height",value);
  }


  public String getParentText() {
    return getStringValue("parentText");
  }

  public void setParentText(String value) {
    setValue("parentText",value);
  }


  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }


  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }


  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }


  public String getNameFont() {
    return getStringValue("nameFont");
  }

  public void setNameFont(String value) {
    setValue("nameFont",value);
  }


  public String getParentFont() {
    return getStringValue("parentFont");
  }

  public void setParentFont(String value) {
    setValue("parentFont",value);
  }


  public SEArtefactIconToBase getprArtefactIconToBase() {
    return (SEArtefactIconToBase) getOneRelated("MVViewRel",MVParentRelComps);
  }

  public void establishArtefactIconToBase(SEBaseArtefact comp) {
    comp.establishArtefactIconToBase((SEArtefactIcon) this);
  }

  public void dissolveArtefactIconToBase(SEBaseArtefact comp) {
    comp.dissolveArtefactIconToBase((SEArtefactIcon) this);
  }

  public SEBaseArtefact getpArtefactIconToBase() {
    return (SEBaseArtefact) getOneRelated("MVViewRel",MVParents);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
      if(((MVSetValue) c).getPropertyName().equals("nameText"))
        getJCComponent().setNameText((getNameText()));
      if(((MVSetValue) c).getPropertyName().equals("width"))
        getJCComponent().setWidth((getWidth()));
      if(((MVSetValue) c).getPropertyName().equals("height"))
        getJCComponent().setHeight((getHeight()));
      if(((MVSetValue) c).getPropertyName().equals("parentText"))
        getJCComponent().setParentText((getParentText()));
      if(((MVSetValue) c).getPropertyName().equals("foreground"))
        getJCComponent().setForeground(java_awt_Color_fromString(getForeground()));
      if(((MVSetValue) c).getPropertyName().equals("y"))
        getJCComponent().setY((getY()));
      if(((MVSetValue) c).getPropertyName().equals("x"))
        getJCComponent().setX((getX()));
      if(((MVSetValue) c).getPropertyName().equals("nameFont"))
        getJCComponent().setNameFont(java_awt_Font_fromString(getNameFont()));
      if(((MVSetValue) c).getPropertyName().equals("parentFont"))
        getJCComponent().setParentFont(java_awt_Font_fromString(getParentFont()));
    }

    return super.afterChange(c,from,rel_name);
  }

  public String viewRelKind() {
    return "SEArtefactIconToBase";
  }

  public MVViewRel newViewRel() {
    return new SEArtefactIconToBase();
  }


  public JCComponent getJCComponent() {
    return (JCComponent) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

      if(evt.getPropertyName().equals("nameText"))
        setNameText((getJCComponent().getNameText()));
      if(evt.getPropertyName().equals("width"))
        setWidth((getJCComponent().getWidth()));
      if(evt.getPropertyName().equals("height"))
        setHeight((getJCComponent().getHeight()));
      if(evt.getPropertyName().equals("parentText"))
        setParentText((getJCComponent().getParentText()));
      if(evt.getPropertyName().equals("foreground"))
        setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
      if(evt.getPropertyName().equals("y"))
        setY((getJCComponent().getY()));
      if(evt.getPropertyName().equals("x"))
        setX((getJCComponent().getX()));
      if(evt.getPropertyName().equals("nameFont"))
        setNameFont(java_awt_Font_toString(getJCComponent().getNameFont()));
      if(evt.getPropertyName().equals("parentFont"))
        setParentFont(java_awt_Font_toString(getJCComponent().getParentFont()));
    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
        setNameText((getJCComponent().getNameText()));
        setWidth((getJCComponent().getWidth()));
        setHeight((getJCComponent().getHeight()));
        setParentText((getJCComponent().getParentText()));
        setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
        setY((getJCComponent().getY()));
        setX((getJCComponent().getX()));
        setNameFont(java_awt_Font_toString(getJCComponent().getNameFont()));
        setParentFont(java_awt_Font_toString(getJCComponent().getParentFont()));
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
        if(getAttribute("nameText") == null)
          setNameText((getJCComponent().getNameText()));
        else
          getJCComponent().setNameText((getNameText()));
        if(getAttribute("width") == null)
          setWidth((getJCComponent().getWidth()));
        else
          getJCComponent().setWidth((getWidth()));
        if(getAttribute("height") == null)
          setHeight((getJCComponent().getHeight()));
        else
          getJCComponent().setHeight((getHeight()));
        if(getAttribute("parentText") == null)
          setParentText((getJCComponent().getParentText()));
        else
          getJCComponent().setParentText((getParentText()));
        if(getAttribute("foreground") == null)
          setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
        else
          getJCComponent().setForeground(java_awt_Color_fromString(getForeground()));
        if(getAttribute("y") == null)
          setY((getJCComponent().getY()));
        else
          getJCComponent().setY((getY()));
        if(getAttribute("x") == null)
          setX((getJCComponent().getX()));
        else
          getJCComponent().setX((getX()));
        if(getAttribute("nameFont") == null)
          setNameFont(java_awt_Font_toString(getJCComponent().getNameFont()));
        else
          getJCComponent().setNameFont(java_awt_Font_fromString(getNameFont()));
        if(getAttribute("parentFont") == null)
          setParentFont(java_awt_Font_toString(getJCComponent().getParentFont()));
        else
          getJCComponent().setParentFont(java_awt_Font_fromString(getParentFont()));
  }

}

