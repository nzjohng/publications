package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEArtefactIconToBaseG extends MVViewRel
 {

  public SEArtefactIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("id")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEArtefactIcon)e.nextElement()).setNameText(((SEBaseArtefact)c.target).getId());
        }
      }
            else if(isChild(c.target) && name.equals("nameText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseArtefact)e.nextElement()).setId(((SEArtefactIcon)c.target).getNameText());
        }
      }
      if(isParent(c.target) && name.equals("classname")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEArtefactIcon)e.nextElement()).setParentText(((SEBaseArtefact)c.target).getClassname());
        }
      }
            else if(isChild(c.target) && name.equals("parentText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseArtefact)e.nextElement()).setClassname(((SEArtefactIcon)c.target).getParentText());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "SEArtefactIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEArtefactIcon)vc).setNameText(((SEBaseArtefact)bc).getId());
  ((SEArtefactIcon)vc).setParentText(((SEBaseArtefact)bc).getClassname());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEBaseArtefact)bc).setId(((SEArtefactIcon)vc).getNameText());
  ((SEBaseArtefact)bc).setClassname(((SEArtefactIcon)vc).getParentText());
  }

  public MVViewRel newViewRel() {
    return new SEArtefactIconToBase();
  }

  public String getViewRelKind() {
    return "SEArtefactIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

