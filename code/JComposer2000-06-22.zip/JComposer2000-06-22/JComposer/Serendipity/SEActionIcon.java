package Serendipity;

import java.awt.*;
import java.awt.event.*;
import bbw.*;

import JViews.*;

public class SEActionIcon extends SEActionIconG {

  public SEActionIcon() {
    super();
  }

  public String userName() {
    return getText();
  }
  
  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
  {
    if(from == this && c instanceof MVSetStringValue &&
        ((MVSetStringValue) c).getPropertyName().equals("text") &&
        getBaseComp() == null)
        mapComponent(true);
    
    return super.afterChange(c,from,rel);
  }
  
  public MVBaseComp mapComponent(boolean do_map)
  {

System.out.println("in SEFilterIcon::mapComponent()");

        if(getText().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getText() = '"+getText()+"'");

        SEBaseLayer base_layer = (SEBaseLayer) view().getBaseLayer();
        SEBaseStage base_comp = base_layer.findBaseStage(getText());

if(base_comp != null)
    System.out.println("Base stage found = "+ base_comp);
else
    System.out.println("No base stage found");
        
        if(base_comp != null && !(base_comp instanceof SEBaseAction)) {
            System.out.println("*** Base stage not an action!!");
            return null;
        }   

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = new SEBaseAction();
                mapToCreatedBase(base_comp);
                base_comp.init(base_layer);
                base_layer.establishBaseStages(base_comp);
                
                // if view is a substage defn, then make new stage
                // a substage of view owner
                SEBaseStage base_stage = ((SEDiagram) view()).getpSubviews();
                if(base_stage != null)
                    base_stage.establishSubstages(base_comp);
                
                return base_comp;
            }
        }
            else return base_comp;

    }
    
    MenuItem newSubView = new MenuItem("New Substage View");
    MenuItem attrs = new MenuItem("Edit Action Attributes");
    MenuItem create = new MenuItem("Create Listener Comp");
    MenuItem initComp = new MenuItem("Initialise Listener Comp");
    MenuItem propSheet = new MenuItem("Show Action Property Sheet");
    MenuItem aspectInfo = new MenuItem("Show Aspect Info");

    public void addJViewsPopups(BBWComponent shape)
    {
        super.addJViewsPopups(shape);
        shape.addPopupMenuItem(new MenuItem("-"));
        shape.addPopupMenuItem(newSubView);
        newSubView.addActionListener(this);
        shape.addPopupMenuItem(attrs);
        attrs.addActionListener(this);
        shape.addPopupMenuItem(create);
        create.addActionListener(this);
        shape.addPopupMenuItem(initComp);
        initComp.addActionListener(this);
        shape.addPopupMenuItem(propSheet);
        propSheet.addActionListener(this);
        shape.addPopupMenuItem(aspectInfo);
        aspectInfo.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        super.actionPerformed(e);
        
        if(e.getSource() == newSubView)
             addNewSubview();
        else if(e.getSource() == attrs) {
            if(getBaseComp() != null)
                ((SEBaseAction) getBaseComp()).editUserAttributes();
        } else if(e.getSource() == propSheet) {
            if(getBaseComp() != null)
                ((SEBaseAction) getBaseComp()).showListenerPropertySheet();
        }  else if(e.getSource() == create)  {
            if(getBaseComp() != null)
                if(((SEBaseAction) getBaseComp()).getListener() == null)
                    ((SEBaseAction) getBaseComp()).addListener(((SEBaseAction) getBaseComp()).getClassname());    
        } else if(e.getSource() == aspectInfo) {
            if(getBaseComp() != null)
                ((SEBaseAction) getBaseComp()).showAspectInfo();
        } else if(e.getSource() == initComp) {
               if(((SEBaseAction) getBaseComp()).getListener() != null)
                    ((SEBaseAction) getBaseComp()).initComp();
        }

    }
    
    public void addNewSubview()
    {
        SEBaseStage base_stage = (SEBaseStage) getBaseComp();
        if(base_stage == null)
            return;
        base_stage.addNewSubview();
    }

}


