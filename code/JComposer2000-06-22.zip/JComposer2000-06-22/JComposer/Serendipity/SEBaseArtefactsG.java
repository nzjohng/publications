package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEBaseArtefactsG extends MVHashtableRel
 {

  public SEBaseArtefactsG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

