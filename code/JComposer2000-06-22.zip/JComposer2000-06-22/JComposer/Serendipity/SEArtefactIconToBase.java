package Serendipity;

import JViews.*;

public class SEArtefactIconToBase extends SEArtefactIconToBaseG {

  public SEArtefactIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

