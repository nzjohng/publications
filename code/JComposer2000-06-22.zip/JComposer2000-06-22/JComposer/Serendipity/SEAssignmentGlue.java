package Serendipity;

import JViews.*;

public class SEAssignmentGlue extends SEAssignmentGlueG {

  public SEAssignmentGlue() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

