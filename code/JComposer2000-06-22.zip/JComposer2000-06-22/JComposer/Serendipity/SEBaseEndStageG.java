package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEBaseEndStageG extends SEBaseStage
 {

  public SEBaseEndStageG() {
    super();
  }

  public String kindName() {
    return "Base End Stage";
  }

  public abstract String userName();


  public String getName() {
    return getStringValue("name");
  }

  public void setName(String value) {
    setValue("name",value);
  }


  public SEEndIconToBase getcrEndIconToBase() {
    return (SEEndIconToBase) getOneRelated("MVViewRel",MVChildRelComps);
  }

  public void establishEndIconToBase(SEEndIcon comp) {
    getcrEndIconToBase().establish(this,comp);
  }

  public void dissolveEndIconToBase(SEEndIcon comp) {
    getcrEndIconToBase().dissolve(this,comp);
  }

  public SEEndIcon getcEndIconToBase() {
    return (SEEndIcon) getOneRelated("MVViewRel",MVChildren);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

