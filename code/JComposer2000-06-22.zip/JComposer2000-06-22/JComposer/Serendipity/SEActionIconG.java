package Serendipity;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class SEActionIconG extends MVViewComp
 {

  public SEActionIconG() {
    super();
  }

  public String kindName() {
    return "Action Icon";
  }

  public abstract String userName();


  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
    setValue("width",value);
  }


  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
    setValue("height",value);
  }


  public String getText() {
    return getStringValue("text");
  }

  public void setText(String value) {
    setValue("text",value);
  }


  public String getParentName() {
    return getStringValue("parentName");
  }

  public void setParentName(String value) {
    setValue("parentName",value);
  }


  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }


  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }


  public String getFont() {
    return getStringValue("font");
  }

  public void setFont(String value) {
    setValue("font",value);
  }


  public SEActionIconToBase getprActionIconToBase() {
    return (SEActionIconToBase) getOneRelated("MVViewRel",MVParentRelComps);
  }

  public void establishActionIconToBase(SEBaseAction comp) {
    comp.establishActionIconToBase((SEActionIcon) this);
  }

  public void dissolveActionIconToBase(SEBaseAction comp) {
    comp.dissolveActionIconToBase((SEActionIcon) this);
  }

  public SEBaseAction getpActionIconToBase() {
    return (SEBaseAction) getOneRelated("MVViewRel",MVParents);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
      if(((MVSetValue) c).getPropertyName().equals("width"))
        getJCRelnShadedShape().setWidth((getWidth()));
      if(((MVSetValue) c).getPropertyName().equals("height"))
        getJCRelnShadedShape().setHeight((getHeight()));
      if(((MVSetValue) c).getPropertyName().equals("text"))
        getJCRelnShadedShape().setText((getText()));
      if(((MVSetValue) c).getPropertyName().equals("parentName"))
        getJCRelnShadedShape().setParentName((getParentName()));
      if(((MVSetValue) c).getPropertyName().equals("y"))
        getJCRelnShadedShape().setY((getY()));
      if(((MVSetValue) c).getPropertyName().equals("x"))
        getJCRelnShadedShape().setX((getX()));
      if(((MVSetValue) c).getPropertyName().equals("font"))
        getJCRelnShadedShape().setFont(java_awt_Font_fromString(getFont()));
    }

    return super.afterChange(c,from,rel_name);
  }

  public String viewRelKind() {
    return "SEActionIconToBase";
  }

  public MVViewRel newViewRel() {
    return new SEActionIconToBase();
  }


  public JCRelnShadedShape getJCRelnShadedShape() {
    return (JCRelnShadedShape) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

      if(evt.getPropertyName().equals("width"))
        setWidth((getJCRelnShadedShape().getWidth()));
      if(evt.getPropertyName().equals("height"))
        setHeight((getJCRelnShadedShape().getHeight()));
      if(evt.getPropertyName().equals("text"))
        setText((getJCRelnShadedShape().getText()));
      if(evt.getPropertyName().equals("parentName"))
        setParentName((getJCRelnShadedShape().getParentName()));
      if(evt.getPropertyName().equals("y"))
        setY((getJCRelnShadedShape().getY()));
      if(evt.getPropertyName().equals("x"))
        setX((getJCRelnShadedShape().getX()));
      if(evt.getPropertyName().equals("font"))
        setFont(java_awt_Font_toString(getJCRelnShadedShape().getFont()));
    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
        setWidth((getJCRelnShadedShape().getWidth()));
        setHeight((getJCRelnShadedShape().getHeight()));
        setText((getJCRelnShadedShape().getText()));
        setParentName((getJCRelnShadedShape().getParentName()));
        setY((getJCRelnShadedShape().getY()));
        setX((getJCRelnShadedShape().getX()));
        setFont(java_awt_Font_toString(getJCRelnShadedShape().getFont()));
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
        if(getAttribute("width") == null)
          setWidth((getJCRelnShadedShape().getWidth()));
        else
          getJCRelnShadedShape().setWidth((getWidth()));
        if(getAttribute("height") == null)
          setHeight((getJCRelnShadedShape().getHeight()));
        else
          getJCRelnShadedShape().setHeight((getHeight()));
        if(getAttribute("text") == null)
          setText((getJCRelnShadedShape().getText()));
        else
          getJCRelnShadedShape().setText((getText()));
        if(getAttribute("parentName") == null)
          setParentName((getJCRelnShadedShape().getParentName()));
        else
          getJCRelnShadedShape().setParentName((getParentName()));
        if(getAttribute("y") == null)
          setY((getJCRelnShadedShape().getY()));
        else
          getJCRelnShadedShape().setY((getY()));
        if(getAttribute("x") == null)
          setX((getJCRelnShadedShape().getX()));
        else
          getJCRelnShadedShape().setX((getX()));
        if(getAttribute("font") == null)
          setFont(java_awt_Font_toString(getJCRelnShadedShape().getFont()));
        else
          getJCRelnShadedShape().setFont(java_awt_Font_fromString(getFont()));
  }

}

