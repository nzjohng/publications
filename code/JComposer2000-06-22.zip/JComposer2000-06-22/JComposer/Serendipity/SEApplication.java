
package Serendipity;

import bbw.*;
import JViews.*;

public class SEApplication extends MVApplication {
  
  public SEApplication() {
    super();
  }

  public MVProject newProject() {
    return new SEProject("project #1");
  }
  
  public MVCollabServer createCollabServer()
  {
    return new SECollabServer(this);
  }

   public String getDefaultName()
   {
        return "john";
   }    
   
   public String getDefaultPort()
   {
        return "5021";
   }
   
   public String getDefaultServerHost()
   {
        return "johngvp.cs.waikato.ac.nz";
   }
   
   public String getDefaultServerPort()
   {
        return "5020";
   }
   
    public static void main(String argv[]) {
        SEApplication a = new SEApplication();

    }
}

