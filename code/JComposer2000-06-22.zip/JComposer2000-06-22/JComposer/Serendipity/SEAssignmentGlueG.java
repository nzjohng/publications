package Serendipity;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class SEAssignmentGlueG extends MVOneToOneGlue
 {

  public SEAssignmentGlueG() {
    super();
  }

  public String kindName() {
    return "Role Assignment Glue";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
    }

    return super.afterChange(c,from,rel_name);
  }


  public JCDirectedArc getJCDirectedArc() {
    return (JCDirectedArc) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
  }

}

