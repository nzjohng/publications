package Critics;

import JViews.*;
import java.util.*;
import SoftArch.*;

public class MVCritic extends MVCriticG
{

	public MVCritic()
	{
        super();

        
	}

   public String userName()
    {
        return "a critic";
    }   

	public void init()
	// called to initialise this critic...
	{

	
        // register this critic with the critic manager...

        Enumeration projects = MVApplication.application.projects.elements();
        while(projects.hasMoreElements())
        {
            MVProject p = (MVProject) projects.nextElement();
            if(p instanceof SAProject) {
                Enumeration bases = p.getBaseLayers().elements();
                while(bases.hasMoreElements()) {
                    SABaseLayer bl = (SABaseLayer) bases.nextElement();
                    MVCriticManager man = (MVCriticManager) bl.getOneRelatedOrNull("critic_manager",MVParents);
                    if(man != null) {
                        man.registerCritic(this);
                        return;
                    }   
                }
            }
        }
	}

	public MVChangeDescr performFilterAction(MVChangeDescr c, MVComponent from, String rel)
	{
	    try {
        // i.e. detect when critic predicate matches & store critic
        // message in critic's MVCriticReport or manager's default report...
	
            if(c instanceof MVCriticEvent)
                propagateEvent(c);

            // ignore any other events the critic receives??
            // subclass to allow application-specific critis to determine whether
            // to create MVTestCritic() event & send to self??
        } catch (MVFireCritic e) {
            doFireCritic(e);
            if(isConstraint())
                // don't go any further...
                return null;
        }
        
        return super.performFilterAction(c,from,rel);
	}

	public String getCriticGroupName()
	{
        return "Miscellaneous Critics";
	}

	public String[] getEditableProperties()
	{
		String ss[] = { "enabled", "constraint", "critic", "analysis" };
		return ss;
	}

	public void doFireCritic(MVFireCritic event)
	{
        MVCriticReport rep = getcReport();
        if(rep == null)
            rep = getpCritics().getcDefaultReport();

System.out.println("*** Adding critic message: "+event.message);

        rep.addCriticMessage(event.message);
	}

	public void doRemoveMessage(MVComponent comp)
	{
        MVCriticReport rep = getcReport();
        if(rep == null)
            rep = getpCritics().getcDefaultReport();

System.out.println("*** Removing critic message: "+getUserName()+" for "+comp.getUserName());

        rep.removeCriticMessage(this,comp);
	}

	public int getPriority()
	{
        return MVCriticReport.NORMAL;
	}

	public String getCriticMessage(MVCriticMessage mesg)
	{
		return mesg.getInfo();
	}

}
