package Critics;
import JViews.*;
import java.util.*;

public abstract class MVCriticGroupG extends MVBaseComp
 {

  public MVCriticGroupG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public String getGroupName() {
    return getStringValue("GroupName");
  }

  public void setGroupName(String value) {
    setValue("GroupName",value);
  }


  public boolean isEnabled() {
    return getBooleanValue("enabled");
  }

  public void setEnabled(boolean value) {
    setValue("enabled",value);
  }


  public Vector getcCriticGroup() {
    return getRelationship("criticGroup",MVChildren);
  }

  public void establishCriticGroup(MVCritic comp) {
    establishOneToMany("criticGroup",comp);
  }

  public void dissolveCriticGroup(MVCritic comp) {
    dissolveOneToMany("criticGroup",comp);
  }

  public MVCriticManager getpCriticGroups() {
    return (MVCriticManager) getOneRelatedOrNull("criticGroups",MVParents);
  }

  public void establishCriticGroups(MVCriticManager comp) {
    comp.establishCriticGroups((MVCriticGroup) this);
  }

  public void dissolveCriticGroups(MVCriticManager comp) {
    comp.dissolveCriticGroups((MVCriticGroup) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

