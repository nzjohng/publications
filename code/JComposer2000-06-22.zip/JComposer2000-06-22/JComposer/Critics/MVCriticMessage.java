package Critics;

import JViews.*;

public class MVCriticMessage extends MVCriticEvent
{

    public MVCriticMessage()
    {
    }

    public MVCriticMessage(MVCritic critic, MVComponent comp, String info)
    {
        super(critic,comp,info);
    }

    public String toString()
    {
        return ((MVCritic) getTarget()).getCriticMessage(this);
    }

	public String getInfo()
	{
		return getName();
	}
	
}
