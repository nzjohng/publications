package Critics;
import JViews.*;
import java.util.*;

public abstract class MVCriticManagerG extends MVListener
 {

  public MVCriticManagerG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public Vector getcCritics() {
    return getRelationship("critics",MVChildren);
  }

  public void establishCritics(MVCritic comp) {
    establishOneToMany("critics",comp);
  }

  public void dissolveCritics(MVCritic comp) {
    dissolveOneToMany("critics",comp);
  }

  public Vector getcCriticGroups() {
    return getRelationship("criticGroups",MVChildren);
  }

  public void establishCriticGroups(MVCriticGroup comp) {
    establishOneToMany("criticGroups",comp);
  }

  public void dissolveCriticGroups(MVCriticGroup comp) {
    dissolveOneToMany("criticGroups",comp);
  }

  public Vector getcReports() {
    return getRelationship("reports",MVChildren);
  }

  public void establishReports(MVCriticReport comp) {
    establishOneToMany("reports",comp);
  }

  public void dissolveReports(MVCriticReport comp) {
    dissolveOneToMany("reports",comp);
  }

  public MVCriticReport getcDefaultReport() {
    return (MVCriticReport) getOneRelated("defaultReport",MVChildren);
  }

  public void establishDefaultReport(MVCriticReport comp) {
    establishOneToMany("defaultReport",comp);
  }

  public void dissolveDefaultReport(MVCriticReport comp) {
    dissolveOneToMany("defaultReport",comp);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

