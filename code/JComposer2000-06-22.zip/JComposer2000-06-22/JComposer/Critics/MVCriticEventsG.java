package Critics;
import JViews.*;
import java.util.*;

public abstract class MVCriticEventsG extends MVVersionRecord
 {

  public MVCriticEventsG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public MVCriticReport getpEvents() {
    return (MVCriticReport) getOneRelated("events",MVParents);
  }

  public void establishEvents(MVCriticReport comp) {
    comp.establishEvents((MVCriticEvents) this);
  }

  public void dissolveEvents(MVCriticReport comp) {
    comp.dissolveEvents((MVCriticEvents) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

