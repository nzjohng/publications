package Critics;

import javax.swing.*;
import java.util.*;
import javax.swing.tree.*;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.*;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Graphics;

public class MVCriticManagerInterface extends JFrame implements ActionListener
{

    MVCriticManager man;

    public MVCriticManagerInterface()
    {
        super("Critic Manager");
    }

    MVCriticRenderer renderer = new MVCriticRenderer();
    
    public void init(MVCriticManager man)
    {   MVCriticRenderer renderer = new MVCriticRenderer();

        this.man = man;

System.out.println("Creating tree...");

        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Critics");
        tree = new JTree(root);
        root.setAllowsChildren(true);
        tree.setCellRenderer(renderer);
        //tree.setRootVisible(false);
        
        Dimension d = new Dimension(390,300);
        tree.setMinimumSize(d);
        tree.setPreferredSize(d);
        
        Enumeration e1 = man.getcCriticGroups().elements();
        while(e1.hasMoreElements()) {
            MVCriticGroup cg = (MVCriticGroup) e1.nextElement();
            DefaultMutableTreeNode group = new DefaultMutableTreeNode(cg.getGroupName());
            root.add(group);
            group.setAllowsChildren(true);
            // tree.expandPath(group.getPath());
            
            Enumeration e2 = cg.getcCriticGroup().elements();
            while(e2.hasMoreElements()) {
                MVCritic cr = (MVCritic) e2.nextElement();
                DefaultMutableTreeNode critic = new DefaultMutableTreeNode(cr);
                critic.setAllowsChildren(false);
                group.add(critic);
            }
        }

  tree.expandPath(new TreePath(root.getPath()));


        Vector rep_names = new Vector();

        d = new Dimension(390,80);
        reports.setMinimumSize(d);
        reports.setPreferredSize(d);

        Enumeration e2 = man.getcReports().elements();
        while(e2.hasMoreElements()) {
            MVCriticReport rep = (MVCriticReport) e2.nextElement();
            rep_names.addElement(rep.getReportName());
        }

        rep_list = new JList(rep_names);
        reports.getViewport().setView(rep_list);

        closeButton.addActionListener(this);
        infoButton.addActionListener(this);
        analyseButton.addActionListener(this);
        showButton.addActionListener(this);
        
        GridBagLayout gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        scroller = new JScrollPane();
        scroller.getViewport().add(tree);

        getContentPane().setLayout(gbl);
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        addPanel(getContentPane(),gbl,gbc,scroller,0,0,4,9);
        gbc.weightx = 0.0;
        gbc.weighty = 0.0;
        addPanel(getContentPane(),gbl,gbc,reports,0,9,4,3);
        addPanel(getContentPane(),gbl,gbc,showButton,0,12,1,1);
        addPanel(getContentPane(),gbl,gbc,infoButton,1,12,1,1);
        addPanel(getContentPane(),gbl,gbc,analyseButton,2,12,1,1);
        addPanel(getContentPane(),gbl,gbc,closeButton,3,12,1,1);
        
        setSize(400,400);
        refresh();
        setVisible(true);
    }

    public void addPanel(Container cont, GridBagLayout gbl, GridBagConstraints gbc, Component comp, int x, int y, int w, int h)
    {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = w;
        gbc.gridheight = h;
        gbl.setConstraints(comp,gbc);
        cont.add(comp);
    }

    JTree tree;

    JScrollPane reports = new JScrollPane();
    JList rep_list;

    JScrollPane scroller;

    JButton infoButton = new JButton("Configure");
    JButton analyseButton = new JButton("Analyse");
    JButton showButton = new JButton("Show Report");
    JButton closeButton = new JButton("Close");

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == closeButton)
            setVisible(false);
        else if(e.getSource() == infoButton)
            showCriticPropertySheet();
        else if(e.getSource() == showButton)
            showReport();
        else if(e.getSource() == analyseButton)
            analyseCritic();
    }

    public void showCriticPropertySheet()
    {
        TreePath path = tree.getSelectionPath();
        Object o = ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
        
      System.out.println("Selected comp object = "+o.getClass().toString());
        
        if(o instanceof MVCritic) {
System.out.println("show props");
        	((MVCritic) o).showPropertySheet();
       	}
    }

    public void analyseCritic()
    {
        // need to create new report, set critic report to new report,
        // run critic (in analysis mode???) & show report when done...

    }

    public void showReport()
    {
        String name = (String) rep_list.getSelectedValue();
        MVCriticReport rep = man.findReport(name);

System.out.println("show report for name "+name+" = "+rep);
        if(rep != null)
            rep.displayReport();
    }
    
    public void refresh()
    {

    }

}

/*
class MVCriticGroupNode extends DefaultMutableTreeNode
{
    public MVCriticGroupNode()
    {
        super();
        setAllowsChildren(true);
    }
}

class MVCriticNode extends DefaultMutableTreeNode
{
    public MVCriticGroupNode()
    {
        super();
        setAllowsChildren(false);
    }
}
*/

class MVCriticRenderer implements TreeCellRenderer
{
    public MVCriticRenderer()
    {
        super();
    }

    static protected Font             defaultFont;

    static protected ImageIcon        collapsedIcon;

    static protected ImageIcon        expandedIcon;

    static protected final Color selectedBackgroundColor = Color.yellow;

    static
    {
        try {
            defaultFont = new Font("SansSerif", 0, 12);
        } catch (Exception e) {}
        try {
            collapsedIcon = new ImageIcon("images/collapsed.gif");
            expandedIcon = new ImageIcon("images/expanded.gif");
        } catch (Exception e) {
            System.out.println("Couldn't load images: " + e);
        }
    }

    MVCriticPanel panel = new MVCriticPanel();
    MVGroupLabel label = new MVGroupLabel();

    Component comp;

    protected boolean            selected;

    public Component getTreeCellRendererComponent(JTree tree, Object value,
                      boolean selected, boolean expanded,
                      boolean leaf, int row,
                          boolean hasFocus) {
    Font            font;
    String          stringValue = tree.convertValueToText(value, selected,
                       expanded, leaf, row, hasFocus);

    if(value instanceof DefaultMutableTreeNode)
        value = ((DefaultMutableTreeNode) value).getUserObject();

    if(value instanceof MVCritic) {
        if(hasFocus) {
            panel.setForeground(Color.cyan);
            panel.setBackground(selectedBackgroundColor);
        } else {
            panel.setForeground(Color.black);
            panel.setBackground(Color.white);
        }
        
        panel.setCritic((MVCritic) value);

        comp = panel;
        return panel;
    } else {
        if(expanded)
            label.setIcon(expandedIcon);
        else if(!leaf)
            label.setIcon(collapsedIcon);
        else
            label.setIcon(null);
            
        if(hasFocus) {
            label.setForeground(Color.cyan);
            // label.setBackground(selectedBackgroundColor);
            label.selected = selected;            
        } else {
            label.setForeground(Color.black);
        }

        label.selected = selected;
        
        label.setText(value.toString());

        comp = label;
        return label;
    }

    } 




class MVGroupLabel extends JLabel
{
    public boolean selected = false;
    
    public void paint(Graphics g) {
    Color            bColor;
    Icon             currentI = getIcon();

    if(selected)
        bColor = selectedBackgroundColor;
    else if(getParent() != null)
        /* Pick background color up from parent (which will come from
           the JTree we're contained in). */
        bColor = getParent().getBackground();
    else
        bColor = getBackground();
    g.setColor(bColor);
    if(currentI != null && getText() != null) {
        int          offset = (currentI.getIconWidth() + getIconTextGap());

        g.fillRect(offset, 0, getWidth() - 1 - offset,
               getHeight() - 1);
    }
    else
        g.fillRect(0, 0, getWidth()-1, getHeight()-1);
    super.paint(g);
    }

    }


   class MVCriticPanel extends JPanel
    {
        JLabel name = new JLabel("");
        JCheckBox enabled = new JCheckBox("Enabled",true);
        JCheckBox constraint = new JCheckBox("Constraint",true);
        JCheckBox iscritic = new JCheckBox("Critic",true);
        JCheckBox analysis = new JCheckBox("Analysis",true);

		JPanel p2 = new JPanel();
        
        MVCritic critic;

        public MVCriticPanel()
        {
        setLayout(new GridLayout(1,2));
        add(name);
        add(p2);
        p2.setLayout(new GridLayout(1,4));
        p2.add(enabled);
        p2.add(constraint);
        p2.add(iscritic);
        p2.add(analysis);

        // panel size??
        }
    
        public void setCritic(MVCritic critic) {
            this.critic = critic;
            name.setText(critic.getUserName());
            name.setForeground(getForeground());
            name.setBackground(getBackground());
            enabled.setSelected(critic.isEnabled());
            enabled.setForeground(getForeground());
            enabled.setBackground(getBackground());
            constraint.setSelected(critic.isConstraint());
            constraint.setForeground(getForeground());
            constraint.setBackground(getBackground());
            iscritic.setSelected(critic.isCritic());
            iscritic.setForeground(getForeground());
            iscritic.setBackground(getBackground());
            analysis.setSelected(critic.isAnalysis());
            analysis.setForeground(getForeground());
            analysis.setBackground(getBackground());
            // validate();
        }

    }

}
