package Critics;

import JViews.*;
import java.util.*;

public class MVCriticReport extends MVCriticReportG {

  public MVCriticReport() {
    super();
  }

  public void init(MVBaseLayer bl) {
    super.init(bl);
    
    MVCriticEvents events = new MVCriticEvents();
    establishEvents(events);
    events.setSaveChanges(true);

  }


  public String userName() {
    return getReportName();
  }

  MVCriticDisplayInterface rep_int = null;

  public static final int NUM_PRIORITIES = 5;
  
  public static final int HIGHEST = 0;
  public static final int HIGH = 1;
  public static final int NORMAL = 2;
  public static final int LOW = 3;
  public static final int LOWEST = 4;

  public void displayReport()
  {
    if(rep_int != null)
        rep_int.setVisible(true);
    else {
        rep_int = new MVCriticDisplayInterface(this);
        rep_int.setVisible(true);
    }

    rep_int.refresh();
  }

  public void addCriticMessage(MVCriticMessage message)
  {
        // need to check critic/comp pair aren't already in event list...
		Enumeration e = getcEvents().get_changes_forwards();
		while(e.hasMoreElements()) {
			MVCriticMessage mesg = (MVCriticMessage) e.nextElement();
			if((mesg.getTarget() == message.getTarget()) &&
			   (mesg.getComponent() == message.getComponent()))
			   return;
		}

  System.out.println("Adding : "+message);
        getcEvents().add_change(message);
        // should call "addItem" or something & incrementally
		// update tree...
        if(rep_int != null)
            rep_int.refresh();
  }

  public void removeCriticMessage(MVCritic critic, MVComponent comp)
  {
        // need to check critic/comp pair aren't already in event list...
		Enumeration e = getcEvents().get_changes_forwards();
		while(e.hasMoreElements()) {
			MVCriticMessage mesg = (MVCriticMessage) e.nextElement();
			if((mesg.getTarget() == critic) &&
			   (mesg.getComponent() == comp))
			   getcEvents().remove_change(mesg.getCount());
			   // should call "removeItem" or something & incrementally
			   // update tree...
			   
			   if(rep_int != null)
            		rep_int.refresh();
		}

  }


    public static String getPriorityName(int i)
    {
        switch(i) {
        case HIGHEST : return "Highest";
        case HIGH : return "High";
        case NORMAL : return "Normal";
        case LOW : return "Low";
        case LOWEST : return "Lowest";
        }

        return "";
    }

}

