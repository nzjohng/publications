package Critics;

public class MVCriticGroup extends MVCriticGroupG
{

	public MVCriticGroup()
	{

	}

	public String userName()
	{
        return getGroupName();
	}

}

