package Critics;

public class MVTestCritic extends MVCriticEvent
{

    public MVTestCritic(MVCritic critic, MVComponent comp)
    {
        super(critic,comp,"Test Critic");
    }

}


