package Critics;
import JViews.*;
import java.util.*;

public abstract class MVCriticReportG extends MVBaseComp
 {

  public MVCriticReportG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public String getReportName() {
    return getStringValue("ReportName");
  }

  public void setReportName(String value) {
    setValue("ReportName",value);
  }


  public MVCriticEvents getcEvents() {
    return (MVCriticEvents) getOneRelatedOrNull("events",MVChildren);
  }

  public void establishEvents(MVCriticEvents comp) {
    establishOneToMany("events",comp);
    setAggregateRel("events");
  }

  public void dissolveEvents(MVCriticEvents comp) {
    dissolveOneToMany("events",comp);
  }

  public MVCriticManager getpReports() {
    return (MVCriticManager) getOneRelated("reports",MVParents);
  }

  public void establishReports(MVCriticManager comp) {
    comp.establishReports((MVCriticReport) this);
  }

  public void dissolveReports(MVCriticManager comp) {
    comp.dissolveReports((MVCriticReport) this);
  }

  public Vector getpReport() {
    return getRelationship("report",MVParents);
  }

  public void establishReport(MVCritic comp) {
    comp.establishReport((MVCriticReport) this);
  }

  public void dissolveReport(MVCritic comp) {
    comp.dissolveReport((MVCriticReport) this);
  }

  public MVCriticManager getpDefaultReport() {
    return (MVCriticManager) getOneRelatedOrNull("defaultReport",MVParents);
  }

  public void establishDefaultReport(MVCriticManager comp) {
    comp.establishDefaultReport((MVCriticReport) this);
  }

  public void dissolveDefaultReport(MVCriticManager comp) {
    comp.dissolveDefaultReport((MVCriticReport) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

