package Critics;

import JViews.*;

public class MVCriticEvents extends MVCriticEventsG {

  public MVCriticEvents() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

