package Critics;

import JViews.*;
import java.awt.event.*;
import SoftArch.*;
import java.awt.MenuItem;
import java.util.*;

public class MVCriticManager extends MVCriticManagerG implements ActionListener
{

    public MVCriticManager()
    {
        
    }

    public String userName()
    {
        return "Critic Manager";
    }   

    public void init(MVBaseLayer bl)
    {
        super.init(bl);

        establishOneToMany("critic_manager",bl);
        bl.setListenAfterRel("critic_manager");

        MVCriticReport def = new MVCriticReport();
        def.init(bl);
        establishDefaultReport(def);
        establishReports(def);
        def.setReportName("Default Analysis Agent Report");
    }

    public void actionPerformed(ActionEvent e)
    {

        if(e.getSource() instanceof MenuItem) {
            MenuItem i = (MenuItem) e.getSource();
            if(i.getLabel().equals("Critic Manager"))
                showCriticManager();
            else if(i.getLabel().equals("Critic Display"))
                showCriticDisplay();
        }

    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
    {

    System.out.println("Critic manager got "+c);
    
        // SADiagram view creation event...
        if(c instanceof MVEstablishRel &&
            ((MVEstablishRel) c).getChild() instanceof MVViewLayer) {
            
            MVViewLayer d = (MVViewLayer) ((MVEstablishRel) c).getChild();
            establishOneToMany("critic_manager",d);
            d.setListenAfterRel("critic_manager");
        }

        // from MVViewLayer...

        if(from instanceof MVViewLayer) {
            if(c instanceof MVRedisplayView) {
                addCriticManagerMenuItem((MVViewLayer) from);
            }
        }

        // pass event to all active critics...

        testActiveCritics(c);
        
        return super.afterChange(c,from,rel);
    }

    transient Vector added = new Vector();

    public void addCriticManagerMenuItem(MVViewLayer d)
    // add a "Critic Manager" menu item to "Views" menu...
    {
        // check if already added...

        if(added.contains(d))
            return;

        added.addElement(d);
    
        MenuItem m = new MenuItem("Critic Manager");
        m.addActionListener(this);
        d.getViewFrame().addMenuItem("View",m);

        m = new MenuItem("Critic Display");
        m.addActionListener(this);
        d.getViewFrame().addMenuItem("View",m);
    }

    MVCriticManagerInterface man_int = null;

    public void showCriticManager()
    {
        if(man_int != null)
            man_int.setVisible(true);
        else {
            man_int = new MVCriticManagerInterface();
            man_int.init(this);
        }
        
        man_int.refresh();
    }

    public void showCriticDisplay()
    {
        MVCriticReport def = getcDefaultReport();
        def.displayReport();
    }

    public MVCriticReport findReport(String name)
    {
        Enumeration e = getcReports().elements();
        while(e.hasMoreElements()) {
            MVCriticReport rep = (MVCriticReport) e.nextElement();
            if(rep.getReportName().equals(name))
                return rep;
        }

        return null;
    }

    public void registerCritic(MVCritic critic)
    {
        establishCritics(critic);
 
        MVCriticGroup cg = critic.getpCriticGroup();
        if(cg == null) {
            cg = findCriticGroup(critic.getCriticGroupName());
        
            if(cg == null) {
                cg = new MVCriticGroup();
                cg.setEnabled(true);
                cg.setGroupName(critic.getCriticGroupName());
                establishCriticGroups(cg);
            }

            cg.establishCriticGroup(critic);
        }

        critic.setEnabled(true); // or let critic do this itself???


// change to generate event & have interface listen for new critic rels established with manager...

        if(man_int != null)
            man_int.refresh();
    }

    public MVCriticGroup findCriticGroup(String name)
    {
        Enumeration e = getcCriticGroups().elements();
        while(e.hasMoreElements()) {
            MVCriticGroup cg = (MVCriticGroup) e.nextElement();
            if(cg.getGroupName().equals(name))
                return cg;
        }
        
        return null;
    }

    public void testActiveCritics(MVChangeDescr c)
    {    
        Enumeration e1 = getcCriticGroups().elements();
        while(e1.hasMoreElements()) {
            MVCriticGroup cg = (MVCriticGroup) e1.nextElement();
            if(cg.isEnabled()) {
                Enumeration e2 = cg.getcCriticGroup().elements();
                while(e2.hasMoreElements()) {
                    MVCritic cr = (MVCritic) e2.nextElement();
                    if(cr.isEnabled() && (cr.isConstraint() || cr.isCritic())) {
                        // test critic by passing change description to it...
                        c = cr.afterChange(c,this,"critic_manager");
                        if(c == null)
                            // constraint fired, so stop firing...
                            return;
                    }
                }
            }
        }
    }

}


