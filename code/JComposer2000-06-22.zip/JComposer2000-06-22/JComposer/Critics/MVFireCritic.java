package Critics;

public class MVFireCritic extends RuntimeException
{
    protected MVCritic critic;
    protected MVCriticMessage message;

    public MVFireCritic(MVCritic critic, MVCriticMessage mesg)
    {
        this.critic = critic;
        this.message = mesg;
    }
}
