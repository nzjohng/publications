package Critics;

import javax.swing.*;
import java.util.*;
import javax.swing.tree.*;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.*;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Graphics;

public class MVCriticDisplayInterface extends JFrame implements ActionListener
{

    MVCriticReport rep;

    MVCriticReportRenderer renderer = new MVCriticReportRenderer();

    DefaultMutableTreeNode root;

    GridBagLayout gbl;
    
    public MVCriticDisplayInterface(MVCriticReport rep)
    {
        super(rep.getReportName());
        this.rep = rep;

        root = new DefaultMutableTreeNode("Messages:");
        tree = new JTree(root);
        root.setAllowsChildren(true);
        tree.setCellRenderer(renderer);
        
        Dimension d = new Dimension(390,300);
        //tree.setMinimumSize(d);
        //tree.setPreferredSize(d);

        for(int i=0; i < MVCriticReport.NUM_PRIORITIES; i++)
        {
            DefaultMutableTreeNode group = new DefaultMutableTreeNode(MVCriticReport.getPriorityName(i));
            nodes[i] = group;
            root.add(group);
            group.setAllowsChildren(true);
            // refresh adds messages...
        }

   tree.expandPath(new TreePath(root.getPath()));

        fixField = new JComboBox();
        
        d = new Dimension(300,50);
        infoField.setMinimumSize(d);
        infoField.setPreferredSize(d);
        infoField.setEditable(true); // change!

        
        closeButton.addActionListener(this);
        infoButton.addActionListener(this);
        recheckButton.addActionListener(this);
        ignoreButton.addActionListener(this);
        viewsButton.addActionListener(this);
        fixButton.addActionListener(this);

        gbl = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        getContentPane().setLayout(gbl);

        scroller = new JScrollPane();
        scroller.getViewport().add(tree);
        
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        addPanel(getContentPane(),gbl,gbc,scroller,0,0,6,9);
        gbc.weightx = 0.0;
        gbc.weighty = 0.0;
        addPanel(getContentPane(),gbl,gbc,infoField,0,9,5,3);
        addPanel(getContentPane(),gbl,gbc,fixLabel,5,9,1,1);
        addPanel(getContentPane(),gbl,gbc,fixField,5,10,1,1);
        
        addPanel(getContentPane(),gbl,gbc,infoButton,0,12,1,1);
        addPanel(getContentPane(),gbl,gbc,recheckButton,1,12,1,1);
        addPanel(getContentPane(),gbl,gbc,ignoreButton,2,12,1,1);
        addPanel(getContentPane(),gbl,gbc,viewsButton,3,12,1,1);
        addPanel(getContentPane(),gbl,gbc,fixButton,4,12,1,1);
        addPanel(getContentPane(),gbl,gbc,closeButton,5,12,1,1);
        
        setSize(450,400);
        setVisible(true);
    }

    public void addPanel(Container cont, GridBagLayout gbl, GridBagConstraints gbc, Component comp, int x, int y, int w, int h)
    {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = w;
        gbc.gridheight = h;
        gbl.setConstraints(comp,gbc);
        cont.add(comp);
    }

    JTree tree;
    DefaultMutableTreeNode nodes[] = new DefaultMutableTreeNode[MVCriticReport.NUM_PRIORITIES];

    JLabel fixLabel = new JLabel("Fix with:");
    JComboBox fixField;
    
    JTextArea infoField = new JTextArea();

    JScrollPane scroller;

    JButton infoButton = new JButton("More Info");
    JButton recheckButton = new JButton("Recheck");
    JButton ignoreButton = new JButton("Ignore");
    JButton viewsButton = new JButton("Views");
    JButton fixButton = new JButton("Fix...");
    JButton closeButton = new JButton("Close");

    public void refresh()
    {
        getContentPane().remove(scroller);
    
        root = new DefaultMutableTreeNode("Messages:");
        tree = new JTree(root);
        root.setAllowsChildren(true);
        tree.setCellRenderer(renderer);
        
        Dimension d = new Dimension(390,300);
        //tree.setMinimumSize(d);
        //tree.setPreferredSize(d);

        for(int i=0; i < MVCriticReport.NUM_PRIORITIES; i++)
        {
            DefaultMutableTreeNode group = new DefaultMutableTreeNode(MVCriticReport.getPriorityName(i));
            nodes[i] = group;
            root.add(group);
            group.setAllowsChildren(true);
            // refresh adds messages...
        }

   tree.expandPath(new TreePath(root.getPath()));

   
        Enumeration e = rep.getcEvents().get_changes_forwards();
        while(e.hasMoreElements()) {
            MVCriticMessage m = (MVCriticMessage) e.nextElement();
            DefaultMutableTreeNode parent = nodes[m.getCritic().getPriority()];
            DefaultMutableTreeNode child = new DefaultMutableTreeNode(m);
            parent.add(child);
            child.setAllowsChildren(false);
        }

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;

        scroller = new JScrollPane();
        scroller.getViewport().add(tree);

        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        addPanel(getContentPane(),gbl,gbc,scroller,0,0,6,9);
        

        validate();
    }

    

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == closeButton)
            setVisible(false);
            
    }

}

class MVCriticReportRenderer implements TreeCellRenderer
{
    public MVCriticReportRenderer()
    {
        super();
    }

    static protected Font             defaultFont;

    static protected ImageIcon        collapsedIcon;

    static protected ImageIcon        expandedIcon;

    static protected final Color selectedBackgroundColor = Color.yellow;

    static
    {
        try {
            defaultFont = new Font("SansSerif", 0, 12);
        } catch (Exception e) {}
        try {
            collapsedIcon = new ImageIcon("images/collapsed.gif");
            expandedIcon = new ImageIcon("images/expanded.gif");
        } catch (Exception e) {
            System.out.println("Couldn't load images: " + e);
        }
    }

    MVMessageLabel label = new MVMessageLabel();

    Component comp;

    protected boolean            selected;

    public Component getTreeCellRendererComponent(JTree tree, Object value,
                      boolean selected, boolean expanded,
                      boolean leaf, int row,
                          boolean hasFocus) {
    Font            font;
    String          stringValue = tree.convertValueToText(value, selected,
                       expanded, leaf, row, hasFocus);

    if(value instanceof DefaultMutableTreeNode)
        value = ((DefaultMutableTreeNode) value).getUserObject();

//    if(value instanceof MVCriticMessage) {
        if(expanded)
            label.setIcon(expandedIcon);
        else if(!leaf)
            label.setIcon(collapsedIcon);
        else
            label.setIcon(null);
            
        if(hasFocus) {
            label.setForeground(Color.cyan);
            // label.setBackground(selectedBackgroundColor);
            label.selected = selected;            
        } else {
            label.setForeground(Color.black);
        }

        label.selected = selected;
        
        label.setText(value.toString());

//    }
    
        return label;

    } 




class MVMessageLabel extends JLabel
{
    public boolean selected = false;
    
    public void paint(Graphics g) {
    Color            bColor;
    Icon             currentI = getIcon();

    if(selected)
        bColor = selectedBackgroundColor;
    else if(getParent() != null)
        /* Pick background color up from parent (which will come from
           the JTree we're contained in). */
        bColor = getParent().getBackground();
    else
        bColor = getBackground();
    g.setColor(bColor);
    if(currentI != null && getText() != null) {
        int          offset = (currentI.getIconWidth() + getIconTextGap());

        g.fillRect(offset, 0, getWidth() - 1 - offset,
               getHeight() - 1);
    }
    else
        g.fillRect(0, 0, getWidth()-1, getHeight()-1);
    super.paint(g);
    }

    }

}
