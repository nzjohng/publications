package Critics;

import JViews.*;
import java.io.*;
import java.util.*;

/*
 * Critic events store critic (target) and component critic event refers
 * to (comp). Access critic by getTarget() and component by getComponent()
 *
 */

public class MVCriticEvent extends MVChangeDescr
{
    MVComponent comp;
    String name;

    public MVCriticEvent()
    {

    }

    public MVCriticEvent(MVCritic critic, MVComponent comp, String name)
    {
        super(critic);
        this.comp = comp;
        this.name = name;
    }

    public void execute()
    {
    }

    public void undo()
    {
    }

    public void redo()
    {
    }

    public MVCritic getCritic()
    {
        return (MVCritic) target;
    }

    public String getName()
    {
        return name;
    }

    public MVComponent getComponent()
    {
        return comp;
    }

    public String toString()
    {
        return "MVCriticEvent for "+getCritic().getUserName()+", comp "+getComponent().getUserName()+": "+getName();
    }

      public boolean targets(MVComponent c) {
    if(target == c)
      return true;
    if(comp == c)
      return true;
      
    return false;
  }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        super.getAggregatesRelated(aggs,rel);
        if(!rel.contains(comp))
            rel.addElement(comp);
    }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writelnQuoted(name);
        output.writeln(comp);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        name = input.getStringToken();
        int compID = input.getIntToken();
        comp = locator.findOrCreateComp(compID,0,"");
    }
    
    public boolean isValid()
    {
        return super.isValid() && (comp != null);
    }

}
