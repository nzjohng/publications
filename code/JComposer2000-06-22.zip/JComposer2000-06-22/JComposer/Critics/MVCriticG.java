package Critics;
import JViews.*;
import java.util.*;

public abstract class MVCriticG extends MVListener
 {

  public MVCriticG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public boolean isConstraint() {
    return getBooleanValue("constraint");
  }

  public void setConstraint(boolean value) {
    setValue("constraint",value);
  }


  public boolean isCritic() {
    return getBooleanValue("critic");
  }

  public void setCritic(boolean value) {
    setValue("critic",value);
  }


  public boolean isEnabled() {
    return getBooleanValue("enabled");
  }

  public void setEnabled(boolean value) {
    setValue("enabled",value);
  }


  public boolean isAnalysis() {
    return getBooleanValue("analysis");
  }

  public void setAnalysis(boolean value) {
    setValue("analysis",value);
  }


  public MVCriticReport getcReport() {
    return (MVCriticReport) getOneRelatedOrNull("report",MVChildren);
  }

  public void establishReport(MVCriticReport comp) {
    establishOneToMany("report",comp);
  }

  public void dissolveReport(MVCriticReport comp) {
    dissolveOneToMany("report",comp);
  }

  public MVCriticManager getpCritics() {
    return (MVCriticManager) getOneRelatedOrNull("critics",MVParents);
  }

  public void establishCritics(MVCriticManager comp) {
    comp.establishCritics((MVCritic) this);
  }

  public void dissolveCritics(MVCriticManager comp) {
    comp.dissolveCritics((MVCritic) this);
  }

  public MVCriticGroup getpCriticGroup() {
    return (MVCriticGroup) getOneRelatedOrNull("criticGroup",MVParents);
  }

  public void establishCriticGroup(MVCriticGroup comp) {
    comp.establishCriticGroup((MVCritic) this);
  }

  public void dissolveCriticGroup(MVCriticGroup comp) {
    comp.dissolveCriticGroup((MVCritic) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

