package ;
import JViews.*;
import java.util.*;

public abstract class AspectIconToBaseG extends MVViewRel
 {

  public AspectIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("aspectName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((AspectInfoIcon)e.nextElement()).setAspectName(((BaseAspectInfo)c.target).getAspectName());
        }
      }
            else if(isChild(c.target) && name.equals("aspectName")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((BaseAspectInfo)e.nextElement()).setAspectName(((AspectInfoIcon)c.target).getAspectName());
        }
      }
      if(isParent(c.target) && name.equals("aspectType")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((AspectInfoIcon)e.nextElement()).setAspectType(((BaseAspectInfo)c.target).getAspectType());
        }
      }
            else if(isChild(c.target) && name.equals("aspectType")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((BaseAspectInfo)e.nextElement()).setAspectType(((AspectInfoIcon)c.target).getAspectType());
        }
      }
      if(isParent(c.target) && name.equals("jviewsClass")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((AspectInfoIcon)e.nextElement()).setJviewsClass(((BaseAspectInfo)c.target).getJviewsClass());
        }
      }
            else if(isChild(c.target) && name.equals("jviewsClass")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((BaseAspectInfo)e.nextElement()).setJviewsClass(((AspectInfoIcon)c.target).getJviewsClass());
        }
      }
      if(isParent(c.target) && name.equals("designLevel")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((AspectInfoIcon)e.nextElement()).setDesignLevel(((BaseAspectInfo)c.target).getDesignLevel());
        }
      }
            else if(isChild(c.target) && name.equals("designLevel")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((BaseAspectInfo)e.nextElement()).setDesignLevel(((AspectInfoIcon)c.target).getDesignLevel());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "AspectIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((AspectInfoIcon)vc).setAspectName(((BaseAspectInfo)bc).getAspectName());
  ((AspectInfoIcon)vc).setAspectType(((BaseAspectInfo)bc).getAspectType());
  ((AspectInfoIcon)vc).setJviewsClass(((BaseAspectInfo)bc).getJviewsClass());
  ((AspectInfoIcon)vc).setDesignLevel(((BaseAspectInfo)bc).getDesignLevel());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((BaseAspectInfo)bc).setAspectName(((AspectInfoIcon)vc).getAspectName());
  ((BaseAspectInfo)bc).setAspectType(((AspectInfoIcon)vc).getAspectType());
  ((BaseAspectInfo)bc).setJviewsClass(((AspectInfoIcon)vc).getJviewsClass());
  ((BaseAspectInfo)bc).setDesignLevel(((AspectInfoIcon)vc).getDesignLevel());
  }

  public MVViewRel newViewRel() {
    return new AspectIconToBase();
  }

  public String getViewRelKind() {
    return "AspectIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

