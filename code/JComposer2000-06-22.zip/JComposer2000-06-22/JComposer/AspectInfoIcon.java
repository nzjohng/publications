package ;

import JViews.*;

public class AspectInfoIcon extends AspectInfoIconG {

  public AspectInfoIcon() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

