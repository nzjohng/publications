package Actions;

import JViews.*;

public class JCAPrintChange extends MVListener {

    public JCAPrintChange() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("PrintAction: got "+event+" from "+from.userName()+" along "+rel);
        propagateEvent(event);
        return event;
    }

}

