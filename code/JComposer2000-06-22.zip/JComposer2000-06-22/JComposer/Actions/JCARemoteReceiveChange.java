package Actions;

import JViews.*;

import java.util.*;

public class JCARemoteReceiveChange extends MVListener implements MVRemoteChangeReceiver {

    public JCARemoteReceiveChange() {
        super();
    }
    
    public String userName()
    {
        return getLocalName();
    }
    
    protected MVImportDefaultLocator locator = null;
    
    public void receiveRemoteChange(String user, String from, byte bytes[])
    {
        System.out.println("*** RemoteReceiveChange got from "+user+" comp "+from+" change:\n"+bytes);

        MVProject p = getProject();
        MVInputBuffer2 buffer = new MVInputBuffer2(bytes);

        if(locator == null)
            locator = new MVImportDefaultLocator(p);
        Vector change = p.importChanges(buffer, locator);
        if(change.size() > 0) {            
            MVChangeDescr c = (MVChangeDescr) change.firstElement();

  System.out.println("Received change: "+c);
            propagateEvent(c);
        }
    
        // need to decode then call performFilterAction - just
        // propagate to connected comps...
        //
        // should we set rel to be the "from" String value i.e. the
        // remote comp we got this change from???
    }    

    public MVChangeDescr afterChange(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("*** Remote receive change got: "+event);

/*
        if(rel.equals("listener_proxy") || rel.equals("this")) {
            // make sure register this comp if get change from self or "proxy" comp
            String name = getLocalName();
            if(!getLocalName().equals("")) {
                MVProject p = getProject();
System.out.println("registering "+name);
                p.registerComp(name,this);   
            }     
        }
*/
        
        return super.afterChange(event,from,rel);
    }
    
    public String getLocalName()
    {
        return getAttributeValue("localName");    
    }
    
    public void setLocalName(String value)
    {
        setAttributeValue("localName",value);
    }    
    
    public void addProxy(MVListenerProxy proxy)
    {
        super.addProxy(proxy);
        ((MVComponent) proxy).setHandleAfterRel("listener_proxy");   
        setLocalName("");
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"localName"};

        return ss;
    }

}

