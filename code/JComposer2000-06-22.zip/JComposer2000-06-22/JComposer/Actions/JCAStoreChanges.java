package Actions;

import JViews.*;
import java.awt.*;

public class JCAStoreChanges extends MVListener {

    public JCAStoreChanges() {
        super();
    }
    
    public MVVersionRecord getcVersionRecord()
    {
        MVVersionRecord v = (MVVersionRecord) getOneRelatedOrNull("versionRecord",MVChildren);
        if(v != null)
            return v;
        
        v = new MVVersionRecord();
        v.init();
        establishVersionRecord(v);

        return v;
    }
    
    public void establishVersionRecord(MVVersionRecord v)
    {
        establishOneToMany("versionRecord",v);
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        getcVersionRecord().add_change(event);
        propagateEvent(event);
        return event;
    }
    
    public void storeChange(MVChangeDescr event)
    {
        getcVersionRecord().add_change(event);
    }

    boolean addedButtons = false;
    
    public void showPropertySheet()
    {
        // should change so this action adds a menu opiton to
        // e.g. JVis or Ser-II icons???
        
        MVVersionRecord v = getcVersionRecord();

    if(!addedButtons) {
	    // add extra buttons...
	    //((MVPanelInfo) v.getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).addComponent(new Button("Check in"));
        //((MVPanelInfo) v.getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).addComponent(new Button("Check out"));

        ((MVPanelInfo) v.getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).disableComponent("Undo");
        ((MVPanelInfo) v.getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).disableComponent("Redo");

         addedButtons = true;
    }
        v.displayRecords();
    }
    
    public MVAspects getAspects()
    {
        MVAspects aspects = super.getAspects();
        
        // attributes
        
        /*
        MVPropertyAspect pas = aspects.getPropertyAspect();
        pas.addPropertyInfo(new MVPropertyInfo("localName","String","This is the unique local name for the sender component used when sending it to a remote host"));
        pas.addPropertyInfo(new MVPropertyInfo("remoteUser","String","The name of the remote user's environment e.g. 'john' or 'monitoring agent'"));
        pas.addPropertyInfo(new MVPropertyInfo("remoteName","String","The unique name of the remote receiver component this sender forwards changes/messages to"));
        */
                
        // relationships
        
        MVRelationshipAspect ras = aspects.getRelationshipAspect();
        ras.addRelationshipInfo(new MVRelationshipInfo("<any input comp>","1:1",MVRelationshipInfo.MVAnyInputRel,true,"Component which stores changes in this version record component"));
        ras.addRelationshipInfo(new MVRelationshipInfo("VersionRecord","1:1",MVRelationshipInfo.MVAnyOutputRel,true,"Version record component used to store changes in"));
        
        // how about comp to forward "errors" to? Ok sends to??
            // "error" & "ok" ??
        
        // configuration info - what required to work etc.??
          // info this case ALL properties and at least one input comp's rel
      
        /*
        MVConfigurationAspect cas = aspects.getConfigurationAspect();
        String config_names[] = {"localName","remoteUser","remoteName","<sender>"};
        cas.addConfigurationInfo(new MVConfigurationInfo("required attributes/rels",MVConfigurationInfo.MVRequiredSettings,config_names,"Must set all these attributes & have at least one input component for this remote change sender to work. Must also have remoteUser/remoteName on-line and named"));
        */
        
        // human interface provision/requirements
        
        MVHumanInterfaceAspect hias = aspects.getHumanInterfaceAspect();
        // hias .addHumanInterfaceInfo(new MVHumanInterfaceInfo("property sheet",true,false,MVHumanInterfaceInfo.MVPropertySheetHIAspect,"Simple property sheet provided to set remote sender's attributes"));
        hias .addHumanInterfaceInfo(new MVHumanInterfaceInfo("changes dialogue",true,false,MVHumanInterfaceInfo.MVDialogueHIAspect,"Dialogue provided to show changes held by version record"));
        hias .addHumanInterfaceInfo(new MVHumanInterfaceInfo("buttons panel",true,false,MVHumanInterfaceInfo.MVPanelHIAspect,"Button affordances which can be disabled/added to by other components to add extra functionality"));
        
        // persistency management provision/requirements
        
        MVPersistencyAspect peras = aspects.getPersistencyAspect();
        
        
        return aspects;
    }  

}

