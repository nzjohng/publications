package Actions;

import JViews.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class JCASimpleChooserWizard1 extends MVListener {
    // need generalised wizard class to extend???


    public JCASimpleChooserWizard1() {
        super();
    }
    
    public void addView(MVViewLayer view) {
        establishOneToMany("chooser1_view",view);
    } 
    
    public MVViewLayer getView()
        // view this listener attached to...
    {
        return (MVViewLayer) getOneRelated("chooser1_view",MVChildren);
    }
            
    public void showPropertySheet()
    {
        wizardSetUp();
    }

    public void wizardSetUp()
    {
        JCSCW1Frame f = new JCSCW1Frame(this);
        f.setVisible(true);
    }
    
}

class JCSCW1Frame extends Frame
{

    JCSCW1QueryPanel qp;
    JCSCW1CompsPanel cp;
    JCASimpleChooserWizard1 wizard;

    public JCSCW1Frame(JCASimpleChooserWizard1 wiz)
    {
        super("Simple Component Repository");
        wizard = wiz;
        setLayout(new GridLayout(2,1));
        qp = new JCSCW1QueryPanel(this);
        add(qp);
        cp = new JCSCW1CompsPanel(this);
        add(cp);
        setSize(400,400);
        pack();
    }
    
    public JCASimpleChooserWizard1 getWizard()
    {
        return wizard;
    }

}

class JCSCW1QueryPanel extends Panel implements ActionListener
{
    JCSCW1Frame frame;
    
    List aspectsl = new List();
  
    Panel detailsp = new Panel();
    Panel propsp = new Panel();
    List propsl = new List();
    TextField propf = new TextField("");
    List queryl = new List();
    
    Panel buttonsp = new Panel();
    Button addProp = new Button("Add Property");
    Button removeProp = new Button("Remove Property");

    Panel buttonsp2 = new Panel();
    Button findComps = new Button("FIND");
    Button newQuery = new Button("New Query");
    Button addComp = new Button("Add Component");
    Button aspectInfo = new Button("Aspect Info");

    public JCSCW1QueryPanel(JCSCW1Frame frame)
    {
        this.frame = frame;
        
        setLayout(new GridLayout(1,2));
        add(aspectsl);
        add(detailsp);
        
        detailsp.setLayout(new GridLayout(4,1));
        detailsp.add(propsl);
        detailsp.add(propsp);
        detailsp.add(queryl);
        detailsp.add(buttonsp2);

        propsp.setLayout(new GridLayout(2,1));
        propsp.add(propf);
        propsp.add(buttonsp);

        buttonsp.setLayout(new GridLayout(1,2));
        buttonsp.add(addProp);
        buttonsp.add(removeProp);

        buttonsp2.setLayout(new GridLayout(2,2));
        buttonsp2.add(findComps);
        buttonsp2.add(newQuery);
        buttonsp2.add(addComp);
        buttonsp2.add(aspectInfo);
      
        addProp.addActionListener(this);
        removeProp.addActionListener(this);
        propsl.addActionListener(this);
        queryl.addActionListener(this);

        aspectsl.addItem("<<User Interface>>");
        aspectsl.addItem("  view");
        aspectsl.addItem("  extensible affordance");
        aspectsl.addItem("<<Collaborative Work>>");
        aspectsl.addItem("  event generation");
        aspectsl.addItem("  event actioning");
        aspectsl.addItem("  broadcast data/event");
        aspectsl.addItem("  receive data/event");
        aspectsl.addItem("  locking");
        aspectsl.addItem("  versioning");
        aspectsl.addItem("<<Persistency>>");
        aspectsl.addItem("  encode data");
        aspectsl.addItem("  decode data");
        aspectsl.addItem("  query data");
        aspectsl.addItem("  store data");
        aspectsl.addItem("  retrieve data");
        aspectsl.addItem("  version data");
        aspectsl.addItem("<<Distribution>>");
        aspectsl.addItem("  remote identification");
        aspectsl.addItem("  remote method call");
        aspectsl.addItem("  locking");
        aspectsl.addItem("  store events");
        aspectsl.addItem("  replay events");
        aspectsl.addItem("<<Security>>");
        aspectsl.addItem("  encoding");
        aspectsl.addItem("  key management");
        aspectsl.addItem("  authentication");


        //aspectsl.setSelected("  event generation");

 /*
        propsl.addItem("GENERATE");
        propsl.addItem("AGGREGATE");
        propsl.addItem("TRANSITIVE");
        propsl.addItem("MACROS");
        propsl.addItem("DISCRETE");

        propf.setText("-GENERATE INCLUDES after");

        queryl.addItem("-event generation");
        queryl.addItem("  GENERATE INCLUDES after");
        queryl.addItem("+broadcast data/event");
        queryl.addItem("  MULTICAST=false");
 */

        propsl.addItem("MULTICAST");
        propsl.addItem("TRANSPORT");
        propsl.addItem("SERIALISATION");
        propsl.addItem("");

        propf.setText("-TRANSPORT");
 
        queryl.addItem("+event generation");
        queryl.addItem("  GENERATE=after");
        queryl.addItem("  EVENT_KIND=message");
        queryl.addItem("-broadcast data/event");
        queryl.addItem("  MULTICAST=false");
    }
    
    public void actionPerformed(ActionEvent e)
    {
    
        if(e.getSource() == addProp)
        {
            
        }
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(400,200);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(400,200);
    }
    

}

class JCSCW1CompsPanel extends Panel
{
    JCSCW1Frame frame;

    JCSCW1CompsList compsl = new JCSCW1CompsList();

    public JCSCW1CompsPanel(JCSCW1Frame frame)
    {
        this.frame = frame;
        
        setLayout(new GridLayout(1,1));
        add(compsl);
/*
        compsl.addItem("Collaborative editing (TCP/IP Sockets)");
        compsl.addItem("Collaborative editing (RMI)");
        compsl.addItem("Remote event history");
*/

        compsl.addItem("CIG Send Email Message");
        compsl.addItem("CIG Send Chat Message");
        compsl.addItem("Eudora Send Email");
        compsl.addItem("Eudora Send Attachment");
        compsl.addItem("FS1 Notify Checkin File");
        compsl.addItem("FS1 Notify Checkout File");
    }

    public Dimension getPreferredSize()
    {
        return new Dimension(400,200);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(400,200);
    }

}

class JCSCW1CompsList extends List
{

    public JCSCW1CompsList()
    {

    }

    public Dimension getPreferredSize()
    {
        return new Dimension(300,220);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(300,220);
    }

}

class JCSCW1CompsButtonPanel extends Panel
{

    public JCSCW1CompsButtonPanel()
    {

    }

    public Dimension getPreferredSize()
    {
        return new Dimension(300,30);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(300,30);
    }

    public Dimension getMaximumSize()
    {
        return new Dimension(300,30);
    }


}

