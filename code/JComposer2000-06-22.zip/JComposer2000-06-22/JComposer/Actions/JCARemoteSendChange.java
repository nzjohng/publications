package Actions;

import JViews.*;

import java.util.*;

public class JCARemoteSendChange extends MVListener {

    public JCARemoteSendChange() {
        super();
    }
    
    MVOutputBuffer buffer = new MVOutputBuffer();
    MVClient client = new MVClient();

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("*** Remote send change got: "+event+" from "+from.userName()+" along "+rel);
        
 System.out.println("sending change to remote person "+getRemoteUser()+" and comp "+getRemoteName());       

        /* Need to know project so can get user host/port info... */


        MVProject project = getProject();
        MVCollabUserInfo u = project.findCollabUser(getRemoteUser());

        if(u != null) {
            if(!client.isValidConnection())
                client.connect(MVApplication.application.getUserName(),u.getUser(),u.getHost(),u.getPort());
            
            if(client.isValidConnection()) {
                Vector v = new Vector();
                v.addElement(event);
                buffer.reset();
                MVApplication.application.current_project.exportChanges(v,buffer);

                client.sendRequest("remoteChangeSend");
                client.sendRequest(MVApplication.application.getUserName());
                client.sendRequest(MVApplication.application.current_project.getName());
                client.sendRequest(getLocalName());
                client.sendRequest(getRemoteName());
                client.sendRequest(buffer.getBytes());            
            }
        }
        /* should store change if can't send & try later?? Should generate
             event to say can't send??? */
        
        return event;
    }
    
    public String getRemoteUser()
    {
        return getAttributeValue("remoteUser");
    }
    
    public void setRemoteUser(String value)
    {
        setValue("remoteUser",value);
    }

    public String getRemoteName()
    {
        return getAttributeValue("remoteName");    
    }
    
    public void setRemoteName(String value)
    {
        setAttributeValue("remoteName",value);
    }

    public String getLocalName()
    {
        return getAttributeValue("localName");    
    }
    
    public void setLocalName(String value)
    {
        setAttributeValue("localName",value);
    }    
    
    public String userName()
    {
        return getLocalName();
    }
    
    /* **** NEED TO PUBLICISE ATTRIBUTES/EVENTS/METHODS OF THIS
      CLASS VIA BEANINFO OR SOMETHING!! *** */

    public String [] getEditableProperties() {
        String ss[] = {"localName","remoteUser","remoteName"};

        return ss;
    }
     
    public MVAspects getAspects()
    {
        MVAspects aspects = super.getAspects();
        
        // attributes
        
        MVPropertyAspect pas = aspects.getPropertyAspect();
        pas.addPropertyInfo(new MVPropertyInfo("localName","String","This is the unique local name for the sender component used when sending it to a remote host"));
        pas.addPropertyInfo(new MVPropertyInfo("remoteUser","String","The name of the remote user's environment e.g. 'john' or 'monitoring agent'"));
        pas.addPropertyInfo(new MVPropertyInfo("remoteName","String","The unique name of the remote receiver component this sender forwards changes/messages to"));
                
        // relationships
        
        MVRelationshipAspect ras = aspects.getRelationshipAspect();
        ras.addRelationshipInfo(new MVRelationshipInfo("<sender>","1:n",MVRelationshipInfo.MVAnyInputRel,true,"Component(s) which send changes to this sender component"));
        ras.addRelationshipInfo(new MVRelationshipInfo("event hisotry","0:1",MVOneToMany,true,"Event history component for supporting event query & retransmission"));
        
        // how about comp to forward "errors" to? Ok sends to??
            // "error" & "ok" ??
        
        // configuration info - what required to work etc.??
          // info this case ALL properties and at least one input comp's rel
      
        MVConfigurationAspect cas = aspects.getConfigurationAspect();
        String config_names[] = {"localName","remoteUser","remoteName","<sender>"};
        cas.addConfigurationInfo(new MVConfigurationInfo("required attributes/rels",MVConfigurationInfo.MVRequiredSettings,config_names,"Must set all these attributes & have at least one input component for this remote change sender to work. Must also have remoteUser/remoteName on-line and named"));
        String config_names2[] = {"event history"};
        cas.addConfigurationInfo(new MVConfigurationInfo("recommended rels",MVConfigurationInfo.MVRecommendedSettings,config_names,"Need event history linked so can do querying/retransmission"));
        
        // human interface provision/requirements
        
        MVHumanInterfaceAspect hias = aspects.getHumanInterfaceAspect();
        hias .addHumanInterfaceInfo(new MVHumanInterfaceInfo("property sheet",true,false,MVHumanInterfaceInfo.MVPropertySheetHIAspect,"Simple property sheet provided to set remote sender's attributes"));
        
        return aspects;
    }  
     
}

