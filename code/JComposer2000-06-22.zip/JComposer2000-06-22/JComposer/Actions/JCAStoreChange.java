package Actions;

import JViews.*;

public class JCAStoreChange extends MVListener {

    public JCAStoreChange() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("StoreChange: got "+event+" from "+from.userName()+" along "+rel);
        
        if(doStoreChange(event))
            propagateEvent(event);
        
        return event;
    }
    
    public MVComponent getcRecord()
    {
        return getInputComp("record");
    }
    
    public boolean doStoreChange(MVChangeDescr event)
    {
        try {
            MVComponent comp = getcRecord();
System.out.println("Comp to send to:\n"+comp);
            MVMessage msg = new MVMessage(comp,"add_change",event);
            msg.execute();
        
            propagateEvent(event);
            return true;
        } catch(Exception e) {
            System.out.println("*** JCAStorechange generated "+e);
            return false;
        }
     }
    
     
}

