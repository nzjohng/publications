package Actions;

import JViews.*;
import Serendipity.*;
import java.util.*;

public class JCACreateSEProject extends MVListener {

	public JCACreateSEProject()
	{

	}
	public void init()
	{
		MVApplication app = MVApplication.application;
		Enumeration e = app.projects.elements();
		while(e.hasMoreElements()) {
			MVProject p = (MVProject) e.nextElement();
			if(p instanceof SEProject)
				return;
		}

		// create SEProject & open it...

		SEProject sep = new SEProject("Default SEProject");
		app.addProject(sep);
		sep.openProjectInfo();
		MVApplication.application.makeCurrent(sep,null,null);
	}

}

