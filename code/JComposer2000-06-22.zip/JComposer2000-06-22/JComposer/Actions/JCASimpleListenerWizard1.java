package Actions;

import JViews.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class JCASimpleListenerWizard1 extends MVListener {
    // need generalised wizard class to extend???


    public JCASimpleListenerWizard1() {
        super();
    }
    
    public void addView(MVViewLayer view) {
        establishOneToMany("wiz1_view",view);
    } 
    
    public MVViewLayer getView()
        // view this listener attached to...
    {
        return (MVViewLayer) getOneRelated("wiz1_view",MVChildren);
    }
    
    public void establishComps(MVViewComp vc)
    {
        establishOneToMany("wiz1_view_comps",vc);
        vc.setListenAfterRel("wiz1_view_comps");
    }
    
    public Vector getcComps()
        // view comps listening to...
    {
        return getRelationship("wiz1_view_comps",MVChildren);
    }
    
    public void setKind(String kind)
    {
        setValue("kind",kind);
    }
    
    public String getKind()
        // kind of MVChangeDescr listening for...
    {
        return getStringValue("kind");
    }
    
    public void setAction(String action)
    {
        setValue("action",action);
    }
    
    public String getAction()
        // action - what to do when get change descr matching
        // kind specified above:
        //  - store in version record ("store")
        //  - send to user ("send")
        //  - display in view message bar ("message")
        //  - abort operation causing change ("abort")
    {
        return getStringValue("action");
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("JCASimpleListenerWizard1: got "+event+" from "+from.userName()+" along "+rel);
        
        if(doHandleChange(event))
            propagateEvent(event);
        
        return event;
    }
 
    public boolean doHandleChange(MVChangeDescr event)   
    {
        if(getcComps().contains(event.getTarget())) {
            // change description from one of view comps listening to
            if(getKind().equals(event.getClass().getName())) {
                // kind of change description matches
                //
                // should allow for argument value check too...
                
               String action = getAction();
               if(action.equals("store"))
                doStoreEvent(event);
               else if(action.equals("message"))
                doMessageEvent(event);
               // and so on...
               
               return true;
            }
        }  
        
        return false;  
    }
    
    public void doStoreEvent(MVChangeDescr event)
    {
        System.out.println("JCASimpleListenerWizard1: Store event "+event);
    }
    
    public void doMessageEvent(MVChangeDescr event)
    {
        getView().setMessage(event.toString());
    }
    
    public void showPropertySheet()
    {
        wizardSetUp();
    }

    public void wizardSetUp()
    {
        JCSLW1Frame f = new JCSLW1Frame();
        JCSLW1Panel1 p = new JCSLW1Panel1(this,f);
        f.setPanel(p);
        f.setVisible(true);
    }
    
}

class JCSLW1Frame extends Frame
{

    Panel p = null;

    public JCSLW1Frame()
    {
        super("Listener set-up Wizard");
        setLayout(new GridLayout(1,1));
        setSize(300,300);
    }
    
    public void setPanel(Panel new_p)
    {
        if(p != null)
            remove(p);
            
         add(new_p);
         p = new_p;
         pack();
    }

}

class JCSLW1Panel1 extends Panel implements ActionListener
{
    JCASimpleListenerWizard1 wiz;
    JCSLW1Frame frame;
    
    List comps = new List();
    JCSLW1ButtonPanel bp = new JCSLW1ButtonPanel();
    Button next = new Button(">Next");
    Button cancel = new Button("Cancel");
     
    public JCSLW1Panel1(JCASimpleListenerWizard1 wiz, JCSLW1Frame frame)
    {
        this.wiz = wiz;
        this.frame = frame;
        
        Enumeration e = wiz.getView().components();
        while(e.hasMoreElements())
        {
            MVViewComp vc = (MVViewComp) e.nextElement();
            comps.addItem(vc.userName());
        }
        
        bp.setLayout(new GridLayout(1,2));
        bp.add(next);
        bp.add(cancel);
        
        setLayout(new GridLayout(2,1));
        add(comps);
        add(bp);
        
        next.addActionListener(this);
        cancel.addActionListener(this);
        frame.pack();     
    }
    
    public void actionPerformed(ActionEvent e)
    {
    
        if(e.getSource() == next)
        {
            // should check for selected comp!
            JCSLW1Panel2 p = new JCSLW1Panel2(wiz,frame);
            frame.setPanel(p);
        }
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(300,250);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(300,250);
    }
    

}

class JCSLW1ButtonPanel extends Panel
{
    public JCSLW1ButtonPanel()
    {
        super();
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(300,20);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(300,20);
    }
    
    public Dimension getMaximumSize()
    {
        return new Dimension(300,20);
    }
    
}


class JCSLW1Panel2 extends Panel implements ActionListener
{
    JCASimpleListenerWizard1 wiz;
    JCSLW1Frame frame;
    
    Label l = new Label("Kind of change description:");
    List kinds = new List();
    
    Button next = new Button(">Next");
    Button cancel = new Button("Cancel");
     
    public JCSLW1Panel2(JCASimpleListenerWizard1 wiz, JCSLW1Frame frame)
    {
        this.wiz = wiz;
        this.frame = frame;
        
        kinds.addItem("Property change");
        kinds.addItem("Add component");
        kinds.addItem("Delete component");
        kinds.addItem("Establish relationship");
        kinds.addItem("Disolve relationship");
        
        setLayout(new GridLayout(4,1));
        add(l);
        add(kinds);
        add(next);
        add(cancel);
       
        next.addActionListener(this);
        cancel.addActionListener(this);
        frame.pack();     
    }
    
    public void actionPerformed(ActionEvent e)
    {
    
        if(e.getSource() == next)
        {
            // should check for selected comp!
            JCSLW1Panel3 p = new JCSLW1Panel3(wiz,frame);
            frame.setPanel(p);
        }
    }

}

class JCSLW1Panel3 extends Panel implements ActionListener
{
    JCASimpleListenerWizard1 wiz;
    JCSLW1Frame frame;
    
    Label l = new Label("Property name/value:");
    TextField t1 = new TextField("<Name>");
    TextField t2 = new TextField("<Value>");
    
    Button next = new Button(">Next");
    Button cancel = new Button("Cancel");
     
    public JCSLW1Panel3(JCASimpleListenerWizard1 wiz, JCSLW1Frame frame)
    {
        this.wiz = wiz;
        this.frame = frame;
        
        setLayout(new GridLayout(5,1));
        add(l);
        add(t1);
        add(t2);
        add(next);
        add(cancel);
       
        next.addActionListener(this);
        cancel.addActionListener(this);
        frame.pack();     
    }
    
    public void actionPerformed(ActionEvent e)
    {
    
        if(e.getSource() == next)
        {
            // should check for selected comp!
            JCSLW1Panel4 p = new JCSLW1Panel4(wiz,frame);
            frame.setPanel(p);
        }
    }

}

class JCSLW1Panel4 extends Panel implements ActionListener
{
    JCASimpleListenerWizard1 wiz;
    JCSLW1Frame frame;
    
    Label l = new Label("Action to take:");
    List kinds = new List();
    
    Button next = new Button("Finish");
    Button cancel = new Button("Cancel");
     
    public JCSLW1Panel4(JCASimpleListenerWizard1 wiz, JCSLW1Frame frame)
    {
        this.wiz = wiz;
        this.frame = frame;
        
        kinds.addItem("Store change");
        kinds.addItem("Message user");
        kinds.addItem("Display change");
        kinds.addItem("Abort operation");
        
        setLayout(new GridLayout(4,1));
        add(l);
        add(kinds);
        add(next);
        add(cancel);
       
        next.addActionListener(this);
        cancel.addActionListener(this);
        frame.pack();     
    }
    
    public void actionPerformed(ActionEvent e)
    {
    
        if(e.getSource() == next)
        {
            // should check for selected comp!
           frame.setVisible(false);
        }
    }

}

