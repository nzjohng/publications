
package Actions;

import JViews.*;
import JComp.*;
import java.util.*;

public class SEADetectJCompChanges extends MVListener
{

	public SEADetectJCompChanges()
	{
	}

	public void init()
	{
		super.init();
		
		if(getcrBaseComps() == null) {
			MVApplication app = MVApplication.application;
			Enumeration e = app.projects.elements();
			while(e.hasMoreElements()) {
				MVProject p = (MVProject) e.nextElement();
				if(p instanceof JCProject) {
					Enumeration e2 = ((JCProject) p).getBaseLayers().elements();
					while(e2.hasMoreElements()) {
						JCBaseLayer bl = (JCBaseLayer) e2.nextElement();
						bl.getcrBaseComps().establishOneToMany("change_listener",this);
					}
				}
		}

		}
	}

	public JCBaseComps getcrBaseComps()
	{
		return (JCBaseComps) getOneRelatedOrNull("change_detector",MVParents);
	}

	public MVChangeDescr afterUpdate(MVChangeDescr event, MVComponent from, String rel)
	{
		System.out.println("SEADetectJCompChanges get "+event);
		System.out.println("From: "+from.getUserName());

		if(from != this)
			broadcastAfter(event);

		return super.afterChange(event,from,rel);
	}

}

