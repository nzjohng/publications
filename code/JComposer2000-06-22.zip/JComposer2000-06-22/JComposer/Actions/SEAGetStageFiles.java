package Actions;

import JViews.*;
import Serendipity.*;

public class SEAGetStageFiles extends MVListener {

    public SEAGetStageFiles() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        System.out.println("*****************");
        System.out.println("* GET FILES!!!  *");
        System.out.println("*****************");  
        
        return event;
    }

}
