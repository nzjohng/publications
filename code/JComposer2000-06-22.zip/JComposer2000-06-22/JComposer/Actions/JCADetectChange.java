package Actions;

import JViews.*;

public class JCADetectChange extends MVListener {

    public JCADetectChange() {
        super();
    }
    
    public String getType()
    {
        return getStringValue("type");
    }
    
    public void setType(String value)
    {
        setValue("type",value);
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        try {
          if(getType() != "") {
            Class compClass = Class.forName(getType());
            if(compClass.isInstance(event))
                propagateEvent(event); 
          }
        } catch (Exception e) {
            System.out.println("JCADetectChange got: "+e);
            e.printStackTrace();
        }
       
        return event;
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"type"};

        return ss;
    }

}

