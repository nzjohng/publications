package Filters;

import JViews.*;
import Serendipity.*;

public class SEFFinishedStage extends MVListener {

    public SEFFinishedStage() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof SEFinishStage) 
            propagateEvent(event);
        return event;
    }

}
