package Filters;

import JViews.*;
import Serendipity.*;

public class SEFEnactedStage extends MVListener {

    public SEFEnactedStage() {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof SEEnactStage) 
            propagateEvent(event);
        return event;
    }

}
