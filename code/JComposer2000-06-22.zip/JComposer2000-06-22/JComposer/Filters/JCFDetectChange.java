package Filters;

import JViews.*;

public class JCFDetectChange extends MVListener {

    public JCFDetectChange() {
        super();
    }
    
    public String getType()
    {
        return getStringValue("type");
    }
    
    public void setType(String value)
    {
        setValue("type",value);
    }
    
    public String getChangeValue() 
    {
        return getStringValue("changeValue");
    }
    
    public void setChangeValue(String value)
    {
        setValue("changeValue",value);
    }
    

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        try {
          if(getType() != "") {
            Class compClass = Class.forName(getType());
            if(compClass.isInstance(event))
                propagateEvent(event); 
          }
        } catch (Exception e) {
            System.out.println("JCADetectChange got: "+e);
            e.printStackTrace();
        }
       
        return event;
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"type", "changeValue"};

        return ss;
    }

}

