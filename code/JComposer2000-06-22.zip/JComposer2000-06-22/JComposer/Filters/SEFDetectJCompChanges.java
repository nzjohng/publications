
package Filters;

import JViews.*;
import JComp.*;
import java.util.*;

public class SEFDetectJCompChanges extends MVListener
{

	public SEFDetectJCompChanges()
	{
	}

	public void init()
	{
		super.init();
		
		if(getcrBaseComps() == null) {
			MVApplication app = MVApplication.application;
			Enumeration e = app.projects.elements();
			while(e.hasMoreElements()) {
				MVProject p = (MVProject) e.nextElement();
				if(p instanceof JCProject) {
					Enumeration e2 = ((JCProject) p).getBaseLayers().elements();
					while(e2.hasMoreElements()) {
						MVBaseLayer bl = (MVBaseLayer) e2.nextElement();
						if(bl instanceof JCBaseLayer) {
						    ((JCBaseLayer) bl).getcrBaseComps().establishOneToMany("se_change_detector",this);
                            ((JCBaseLayer) bl).getcrBaseComps().setListenAfterRel("se_change_detector");
                            ((JCBaseLayer) bl).getcrBaseComps().setHandleAfterRel("se_change_detector");
						}
					}
				}
		}

		}
	}

	public JCBaseComps getcrBaseComps()
	{
		return (JCBaseComps) getOneRelatedOrNull("se_change_detector",MVParents);
	}

	public MVChangeDescr afterChange(MVChangeDescr event, MVComponent from, String rel)
	{

        if(event instanceof MVEstablishRel && ((MVEstablishRel) event).getChild() instanceof JCBaseComp) {
            ((MVEstablishRel) event).getChild().setListenAfterRel(getcrBaseComps().relName());
        }

		if(from != this)
			propagateEvent(event);

		return super.afterChange(event,from,rel);
	}
	
    public MVChangeDescr afterReceive(MVChangeDescr event,
        MVComponent from, String rel_name, MVComponent sent_from, String sent_rel) {

        if(from != this)
            propagateEvent(event);
    
        return super.afterReceive(event,from,rel_name,sent_from,sent_rel);
    }
  

}

