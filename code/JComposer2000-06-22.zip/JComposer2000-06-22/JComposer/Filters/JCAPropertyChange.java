package Filters;

import JViews.*;

public class JCAPropertyChange extends MVListener {

    public JCAPropertyChange() {
        super();
    }
    
    public String getName()
    {
        return getStringValue("name");
    }
    
    public void setName(String value)
    {
        setValue("name",value);
    }
    
    public String getType()
    {
        return getStringValue("type");
    }
    
    public void setType(String value)
    {
        setValue("type",value);
    }
    
    public String getNewValue()
    {
        return getStringValue("newValue");   
    }
    
    public void setNewValue(String value)
    {
        setValue("newValue",value);
    }
    
    public String [] getEditableProperties() {
        String ss[] = {"name","type","newValue"};

        return ss;
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof MVSetValue)  {
            if(getName().equals("") || getName().equals(((MVSetValue)event).getPropertyName())) {
                if(getType().equals("") || getNewValue().equals(""))
                    propagateEvent(event);
                else {
                    if(getType().equals("String") &&  event instanceof MVSetStringValue)
                        if(getNewValue().equals(((MVSetStringValue) event).getNewValue()))
                            propagateEvent(event);
                    
                    if(getType().equals("Integer") &&  event instanceof MVSetIntValue)
                        if(Integer.parseInt(getNewValue()) == (((MVSetIntValue) event).getNewValue()))
                            propagateEvent(event);
                            
                    if(getType().equals("Boolean") &&  event instanceof MVSetBooleanValue)
                        if(getNewValue().equals("true") && (((MVSetBooleanValue) event).getNewValue()))
                            propagateEvent(event);
                        else if(getNewValue().equals("false") && !(((MVSetBooleanValue) event).getNewValue()))
                            propagateEvent(event);
                }
            }
        }
        
        return event;
    }

}
