
package Filters;

import JViews.*;
import JComp.*;
import java.util.*;

public class SEFCritiqueNumAttributes extends MVListener
{

    MVVersionRecord rec; // would need a global "critique record" in reality...

	public SEFCritiqueNumAttributes()
	{
	}

	public void init()
    {
        if(rec == null) {
            rec = new MVVersionRecord();
            rec.setTitle("Critic record");
            rec.displayRecords();
        }
    }

    public MVChangeDescr afterChange(MVChangeDescr event, MVComponent from, String rel)
    {
        if(event.getTarget() instanceof JCBaseComp) {
            JCBaseComp comp = (JCBaseComp) event.getTarget();
            if(comp.getcClassAttributes().size() == 0) {
                // should find existing one first?
                // need to add extra critique info (file name containing this??)
                rec.add_change(new JCCritiqueRecord(this,"No attributes defined",comp));
            }

            if(comp.getcClassAttributes().size() > 3) { // would be e.g. > 15 in reality...
                rec.add_change(new JCCritiqueRecord(this,"Too many attributes?",comp));
            }
                
        }

        return super.afterChange(event,from,rel);
    }

}
