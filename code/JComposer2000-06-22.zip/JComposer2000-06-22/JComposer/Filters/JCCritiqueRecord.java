
package Filters;

import JComp.*;
import JViews.*;

public class JCCritiqueRecord extends MVChangeDescr
{

    String mesg;
    MVComponent comp;

	public JCCritiqueRecord()
    {
    }

    public JCCritiqueRecord(MVListener critic, String mesg, MVComponent comp)
    {
        setTarget(critic);
        this.mesg = mesg;
        this.comp = comp;
    }

    public void execute() { }

    public void undo() { }

    public void redo() { }

    public String toString()
    {
        return "Critic "+target.getUserName()+": "+mesg+" for "+comp.getUserName();
    }

}

