
import JViews.*;
import Serendipity.*;

public class OR extends MVListener {

    public OR () {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof SEFinishStage) 
            propagateEvent(event);
        return event;
    }

}
