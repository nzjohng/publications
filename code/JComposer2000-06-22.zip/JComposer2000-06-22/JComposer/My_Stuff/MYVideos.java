package my_stuff;

import JViews.*;

public class MYVideos extends MYVideosG {

  public MYVideos() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

