package my_stuff;
import JViews.*;
import java.util.*;

public abstract class MYCustomersG extends MVBaseComp
 {

  public MYCustomersG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public String getName() {
    return getStringValue("name");
  }

  public void setName(String value) {
    setValue("name",value);
  }


  public int getId() {
    return getIntValue("id");
  }

  public void setId(int value) {
    setValue("id",value);
  }


  public Vector getcVideos() {
    return getRelationship("videos",MVChildren);
  }

  public void establishVideos(MYVideos comp) {
    establishOneToMany("videos",comp);
  }

  public void dissolveVideos(MYVideos comp) {
    dissolveOneToMany("videos",comp);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

