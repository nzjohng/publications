package my_stuff;
import JViews.*;
import java.util.*;

public abstract class MYVideosG extends MVBaseComp
 {

  public MYVideosG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public MYCustomers getpVideos() {
    return (MYCustomers) getOneRelatedOrNull("videos",MVParents);
  }

  public void establishVideos(MYCustomers comp) {
    comp.establishVideos((MYVideos) this);
  }

  public void dissolveVideos(MYCustomers comp) {
    comp.dissolveVideos((MYVideos) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

