package my_stuff;

import JViews.*;

public class MYCustomers extends MYCustomersG {

  public MYCustomers() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

