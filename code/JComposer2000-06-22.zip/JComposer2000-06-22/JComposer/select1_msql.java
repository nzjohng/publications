
import java.sql.*;

public class select1_msql {

    public static void main(String argv[])
    {
        select1_msql c = new select1_msql();
        c.run();
    }

    public void run()
    {
      String dbURL = "jdbc:msql://lucy.cs.waikato.ac.nz:4333/test";
      String httpServer = "jgrundy.slip.waikato.ac.nz";

      Class.forName("com.imaginary.sql.msql.MsqlDriver");
      String url = dbURL;
      Connection con = DriverManager.getConnection(url, httpServer, "");
      Statement stmt = con.createStatement();
      ResultSet rs =
      stmt.executeQuery("select * FROM jcg_lines");
 
            String row[] = null;
            out.println("OK");
            while(rs.next()) {

                int id = rs.getInt("line_id");
               String data = rs.getString("line_data");
                        
               System.out.println(id+" "+data);

            }
            stmt.close();
        } catch(Exception e) {
            System.out.println("Exception in processProductList(): "+e);
            System.exit(1);
        }                 
        
        System.out.println("DONE");
    }

}
