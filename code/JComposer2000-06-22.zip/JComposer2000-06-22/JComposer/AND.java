
import JViews.*;
import Serendipity.*;
import java.util.*;

public class AND extends MVListener {

    public AND () {
        super();
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
        if(event instanceof SEFinishStage) {
             if(from instanceof SEBaseEventFlow)
                // mark input event flow as "finished"
                ((SEBaseEventFlow) from).setValue("finished",true);
             
             // if all stages connected by input event flows
             // have been finished, pass on a finished event
             // to stage(s) connected by output flows
             //
             // currently generate new finished event
             //
             Enumeration e = getBaseListener().getpInEvent().elements();
             boolean all_finished = true;
             while(e.hasMoreElements()) {
                SEBaseEventFlow bf = (SEBaseEventFlow) e.nextElement();
                if(!bf.getBooleanValue("finished"))
                    all_finished = false;
             }
             
             if(all_finished) {
                propagateEvent(new SEFinishStage(getBaseListener(),((SEFinishStage) event).getUser(),getBaseListener().userName(),"all inputs to AND finished",""));
             }
        }
        
        if(event instanceof SEEnactStage && getBaseListener().getpInEvent().contains(from)) {
             // if any input stage is started, reset ALL markers
             // on all input event flows
             Enumeration e = getBaseListener().getpInEvent().elements();            
             while(e.hasMoreElements()) {
                SEBaseEventFlow bf = (SEBaseEventFlow) e.nextElement();
                bf.setValue("finished",false);
             }       
        }
        
        return event;
    }
    
    public SEBaseListener getBaseListener()
    {
        return (SEBaseListener) getProxy();
    }

}
