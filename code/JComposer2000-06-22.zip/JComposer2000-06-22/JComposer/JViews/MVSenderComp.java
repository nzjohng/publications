package JViews;

public interface MVSenderComp
{   
    public void removeServer(MVClient c);

}
