package JViews;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

/*
 * Implements the base layer, which groups all base layer components
 * for an MViews environment
 *
 */

public class MVBaseLayer extends MVLayer {

  public MVBaseLayer(String name) {
    // initialise base layer component
    super();
        init(name);
    }

    public void init(String name) {
    setName(name);
    MVBaseCompsRel comps = new MVBaseCompsRel("viewComponents",this);
    setAggregateRel("viewComponents");
    MVBaseViewsRel views = new MVBaseViewsRel("views",this);
    setAggregateRel("views");
    
        setViewName(1);
        chooseView();
  }

    public MVBaseLayer() {
        super();
    }

    public void initialise() {

    }

    public MVProject getProject() {
        return (MVProject) getOneRelated("base_layers",MVParents);
    }

    public MVBaseCompsRel getCompsRel() {
        return (MVBaseCompsRel) getOneRelated("viewComponents",MVChildRelComps);
    }

    public Enumeration components() {
        return getCompsRel().children();
    }

  public void addLayerComponent(MVLayerComp comp) {
    // add to viewComponents relationship
    // can be overridden or simply not used...
    
        if(getCompsRel().get(Integer.toString(comp.compID)) == null)
            getCompsRel().establish(this,comp);
  }
  
  public void removeLayerComponent(MVLayerComp comp) {
    getCompsRel().dissolve(this,comp);
  }
  
  public MVComponent findComponentID(String compKind, String userName) {
    // default component location based on compKind, userName pair 
    // uses viewComponents hashtable rel to find specified component
    // This can be overridden to use application-specific lookup tables
    // for greater efficiency...
    
        Enumeration e = getCompsRel().children();

        while(e.hasMoreElements()) {
            MVComponent b = (MVComponent) e.nextElement();
            if(b.compKind().equals(compKind) &&
                b.userName().equals(userName))
                    return b;
        }

        return null;
  }

  /*
   * view management
   *
   */
   
    public void setViewName(int num) {
        setValue("ViewName",num);
    }

    public int getViewName() {
        return getIntValue("ViewName");
    }

    public String nextViewName() {
        int num = getViewName();
        setViewName(num+1);

        return "Diagram "+num;
    }

  public MVViewLayer current_view_layer = null;
    // the "current" i.e. front view layer for this base layer
  
  public void setCurrentView(MVViewLayer new_view) {
    // set given view as the "current" i.e. front view
    
    current_view_layer = new_view;
  }
  
  public MVBaseViewsRel getViewsRel() {
    // views relationship
    
    return (MVBaseViewsRel) getOneRelated("views",MVChildRelComps);
  }
   
  public void makeCurrent(MVViewLayer view) {
    // make this base layer current layer for project
    
    getProject().makeCurrent(this,view);
  }
  
  public MVViewLayer findViewByName(String name) {
    // find view by name in views relationship
    
    return (MVViewLayer) getViewsRel().get(name);
  }
  
  public void addView(MVViewLayer new_view) {
    // add new view to views relationship
    getViewsRel().establish(this,new_view);
  }
  
  public void removeView(MVViewLayer new_view) {
    // remove view from views relationship
    getViewsRel().dissolve(this,new_view);
  }

  public void viewCompCreated(MVViewLayer view) {
    MVAddView c = new MVAddView(this,view.compKind(),view);
    
    recordUpdate(c);
  }
  
    public void reopenViews() {
        Enumeration e = getViewsRel().children();
        while(e.hasMoreElements()) {
            ((MVViewLayer) e.nextElement()).show();
        }
    }
  
  /*
   * Component inspection facility
   *
   */

  private MVInspectorFrame inspectorFrame  = null; 

  public void inspect(MVComponent comp) {
    
    if(inspectorFrame == null)
      inspectorFrame = new MVInspectorFrame("Inspector Window");
    inspectorFrame.inspect(comp);
  }

    protected MVViewChooserFrame chooser = null;

    public void chooseView() {
        if(chooser == null)
            chooser = new MVViewChooserFrame(this);
        chooser.show();
    }
        
    public MVComponent findOldCompForView(int compID, int copiedFrom, String compKind, String userName)  
    {
        // default is to return null...
        
        return null;
    }


}
    
class MVInspectorFrame extends Frame implements MVChangeListener {

  MVInspectorInfoPanel infoPanel = new MVInspectorInfoPanel();
  MVInspectorListPanel listPanel = new MVInspectorListPanel();
  MVInspectorButtonPanel buttonPanel = new MVInspectorButtonPanel(this);
  
  MVComponent inspecting = null;
  Vector previous = new Vector();
  int prev_index = -1;

  public MVInspectorFrame(String title) {
    super(title);
    setLayout(new BorderLayout());
    add("North",infoPanel);
    add("Center",listPanel);
    add("South",buttonPanel);
    setSize(400,300);
    pack();
  }
  
  public void processEvent(AWTEvent e) {
        if(e instanceof WindowEvent) {
            if(e.getID() == WindowEvent.WINDOW_CLOSED)
                doFinish();
        }

        super.processEvent(e);
  }

  public void inspect(MVComponent comp) {
        if(inspecting != null)
            inspecting.removeListenAfter(this);
    inspecting = comp;
        inspecting.addListenAfter(this);
    infoPanel.setComponentName(comp);
    listPanel.setListValues(comp);
    validate();
    setVisible(true);
  }

    public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent comp) {
        return c;
    }

    public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent sent_from,
            String sent_rel, MVComponent comp) {
        return c;
    }

    public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent sent_from, 
            String sent_rel, MVComponent comp) {
        return c;
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent comp) {
        listPanel.setListValues(comp);
        validate();
        return c;
    }

  public void doBack() {
    if(prev_index == previous.size()) {
      try {
        MVComponent c = (MVComponent) previous.lastElement();
        if(c != inspecting) {
          previous.addElement(inspecting);
        prev_index = previous.size() - 1;
          }
      } catch (Exception e) {
        throw(new MVFatalException("Out of bounds in MVBaseLayer.doBack()"));
      }  
    }
    if(prev_index > 0) {
      prev_index--;
      try {
        inspect((MVComponent) previous.elementAt(prev_index));  
      } catch (Exception e) {
        throw(new MVFatalException("Out of bounds in MVBaseLayer.doBack()"));
      }
    }
  }

  public void doForward() {
    if(prev_index >= 0 && prev_index <= previous.size() - 2) {
      try {
        prev_index++;
        MVComponent c = (MVComponent) previous.elementAt(prev_index);
        inspect(c);
      } catch (Exception e) {
        throw(new MVFatalException("Out of bounds in MVBaseLayer.doForward()"));
      }
    }    
  }

  public void doVersion() {
    // print version record - should call its versionMenu() command...
    
    if(inspecting.getVersionRecord() != null)
      inspecting.getVersionRecord().displayRecords();
  }

  public void doInspect() {
    MVComponent next_comp = listPanel.findSelectedComp(inspecting);
    
    if(next_comp != null) {
      if(prev_index >= 0 && prev_index < previous.size()) {
        // drop things in forward part of previous vector...
        while(previous.size() > prev_index)
          try {
            previous.removeElementAt(prev_index);
          } catch (Exception e) {
            throw(new MVFatalException("Out of bounds in MVBaseLayer.doInspect()"));
          }  
      }
      previous.addElement(inspecting);
      prev_index = previous.size();
      inspect(next_comp);
    }
  }

  public void doFinish() {
    setVisible(false);
  }
}

class MVInspectorInfoPanel extends Panel {
  Label componentNameField = new Label("Component: ");

  public MVInspectorInfoPanel() {
    setLayout(new GridLayout(1,1,3,3));
    add(componentNameField);
  }
  
  public void setComponentName(MVComponent comp) {
    componentNameField.setText("Component: "+comp.kindName()+" "+comp.userName()+" ("+comp.compID+")");
  }
  
  public Dimension getMinimumSize() {
    return new Dimension(400,30);
  }

  public Dimension getPreferredSize() {
    return new Dimension(400,30);
  }

}

class MVInspectorListPanel extends Panel {
  List attributesList = new List();
  List relationshipsList = new List();
  
  public MVInspectorListPanel() {
    setLayout(new GridLayout(2,1,3,3));
    add(attributesList);
    add(relationshipsList);
  }
  
  public Vector comps = new Vector();
  
  public void setListValues(MVComponent comp) {
    Enumeration e1 = comp.getAttributes().elements();
    Enumeration e2 = comp.getRelationships().elements();
    MVRelItem r;
    MVComponent c;
    
    attributesList.removeAll();
    relationshipsList.removeAll();
    comps.removeAllElements();
    
    // get attribute names
    while(e1.hasMoreElements()) {  
      attributesList.addItem((e1.nextElement()).toString());
    }
    
    // *** Need to check if instanceof MVRelationship and if so get parents() & children()
    // values & display...
    
    if(comp instanceof MVRelationship) {
      relationshipsList.addItem("+parents:");
      comps.addElement(null);
      Enumeration e3 = ((MVRelationship) comp).parents();
      while(e3.hasMoreElements()) {
        c = (MVComponent) e3.nextElement();
        relationshipsList.addItem("  "+c.userName()+" ("+c.compID+")");
        comps.addElement(c);
      }
      relationshipsList.addItem("+children:");
      comps.addElement(null);
      Enumeration e4 = ((MVRelationship) comp).children();
      while(e4.hasMoreElements()) {
        c = (MVComponent) e4.nextElement();
        relationshipsList.addItem("  "+c.userName()+" ("+c.compID+")");
        comps.addElement(c);
      }
    }
    
    // get for each rel item the rel name/kind then each component connected's userName()
    while(e2.hasMoreElements()) {
      r = (MVRelItem) e2.nextElement();
      relationshipsList.addItem(r.name+" ("+r.itemKind()+") "+r.getFlags()+":");
      comps.addElement(null);
      for(Enumeration e3 = r.elements(); e3.hasMoreElements(); ) {
        c = (MVComponent) e3.nextElement();
        relationshipsList.addItem("  "+c.userName()+" ("+c.compID+")");
        comps.addElement(c);
      }
    }

  }

  public Dimension getMinimumSize() {
    return new Dimension(400,220);
  }

  public Dimension getPreferredSize() {
    return new Dimension(400,220);
  }

  public MVComponent findSelectedComp(MVComponent comp) {    
    int index = relationshipsList.getSelectedIndex();
    
    try {
      return (MVComponent) comps.elementAt(index);
    } catch (Exception e) {
      return null;
    }
  }
  
}

class MVInspectorButtonPanel extends Panel implements ActionListener {
  Button backButton = new Button("<-");
  Button forwardButton = new Button("->");
  Button versionButton = new Button("Version Record");
  Button inspectButton = new Button("Inspect");
  Button finishButton = new Button("Finish");
  
  MVInspectorFrame frame;
  
  public MVInspectorButtonPanel(MVInspectorFrame frame) {
    setLayout(new GridLayout(1,3,3,3));
    add(backButton);
        backButton.addActionListener(this);
    add(forwardButton);
        forwardButton.addActionListener(this);
    add(versionButton);
        versionButton.addActionListener(this);
    add(inspectButton);
        inspectButton.addActionListener(this);
    add(finishButton);
        finishButton.addActionListener(this);
    this.frame = frame;
  }
  
  public Dimension getMinimumSize() {
    return new Dimension(400,20);
  }

  public Dimension getPreferredSize() {
    return new Dimension(400,20);
  }

  public void actionPerformed(ActionEvent e) {
  
    if(e.getSource() == backButton)
      frame.doBack();
    else if(e.getSource() == forwardButton)
      frame.doForward();
    else if(e.getSource() == versionButton)
      frame.doVersion();
    else if(e.getSource() == inspectButton)
      frame.doInspect();
    else if(e.getSource() == finishButton)
      frame.doFinish();
  }

}



/*
 * Base components relationship
 *
 */
 

class MVBaseCompsRel extends MVHashtableRel {

  public String userName() {
    return "viewComponents";
  }
  
  public MVBaseCompsRel() {
    super();
  }

  public MVBaseCompsRel(String name, MVComponent parent) {
    super(name,parent);
        setAggregate(true);
  }

  public String extractKey(MVComponent comp) {
    return Integer.toString(comp.compID);
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {
    // receive listen after change description
    
    // need to detect when component's userName() changes so can update
    // its index value => will need beforeChange detection too...

        // 
    
    return super.afterChange(c,from,rel_name);
  }
  
}

class MVViewChooserFrame extends Frame implements MVChangeListener {
  MVViewChooserInfoList listPanel = new MVViewChooserInfoList();
  MVViewChooserInfoButtons buttonPanel = new MVViewChooserInfoButtons(this);
  
  public MVBaseLayer base_layer;
  
  public MVViewChooserFrame(MVBaseLayer base_layer) {
    super("Base Layer: "+base_layer.getName());
    this.base_layer = base_layer;
        base_layer.getViewsRel().addListenAfter(this);
    setLayout(new BorderLayout());
    add("Center",listPanel);
    add("South",buttonPanel);
    redisplayViewLayers();
    setSize(250,180);
    pack();
    setVisible(true);
  }
  
  public void processEvent(AWTEvent e) {
System.out.println("View chooser got AWTEvent: "+e);
        if(e instanceof WindowEvent) {
            if(e.getID() == WindowEvent.WINDOW_CLOSED)
        setVisible(false);
        }
    super.processEvent(e);
  }

    public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent comp) {
        return c;
    }

    public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent sent_from,
            String sent_rel, MVComponent comp) {
        return c;
    }

    public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent sent_from, 
            String sent_rel, MVComponent comp) {
        return c;
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent comp) {
        if(c.targets(base_layer.getViewsRel()))
            if(c instanceof MVEstablishRel || c instanceof MVDissolveChild)
                redisplayViewLayers();
            else if(c instanceof MVChangeKey)
                renameItem(((MVChangeKey) c).getOldName(),((MVChangeKey) c).getNewName());

        return c;
    }
  
  public void redisplayViewLayers() {
    // redisplay info after base layer's views rel changed ...
    
    listPanel.setListValues(base_layer);
    validate();
  }
  
  public void renameItem(String old_name, String new_name)
  {
    listPanel.renameItem(old_name,new_name);
  }

    public void doNew() {
        // need to ask KIND of view to create???
System.out.println("create new view layer...");
    }
  
        public void doShow() {
            MVViewLayer view = listPanel.findSelectedView(base_layer.getViewsRel());
            if(view != null)
                view.show();
        }
        
        public void doHide() {
            MVViewLayer view = listPanel.findSelectedView(base_layer.getViewsRel());
            if(view != null)
                view.hide();
        }
        
        public void doDelete() {
    System.out.println("doDelete");  
        
        }
        
    }

    class MVViewChooserInfoList extends Panel {
        List viewList = new List();
        
        public MVViewChooserInfoList() {
            setLayout(new GridLayout(1,1));
            add(viewList);
        }
        
        public Vector comps = new Vector();
        
        public void setListValues(MVBaseLayer base_layer) {
            Enumeration e = base_layer.getViewsRel().children();
            MVViewLayer v;
                    
            viewList.removeAll();
            
            while(e.hasMoreElements()) {
                v = (MVViewLayer) e.nextElement();
                viewList.addItem(v.getName());
            }
        }
        
        public void renameItem(String old_name, String new_name)
        {
            for(int i=0;i<viewList.getItemCount();i++)
                if(viewList.getItem(i).equals(old_name)) {
                    viewList.replaceItem(new_name,i);
                    return;
                }
        }

        public Dimension getMinimumSize() {
            return new Dimension(250,150);
        }

        public Dimension getPreferredSize() {
            return new Dimension(250,150);
        }

        public MVViewLayer findSelectedView(MVBaseViewsRel view_layers) {    
            return (MVViewLayer) view_layers.get(viewList.getSelectedItem());
        }
        
    }

    class MVViewChooserInfoButtons extends Panel implements ActionListener {
        Button newButton = new Button("New View");
        Button showButton = new Button("Show");
        Button hideButton = new Button("Hide");
        Button deleteButton = new Button("Delete");
        
        MVViewChooserFrame frame;
        
        public MVViewChooserInfoButtons(MVViewChooserFrame frame) {
            setLayout(new GridLayout(1,4,3,3));
            add(newButton);
            newButton.addActionListener(this);
            add(showButton);
            showButton.addActionListener(this);
            add(hideButton);
            hideButton.addActionListener(this);
            add(deleteButton);
            deleteButton.addActionListener(this);
            this.frame = frame;
        }
        
        public Dimension getMinimumSize() {
    return new Dimension(250,20);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,20);
  }

  public void actionPerformed(ActionEvent e) {
        if(e.getSource() == newButton)
            frame.doNew();
    if(e.getSource() == showButton)
      frame.doShow();
    else if(e.getSource() == hideButton)
      frame.doHide();
    else if(e.getSource() == deleteButton)
      frame.doDelete();
  }

}
