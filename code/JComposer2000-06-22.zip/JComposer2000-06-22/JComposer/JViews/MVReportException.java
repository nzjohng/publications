package JViews;

public class MVReportException extends MVException {

  public MVReportException(String message) {
    super(message);
  }

}
