package JViews;

import java.awt.*;

public interface MVExtensiblePanel
{

    public Component findComponent(String name);
    
    public void addComponent(Component comp);
    
    public void removeComponent(Component comp);
    
    // could have enable/disable, or do on comp directly???

}
