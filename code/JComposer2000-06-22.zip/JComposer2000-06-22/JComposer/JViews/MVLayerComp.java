package JViews;

public class MVLayerComp extends MVComponent {

  public MVLayerComp(MVLayer layer) {
  }

  public MVLayerComp() {
  }

  public void init(MVLayer layer) {
    layer.compCreated(this);
  }

}
