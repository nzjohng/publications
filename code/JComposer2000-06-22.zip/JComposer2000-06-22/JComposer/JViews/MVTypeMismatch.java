package JViews;

public class MVTypeMismatch extends MVFatalException {

  public MVTypeMismatch(MVComponent target, String name, String type) {
    super("MVTypeMismatch: "+target.compID+":"+name+" - expected type to be "+type);
  }

}
