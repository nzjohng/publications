package JViews;

public class MVConfigurationInfo extends MVAspectInfo
{

    String name;
        // name of configuration settings info
        
    int kind;
        // kind of configuration info: required attrs/rels, optional attrs/rels, user interface etc.
        
    String aspects[];
        // aspects e.g. attributes/rels names
  
    public static final int MVRequiredSettings = 1;
    public static final int MVOptionalSettings = 2;
    public static final int MVRecommendedSettings = 3;

    public MVConfigurationInfo()
    {
    
    }
    
    public String getBasicInfo()
    {
        return "<"+getKindName()+"> "+name;
    }
    
    public String toString()
    {
        return getBasicInfo()+" ("+getInfo()+")";
    }
    
    public MVConfigurationInfo(String name, int kind, String aspects[], String info)
    {
        super(info);
        this.name = name;
        this.kind = kind;
        this.aspects = aspects;
    }

    public String getName()
    {
        return name;
    }
    
    public String getKindName()
    {
        switch(kind) {
        case MVRequiredSettings : return "required settings";
        case MVRecommendedSettings : return "recommended settings";
        default : return "(unknown)";
        }
    }

    public String validate(MVAspects as)
    {
        if(kind == MVRequiredSettings) {
            for(int i=0; i < aspects.length; i++) {
                MVPropertyAspect pas = as.getPropertyAspect();
                MVPropertyInfo pi = pas.findPropertyInfo(aspects[i]);
                if(pi != null && !pi.isSet())
                    return "Error: property "+aspects[i]+" not set: "+info;
                MVRelationshipAspect ras = as.getRelationshipAspect();
                MVRelationshipInfo ri = ras.findRelationshipInfo(aspects[i]);
                if(ri != null && !ri.isEstablished())
                    return "Error: relationship "+aspects[i]+" not established: "+info;
            }
        }
        else if(kind == MVRecommendedSettings) {
            for(int i=0; i < aspects.length; i++) {
                MVPropertyAspect pas = as.getPropertyAspect();
                MVPropertyInfo pi = pas.findPropertyInfo(aspects[i]);
                if(pi != null && !pi.isSet())
                    return "Warning: property "+aspects[i]+" not set: "+info;
                MVRelationshipAspect ras = as.getRelationshipAspect();
                MVRelationshipInfo ri = ras.findRelationshipInfo(aspects[i]);
                if(ri != null && !ri.isEstablished())
                    return "Warning: relationship "+aspects[i]+" not established: "+info;
            }
        }

        return null;
    }
    
}
