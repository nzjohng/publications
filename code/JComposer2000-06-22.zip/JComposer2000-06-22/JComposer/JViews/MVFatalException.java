package JViews;

public class MVFatalException extends MVReportException {

  public MVFatalException(String message) {
    super(message);  
  }

}
