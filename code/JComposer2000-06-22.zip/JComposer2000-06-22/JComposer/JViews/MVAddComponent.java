package JViews;

import java.io.*;
import java.util.*;

public class MVAddComponent extends MVChangeDescr {

  public String comp_kind;
    // kind of component created
    
  public MVComponent comp;
    // the component created

  public MVAddComponent(MVLayer layer, String comp_kind, MVComponent comp) {
    target = layer;
    this.comp_kind = comp_kind;
    this.comp  = comp;
  }

    public MVAddComponent() {
        super();
    }

    public void setComponent(MVComponent comp) {
        this.comp = comp;
    }

    public MVComponent getComponent() {
        return comp;
    }

  public void execute() {
    done = true;
      // component has already been created by call to its constructor method
  }
  
  public void undo() {
    comp.delete();
  }
  
  public void redo() {
    comp.undelete();
    target.recordUpdate(this);
  }
  
  public String toString() {
    return ("AddComponent "+comp_kind);
  }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(comp_kind);
        output.writeln(comp);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        comp_kind = input.getToken();
        int compID = input.getIntToken();
        comp = locator.findOrCreateComp(compID,0,"");
    }
    
    public boolean isValid()
    {
        return super.isValid() && (comp != null);
    }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        if(!rel.contains(target))
            rel.addElement(target);
        if(!aggs.contains(comp))
            aggs.addElement(comp);
    }

}
