package JViews;

public interface MVCompLocator {
    public MVComponent findOrCreateComp(int compID, int copiedFrom, String compKind);
        // creates new component or returns already created/found one
    public MVComponent findOldComp(int compID, int copiedFrom, String compKind, String userName);

    public MVComponent createNewComp(int compID, int copiedFrom, String compKind);

    public void reestablishRel(MVComponent otherComp, MVRelItem locatorRel,
        MVComponent locatorComp);

    public MVChangeDescr createNewChange(String changeKind);

}
