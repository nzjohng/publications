package JViews;

public class MVRelationshipInfo extends MVAspectInfo
{

    String name;
    String arity = "0:n"; /* 1:1, 1:n, etc. */
    int kind = 0; /* MVRelLinksChildren etc. */
    String flags = ""; /* e.g. la, hb */
    boolean aggregate = false;
    String links = "MVComponent"; /* compKind linked by this rel */
    boolean dynamic = false;

    public MVRelationshipInfo()
    {
    
    }
    
    public MVRelationshipInfo(String name, String arity, int kind)
    {
        this.name = name;
        this.arity = arity;
        this.kind = kind;
    }
    
    public MVRelationshipInfo(String name, String arity, int kind, boolean dynamic)
    {                                                                              
        this.name = name;
        this.arity = arity;
        this.kind = kind;
        this.dynamic = dynamic;
    }
    
    public MVRelationshipInfo(String name, String arity, int kind, String flags, boolean aggregate, String links, boolean dynamic)
    {                                                                              
        this.name = name;
        this.arity = arity;
        this.kind = kind;
        this.flags = flags;
        this.aggregate = aggregate;
        this.links = links;
        this.dynamic = dynamic;
    }
    
    public MVRelationshipInfo(String name, String arity, int kind, boolean dynamic, String info)
    {
        super(info);
        this.name = name;
        this.arity = arity;
        this.kind = kind;
        this.dynamic = dynamic;
    }
    
    public String getBasicInfo()
    {
        String info = flags+" "+getKindName(kind)+" "+name+" ("+arity+") -> "+links;
        if(aggregate)
            info = "aggregate "+info;
        if(dynamic)
            info = "(dynamic) "+info;
            
        return info;
    }
    
    public String toString()
    {
        return getBasicInfo()+" ("+getInfo()+")";
    }

    public static final int MVAnyInputRel = MVComponent.MVMaxRelKind+1;
    public static final int MVAnyOutputRel = MVComponent.MVMaxRelKind+2;
    public static final int MVAnyRel = MVComponent.MVMaxRelKind+3;   
    
    public String getKindName(int kind)
    {
        switch(kind) {
        case MVComponent.MVOneToMany : return "one-to-many";
        case MVComponent.MVReverseOneToMany : return "reverse one-to-many";
        case MVComponent.MVRelLinksParents : return "links parents";
        case MVComponent.MVRelLinksChildren : return "links children";
        case MVAnyInputRel : return "any input rel";
        case MVAnyOutputRel : return "any output rel";
        case MVAnyRel : return "any in/out rel";
        default : return "(unknown)";
        }
    }                  
    
    public String getName()
    {
        return name;
    }      
    
    public void setLinks(String links)
    {
        this.links = links;
    }           
    
    public void setDynamic(boolean dynamic)
    {
        this.dynamic = false;
    }

    public boolean isEstablished()
    {
        // is this relationship established for this component???
        
        return false;
    }
    
}
