package JViews;

import java.io.*;
import java.net.*;

public class MVServerProcess implements Runnable {

   protected Thread t = null;

   protected InputStream in = null;  // Socket input stream
   protected OutputStream out = null;    // Socket output stream
   protected Socket con = null;
   
   protected MVServerMultListen serv;
   
   protected String name;

    public MVServerProcess(MVServerMultListen s, Socket con)
    {
        this.con = con;
        serv = s;
    }
    
  // Start thread running (allocing if needed)
  public synchronized void start( ) {

    if( t == null ) {
      t = new Thread( this );
      t.setPriority( Thread.MAX_PRIORITY / 4 );
      t.start();
    }
  }

  // Stop thread from running if it exists
  public synchronized void stop( ) {

    if( t != null ) {

System.out.println("MVServerProcess thread for "+name+" stopped!");
      t.stop( );
      t = null;
serv.resume(); // if server stopped???
    }
  }
         
  // Allow join with our thread
  public final void join( ) 
    throws java.lang.InterruptedException 
  {
    try {
      if( t != null ) {
    t.join();
      } 
    } catch ( InterruptedException e ) {
      throw e;
    }

    return;
  }

    // Process requests from client
  public void run()
  {
          // Get the I/O streams from socket
      try {
                out = con.getOutputStream();
                in = con.getInputStream();
      } catch ( Exception e ) {
                System.out.println( "error building streams: " + e );
                throw(new MVFatalException(e.toString()));
      }
        
      communicate();
      
      try {
         con.close();
         stop();
      } catch(IOException e) {
         System.out.println("closing: "+e);
      } 
      
  }
  
  public String getName()
  {
    return name;
  }
  
  public void setName(String value)
  {
    name = value;
  }

    // override this in subclasses
    //
    public void communicate() {

    // Read what comes in on the socket and 
    // give to MVServerMultListen to process
    //
    //try {
            String str;
            boolean done = false;
            
            setName(getStringRequest());

            while(!done) {
                str = getStringRequest();
                if(str == null || str.equals("DONE"))
                    done = true;
                else
                    serv.processRequest(this,str);
               
            }

    }

    public String getStringRequest() {
        byte bytes[] = getBytesRequest();
        if(bytes != null) {
            if(bytes.length == 0)
                return "";
            else
                return new String(bytes,0,bytes.length);
        } else
            return null;
    }

    public byte[] getBytesRequest() {
        try {
            int b1 = in.read();
            int b2 = in.read();
            int size = b1 * 256 + b2;
            byte bytes[] = new byte[size];
            
                int i = 0;
                while(i < size) {
                    int num_read = in.read(bytes,i,size-i);
                    i += num_read;
                }
            
            return bytes;
        } catch (IOException e) {
            System.out.println("Error while reading from client: "+e);
            stop();
            return null;
        }
    }

    public boolean sendReply(String data) {
        try {
            out.write(data.length() / 256);
            out.write(data.length() % 256);
            byte bytes[] = data.getBytes();
            out.write(bytes,0,bytes.length);
            out.flush();
            return true;
        } catch(IOException e) {
            System.out.println("Error while writing to client: "+e);
            stop();
            return false;
        }
    }

}

