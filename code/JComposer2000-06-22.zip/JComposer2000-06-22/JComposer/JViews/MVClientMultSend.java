
package JViews;

import java.util.*;


// MVClientMultSend used to send changes to multiple
// other users' environments i.e. via point-to-point
// comms with their environment server
//
// Could use "usual" client-server model instead, where server
// dispatches to appropriate clients...
//
public class MVClientMultSend implements Runnable
{

    public MVClientMultSend()
    {
         start();
    }

  Thread t = null;      // Client send thread

  public void destroy( ) {
    System.out.println( "MVMultClient::destroy called" );
  }

  // Start thread running (allocing if needed)
  public synchronized void start( ) {
    System.out.println( "start: t = " + t );

    if( t == null ) {
      t = new Thread( this );
      t.setPriority( Thread.MAX_PRIORITY / 4 );
      t.start();
    }
  }

  // Stop thread from running if it exists
  public synchronized void stop( ) {
    System.out.println( "stop: t = " + t );

    if( t != null ) {
      t.stop( );
      t = null;
    }
  }

  // Allow join with our thread
  public final void join( ) 
    throws java.lang.InterruptedException 
  {
    try {
      if( t != null ) {
    t.join();
      } 
    } catch ( InterruptedException e ) {
      throw e;
    }

    return;
  }
  
  public void run( ) {
    while(true) {
        MVClientMultRequest req;

        while((req = getRequest()) != null)
        {
            
            Enumeration e = req.clients.elements();        
            while(e.hasMoreElements())
            {
                MVClient s = (MVClient) e.nextElement();
                if(!s.isValidConnection() || !s.sendRequest(req.data)) {
                    // server died
                    req.comp.removeServer(s);
                }
            }
        }
        
        t.suspend();
    }
  }

    protected Vector servers = new Vector();
    
    public synchronized MVClient addServer(String name, String host,int port)
    {
        MVClient s = findServer(name);
         if(s != null) {
 System.out.println("Found server for "+s.getUserName());
           if(!host.equals(s.getHost()) || port != s.getPort())
                s.close();
            else {
                if(s.isValidConnection())  {
  System.out.println("send checkConnection to "+s.getHost()+"("+s.getPort()+")");

                    s.sendRequest("checkConnection");
                    //if(s.getStringReply() == null)
                    //   s.close();
                }
  else
    System.out.println("not valid connection");
            }
        } else {
            s = new MVClient();
            servers.addElement(s);
        }
        
        if(s.isValidConnection())
            return s;

System.out.println("trying to connect to "+host+" "+port);    
        if(s.connect(MVApplication.application.getUserName(),name,host,port)) {
   System.out.println("got connection!");         
            return s; 
        } else
            return null;
    }
      
    public MVClient findServer(String name)
    {
        Enumeration e = servers.elements();
        
        while(e.hasMoreElements()) 
        {
            MVClient c = (MVClient) e.nextElement();
            if(c.getUserName().equals(name))
                return c;
        }
        
        return null;
    }
    
    public synchronized void removeServer(String name)
    {
        MVClient c = findServer(name);
        if(c != null) {
            servers.removeElement(c);
            c.sendRequest("DONE");
            c.close();
        }
    }
    
    protected Vector requests = new Vector();
    
    synchronized public void sendRequest(MVSenderComp comp, Vector clients, String data)
    {
        sendRequest(comp,clients,data.getBytes());
    }
    
    protected Vector brequests = new Vector();
    
    synchronized public void sendRequest(MVSenderComp comp, Vector clients, byte bytes[])
    {
        requests.addElement(new MVClientMultRequest(comp,clients,bytes));
        t.resume();
    }
    
    synchronized public MVClientMultRequest getRequest()
    {
        if(requests.size() > 0) {
            MVClientMultRequest req = (MVClientMultRequest) requests.firstElement();
            requests.removeElementAt(0);
        
            return req;
        } else
            return null;
    }
    
    public void close()
    {
        Enumeration e = servers.elements();
        
        while(e.hasMoreElements()) {
            MVClient c = (MVClient) e.nextElement();
            System.out.println("closing...");
            c.close();
            System.out.println("closed!");
        }
    }
    
}

class MVClientMultRequest
{

    MVSenderComp comp;
    Vector clients;
    byte data[];

    MVClientMultRequest(MVSenderComp m, Vector c, byte d[])
    {
        comp = m;
        clients = c;
        data = d;
    }
}
