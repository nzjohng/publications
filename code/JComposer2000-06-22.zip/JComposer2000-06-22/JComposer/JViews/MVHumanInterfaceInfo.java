package JViews;

import java.util.*;

public class MVHumanInterfaceInfo extends MVAspectInfo
{

    String name;
        // component-unique name of UI aspect
        
    boolean provides;
        // describes UI aspect provided for others to use?
        
    boolean requires;
        // describes UI aspect required by this component
        
    int kind;
        // kind of UI aspect (window, dialogue, property sheet, button, pull-down menu, pop-up menu, menu item, etc.

    public static final int MVWindowHIAspect = 1;
    public static final int MVDialogueHIAspect = 2;
    public static final int MVPropertySheetHIAspect = 3;
    public static final int MVButtonHIAspect = 4;
    public static final int MVPullDownMenuHIAspect = 5;
    public static final int MVPopupMenuHIAspect = 6;
    public static final int MVMenuItemHIAspect = 7;
    public static final int MVPanelHIAspect = 8;
 
    // could also specify size, "extensible", etc. etc.
         

    public MVHumanInterfaceInfo(String name, boolean provides, boolean requires, int kind)
    {
        this.name = name;
        this.provides = provides;
        this.requires = requires;
        this.kind = kind;
    }
    
    public MVHumanInterfaceInfo(String name, boolean provides, boolean requires, int kind, String info)
    {
        super(info);
        this.name = name;
        this.provides = provides;
        this.requires = requires;
        this.kind = kind;
    }
    
    public String toString()
    {
        return getBasicInfo()+" ("+getInfo()+")";
    }
    
    public String getName()
    {
        return name;
    } 
    
    public boolean isRequires()
    {
        return requires;
    }                
    
    public boolean isProvides()
    {
        return provides;
    }
    
    public int getKind()
    {
        return kind;
    }
    
    public String getKindName()
    {
        switch(kind)
        {
        case MVWindowHIAspect : return "window";
        case MVDialogueHIAspect : return "dialogue";
        case MVPropertySheetHIAspect : return "property sheet";
        case MVButtonHIAspect : return "button";
        case MVPullDownMenuHIAspect : return "pull-down menu";
        case MVPopupMenuHIAspect : return "pop-up menu";
        case MVMenuItemHIAspect : return "menu item";
        case MVPanelHIAspect : return "panel";
        default : return "(unknown)";
        }
    }

    public String getBasicInfo()
    {
     String provides_str = " ";
        String requires_str = " ";
        if(provides)
            provides_str="provides";
        if(requires)    
            requires_str = "requires";
        return "<"+getKindName()+"> "+name+" "+provides_str+" "+requires_str;
    }
    
    // methods to manipulate/use this HI aspect...
    
    
}
