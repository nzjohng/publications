package JViews;

import java.io.*;
import java.net.*;

public class MVServerListen implements Runnable {
  Thread t = null;      // Server thread

  public MVServerListen( ) {
    }

  public void destroy( ) {
    System.out.println( "MVServerListen::destroy called" );
  }

  // Start thread running (allocing if needed)
  public synchronized void start( ) {
    System.out.println( "start: t = " + t );

    if( t == null ) {
      t = new Thread( this );
      t.setPriority( Thread.MAX_PRIORITY / 4 );
      t.start();
    }
  }

  // Stop thread from running if it exists
  public synchronized void stop( ) {
    System.out.println( "stop: t = " + t );

    if( t != null ) {
      t.stop( );
      t = null;
    }
  }

  // Allow join with our thread
  public final void join( ) 
    throws java.lang.InterruptedException 
  {
    try {
      if( t != null ) {
    t.join();
      } 
    } catch ( InterruptedException e ) {
      throw e;
    }

    return;
  }

    //
  // Run method to be started by Thread
    //

  protected ServerSocket s = null;  // Socket we're listening to.
  protected InputStream in = null;  // Socket input stream
  protected OutputStream out = null;    // Socket output stream
  protected Socket con = null;      // Current connection

    // need to override for specific ports...
    //
    public int getPort() {
        return 5000;
    }

    protected int localPort = 0;

  public void run( ) {

    // Open a new server socket on port or die
    try {
      s = new ServerSocket(getPort());
            localPort = s.getLocalPort();
    } catch ( Exception e ) {
      System.out.println( "Exception:\n" + e );
            throw(new MVFatalException(e.toString()));
    }   

    // Print out our socket
    System.out.println( "ServerSocket: " + s );

    // While the thread is running . . .
    while( t != null ) {
      // Accept an incomming connection
      try {
                con = s.accept( );
      } catch ( Exception e ) {
                System.out.println( "accept: " + e );
                throw(new MVFatalException(e.toString()));
      }

      // Get the I/O streams from socket
      try {
                out = con.getOutputStream();
                in = con.getInputStream();
      } catch ( Exception e ) {
                System.out.println( "building streams: " + e );
                throw(new MVFatalException(e.toString()));
      }
        
            communicate();

            try {
                con.close();
            } catch(IOException e) {
                System.out.println("closing: "+e);
            }

        }
    }

    // override this in subclasses
    //
    public void communicate() {

        sendReply("Hi there - type bye to leave");

    // Read what comes in on the socket and spit it back
    try {
            String str;
            boolean done = false;

            while(!done && (str = getStringRequest()) != null) {
                // Spit back what we recieved
                sendReply("Received: |"+str+"|");

                // Done if user says bye
                if( str.trim().compareTo( "bye" ) == 0 ) {
                    done = true;
                }

                // Die if they enter "DIE!"
                if( str.trim().compareTo( "DIE!" ) == 0 ) {
                    t.stop();
                    t = null;
                }
            }

            sendReply("bye");
        } catch( Exception e ) {
            System.out.println( "reading: " + e );
            throw(new MVFatalException(e.toString()));
        }

    }

    public String getStringRequest() {
        try {
            int b1 = in.read();
            int b2 = in.read();
            int size = b1 * 256 + b2;
            byte bytes[] = new byte[size];
            in.read(bytes,0,size);
            return new String(bytes);
        } catch (IOException e) {
            System.out.println("Error while reading from client: "+e);
            return null;
        }
    }

    public byte[] getBytesRequest() {
        try {
            int b1 = in.read();
            int b2 = in.read();
            int size = b1 * 256 + b2;
            byte bytes[] = new byte[size];
            in.read(bytes,0,size);
            return bytes;
        } catch (IOException e) {
            System.out.println("Error while readinf from client: "+e);
            return null;
        }
    }

    public boolean sendReply(String data) {
        try {
            out.write(data.length() / 256);
            out.write(data.length() % 256);
            byte bytes[] = data.getBytes();
            out.write(bytes,0,bytes.length);
System.out.println("server written bytes:");
System.out.write(bytes,0,bytes.length);
System.out.println("");
            out.flush();
            return true;
        } catch(IOException e) {
            System.out.println("Error while writing to client: "+e);
            return false;
        }
    }

}

