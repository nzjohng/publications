package JViews;

import java.util.*;

public class MVPropertyAspect extends MVAspect
{

    public MVPropertyAspect()
    {
    
    }
    
    public String getAspectKind()
    {
        return "Properties";
    }
    
    Vector properties = new Vector();
    
    public void addPropertyInfo(MVPropertyInfo info)
    {
        MVPropertyInfo i = findPropertyInfo(info.getName());
        if(i != null)
            properties.removeElement(i);
        properties.addElement(info);
    }
    
    public MVPropertyInfo findPropertyInfo(String name)
    {
        Enumeration e = properties.elements();
        while(e.hasMoreElements()) {
            MVPropertyInfo info = (MVPropertyInfo) e.nextElement();
            if(info.getName().equals(name))
                return info;
        }
        
        return null;
    }
    
    public String toString()
    {
        String value = " Properties:\n";
        
        Enumeration e = properties.elements();
        while(e.hasMoreElements()) {
            MVPropertyInfo info = (MVPropertyInfo) e.nextElement();
            value = value+"  "+info.toString()+"\n";
        }
        
        return value;
     }
     
          
         
    public Vector getAspectInfos()
    {
        return properties;
    }
}
