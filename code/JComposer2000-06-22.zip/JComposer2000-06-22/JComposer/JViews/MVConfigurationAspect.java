package JViews;

import java.util.*;

public class MVConfigurationAspect extends MVAspect
{

    public MVConfigurationAspect()
    {
    
    }
    
    Vector cis = new Vector();
    
    public void addConfigurationInfo(MVConfigurationInfo info)
    {
        MVConfigurationInfo i = findConfigurationInfo(info.getName());
        if(i != null)
            cis.removeElement(i);
        cis.addElement(info);
    }
    
    public MVConfigurationInfo findConfigurationInfo(String name)
    {
        Enumeration e = cis.elements();
        while(e.hasMoreElements()) {
            MVConfigurationInfo info = (MVConfigurationInfo) e.nextElement();
            if(info.getName().equals(name))
                return info;
        }
        
        return null;
    }
    
    public String toString()
    {
        String value = " Configuration constraints:\n";
        
        Enumeration e = cis.elements();
        while(e.hasMoreElements()) {
            MVConfigurationInfo info = (MVConfigurationInfo) e.nextElement();
            value = value+"  "+info.toString()+"\n";
        }
        
        return value;
     }
     
     public String getAspectKind()
     {
        return "Configuration settings";
     }
    
         
         
    public Vector getAspectInfos()
    {
        return cis;
    }

    public String validate(MVAspects as)
    {
        Enumeration e = cis.elements();
        while(e.hasMoreElements()) {
            MVConfigurationInfo info = (MVConfigurationInfo) e.nextElement();
            String mesg = info.validate(as);
            if(mesg != null)
                return mesg;
        }

        return null;
    }
    
}
