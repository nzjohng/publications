package JViews;

public class MVDuplicateKey extends MVReportException {

  public MVDuplicateKey(String message) {
    super(message);
System.out.println("*** ERROR "+message);
  }

}
