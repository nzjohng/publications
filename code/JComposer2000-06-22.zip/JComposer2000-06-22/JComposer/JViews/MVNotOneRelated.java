package JViews;

public class MVNotOneRelated extends MVFatalException {

  public MVNotOneRelated(MVComponent target, String rel_name, int rel_flag) {
    super("NotOneRelated: "+target.compID+" "+rel_name);
  }
  
}
