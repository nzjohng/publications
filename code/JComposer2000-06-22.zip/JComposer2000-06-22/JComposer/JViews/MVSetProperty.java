package JViews;

public class MVSetProperty extends MVSetValue {

    Object newValue;

    public Object getNewValue() {
        return newValue;
    }

    public void setNewValue(Object value) {
        newValue = value;
    }

    Object oldValue;

    public Object getOldValue() {
        return oldValue;
    }

    public void setOldValue(Object value) {
        oldValue = value;
    }

    public MVSetProperty(MVComponent target, String propertyName, Object old_value, Object new_value) {
        this.target = target;
        setPropertyName(propertyName);
        this.oldValue = old_value;
        this.newValue = new_value;
    }

    public void execute() {
        // doSetNamedProperty doesn't generate a change description...
        getTarget().doSetNamedProperty(getPropertyName(),getNewValue());

        done = true;
    }

    public void undo() {
        getTarget().setNamedProperty(getPropertyName(),getOldValue());
    }

    public void redo() {
        getTarget().setNamedProperty(getPropertyName(),getNewValue());
    }

    public String toString() {
        return "MVSetProperty "+target.compID+" "+getPropertyName()+" to "+getNewValue();
    }

}


