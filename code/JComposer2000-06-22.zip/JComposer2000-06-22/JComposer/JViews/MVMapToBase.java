package JViews;

import java.io.*;

public class MVMapToBase extends MVMacroChangeDescr {

  public MVBaseComp base_comp;

    public MVMapToBase() {
        super();
    }
  
  public MVMapToBase(MVViewComp target, MVBaseComp base_comp) {
    super(target,"MapToBase");
    this.base_comp = base_comp;
  }
  
  public void execute() {  
    MVViewRel view_rel = base_comp.findViewRel(((MVViewComp)target).viewRelKind());
    
    if(view_rel == null)
      view_rel = ((MVViewComp)target).newViewRel();
      
    view_rel.establish(base_comp,target);
System.out.println("calling upliftAttributes()...");
        view_rel.upliftAttributes(base_comp,(MVViewComp) target);
  }
  
  // undo = target.unmapFromBase() ??
  
  // redo = target.mapToBase(base_comp) ??

    public boolean targets(MVComponent c) {
        if(c == target || c == base_comp)
            return true;

        return false;
    }
    
    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(base_comp);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        int id = input.getIntToken();
        base_comp = (MVBaseComp) locator.findOrCreateComp(id,0,"");
    } 
    
    
    public boolean isValid()
    {
        return super.isValid() && (base_comp != null);
    }


}
