package JViews;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import bbw.*;
import java.beans.*;
import JCVisualise.*;

public class MVViewComp extends MVLayerComp implements PropertyChangeListener, MVProcessBBWChange, ActionListener {

  public MVViewComp(MVViewLayer view_layer) {
    super(view_layer);
  }
  
  public MVViewComp() {
    super();
  }

    public void init(MVViewLayer view_layer) {
        super.init(view_layer);
        view_layer.addLayerComponent(this);
    }
  
  public MVViewLayer view() {
    // returns the view layer comp this belongs to
    
    return (MVViewLayer) getOneRelated("viewComponents",MVParentRelComps);
  }
  
  public boolean hasView() {
    // is this component linked to a view??
    
    Vector v = getRelationship("viewComponents",MVParentRelComps);
    
    return (v.size() != 0);
  }
  
  public boolean canBeDrawn()
    {
        if(!deleted && hasView())
            return true;
        else
            return false;
    }

  
  public MVViewRel viewRel() {
    // returns the view relationship for this view component (if any)
    
        return (MVViewRel) getOneRelatedOrNull("MVViewRel",MVParentRelComps);
  }
  
  public MVBaseComp getBaseComp() {
    // returns the base component this is linked to (if any)
    
    if(viewRel() == null)
      return null;
    else
      return (MVBaseComp) getOneRelatedOrNull("MVViewRel",MVParents);
  }
  
  public MVBaseComp baseComp() { return getBaseComp(); }
    // should deprecate this!!
    
  public String viewRelKind() {
    // relKind() kind MUST be MVViewRel - but compKind can be specialisation
    // of this MVViewRel class...
    return "MVViewRel";
  }
  
  public MVViewRel newViewRel() {
    // creates us a view rel... default is the standard view rel
    
    MVViewRel new_rel = new MVViewRel(viewRelKind());
//    view().compCreated(new_rel); <- don't need to know this...
    
    return new_rel;
  }
  
  public void unmapFromBase() {
    // disconnect from existing view rel
    
  }
  
  public void remapComponent() {
    // remap to new base component
    
    mapComponent(true);
  }
  
  public MVBaseComp mapComponent(boolean do_map) {
    // find a suitable base comp to map to
    // map this view comp to base comp and, if necessary, create a new base
    // comp if the do_map flag is true
    
    return(null);
  }
  
  public void mapToBase(MVBaseComp comp) {
    // map to base component that's been found
        if(viewRel() != null)
            viewRel().dissolve(getBaseComp(),this);

		if(getBBWShape() != null)
            getBBWShape().setForeground(Color.black);  // should set to default/prev colour???
	
    recordUpdate(new MVMapToBase(this,comp));
  }

  public void dissolveFromBase()
  {
	if(viewRel() != null) {
    	viewRel().dissolve(getBaseComp(),this);
		if(getBBWShape() != null)
            getBBWShape().setForeground(Color.red);
   	}
  }
  
  public void mapToCreatedBase(MVBaseComp comp) {
    // map to a base component we've just created
  
	if(getBBWShape() != null)
    	getBBWShape().setForeground(Color.black); // should set to default/prev colour???
    	
    recordUpdate(new MVMapToCreatedBase(this,comp));
  }
  
  public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, 
    String rel_name) {
  
    if(c.targets(this) && hasView() && !rel_name.equals("viewComponents"))
      // send to view if not from view...
      view().beforeChange(c,this,"viewComponents");
      
    return super.beforeChange(c,from,rel_name);
  }
  
  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
    String rel_name) {
    
    if(c.targets(this) && hasView() && !rel_name.equals("viewComponents"))
      // send to view if not from view...
      view().afterChange(c,this,"viewComponents");
      
/*
    if(getBaseComp() == null && hasView())
      // if not currently mapped to base, try to map whenever receive a change...
      mapComponent(true);
*/

    return super.afterChange(c,from,rel_name);
  }
  
  private BBWComponent BBWShape = null;

    public void setBBWShape(BBWComponent BBWShape) {
System.out.println("BBWShape for "+compID+" = "+BBWShape);
        this.BBWShape = BBWShape;
    }

    public BBWComponent getBBWShape() {
        return BBWShape;
    }
  
  public void addedBBWShape(BBWComponent BBWShape) {
    setBBWShape(BBWShape);
System.out.println("**** ADDED PROP CHANGE!!");
    BBWShape.addPropertyChangeListener(this);
        addJViewsPopups(BBWShape);
  }

  public void addedViewComp(BBWComponent BBWShape) {
    setBBWShape(BBWShape);
    BBWShape.addPropertyChangeListener(this);
        addJViewsPopups(BBWShape);
  }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange)
            view().addBBWEvent(this,evt);

/*
System.out.println("MVViewComp got BBW event "+evt);
        MVBBWSetProperty s = new MVBBWSetProperty(this,capitalize(evt.getPropertyName()),evt.getOldValue(),evt.getNewValue());
System.out.println("Generated "+s);
        recordUpdate(s);
*/

    }

    private String capitalize(String s) {
    char chars[] = s.toCharArray();
    chars[0] = Character.toUpperCase(chars[0]);
    return new String(chars);
     }

    public void processBBWEvent(EventObject evt) {
System.out.println("MVViewComp.processBBWEvent got "+evt);
        if(!view().processingBBWEvents && view().processingBBWChange)
            view().addBBWEvent(this,evt);


    }

/*
    public void redisplayComp() {
        Enumeration e = getAttributes().elements();

        while(e.hasMoreElements()) {
            MVAttribute a = (MVAttribute) e.nextElement();
            if(a instanceof MVStringAttribute) {
                setNamedProperty(((MVStringAttribute) a).getPropertyName(),
                        ((MVStringAttribute) a).getValue());
            } else if(a instanceof MVIntAttribute) {

            } else if(a instanceof MVBooleanAttribute) {

            }
        }
    }
*/

    public String java_awt_Color_toString(Color c) {
        return c.getRed()+" "+c.getGreen()+" "+c.getBlue();
    }

    public Color java_awt_Color_fromString(String s) {
        int r, g, b;
        
        if(s.equals("0 0 0") || s.equals(""))
            return Color.black;
        else if(s.equals("255 255 255"))
            return Color.white;
        
        StringTokenizer tokens = new StringTokenizer(s," ", false);

        r = Integer.parseInt(tokens.nextToken());
        g = Integer.parseInt(tokens.nextToken());
        b = Integer.parseInt(tokens.nextToken());

        return new Color(r,g,b);
    }
    
    public Font java_awt_Font_fromString(String s) {
        String name;
        int size, style;
        
        if(s.equals(""))
            return new Font("Helvetica",0,10);
        
        StringTokenizer tokens = new StringTokenizer(s," ",false);
        
        name = tokens.nextToken();
        style = Integer.parseInt(tokens.nextToken());
        size = Integer.parseInt(tokens.nextToken());
        
        return new Font(name,style,size);
    }
    
    public String java_awt_Font_toString(Font f) {
        return f.getName()+" "+f.getStyle()+" "+f.getSize();
    }

    public String BBWPoint_toString(BBWPoint p) {
        return p.x+" "+p.y; 
    }

    public BBWPoint BBWPoint_fromString(String s) {
        int x, y;
        StringTokenizer tokens = new StringTokenizer(s," ", false);

        x = Integer.parseInt(tokens.nextToken());
        y = Integer.parseInt(tokens.nextToken());

        return new BBWPoint(x,y);
    }

    public String BBWVector_toString(BBWVector v) {
        return v.x+" "+v.y;
    }

    public BBWVector BBWVector_fromString(String s) {
        int x, y;
        StringTokenizer tokens = new StringTokenizer(s," ", false);

        x = Integer.parseInt(tokens.nextToken());
        y = Integer.parseInt(tokens.nextToken());

        return new BBWVector(x,y);

    }

	protected MenuItem propSheet = new MenuItem("Comp Properties");
    protected MenuItem hideItem = new MenuItem("Hide in view");
    protected MenuItem deleteItem = new MenuItem("Delete in base");

    protected Menu printMenu = new Menu("Print/inspect...");
    protected MenuItem printItem = new MenuItem("Print View Comp");
    protected MenuItem inspectItem = new MenuItem("Inspect View Comp");
    protected MenuItem printBase = new MenuItem("Print Base Comp");
    protected MenuItem inspectBase = new MenuItem("Inspect Base Comp");

    protected Menu visualiseMenu = new Menu("Visualise...");
    protected MenuItem visPrevItem = new MenuItem("In Prev View");
    protected MenuItem visNewItem = new MenuItem("In New View");
    protected MenuItem visPrevBase = new MenuItem("Base in Prev View");
    protected MenuItem visNewBase = new MenuItem("Base in New View");

    protected MenuItem baseChanges = new MenuItem("View Base Changes");
    protected MenuItem viewsItem = new MenuItem("Base Comp Views");

    protected MenuItem tryMap = new MenuItem("Try Map to Base");
    protected MenuItem unmap = new MenuItem("Unmap from Base");
    
    public void addJViewsPopups(BBWComponent shape) {
        // add pop-up menus to BBW Component...

        shape.addPopupMenuItem(new MenuItem("-"));
        shape.addPopupMenuItem(propSheet);
        propSheet.addActionListener(this);
        shape.addPopupMenuItem(hideItem);
        hideItem.addActionListener(this);
        shape.addPopupMenuItem(deleteItem);
        deleteItem.addActionListener(this);        
        shape.addPopupMenuItem(printMenu);
        printMenu.add(printItem);
        printItem.addActionListener(this);
        printMenu.add(inspectItem);
        inspectItem.addActionListener(this);
        printMenu.add(printBase);
        printBase.addActionListener(this);
        printMenu.add(inspectBase);
        inspectBase.addActionListener(this);
    
        shape.addPopupMenuItem(visualiseMenu);
        visualiseMenu.add(visPrevItem);
        visualiseMenu.add(visNewItem);
        visPrevItem.addActionListener(this);
        visNewItem.addActionListener(this);
        visualiseMenu.add(visPrevBase);
        visualiseMenu.add(visNewBase);
        visPrevBase.addActionListener(this);
        visNewBase.addActionListener(this);

        shape.addPopupMenuItem(baseChanges);
        baseChanges.addActionListener(this);
        shape.addPopupMenuItem(viewsItem);
        viewsItem.addActionListener(this);

		shape.addPopupMenuItem(tryMap);
		tryMap.addActionListener(this);
		shape.addPopupMenuItem(unmap);
		unmap.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
    	if(e.getSource() == propSheet)
    		showPropertySheet();
        if(e.getSource() == hideItem)
            delete();
        if(e.getSource() == deleteItem)
            deleteBaseComp();
        if(e.getSource() == printItem)
            System.out.println(toString());
        if(e.getSource() == inspectItem)
            view().getBaseLayer().inspect(this);
        if(e.getSource() == printBase)
            if(getBaseComp() != null)
                System.out.println(getBaseComp().toString());
        if(e.getSource() == inspectBase)
            if(getBaseComp() != null)
                view().getBaseLayer().inspect(getBaseComp());
        if(e.getSource() == visPrevItem)
            JCVisBaseLayer.visualisePrev(view().getBaseLayer(),this);
        if(e.getSource() == visNewItem)
            JCVisBaseLayer.visualiseNew(view().getBaseLayer(),this);
        if(e.getSource() == visPrevBase)
            if(getBaseComp() != null)
                JCVisBaseLayer.visualisePrev(view().getBaseLayer(),getBaseComp());
        if(e.getSource() == visNewBase)
            if(getBaseComp() != null)
                JCVisBaseLayer.visualiseNew(view().getBaseLayer(),getBaseComp());

        if(e.getSource() == baseChanges)
            if(getBaseComp() != null)
                if(getBaseComp().getVersionRecord() != null)
                    getBaseComp().getVersionRecord().displayRecords();

        if(e.getSource() == viewsItem)
            selectBaseViews();

        if(e.getSource() == tryMap)
        	mapComponent(true);
        if(e.getSource() == unmap)
        	dissolveFromBase();
    }
        
    public void selectBaseViews()
    {
        MVBaseComp bc = getBaseComp();
        if(bc == null)
            return;
            
        bc.selectBaseViews();
    }
    
    public void deleteBaseComp()
    {
        if(getBaseComp() != null)
        {
            MVBaseCompDeleted c = new MVBaseCompDeleted(this);
            recordUpdate(c);
        }
    }
    
    public void baseDeleted(MVBaseComp comp)
    {
        // should remove "viewed-in" rel from this comps view??
        
        if(getBBWShape() != null)
            getBBWShape().setForeground(Color.red);
    }
    
    public void baseUndeleted(MVBaseComp comp)
    {
        if(getBBWShape() != null)
            getBBWShape().setForeground(Color.black);
            // should remember old foreground colour!!
    }    
    
    public void delete()
    {
        super.delete();
        deleteBBWShape();
    }
    
    public void deleteBBWShape()
    {
        if(getBBWShape() != null) {
            getBBWShape().dispose();
            setBBWShape(null);
        }
    }
    
    public void undelete()
    { 
        if(getBBWShape() != null) { 
            getBBWShape().setVisible(true);
            // getBBWShape().paint();
        } else if(hasView()) {
            view().startJViewsChange();
            view().getViewFrame().addedViewComp(this);
            view().endJViewsChange();
        }
        
        super.undelete();       
    }

    public MVViewLayer getView()
    {
    	return view();
    }

    public Vector getParentOfGlue()
    {
		return getRelationship("Parent",MVParents);
    }

    public Vector getChildOfGlue()
    {
		return getRelationship("Child",MVParents);
    }

}


