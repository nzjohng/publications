
package JViews;

public class MVAddedViewMenus extends MVViewEvent
{

    public MVAddedViewMenus(MVViewLayer v)
    {
        super(v);
    }   
    
    public void execute() { }
    
    public void undo() { }
    
    public void redo() { }
    
    public String toString()
    {
        return "Added view menus "+view.getName();
    }

}
