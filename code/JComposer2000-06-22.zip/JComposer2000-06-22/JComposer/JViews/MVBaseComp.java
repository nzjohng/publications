package JViews;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class MVBaseComp extends MVLayerComp {

  public MVBaseComp(MVBaseLayer base_layer) {
    super(base_layer);
        init(base_layer);
  }

  public MVBaseComp() {
    super();
  }
  
    public void init(MVBaseLayer base_layer) {
        super.init(base_layer);
        base_layer.addLayerComponent(this);
    }
  
  public Vector viewedIn() {
    // views this component appears in
    return getRelationship("viewed-in",MVChildren);
  }
  
  public Vector viewRels() {
    // returns all view relationships this base component has
    return getRelationship("MVViewRel",MVChildRelComps);
  }

  public void addViewComp(MVViewComp comp) {
    // this component now linked to this view component
    
    MVViewLayer view = comp.view();
    establishOneToMany("viewed-in",view);
  }
  
  public void removeViewComp(MVViewComp comp) {
    // need to check if linked to other comps in this comp's view...
    
        dissolveOneToMany("viewed-in",comp.view());
  }
  
  public MVViewRel findViewRel(String kind) {
    // locate (or create) a view relationship of the requested kind
    // so a view comp can be connected to this base comp
    // uses compKind() to distinguish differnt kinds of view rels
    // as the relKind() MUST be always be "MVViewRel"

    Vector rels = viewRels();
    Enumeration e = rels.elements();
    MVViewRel rel = null;

    while(e.hasMoreElements()) {
      rel = (MVViewRel) e.nextElement();
      if(rel.getViewRelKind().equals(kind))
        return(rel);
    }
    
    return(null);
  }
  
  // addGraphicView ??
  
  // textual view stuff ??

    public MVBaseLayer getBaseLayer() {
        return (MVBaseLayer) getOneRelated("viewComponents",MVParents);
    }
    
    public void selectBaseViews()
    {
        MVViewCompViewsFrame f = new MVViewCompViewsFrame(this);
    }

}

class MVViewCompViewsFrame extends Frame {
  MVViewCompChooserInfoList listPanel = new MVViewCompChooserInfoList();
  MVViewCompChooserInfoButtons buttonPanel = new MVViewCompChooserInfoButtons(this);
  
  public MVBaseComp base_comp;
  
  public MVViewCompViewsFrame(MVBaseComp base_comp) {
    super("Views for: "+base_comp.userName());
    this.base_comp = base_comp;
    setLayout(new BorderLayout());
    add("Center",listPanel);
    add("South",buttonPanel);
    redisplayViews();
    setSize(250,180);
    pack();
    setVisible(true);
  }
  
  public void processEvent(AWTEvent e) {
System.out.println("View chooser got AWTEvent: "+e);
        if(e instanceof WindowEvent) {
            if(e.getID() == WindowEvent.WINDOW_CLOSED)
        setVisible(false);
        }
    super.processEvent(e);
  }

  public void redisplayViews() {
    // redisplay info after base layer's views rel changed ...
    
    listPanel.setListValues(base_comp);
    validate();
  }

        public void doShow() {
            MVViewLayer view = listPanel.findSelectedView(base_comp.viewedIn());
            if(view != null)
                view.show();
            setVisible(false);
        }
        
        public void doCancel() { 
            setVisible(false);
        }
        
    }

    class MVViewCompChooserInfoList extends Panel {
        List viewList = new List();
        
        public MVViewCompChooserInfoList() {
            setLayout(new GridLayout(1,1));
            add(viewList);
        }
        
        public Vector comps = new Vector();
        
        public void setListValues(MVBaseComp base_comp) {
            Enumeration e = base_comp.viewedIn().elements();
            MVViewLayer v;
                    
            viewList.removeAll();
            
            while(e.hasMoreElements()) {
                v = (MVViewLayer) e.nextElement();
                viewList.addItem(v.getName());
            }
        }

        public Dimension getMinimumSize() {
            return new Dimension(250,150);
        }

        public Dimension getPreferredSize() {
            return new Dimension(250,150);
        }

        public MVViewLayer findSelectedView(Vector views) { 
            try {   
                return (MVViewLayer) views.elementAt(viewList.getSelectedIndex());
            } catch(Exception e) {
                return null;
            }
        }
        
    }

    class MVViewCompChooserInfoButtons extends Panel implements ActionListener {
        Button showButton = new Button("Show");
        Button cancelButton = new Button("Cancel");
        
        MVViewCompViewsFrame frame;
        
        public MVViewCompChooserInfoButtons(MVViewCompViewsFrame frame) {
            setLayout(new GridLayout(1,4,3,3));
            add(showButton);
            showButton.addActionListener(this);
            add(cancelButton);
            cancelButton.addActionListener(this);
            this.frame = frame;
        }
        
        public Dimension getMinimumSize() {
    return new Dimension(250,20);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,20);
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getSource() == showButton)
      frame.doShow();
    else if(e.getSource() == cancelButton)
      frame.doCancel();
  }

}
