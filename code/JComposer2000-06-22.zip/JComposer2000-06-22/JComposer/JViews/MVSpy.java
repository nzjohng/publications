
import java.util.*;

public class MVSpy extends MVComponent {

  public MVSpy(MVComponent to_spy) {
    super();
    this.to_spy = to_spy;
    establishOneToMany("spy_comp",to_spy);
    to_spy.setListenBeforeRel("spy_comp");
    to_spy.setListenAfterRel("spy_comp");
    to_spy.setHandleBeforeRel("spy_comp");
    to_spy.setHandleAfterRel("spy_comp");
  }
  
  public MVComponent to_spy;
  
  public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel_name) {
    System.out.println("\nSPYING "+to_spy.compKind()+" "+to_spy.userName()+" ("+to_spy.compID+"):");
    System.out.println("  about to do: "+c);
    return c;
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {
    System.out.println("\nSPYING "+to_spy.compKind()+" "+to_spy.userName()+" ("+to_spy.compID+"):");
    System.out.println("  done: "+c);
    return c;
  }

  public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent from, String rel_name,
      MVComponent sent_from, String sent_rel) {
    if(sent_from != to_spy) {
      System.out.println("\nSPYING "+to_spy.compKind()+" "+to_spy.userName()+" ("+to_spy.compID+"):");
      System.out.println("  about to receive: "+c);
      System.out.println("  from: "+sent_from.compKind()+" "+sent_from.userName()+" ("+sent_from.compID+"):");
      System.out.println("  via: "+sent_rel);
    }
    return c;
  }

  public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent from, String rel_name,
      MVComponent sent_from, String sent_rel) {
    if(sent_from != to_spy) {
      System.out.println("\nSPYING "+to_spy.compKind()+" "+to_spy.userName()+" ("+to_spy.compID+"):");
      System.out.println("  received: "+c);
      System.out.println("  from: "+sent_from.compKind()+" "+sent_from.userName()+" ("+sent_from.compID+"):");
      System.out.println("  via: "+sent_rel);
    }
    return c;
  }

}
