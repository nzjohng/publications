package JViews;

import java.io.*;

public class test {

    public static void main(String argv[])
    {
        try {
             MVInputBuffer2 input = new MVInputBuffer2(new FileInputStream(new File("test")));
        
            String a = input.getToken();
 System.out.println(a);
            String b = input.getStringToken();
            System.out.println(b);
            input.readToken("test");
            input.readToken('c');
            int c = input.getIntToken();
            System.out.println(c);
            boolean d = input.getBooleanToken();
            
            System.out.println(d);
            
        } catch(IOException e) {
                System.out.println(e);
                System.exit(1);
        }                                        
    }

}
