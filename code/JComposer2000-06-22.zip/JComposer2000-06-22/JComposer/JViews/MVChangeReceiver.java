package JViews;

import java.util.*;
import java.io.*;

public class MVChangeReceiver extends MVServerListen {

    protected MVVersionRecord changes = new MVVersionRecord();
    protected MVInputBuffer buffer;
    protected MVCompLocator locator;

    public MVChangeReceiver(MVCompLocator locator) {
        super();
        this.locator = locator;
        changes.setTitle("Changes from collaborator");
        changes.displayRecords();
  }

    public int getPort() {
        return 4545;
    }

    public void communicate() {
        boolean done = false;

        while(!done) {
            byte bytes[] = getBytesRequest();
            sendReply("done");
    System.out.println("MVChangeReceiver read: ");
    System.out.write(bytes,0,bytes.length);
            buffer = new MVInputBuffer(bytes);
            try {
                if(!buffer.checkNextToken("done")) {
                    Vector imported = MVApplication.application.current_project.importChanges(buffer,locator);
                    Enumeration e = imported.elements();
                    while(e.hasMoreElements()) {
                        MVChangeDescr cd = (MVChangeDescr) e.nextElement();
    System.out.println("imported change: "+cd);
                        changes.add_change(cd);
                    }
                } else
                    done = true;
            } catch (IOException e) {
                System.out.println("IOException on read from client "+e);
            } catch (MVSyntaxErrorException e) {
                System.out.println("syntax error detected when importing change");
            }
        }

    }

}

