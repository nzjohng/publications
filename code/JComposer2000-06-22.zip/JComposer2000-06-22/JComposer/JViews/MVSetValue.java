package JViews;

import java.io.*;

public abstract class MVSetValue extends MVChangeDescr {
  private String propertyName;

    public void setPropertyName(String name) {
        propertyName = name;
    }

    public String getPropertyName() {
        return propertyName;
    }

  public MVAttribute attribute;

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writelnQuoted(propertyName);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) 
        throws IOException {
        super.deserialize(input,locator);
        propertyName = input.getStringToken();
    }

}
