
/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseAttrG extends MVBaseComp {

	/* Constructors */

	public JCBaseAttrG() {
		super();
	}

	public JCBaseAttrG(JCBaseLayer base_layer) {
		super(base_layer);

		/* initialise attributes */

		setValue("Name",MVStringBlank);
		setValue("Type",MVStringBlank);

	}

	/* Attributes */

	public String getName() {
		return getStringValue("Name");
	}

	public void setName(String value) {
		setValue("Name",value);
	}

	public String getType() {
		return getStringValue("Type");
	}

	public void setType(String value) {
		setValue("Type",value);
	}

	/* Relationships */

	public JCBaseComp getComponent() {
		return (JCBaseComp) getOneRelated("CompAttributes",MVParentComp);
	}

	/* Methods */

	public String kindName() {
		return "Base Attribute";
	}

	public abstract String userName();

	/* Read/write methods */

}

