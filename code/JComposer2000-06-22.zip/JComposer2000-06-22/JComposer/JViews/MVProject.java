package JViews;

/*
 * Organisation of each project open by a JViews
 * environment
 *
 */
 
import java.awt.List;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

public class MVProject extends MVComponent implements MVCompLocator {

    public String getName() {
        return getStringValue("name");
    }

    public void setName(String name) {
        setValue("name",name);
    }
  
  protected boolean updated = true;
    // does this project need to be saved?

    protected boolean loading = false;
        // is this project currently being loaded?

    public void setLoading(boolean flag) {
        loading = flag;
    }

  public MVBaseLayer current_base_layer = null;
     // the currently-selected base layer. Determined by which view layer is
     // the "front" window

   protected MVProjectInfoFrame project_info = null;
     // project info dialogue
     
   protected Hashtable components = new Hashtable();
     // used to store component IDs
     // if incremental persistency used, will actully be only in-core ids
     // persistency manager will store full persistent ID and comp ID tables...
     
   public MVProject(String name) {
     if(!name.equals(""))
        setName(name.intern());
     setIDCounter(MVApplication.application.startID);
     setIncrement(MVApplication.application.increment);
   }
   
   protected MVPersistency persistency = null;
     // persistency manager to be used by this project
     // Note: might in the future want > 1...
 
    int IDcounter = 1;
    int increment = 1;
    
    public void setIDCounter(int c) {
        IDcounter = c;
    }
    
    public void setIncrement(int c)
    {
        increment = c;
    }
    
    public int getIDCounter()
    {
        return IDcounter;
    }
    
    public int getIncrement()
    {
        return increment;
    }

  public void allocCompID(MVComponent comp) {
     // allocate a component ID for a newly-created component
     // also need to store compID/comp pair in table so can save/load component etc.
     //
     // compID's are unique to each object in each project.
     // The copyID of several components will be the same if they are
     // different versions of the same component i.e. copied from
     // a common source
     //
        if(loading)
            return; // createNewComp & findOrCreateComp do alloc.

        int counter = getIDCounter();
        int increment = getIncrement();
        counter += increment;
        setIDCounter(counter);
            // increment same & original ID different
            // for each user's environment
        comp.setCompID(counter);
        comp.setCopiedFrom(counter);
        addCompID(counter,comp);

   }
   
   public MVComponent findCompID(int compID) {
     return (MVComponent) components.get(new Integer(compID));
   }
   
   public void addCompID(int compID, MVComponent comp) {
     components.put(new Integer(compID),comp);
   }
   
   public MVComponent findCopiedComp(int copiedFrom) {
        // needs to be changed to:
        // i) use hashtable
        // ii) allow user to specify "current" version of copied
        // component (currently just finds first occurance of
        // match with copiedFrom
        
        Enumeration e = components.elements();
        while(e.hasMoreElements()) {
            MVComponent c = (MVComponent) e.nextElement();
            if(c.copiedFrom == copiedFrom)
                return c;
        }
        
        return null;
   }
   
   public MVComponent findCompID(int compID,int copiedFrom, String compKind, String userName)
   {
        MVComponent c = findCompID(compID);
        if(c != null)
            return c;
        
        Enumeration e = components.elements();    
        while(e.hasMoreElements()) {
            c = (MVComponent) e.nextElement();
            if(c.copiedFrom == copiedFrom)
                return c;
            if(c.userName().equals(userName) && c.compKind().equals(compKind))
                return c;
        }
        
        return null;
   }
   
   public void openProjectInfo() {  
     // open project info dialog
     
     project_info = new MVProjectInfoFrame(this);
     project_info.redisplayBaseLayers();
  }
 
   public void makeCurrent(MVBaseLayer base, MVViewLayer view) {
     current_base_layer = base;
     MVApplication.application.makeCurrent(this,base,view);
 System.out.println("Current project = "+getName());  
     // may want to inform prev. current base of change of status...
   }
   
  protected Vector base_layers()
  {
    return getRelationship("base_layers",MVChildren);
  }
    
  public Vector getBaseLayers()
  {
		return base_layers();
  }
  
  public MVBaseLayer newBaseLayer() {
    return new MVBaseLayer("base #1");
  }

  public void addBaseLayer(MVBaseLayer base) {
    establishOneToMany("base_layers",base);
    if(project_info != null)
        project_info.redisplayBaseLayers();
  }
  
  public MVBaseLayer findBaseByName(String name)
  {
    Enumeration e = base_layers().elements();
    
    while(e.hasMoreElements()) {
        MVBaseLayer b = (MVBaseLayer) e.nextElement();
        if(b.getName().equals(name))
            return b;
    }
    
    return null;  }
  
  public MVViewLayer findViewByName(String name)
  {
    Enumeration e = base_layers().elements();
    
    while(e.hasMoreElements()) {
        MVViewLayer v = ((MVBaseLayer) e.nextElement()).findViewByName(name);
        if(v != null)
            return v;
    }
    
    return null;
  }
  
  public MVComponent findCompByName(String compKind, String name)
    // find component using compKind/userName
    // doesn't use any indexing at present so SLOW!
    // could have hashtable of compID/userName, but need to
    // update this index if userName changes (and how do we
    // know that in any reliable way??)
  {
/*

    MVComponent comp = findRegisteredComp(name);
    if(comp != null && comp.compKind().equals(compKind))
        return comp;
*/   
    MVComponent comp;
    try {
    Class compClass = Class.forName(compKind);
         
    Enumeration e = components.elements();
    while(e.hasMoreElements()) {
        comp = (MVComponent) e.nextElement();
        if(compClass.isInstance(comp) && comp.userName().equals(name))
            return comp;
    }
    } catch (Exception e) {
        System.out.println("Exception in findCompByName(): "+e);
    }
    
    return null;
  }
/*  
  public MVComponent findRegisteredComp(String name)
  {
        MVRegisteredComps registry = getRegisteredComps();
        return (MVComponent) registry.get(name);
  }
  
  public void registerComp(String name, MVComponent comp)
  {
        MVRegisteredComps registry = getRegisteredComps();
    System.out.println("checking if comp found...");
        if(registry.contains(comp))
            registry.changeKey(name,comp);
        else           
            registry.establish(this,comp);
  }
  
  public void deregisterComp(String name, MVComponent comp)
  {
        MVRegisteredComps registry = getRegisteredComps();
        registry.dissolve(this,comp);
  }
  
  public MVRegisteredComps getRegisteredComps()
  {
    MVRegisteredComps registry = (MVRegisteredComps) getOneRelatedOrNull("MVRegisteredComps",MVChildren);
    if(registry != null)
        return registry;
        
    registry = new MVRegisteredComps("MVRegisteredComps",this);
    
    return registry;
  }
*/  
  public void createPersistency() {
    // create a persistency mechanism
    // may extend this to allow multiple approaches later...
    
    persistency = new MVSimplePersistency(this);
  }
  
  protected String file_name = null;
  protected String directory_name = null;
  
  public String getFileName() {
    if(file_name != null)
      return file_name;
      
    FileDialog dialog = new FileDialog(MVApplication.application.projects_frame,"Project save file",FileDialog.SAVE);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    directory_name = dialog.getDirectory();
    dialog.setVisible(false);
    return file_name;
  }
  
  public void save() {
    // save project data to persistent store...
    
    if(persistency == null)
      createPersistency();
  
    Enumeration e = components.elements();
    
    if(!persistency.prepareToSave(getFileName(),directory_name))
      return;
      
System.out.println("Doing save project...");    
        persistency.saveProjectData(this);
        try {
            persistency.saveComponent(this);
            while(e.hasMoreElements()) {
                persistency.saveComponent((MVComponent) e.nextElement());
            }
        } catch (IOException ex) {
            throw(new MVFatalException("Error when writing component"));
        }
    persistency.finishedSaving();
    
    updated = false;
System.out.println("Done save project.");    
  }
  
  public boolean openProject() {
    FileDialog dialog = new FileDialog(MVApplication.application.projects_frame,"Project file to load",FileDialog.LOAD);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    directory_name = dialog.getDirectory();
    dialog.setVisible(false);
    if(file_name != null) {
      if(persistency == null)
        createPersistency();

      persistency.setProject(this);
        
      updated = false;
      setLoading(true);
  
      if(persistency.loadProject()) {
                Enumeration e = base_layers().elements();

                while(e.hasMoreElements()) {
                    //((MVBaseLayer) e.nextElement()).reopenViews();
                    ((MVBaseLayer) e.nextElement()).chooseView();
                }
                setLoading(false);
                
                return true;
            } else {
                setLoading(false);
                return false;    
            }
    }    
  
    return false;
  }
    
  public MVComponent findOrCreateComp(int compID, int copiedFrom, String compKind) {
    
    if(compID == 0)
        return this;    
    
    MVComponent c = findCompID(compID);
    
    if(c != null)
      return c;
    try {
      Class comp_class = Class.forName(compKind);
      c = (MVComponent) comp_class.newInstance();
      c.setCompID(compID);
      c.setCopiedFrom(copiedFrom);
      addCompID(compID,c);
    } catch (Exception e) {
      throw(new MVFatalException("couldn't create instance of "+compKind));
    }
    
    return c;
  }

    public MVComponent findOldComp(int compID, int copiedFrom, String compKind, String userName) {
        MVComponent c = findCompID(compID);

        // need to try other info e.g. copyID and userName if c == null

        return c;
    }

    public MVComponent createNewComp(int oldCompID, int copiedFrom, String compKind) {
        MVComponent c = null;

    try {
      Class comp_class = Class.forName(compKind);
      c = (MVComponent) comp_class.newInstance();
      boolean old_loading = loading;
      setLoading(false);
      allocCompID(c);
      setLoading(old_loading);
      c.setCopiedFrom(copiedFrom);
    } catch (Exception e) {
      throw(new MVFatalException("couldn't create instance of "+compKind));
    }

        return c;
    }

    public void reestablishRel(MVComponent otherComp, MVRelItem locatorItem,
        MVComponent locatorComp) {
        // does nothing - assume all components stored for project have their
        // rels kept consistent - if import/export comps then the import/export
        // process establishes or dissolves rels as appropriate...

    }

    public MVChangeDescr createNewChange(String changeKind) {
        MVChangeDescr cd = null;

// System.out.println("creating new change: "+changeKind);

        try {
            Class change_class = Class.forName(changeKind);
            cd = (MVChangeDescr) change_class.newInstance();
        } catch (Exception e) {
            throw(new MVFatalException("can't create instance of change "+changeKind));
        }

        return cd;
    }

    public void exportComponent(MVComponent comp, MVOutputBuffer buffer) {
        // exports component & its aggregates data to output buffer
        // first writes list of component IDs, copy IDs, compKind and userName values
        // at start of buffer, which is used by importComponent() to determine
        // relinking of imported components
        Vector aggs = new Vector();
        Vector rel = new Vector();
        comp.getAggregatesRelated(aggs,rel);
            // all part-of comps for this comp & all comps linked to this
            // comp or its aggregates...

        buffer.write("saved\n");
        Enumeration e1 = aggs.elements();
        MVComponent c;
        while(e1.hasMoreElements()) {
            c = (MVComponent) e1.nextElement();
            buffer.write(' ');
            buffer.write(c.compID);
            buffer.write(' ');
            buffer.write(c.copiedFrom);
            buffer.write(' ');
            buffer.write(c.compKind());
            buffer.write(' ');
            buffer.writeQuoted(c.userName());
            buffer.write('\n');
        }

        buffer.write("\nlinked\n");
        Enumeration e2 = rel.elements();
        while(e2.hasMoreElements()) {
            c = (MVComponent) e2.nextElement();
            buffer.write(' ');
            buffer.write(c.compID);
            buffer.write(' ');
            buffer.write(c.copiedFrom);
            buffer.write(' ');
            buffer.write(c.compKind());
            buffer.write(' ');
            buffer.writeQuoted(c.userName());
            buffer.write('\n');
        }

        buffer.write('\n');

        Enumeration e3 = aggs.elements();
        while(e3.hasMoreElements()) {
            c = (MVComponent) e3.nextElement();
            c.serialize(buffer);
        }

        buffer.flush();
    }

    public MVComponent importComponent(MVInputBuffer2 buffer, MVCompLocator locator) {
        // import previously exported group of components
        MVComponent new_comp = null;

        try {
            setLoading(true);

            buffer.readToken("saved");
            while(buffer.nextIsInt()) {
                int id = buffer.getIntToken();
                int copiedFrom = buffer.getIntToken();
                String kind = buffer.getToken();
                String name = buffer.getStringToken();
System.out.println("creating "+id+" "+copiedFrom+" "+kind+" "+name);
                locator.createNewComp(id,copiedFrom,kind);
            }
    
            buffer.readToken("linked");
            while(buffer.nextIsInt()) {
                int id = buffer.getIntToken();
                int copiedFrom = buffer.getIntToken();
                String kind = buffer.getToken();
                String name = buffer.getStringToken();
System.out.println("finding "+id+" "+kind+" "+name);
                locator.findOldComp(id,copiedFrom,kind,name);
            }
    
            while(!buffer.EOF()) {
            buffer.readToken("component");
            String compKind = buffer.getToken();
            int compID = buffer.getIntToken();
            int copiedFrom = buffer.getIntToken();
                MVComponent c = locator.findOrCreateComp(compID,copiedFrom,compKind);
                c.deserialize(buffer,locator);
System.out.println("reloaded "+c.compID);
                if(new_comp == null)
                    new_comp = c;
            }
            setLoading(false);
            
            return new_comp;
        } catch(IOException e) {
            setLoading(false);
            throw(new MVFatalException("IOException occured when importing component"));
        }

    }

    public void exportChanges(Vector changes, MVOutputBuffer buffer) {
        Vector aggs = new Vector();
        Vector rel = new Vector();
        MVChangeDescr cd;

        Enumeration e = changes.elements();
        while(e.hasMoreElements()) {
            cd = (MVChangeDescr) e.nextElement();
            cd.getAggregatesRelated(aggs,rel);
        }

        buffer.write("saved\n");
        Enumeration e1 = aggs.elements();
        MVComponent c;

        while(e1.hasMoreElements()) {
            c = (MVComponent) e1.nextElement();
            buffer.write(' ');
            buffer.write(c.compID);
            buffer.write(' ');
            buffer.write(c.copiedFrom);
            buffer.write(' ');
            buffer.write(c.compKind());
            buffer.write(' ');
            buffer.writeQuoted(c.userName());
            buffer.write('\n');
        }

        buffer.write("\nlinked\n");
        Enumeration e2 = rel.elements();
        while(e2.hasMoreElements()) {
            c = (MVComponent) e2.nextElement();
            buffer.write(' ');
            buffer.write(c.compID);
            buffer.write(' ');
            buffer.write(c.copiedFrom);
            buffer.write(' ');
            buffer.write(c.compKind());
            buffer.write(' ');
            buffer.writeQuoted(c.userName());
            buffer.writeln("");
        }

        buffer.writeln("");

        Enumeration e3 = changes.elements();
        while(e3.hasMoreElements()) {
            cd = (MVChangeDescr) e3.nextElement();
            cd.serialize(buffer);
            buffer.writeQuoted(cd.summaryString());
            buffer.writeln("");
        }

        buffer.flush();
    }

    public Vector importChanges(MVInputBuffer2 buffer, MVCompLocator locator) {
        // import previously exported group of changes
        Vector changes = new Vector();

        try {

            buffer.readToken("saved");
            while(buffer.nextIsInt()) {
                int id = buffer.getIntToken();
                int copiedFrom = buffer.getIntToken();
                String kind = buffer.getToken();
                String name = buffer.getStringToken();
System.out.println("creating "+id+" "+copiedFrom+" "+kind+" "+name);
                locator.createNewComp(id,copiedFrom,kind);
            }
    
            buffer.readToken("linked");
            while(buffer.nextIsInt()) {
                int id = buffer.getIntToken();
                int copiedFrom = buffer.getIntToken();
                String kind = buffer.getToken();
                String name = buffer.getStringToken();
System.out.println("finding "+id+" "+copiedFrom+" "+kind+" "+name);
                MVComponent acomp = locator.findOldComp(id,copiedFrom,kind,name);
if(acomp != null)
    System.out.println("found "+acomp.compID);
else
    System.out.println("couldn't find a matching comp");
            }
    
            while(!buffer.EOF()) {
            buffer.readToken("change");
            String changeKind = buffer.getToken();
                MVChangeDescr cd = locator.createNewChange(changeKind);
                cd.deserialize(buffer,locator);
                String printed = buffer.getStringToken();
                if(cd.isValid()) {
System.out.println("reloaded "+changeKind);
                    changes.addElement(cd);
                } else {
System.out.println("change with invalid components: "+printed);
                    // could add "info" item to version record
                    // to indicate to user invalid items?
                    //
                    // Or maybe put these into another list
                    // for further actioning???
                    // 
                    // E.g.:
                    //
                    // MVErrorChange ec = new MVErrorChange(changeKind);
                    // changes.addElement(ec);  
                    //
                    // However - *really* want more info i.e. which
                    // comp(s) couldn't be found, their userName()
                    // compKind and maybe ID, etc.
                }
            }

            return changes;
        } catch(IOException e) {
            throw(new MVFatalException("IOException occured when importing component"));
        }

    }

    public void writeBufferToFile(MVOutputBuffer output, String file_name, String path) {
        if(persistency == null)
            createPersistency();

        persistency.writeBufferToFile(output,file_name,path);
    }

    public MVInputBuffer2 readBufferFromFile(String file_name, String path) {
        if(persistency == null)
            createPersistency();
        
        return persistency.readBufferFromFile(file_name,path);
    }
    
    public void addCollabUserInfo(String name, String host, int port) 
    {
        MVCollabUserInfo u = findCollabUser(name);
        if(u != null) {
            u.setHost(host);
            u.setPort(port);
        } else {
            u = new MVCollabUserInfo(name,host,port);
            establishOneToMany("collabUsers",u);
        }    
    }
 
    public Vector getCollabUsers()
    {
        return getRelationship("collabUsers",MVChildren);
    }
    
    public MVCollabUserInfo findCollabUser(String name)
    {
        Enumeration e = getCollabUsers().elements();
        while(e.hasMoreElements())
        {
            MVCollabUserInfo u = (MVCollabUserInfo) e.nextElement();
            if(u.getUser().equals(name))
                return u;
        }
        
        return null;
    }

}


class MVProjectInfoFrame extends Frame {
  MVProjectInfoList listPanel = new MVProjectInfoList();
  MVProjectInfoButtons buttonPanel = new MVProjectInfoButtons(this);
  
  public MVProject project;
  
  public MVProjectInfoFrame(MVProject project) {
    super("Project: "+project.getName());
    this.project = project;
    setLayout(new BorderLayout());
    add("Center",listPanel);
    add("South",buttonPanel);
    setSize(250,180);
    pack();
    setVisible(true);
  }
  
  public void processEvent(AWTEvent e) {
        if(e instanceof WindowEvent) {
            if(e.getID() == WindowEvent.WINDOW_CLOSED)
        setVisible(false);
        }
    super.processEvent(e);
  }
  
  public void redisplayBaseLayers() {
    // redisplay info after project manipulations...
    
    listPanel.setListValues(project);
    validate();

    
  }
  
  public void doSave() {
    // save this Project's data to persistent store...
  
    project.save();
    MVApplication.application.projects_frame.redisplayProjects();
  }
  
  public void doNew() {
    // create a new base layer
    
    // need to chose kind of base layer to create

   MVApplication.application.makeCurrent(project,null,null);
   MVBaseLayer b = project.newBaseLayer();
   project.addBaseLayer(b);
   b.initialise();
    
  }
  
  public void doShow() {
        MVBaseLayer base = listPanel.findSelectedBase(project.base_layers());
        base.chooseView();
  }
  
  public void doHide() {
System.out.println("doHide");  
  
  }
  
  public void doDelete() {
System.out.println("doDelete");  
  
  }
  
}

class MVProjectInfoList extends Panel {
  List baseList = new List();
  
  public MVProjectInfoList() {
    setLayout(new GridLayout(1,1));
    add(baseList);
  }
  
  public Vector comps = new Vector();
  
  public void setListValues(MVProject project) {
    Enumeration e = project.base_layers().elements();
    MVBaseLayer b;
        
    baseList.removeAll();
    
    while(e.hasMoreElements()) {
      b = (MVBaseLayer) e.nextElement();
      baseList.addItem(b.getName());
    }
  }

  public Dimension getMinimumSize() {
    return new Dimension(250,150);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,150);
  }

  public MVBaseLayer findSelectedBase(Vector base_layers) {    
    int index = baseList.getSelectedIndex();
    
    try {
      return (MVBaseLayer) base_layers.elementAt(index);
    } catch (Exception e) {
      return null;
    }
  }
  
}

class MVProjectInfoButtons extends Panel implements ActionListener {
  Button saveButton = new Button("Save");
  Button newButton = new Button("New");
  Button showButton = new Button("Show");
  Button hideButton = new Button("Hide");
  Button deleteButton = new Button("Delete");
  
  MVProjectInfoFrame frame;
  
  public MVProjectInfoButtons(MVProjectInfoFrame frame) {
    setLayout(new GridLayout(1,5,3,3));
    add(saveButton);
        saveButton.addActionListener(this);
    add(newButton);
        newButton.addActionListener(this);
    add(showButton);
        showButton.addActionListener(this);
    add(hideButton);
        hideButton.addActionListener(this);
    add(deleteButton);
        deleteButton.addActionListener(this);
    this.frame = frame;
  }
  
  public Dimension getMinimumSize() {
    return new Dimension(250,20);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,20);
  }

  public void actionPerformed(ActionEvent e) {
  
    if(e.getSource() == saveButton)
      frame.doSave();
    else if(e.getSource() == newButton)
      frame.doNew();
    else if(e.getSource() == showButton)
      frame.doShow();
    else if(e.getSource() == hideButton)
      frame.doHide();
    else if(e.getSource() == deleteButton)
      frame.doDelete();
      
  }

}

class MVRegisteredComps extends MVHashtableRel
{

    public MVRegisteredComps()
    {
        super();
    }
    
    public MVRegisteredComps(String relName, MVComponent parent)
    {
        super(relName,parent);
    }
    
    public String extractKey(MVComponent c)
    {
        return findOldKey(c);
    }

}
