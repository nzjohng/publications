package JViews;

import java.awt.*;

public class MVPanelInfo extends MVHumanInterfaceInfo
{
    MVExtensiblePanel p;

    public MVPanelInfo(String name, boolean provides, boolean requires, int kind, String info, MVExtensiblePanel p)
    {
        super(name,provides,requires,MVDialogueHIAspect,info);
        this.p = p;
    }
    
    public void addComponent(Component comp)
    {
        p.addComponent(comp);
    }
    
    public void disableComponent(String name)
    {
        Component c = p.findComponent(name);
        if(c != null)
            c.setEnabled(false);
    }
}
