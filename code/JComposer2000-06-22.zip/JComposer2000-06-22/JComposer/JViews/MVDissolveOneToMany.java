package JViews;

import java.io.*;
import java.util.*;

public class MVDissolveOneToMany extends MVChangeDescr {
    public String name;
  public MVComponent child;

  public MVDissolveOneToMany(MVComponent init_target, String init_name,
      MVComponent init_child) {
      target = init_target;
          name = init_name;
      child = init_child;
  }

    public MVDissolveOneToMany() {
        super();
    }
    
    public String getName()
    {
        return name;
    }
    
    public MVComponent getChild()
    {
        return child;
    }
   

  public void execute() {
    child.broadcastBefore(this);
    target.removeRelationship(name,MVComponent.MVOneToMany,child);
      child.removeRelationship(name,MVComponent.MVReverseOneToMany,target);
    child.broadcastAfter(this);
    done = true;
  }

  public void undo() {
      target.establishOneToMany(name,child);
      // generate change description
  }

  public void redo() {
    target.dissolveOneToMany(name,child);
      // generate change description
  }

  public String toString() {
      // put component names in here too...
    return ("DissolveOneToMany "+name+": "+target.userName()+" to "+child.userName());
  }
  
  public boolean targets(MVComponent c) {
    if(target == c)
      return true;
    if(child == c)
      return true;
      
    return false;
  }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        super.getAggregatesRelated(aggs,rel);
        if(!rel.contains(child))
            rel.addElement(child);
    }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writelnQuoted(name);
        output.writeln(child);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        name = input.getStringToken();
        int compID = input.getIntToken();
        child = locator.findOrCreateComp(compID,0,"");
    }
    
    public boolean isValid()
    {
        return super.isValid() && (child != null);
    }

}
