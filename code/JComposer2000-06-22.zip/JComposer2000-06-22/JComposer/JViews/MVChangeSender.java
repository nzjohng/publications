package JViews;

import java.util.*;

public class MVChangeSender extends MVComponent {
    // is a kind of listener...

    protected MVClientMultSend sender = null;
    protected MVOutputBuffer buffer = new MVOutputBuffer();

    public MVChangeSender(MVComponent listened) {
        super();
        sender = new MVClientMultSend();
        sender.start();
        establishOneToMany("ChangeSender",listened);
        listened.setHandleAfterRel("ChangeSender");
System.out.println("MVChangeSender connected to "+listened.compID);
    }    
    
    public boolean addServer(String host, int port)
    {
        if(sender.addServer(host,port) != null)
            return true;
        else
            return false;
    }

    public MVComponent getListened() {
        return (MVComponent) getOneRelated("ChangeSender",MVChildren);
    }

    public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent from, String rel_name,
            MVComponent sent_from, String sent_rel) {
System.out.println("MVChangeSender got "+c);
        if(from != this) {
System.out.println("MVChangeSender sending change...");
            // if(sender.connect("lucy.cs.waikato.ac.nz",4545)) {
                Vector v = new Vector();
                v.addElement(c);
                buffer.reset();
                MVApplication.application.current_project.exportChanges(v,buffer);
                    // should store project - when create this listener??

// Need to send info about project, component THEN change info...
                sender.sendRequest("collabEdit");
                sender.sendRequest(MVApplication.application.current_project.getName());
                sender.sendRequest(getListened().userName());
                sender.sendRequest(buffer.getBytes());
//                String s = sender.getStringReply();
//System.out.println("server sent back "+s);
                // sender.close();
            // }
        }

        return super.afterReceive(c,from,rel_name,sent_from,sent_rel);
    }

}

