package JViews;

public class MVHasNoValue extends MVFatalException {

  public MVHasNoValue(MVComponent target, String name, String type) {
    super("MVHasNoValue: "+target.userName()+":"+name+" - has no "+type+" value");  
  }

}
