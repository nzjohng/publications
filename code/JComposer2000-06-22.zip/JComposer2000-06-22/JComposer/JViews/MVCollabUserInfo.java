
package JViews;

public class MVCollabUserInfo extends MVComponent
{

    public MVCollabUserInfo(String name, String host, int port)
    {
         setUser(name);
         setHost(host);
         setPort(port);
    }
    
    public MVCollabUserInfo()
    {

    }    
    
    public void setUser(String name)
    {
        setValue("user",name);
    }
    
    public void setHost(String host)
    {
        setValue("host",host);
    }
    
    public void setPort(int port)
    {
        setValue("port",port);
    }
    
    public String getUser()
    {
        return getStringValue("user");
    }
    
    public String getHost()
    {
        return getStringValue("host");
    }
    
    public int getPort()
    {
        return getIntValue("port");
    }

}
