package JViews;

import java.util.*;       

public class MVImportViewChangesLocator implements MVCompLocator {

    MVViewLayer view;
    Vector table = new Vector();

    public MVImportViewChangesLocator(MVViewLayer v) {
        view = v;
    }

    public MVComponent findOrCreateComp(int compID, int copiedFrom, String compKind) {
        // looks for comp in view...

//System.out.println("Trying to locate match for "+compID+" "+copiedFrom);
        // use look-up table first    
        MVImportViewItem i = findViewItem(compID,copiedFrom);
        if(i != null) {
//System.out.println("found item "+i.newComp.compID);
            return i.newComp;
        }

        // is the component the view itself??
        if(view.compID == compID) {
//System.out.println("found view "+view.compID);
            table.addElement(new MVImportViewItem(compID,view.compID,view.copiedFrom,view));
            return view;
        } if(view.copiedFrom == copiedFrom) {
//System.out.println("found view "+view.compID);
            table.addElement(new MVImportViewItem(compID,view.compID,view.copiedFrom,view));            
            return view;
         }
         
        // otherwise look in view itself
        // & add item to table if found
        MVViewComp c = view.findViewComp(compID,copiedFrom);
        if(c != null) {
//System.out.println("found & added "+c.compID);
            table.addElement(new MVImportViewItem(compID,c.compID,c.copiedFrom,c));
            return c;
        }

//System.out.println("NO MATCHING COMP FOUND!!");

/*        
        // create iff a MVViewComp specialisation
        //                           
        try {
            Class comp_class = Class.forName(compKind);
            MVComponent nc = (MVComponent) comp_class.newInstance();
            if(nc instanceof MVViewComp) { 
                System.out.println("Created new comp "+compID+" "+compKind);
                return createNewComp(compID,copiedFrom,compKind);
            } else {
                System.out.println("Couldn't create new comp "+compID+" "+compKind);
                return null;
            }
        } catch (Exception e) {
            System.out.println("*** couldn't create instance of "+compKind);
            return null;
        }
*/
        return null;      
    }  
    
    public MVImportViewItem findViewItem(int compID, int copiedFrom)
    {
        Enumeration e = table.elements();
        while(e.hasMoreElements()) {
            MVImportViewItem item = (MVImportViewItem) e.nextElement();
//System.out.println("looking for "+compID+"("+copiedFrom+") - checking "+item.oldCompID+"->"+item.newComp.compID+"("+item.copiedFrom+")");
            if(item.oldCompID == compID)
                return item;
            else if(item.copiedFrom == copiedFrom) {
                table.addElement(new MVImportViewItem(compID,item.newComp.compID,item.newComp.copiedFrom,item.newComp));
                return item;
            }
        }
        
        return null;
    }

    public MVComponent findOldComp(int compID, int copiedFrom, String compKind, String userName) {
        return findOrCreateComp(compID,copiedFrom,compKind);
    }

    public MVComponent createNewComp(int compID, int copiedFrom, String compKind) {
        MVComponent c = view.findViewComp(compID,copiedFrom);

        if(c != null)
            return c;

        c = view.getBaseLayer().getProject().createNewComp(compID,copiedFrom,compKind);
        table.addElement(new MVImportViewItem(compID,c.compID,copiedFrom,c));

        return c;
    }

    public MVChangeDescr createNewChange(String changeKind) {
        return view.getBaseLayer().getProject().createNewChange(changeKind);
    }

    public void reestablishRel(MVComponent otherComp, MVRelItem locatorRel,
        MVComponent locatorComp) {
        // does nothing when importing changes...

    }

}

