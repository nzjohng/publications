package JViews;

public class MVSyntaxErrorException extends MVReportException {

  public MVSyntaxErrorException(String message) {
    super(message);
  }

}
