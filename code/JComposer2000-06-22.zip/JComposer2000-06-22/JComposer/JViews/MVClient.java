package JViews;

import java.io.*;
import java.net.*;

public class MVClient implements Runnable {
 
    public MVClient()
    {
    }

    protected OutputStream out = null;
    protected InputStream in = null;
    protected Socket s = null;
    
    protected String myName;
    protected String userName;
    protected String host;
    protected int port;
    
    protected boolean result = false;
    
    public static final int CON_TIMEOUT = 5000; // 5 seconds
    public static final int READ_TIMEOUT = 5000; // 5 seconds
    
    public Thread t = null;
    
    public boolean connect(String user, String server, String host, int port) {
        this.myName = user;
        this.userName = server;
        this.host = host;
        this.port = port;
        result = false;
        
        start();
        
        return result;    
    }
    
    public boolean isValidConnection()
    {
        return result;
    }
    
    public void setValidConnection(boolean v)
    {
        result = v;
    }

    public synchronized void start( ) {
System.out.println("starting client thread...");
if(t != null)
System.out.println("t is not null!!!");
    if( t == null ) {
      t = new Thread( this );
      t.setPriority( Thread.MAX_PRIORITY / 4 );
      t.start();
      try {
        t.join(CON_TIMEOUT);
        if(!result) {
            // if no connection yet, kill thread
            System.out.println("connection attempt timed out!");
            stop();
        }
        if(t != null)
            t.stop();
        t = null;
      } catch (InterruptedException e) {
        System.out.println("no response from server");
        result = false;
        stop();
      }
    }
  }

  // Stop thread from running if it exists
  public synchronized void stop( ) {

    if( t != null ) {
      t.stop( );
      t = null;
    }
  }

  // Allow join with our thread
  public final void join(int millisec) 
    throws java.lang.InterruptedException 
  {
    try {
      if( t != null ) {
    t.join(millisec);
      } 
    } catch ( InterruptedException e ) {
      throw e;
    }

    return;
  }
  
  public void suspend()
  {
    t.suspend();
  }
  
  public void resume()
  {
    t.resume();
  }
  
  public void run()
  {
    result = doConnect();
    // finish thread - still have client IO functions
    // stop();
  }

    public boolean doConnect() {
        System.out.println("Trying for connection to "+host+"("+port+")");
        
        try {
            s = new Socket(host,port);
            out = s.getOutputStream();
            in = s.getInputStream();
            s.setSoTimeout(READ_TIMEOUT);
            sendRequest(myName);
            
            return true;
        } catch (UnknownHostException e) {
            System.out.println("Unknown host in client: "+e);
            s = null;
            out = null;
            in = null;
            return false;
        } catch (IOException e) {
            System.out.println("IO Error in client: "+e);
            s = null;
            out = null;
            in = null;
            return false;
        }
    }

    public boolean close() {
        if(s != null) {
            try {
                out.flush();
                s.close();
                s = null;
                in = null;
                out = null;
                result = false;
                return true;
            } catch(IOException e) {
                System.out.println("IOException when closing client socket: "+e);
                s = null;
                in = null;
                out = null;
                result = false;
                return false;
            }
        } else
            return false;
    }

    public boolean sendRequest(String data) {
        byte bytes[] = data.getBytes();
        return sendRequest(bytes);
    }

    public boolean sendRequest(byte bytes[]) {
        try {
            out.write(bytes.length / 256);
            out.write(bytes.length % 256);
            if(bytes.length < 4096)
                out.write(bytes,0,bytes.length);
            else {
                int i = 0;
                while(i < bytes.length) {
                    int amt = 4096;
                    if(i+amt > bytes.length)
                        amt = bytes.length - i;
                    out.write(bytes,i,amt);
                    i += amt;
                }
            }
            out.flush();
            return true;
        } catch(IOException e) {
            System.out.println("Error while writing to server: "+e);
            result = false;
            return false;
        }
    }

    public String getStringReply() {
        byte bytes[] = getBytesReply();
        if(bytes != null)
            return new String(bytes,0,bytes.length);
        else
            return null;
    }

    public byte[] getBytesReply() {
        try {
            int b1 = in.read();
            int b2 = in.read();
            int size = b1 * 256 + b2;
            byte bytes[] = new byte[size];
            
                int i = 0;
                while(i < size) {
                    int num_read = in.read(bytes,i,size-i);
                    i += num_read;
                }
            
            return bytes;
        } catch (IOException e) {
            System.out.println("Error while reading from server: "+e);
            result = false;
            return null;
        }
    }
    
    public String getUserName()
    {
        return userName;
    }
    
    public String getHost()
    {
        return host;
    }
    
    public int getPort()
    {
        return port;
    }

}
