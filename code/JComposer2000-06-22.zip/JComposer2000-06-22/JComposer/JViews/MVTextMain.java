package JViews;

public class MVTextMain {

  public static void main(String argv[]) {
    MVApplication a = new MVApplication();
  }

}
