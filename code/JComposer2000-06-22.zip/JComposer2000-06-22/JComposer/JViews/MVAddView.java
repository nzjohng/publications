package JViews;
import java.io.*;

public class MVAddView extends MVChangeDescr {

  public String view_kind;
    // kind of view layer created
    
  public MVViewLayer view;
    // the component created

  public MVAddView(MVBaseLayer layer, String view_kind, MVViewLayer view) {
    target = layer;
    this.view_kind = view_kind;
    this.view = view;
  }

  public void execute() {
    done = true;
      // component has already been created by call to its constructor method
  }
  
  public void undo() {
    // comp.delete();
  }
  
  public void redo() {
    // comp.undelete();
  }
  
  public String toString() {
    return ("AddView "+view_kind);
  }
  
    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(view_kind);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        view_kind = input.getToken();
    }

}
