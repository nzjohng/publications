package JViews;

/*                    
 * (C) John Grundy, John Hosking, Rick Mugridge
 *
 * Banquet Group                     Banquet Group
 * Department of Computer Science    Department of Computer Science
 * University of Waikato             University of Auckland
 * Private Bag 3105, Hamilton        Private Bag, Auckland
 * New Zealand                       New Zealand
 *
 * 
 * This code can be used for research purposes as long as this copyright
 * message is retained.
 *
 */


/*
 * MVComponent
 *
 * This is the main component class for JViews. All other specialised
 * kinds of components inherit from it.
 *
 */

import java.io.*;
import java.util.*;
import beanbox.*;
import java.lang.reflect.*;

public class MVComponent {

        /*
         * Component basics
         *
         */

  public int compID;
    // persistent ID
    
  public int copiedFrom;
    // component this one copied from
    // used for simple versioning of components

  public int getCompId() {
    return compID;
  }

    public void setCompID(int compID) {
    // should only be called by project or persistency manager...
    
    this.compID = compID;
  }
  
  public int getCopiedFrom()
  {
    return copiedFrom;
  }
  
  public void setCopiedFrom(int c)
  {
    copiedFrom = c;
  }

  public MVComponent() {
    MVApplication.application.allocID(this);
  }
  
  public String compKind() {
    return (getClass()).getName();
  }
  
        /*
         * Version records
         *
         */

        public MVVersionRecord getVersionRecord() {
                Vector v = getRelationship("VersionRecord",MVParents);

                if(v.size() == 0)
                        return null;
                else
                        if(v.size() == 1)
                                return (MVVersionRecord) v.firstElement();
                        else
                                throw(new MVNotOneRelated(this,"VersionRecord",MVParents));
        }
    
  /*
   * identification
   *
   */
  
  public String kindName() {
    // redefined in specialisations of MVComponent to provide a unique
    // human-readable "component kind" to identify the type of component.
    return compKind();
  }  

  public String userName() {
    // redefined in specialisations of MVComponent to provide a (usually) unique
    // human-readable name for a component. Used to index components in look-up
    // tables, and also to locate components using compKind()/userName() pair
    return "*unknown*";
  }

  public String getUserName() {
	return userName();
  }

        /*
         * Property processing
         *
         */
  
        public void setNamedProperty(String name, Object value) {
                MVSetProperty c = new MVSetProperty(this,name,getNamedProperty(name),value);
                recordUpdate(c);
        }

        public void doSetNamedProperty(String name, Object value) {
                // generated in specialisations by JComposer...
                // DOESN'T generate a change description...
        }

        public Object getNamedProperty(String name) {
                // generated in specialisations by JComposer...

                return null;
        }

  /*
   * Attributes processing
   *
   */

  private Vector attributes = new Vector();
    // attributes of component
    
  public Vector getAttributes() {
    // allows access to property list
    return attributes;
  }
    
  public void setValue(String name, int value) {
    // set a named, integer-valued property
    MVAttribute a;
    MVIntAttribute attribute;
    MVSetIntValue c;
    String iname = name.intern();

    a = getAttribute(iname);
    if (a == null) {
      attribute = new MVIntAttribute(iname,MVIntBlank);
      attributes.addElement(attribute);
      c = new MVSetIntValue(this,iname,MVIntBlank,value,attribute); //generate change even if value 0 
      recordUpdate(c);
    } else {
      if(a instanceof MVIntAttribute)
        attribute = (MVIntAttribute) a;
      else
        //exception - wrong type
        throw(new MVTypeMismatch(this,name,"Integer"));

      if(attribute.value != value) {
        c = new MVSetIntValue(this,iname,attribute.value,value,attribute);      
        recordUpdate(c);
      }
    }
  }
  
  public static final int MVIntBlank = 0;
  public static final String MVStringBlank = "";

  public void setValue(String name, String value) {
    // set a named, string-valued property
    MVAttribute a;
    MVStringAttribute attribute;
    MVSetStringValue c;
    String iname = name.intern();

                if(value == null)
                        return; // or set to ""? or throw exception??

    a = getAttribute(iname);
    if (a == null) {
      attribute = new MVStringAttribute(iname,MVStringBlank);
      attributes.addElement(attribute);
      c = new MVSetStringValue(this,iname,MVStringBlank,value,attribute); //generate change even if value ""    
      recordUpdate(c);
    } else {
      if(a instanceof MVStringAttribute)
        attribute = (MVStringAttribute) a;
      else
        //exception - wrong type
        throw(new MVTypeMismatch(this,name,"String"));

      if(!attribute.value.equals(value)) {
        c = new MVSetStringValue(this,iname,attribute.value,value,attribute);      
        recordUpdate(c);
      }
    }
  }

  public void setValue(String name, boolean value) {
    // set a named, boolean-valued property
    MVAttribute a;
    MVBooleanAttribute attribute;
    MVSetBooleanValue c;
    String iname = name.intern();

    a = getAttribute(iname);
    if (a == null) {
      attribute = new MVBooleanAttribute(iname,false);
      attributes.addElement(attribute);
      c = new MVSetBooleanValue(this,iname,false,value,attribute); 
                                        //generate change even if value 0 
      recordUpdate(c);
    } else {
      if(a instanceof MVBooleanAttribute)
        attribute = (MVBooleanAttribute) a;
      else
        //exception - wrong type
        throw(new MVTypeMismatch(this,name,"Boolean"));

      if(attribute.value != value) {
        c = new MVSetBooleanValue(this,iname,attribute.value,value,attribute);
        recordUpdate(c);
      }
    }
  }
  
  public MVAttribute getAttribute(String name) {
    // locate a named attribute
    MVAttribute a;
    Enumeration e = attributes.elements();
    String iname = name.intern();
    
    while(e.hasMoreElements()) {
      a = (MVAttribute) e.nextElement();
          if(iname == a.name) { //assume intern done on all Strings used as names
        return a;
      }
    }
    return null;
  }

  public int getIntValue(String name) {
    // return value of an integer-valued attribute
    MVAttribute a = getAttribute(name);
    MVIntAttribute attribute;
    
    if(a != null) {
      if(a instanceof MVIntAttribute) {
        attribute = (MVIntAttribute) a;
        return attribute.value;
      } else
        //exception if wrong cast
        throw(new MVTypeMismatch(this,name,"Integer"));
    } else {
      //exception if no attribute of that name ??
      return 0;
    }
  }

  public boolean getBooleanValue(String name) {
    // return value of an boolean-valued attribute
    MVAttribute a = getAttribute(name);
    MVBooleanAttribute attribute;
    
    if(a != null) {
      if(a instanceof MVBooleanAttribute) {
        attribute = (MVBooleanAttribute) a;
        return attribute.value;
      } else
        //exception if wrong cast
        throw(new MVTypeMismatch(this,name,"Boolean"));
    } else {
      //exception if no attribute of that name ??
      return false;
    }
  }

  public String getStringValue(String name) {
    // return value of a string-valued attribute
    MVAttribute a = getAttribute(name);
    MVStringAttribute attribute;
    
    if(a != null) {
      if(a instanceof MVStringAttribute) {
        attribute = (MVStringAttribute) a;
        return attribute.value;
      } else
        //exception if wrong cast
        throw(new MVTypeMismatch(this,name,"String"));
    } else {
      //exception if no attribute of that name??
      return "";
    }
  }
/*  
  public void removeAttribute(String name)
  {
    // remove a named attribute value
    MVAttribute a;
    Enumeration e = attributes.elements();
    String iname = name.intern();
    
    while(e.hasMoreElements()) {
      a = (MVAttribute) e.nextElement();
      if(iname == a.name) {
        attributes.removeElement(a);
        return;
      }
            
  }
*/  
  /*
   * Relationships processing
   *
   */

  public void establishOneToMany(String name, MVComponent child) {
    // establish link relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    MVEstablishOneToMany cd;
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.matches(MVOneToMany,iname)) {
        // already a RelItem for this named relationship in component's relationships list
        if(item.contains(child))
          return;
        else
          break;
      }
    }

    if(child != null) {
      cd = new MVEstablishOneToMany(this,iname,child);
      recordUpdate(cd);
    } else
      addRelationship(iname,MVOneToMany,null);
  }

  public void dissolveOneToMany(String name, MVComponent child) {
    // dissolve link relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    MVDissolveOneToMany cd;
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.matches(MVOneToMany,iname)) {
        if(item.contains(child)) {
                                        cd = new MVDissolveOneToMany(this,iname,child);
                                        recordUpdate(cd);
        } else
          break;
      }
    }
  }

        public void delete() {
                // dissolve all component's relationships and send a MVCompDeleted
                // change description around

                if(!deleted) {
                        MVCompDeleted cd = new MVCompDeleted(this);
                        recordUpdate(cd);
                }
        }

        public void undelete() {
                // restore component's relationships (on undo of delete)

                if(deleted) {
                        MVCompUndeleted cd = new MVCompUndeleted(this);
                        recordUpdate(cd);
                }
        }

        protected boolean deleted = false;
        
        public void setDeleted(boolean value)
        {
            deleted = value;
        }

        public void doDelete() {
                // remove all relationships list links from linked components

                deleted = true;

                Vector rels = getRelationships();
                int index = rels.size() - 1;

                while(index >= 0) {
                        MVRelItem r = (MVRelItem) rels.elementAt(index);
                        index--;

                        if(r.isAggregate()) {
                                // if aggregate, tell all aggregated comps to delete themselves
                                Enumeration e2 = r.elements();
                                while(e2.hasMoreElements()) {
                                        ((MVComponent) e2.nextElement()).delete();
                                }
                        } else {

                                switch(r.kind) {
                        case MVOneToMany :
                                        // remove all MVReverseOneToMany from linked comps
                                        Enumeration e1 = r.elements();
                                        while(e1.hasMoreElements()) {
                                                MVComponent c = (MVComponent) e1.nextElement();
                                                if(!c.deleted)
                                                        c.removeRelationship(r.name, MVReverseOneToMany, this);
                                        }
                                        break;
                        case MVReverseOneToMany :
                                        // remove the MVOneToMany from linked comp
                                        Enumeration e3 = r.elements(); // should be only 1!!
                                        while(e3.hasMoreElements()) {
                                                MVComponent c = (MVComponent) e3.nextElement();
                                                if(!c.deleted)
                                                        c.removeRelationship(r.name, MVOneToMany, this);
                                        }
                                        break;
                                case MVRelLinksParents :
                                        // removeChild(this) from relationship component(s)
                                        Enumeration e4 = r.elements();
                                        while(e4.hasMoreElements()) {
                                                MVRelationship c = (MVRelationship) e4.nextElement();
                                                if(!c.deleted)
                                                        c.removeChild(this);
                                        }

                                break;
                        case MVRelLinksChildren :
                                        // removeParent(this) from relationship component(s)
                                        Enumeration e5 = r.elements(); 
                                        while(e5.hasMoreElements()) {
                                                MVRelationship c = (MVRelationship) e5.nextElement();
                                                if(!c.deleted)
                                                        c.removeParent(this);
                                        }

                                        break;
                                default : // Error!!
                                        break;
                                }
                        }
                }
        }

        public void doUndelete() {
                // restore all relationships list links from linked components

                deleted = false;

                Enumeration e = getRelationships().elements();

                while(e.hasMoreElements()) {
                        MVRelItem r = (MVRelItem) e.nextElement();

                        if(r.isAggregate()) {
                                // if aggregate, tell all aggregated comps to undelete themselves
                                Enumeration e1 = r.elements();
                                while(e1.hasMoreElements()) {
                                        ((MVComponent) e1.nextElement()).undelete();
                                }
                        } else {

                                switch(r.kind) {
                        case MVOneToMany :
                                        // add all MVReverseOneToMany to linked comps
                                        Enumeration e2 = r.elements();
                                        while(e2.hasMoreElements()) {
                                                MVComponent c = (MVComponent) e2.nextElement();
                                                if(!c.deleted)
                                                        c.addRelationship(r.name, MVReverseOneToMany, this);
                                        }
                                        break;
                        case MVReverseOneToMany :
                                        // add the MVOneToMany to linked comp
                                        Enumeration e3 = r.elements(); // should be only 1!!
                                        while(e3.hasMoreElements()) {
                                                MVComponent c = (MVComponent) e3.nextElement();
                                                if(!c.deleted)
                                                        c.addRelationship(r.name, MVOneToMany, this);
                                        }
                                        break;
                                case MVRelLinksParents :
                                        // addChild(this) to relationship component(s)
                                        Enumeration e4 = r.elements();
                                        while(e4.hasMoreElements()) {
                                                MVRelationship c = (MVRelationship) e4.nextElement();
                                                if(!c.deleted)
                                                        c.addChild(this);
                                        }

                                break;
                        case MVRelLinksChildren :
                                        // addParent(this) to relationship component(s)
                                        Enumeration e5 = r.elements();
                                        while(e5.hasMoreElements()) {
                                                MVRelationship c = (MVRelationship) e5.nextElement();
                                                if(!c.deleted)
                                                        c.addParent(this);
                                        }

                                        break;
                                default : // Error!!
                                        break;
                                }
                        }
                }
        }
  
  public void setAggregateRel(String name) {
    // mark a relationship as an "aggregate"
    Enumeration e = relationships.elements();
    MVRelItem r;
    String iname = name.intern();
    
    while(e.hasMoreElements()) {
      r = (MVRelItem) e.nextElement();
      if(r.name == iname) {
        r.setAggregate(true);
        return;
      }
    }
  }
  
  public static final int MVAllComps = 0;
  public static final int MVChildren = 1;
  public static final int MVParents = 2;
  public static final int MVChildRelComps = 3;
  public static final int MVParentRelComps = 4;

  public Vector relationships = new Vector();
    // vector of RelItem objects
    
  public Vector getRelationships() {
    // return relationship item list
    return relationships;  
  }

  public Vector getRelationship(String name, int flag) {
    // search relationships using name & selection flag
    MVRelItem item;
    Enumeration e = relationships.elements();
    Vector v = new Vector();
    String iname = name.intern();

    while(e.hasMoreElements()) {
        item = (MVRelItem) e.nextElement();
        if(item.name == iname) {
          switch(flag) {
          case MVAllComps :
                  for(Enumeration e2 = item.elements(); e2.hasMoreElements(); )
              v.addElement(e2.nextElement());            
            break;
          case MVChildRelComps :
            if(item.kind == MVComponent.MVOneToMany ||
                item.kind == MVRelLinksChildren) {
              // add item.elements() to Vector v...
                    for(Enumeration e2 = item.elements(); e2.hasMoreElements(); )
                v.addElement(e2.nextElement());
            }
            break;
          case MVParentRelComps :
            if(item.kind == MVComponent.MVReverseOneToMany ||
                item.kind == MVRelLinksParents) {
              // add item.elements() to Vector v...
                    for(Enumeration e3 = item.elements(); e3.hasMoreElements(); )
                v.addElement(e3.nextElement());
            }
            break;
          case MVChildren :
            if(item.kind == MVComponent.MVOneToMany) {
              // add item.elements() to Vector v...
                    for(Enumeration e2 = item.elements(); e2.hasMoreElements(); )
                v.addElement(e2.nextElement());
            } else if(item.kind == MVRelLinksChildren) {
              // for each rel_comp in items, add rel_comp.children to Vector v...
                    for(Enumeration e2 = item.elements(); e2.hasMoreElements(); ) {
                MVRelationship rel_comp = (MVRelationship) e2.nextElement();
                for(Enumeration e3 = rel_comp.children(); e3.hasMoreElements(); )
                  v.addElement(e3.nextElement());
              }
            }
            break;
          case MVParents :
            if(item.kind == MVComponent.MVReverseOneToMany) {
              // add item.elements() to Vector v...
                    for(Enumeration e2 = item.elements(); e2.hasMoreElements(); )
                v.addElement(e2.nextElement());
            } else if(item.kind == MVRelLinksParents) {
              // for each rel_comp in items, add rel_comp.parents to Vector v...
                    for(Enumeration e2 = item.elements(); e2.hasMoreElements(); ) {
                MVRelationship rel_comp = (MVRelationship) e2.nextElement();
                for(Enumeration e3 = rel_comp.parents(); e3.hasMoreElements(); )
                  v.addElement(e3.nextElement());
              }
            }
            break;
          }
        }
    }

    return v;
  }
  
  public MVComponent getOneRelated(String name, int flag) {
    // get a singly related component; throw exception if not one and only
    // one component related by this named relationship
    Vector rel_data = getRelationship(name,flag);
    if(rel_data.size() != 1)
      throw(new MVNotOneRelated(this,name,flag));
    
    return (MVComponent) rel_data.firstElement();
  }

        public MVComponent getOneRelatedOrNull(String name, int flag) {
                Vector rel_data = getRelationship(name,flag);
                if(rel_data.size() == 0)
                        return null;
                else if(rel_data.size() == 1)
                        return (MVComponent) rel_data.firstElement();

                throw(new MVNotOneRelated(this,name,flag));
        }
  
  public MVComponent findRelatedCompID(int comp_id) {
    // find any related component with this unique compID value...
    Enumeration e = relationships.elements();
    MVRelItem item;
    MVComponent c;

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      
          for(Enumeration e2 = item.elements(); e2.hasMoreElements(); ) {
        c = (MVComponent) e2.nextElement();    
        if(c.compID == comp_id)
          return(c);
      }        
    }
    
    return null;
  }

  public static final int MVOneToMany = 1;
  public static final int MVReverseOneToMany = 2;
  public static final int MVRelLinksParents = 3;
  public static final int MVRelLinksChildren = 4;
  public static final int MVMaxRelKind = MVRelLinksChildren;

  public void addRelationship(String name, int kind, MVComponent comp) {
    // add to component's relationships Vector
    MVRelItem item;
    Enumeration e = relationships.elements();
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
        if(item.matches(kind,iname)) {
          // already a RelItem for this named relationship in component's relationships list
          if(item.contains(comp))
            return;
          else {
            if(comp != null)
              item.addElement(comp);
            return;
          }
        }
    }

    item = new MVRelItem(iname,kind);
    if(comp != null)
      item.addElement(comp);
    relationships.addElement(item);
  }

  public void removeRelationship(String name, int kind, MVComponent comp) {
    // remove from component's relationships Vector
                MVRelItem item;
                Enumeration e = relationships.elements();
                String iname = name.intern();

                while(e.hasMoreElements()) {
                        item = (MVRelItem) e.nextElement();
                        if(item.matches(kind,iname))
                                item.removeElement(comp);
                }
  }
  
  /*
   * Convert component data to readable (& saveable) strings
   *
   */
   
  public void writeAttributesString(MVOutputBuffer output)
  {
    Enumeration e1 = attributes.elements();
    MVAttribute a;
    
    while(e1.hasMoreElements()) {
      output.writeln("  "+((MVAttribute) e1.nextElement()).toString());
    }  

    output.writeln("  +deleted = "+deleted);

  }
  
  public void writeRelationshipsString(MVOutputBuffer output) {
    // returns relationship name/comps list as a String
      
    Enumeration e2 = relationships.elements();
    MVRelItem r;
    MVComponent c;
    
    while(e2.hasMoreElements()) {
      r = (MVRelItem) e2.nextElement();
      output.writeln("  "+ r.itemKind()+" "+'"'+r.name+'"'+" "+'"'+r.getFlags()+'"'+" =");
      
      output.write("   [ ");
        
      for(Enumeration e3 = r.elements(); e3.hasMoreElements(); ) {
        c = (MVComponent) e3.nextElement();
        output.write(c.compID);
        output.write(' ');
      }
      output.writeln(']');
    }
  }

  public String toString() {
    // convert all component data to a string...

    MVOutputBuffer output = new MVOutputBuffer();
    output.writeln("component "+compKind()+" "+compID+" "+copiedFrom);
    output.writeln("");
    output.writeln("Attributes:");
    writeAttributesString(output);
    output.writeln("");
    output.writeln("Relationships:");
    writeRelationshipsString(output);
    
    return new String(output.getBytes());
  }

        public void serialize(MVOutputBuffer output) {
                // change this to use generated ser/deser methods from JComposer...
                output.write("component ");
                output.write(compKind());
                output.write(' ');
                output.write(compID);
                output.write(' ');
                output.writeln(copiedFrom);
                output.writeln("attributes");
                writeAttributesString(output);
                output.writeln("relationships");
                writeRelationshipsString(output);
                writeSpecialStuff(output);
                output.writeln("end_comp");
                output.writeln("");
        }
        
        public void writeSpecialStuff(MVOutputBuffer output)
        {
        
        }

        public void deserialize(MVInputBuffer2 input_buffer, MVCompLocator locator) throws IOException {
    //Vector attributes = new Vector();
    //Vector relationships = new Vector();
   
    // read attributes structure

    input_buffer.readToken("attributes");
    String next = input_buffer.getToken();
     
    while(!next.equals("relationships")) {
      String name = next.intern();
      input_buffer.readToken('=');
      MVAttribute a = null;
        
      if(input_buffer.nextIsInt())
        a = new MVIntAttribute(name,(int) input_buffer.getIntToken());
      else if(input_buffer.nextIsString())
        a = new MVStringAttribute(name,input_buffer.getStringToken());
      else if(input_buffer.nextChar() == 't') {
         input_buffer.readToken("true");
         if(name == "+deleted ")
            this.deleted = true;
         else
            a = new MVBooleanAttribute(name,true);
      } else if(input_buffer.nextChar() == 'f') {
         input_buffer.readToken("false");
         if(name == "+deleted ")
            this.deleted = false;
         else
            a = new MVBooleanAttribute(name,false);
      } else {
         a = new MVStringAttribute(name,input_buffer.getToken());
      }
      
      if(a != null)
        addAttribute(a);
// System.out.println("got attr "+a);      
      next = input_buffer.getToken();                  
    }
     
    // read relationships structure

    next = input_buffer.getToken();
 
    while(!next.equals("end_comp") && !next.equals("special")) {
      String relKind = next;
      String relName = input_buffer.getStringToken().intern();
      String flags = input_buffer.getStringToken();
      input_buffer.readToken('=');
      input_buffer.readToken('[');
// System.out.println("looking at rel "+relKind+" "+relName+" "+flags);     
      MVRelItem r = null;
      
      char chars[] = relName.toCharArray();
      if(chars[0] != '+') {
                        r = new MVRelItem(relName,relKind,flags);
                        relationships.addElement(r);
        
                        if(r.listenBefore) {
                                if(listenBefores == null)
                                        listenBefores = new Vector();
                                listenBefores.addElement(r);
                        }
                        if(r.listenAfter) {
                                if(listenAfters == null)
                                        listenAfters = new Vector();
                                listenAfters.addElement(r);
                        }
                        if(r.handleBefore) {
                                if(handleBefores == null)
                                        handleBefores = new Vector();
                                handleBefores.addElement(r);
                        }
                        if(r.handleAfter) {
                                if(handleAfters == null)
                                        handleAfters = new Vector();
                                handleAfters.addElement(r);
                        }
      }

      while(input_buffer.nextChar() != ']') {        
        String key = "";
 
        if(input_buffer.nextChar() == '#')
            input_buffer.readToken('#');
        else if(input_buffer.nextChar() == '"')
            key = input_buffer.getStringToken();
        
        int relCompID = input_buffer.getIntToken();

        String relCompKind = "";
        if((input_buffer.nextChar() != ']') && !input_buffer.nextIsInt() && !input_buffer.nextIsString())
            relCompKind = input_buffer.getToken();       
        
        // need to look up compID in project's compID table...
        //
        // for import - may need to look up compKind/userName pair
        // in base view's lookup table...
        //
        // for incremental reload - do this on the fly by storing
        // whole relationships list string for component...
      
        MVComponent c = locator.findOrCreateComp(relCompID,0,relCompKind);
        if(c != null)
            addRelItem(r,locator,relName,key,c);
      }

      input_buffer.readToken(']');
      next = input_buffer.getToken();
    }      
      readSpecialStuff(input_buffer,locator);

    }
    
    public void readSpecialStuff(MVInputBuffer2 input, MVCompLocator locator) throws IOException
    {
    
    }
  
    public void addAttribute(MVAttribute a)
    {
        if(a.getPropertyName().equals("+deleted"))
            deleted = ((MVBooleanAttribute) a).isValue();
        else
            attributes.addElement(a);
    }
    
    public void addRelItem(MVRelItem r, MVCompLocator locator, String name, String key, MVComponent c)
    {
        r.addElement(c);
        // locator.reestablishRel(c,r,this);
    }

    /*
      * Change description processing
     *
     */

  public MVMacroChangeDescr macro_change = null;
  
  public MVMacroChangeDescr getMacroChange()
  {
    return macro_change;
  }

  public void recordUpdate(MVChangeDescr c) {
    // record a change description (not it hasn't been actioned yet...)
    MVMacroChangeDescr old_macro = macro_change;
    MVChangeDescr new_c = c;

    // must catch any MVAbortOperation exceptions...
    try {
      new_c = broadcastBefore(c);
        // broadcast before making state change

      if(new_c != null) {
        if(new_c instanceof MVMacroChangeDescr) {
          ((MVMacroChangeDescr) new_c).parent = old_macro;
          macro_change = (MVMacroChangeDescr) new_c;
        }
      
        // execute operation:
        new_c.execute();
      
        // switch back to old macro...
        macro_change = old_macro;
      
        broadcastAfter(new_c);
        // broadcast after making state change
        
      }
    } catch (MVAbortOperation e) {
      if(old_macro != null) {
        macro_change = old_macro;
        throw(e); // go back up to enclosing catch() block...
      } else {
        // no enclosing macro, so handle AbortOperation here
        System.out.println("Aborting operation!!!");
        new_c.undo(); // undo changes made
        macro_change = null;
          // if "inform user" abort, show in dialog???
      }
    }
  }

  public void startMacroChange(MVMacroChangeDescr mc) {
    // alternative way to do macro change descriptions - wrap code which (may)
    // generate sub change descriptions in start/endMacroChange() calls...
    MVMacroChangeDescr new_mc;

    mc.parent = macro_change;
    new_mc = (MVMacroChangeDescr) broadcastBefore(mc);
      // notify dependents about to begin macro change description...
      
    if(new_mc == null)
      throw(new MVAbortOperation());
      
    if(macro_change != null)
      macro_change.addSubChangeDescr(new_mc);
    macro_change = new_mc;
  }

  public void endMacroChange() {
    // finished a macro change...
    MVMacroChangeDescr mc = macro_change, old_mc = macro_change.parent;

    mc.execute();
      // should just set "done" flag for macro change description...
    macro_change = old_mc;
    broadcastAfter(mc);
      // notify dependents of completed macro change description...
  }

  /* 
   * "Listeners" listen to changes descriptions GENERATED by this component
   * i.e. used by broadcastBefore/After rel to propagate change descriptions
   *
   * "Handlers" listen to changes descriptions SENT to this component
   * i.e. used to implement this component's response to changes OUTSIDE
   * this components before/afterChange methods
   *
   */

  protected Vector listenBefores = null;
  protected Vector listenAfters = null;
  protected Vector handleBefores = null;
  protected Vector handleAfters = null;

  public void setListenBeforeRel(String name) {
    // add a listen-before relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.name == iname) {
                                addListenBefore(item);
                                item.listenBefore = true;
                        }
                }
        }

        public void addListenBefore(MVChangeListener obj) {
     if(listenBefores == null)
       listenBefores = new Vector();
     if(listenBefores.contains(obj))
       return;
     else
       listenBefores.addElement(obj);
  }

        public void removeListenBefore(MVChangeListener obj) {
                if(listenBefores == null)
                        return;
                listenBefores.removeElement(obj);
        }

  public void setListenAfterRel(String name) {
    // add a listen-after relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.name == iname) {
                                addListenAfter(item);
                                item.listenAfter = true;
                        }
                }
        }

        public void addListenAfter(MVChangeListener obj) {
     if(listenAfters == null)
       listenAfters = new Vector();
     if(listenAfters.contains(obj))
       return;
     else
       listenAfters.addElement(obj);
  }
  
        public void removeListenAfter(MVChangeListener obj) {
                if(listenAfters == null)
                        return;
                listenAfters.removeElement(obj);
        }

  public void setHandleBeforeRel(String name) {
    // add a handle-before relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.name == iname) {
                                addHandleBefore(item);
                                item.handleBefore = true;
                        }
                }
        }

        public void addHandleBefore(MVChangeListener obj) {
     if(handleBefores == null)
       handleBefores = new Vector();
     if(handleBefores.contains(obj))
       return;
     else
       handleBefores.addElement(obj);
  }

        public void removeHandleBefore(MVChangeListener obj) {
                if(handleBefores == null)
                        return;
                handleBefores.removeElement(obj);
        }

  public void setHandleAfterRel(String name) {
    // add a handle-after relationship
    MVRelItem item;
    Enumeration e = relationships.elements();
    String iname = name.intern();

    while(e.hasMoreElements()) {
      item = (MVRelItem) e.nextElement();
      if(item.name == iname) {
                                addHandleAfter(item);
                                item.handleAfter = true;
                        }
                }
        }

        public void addHandleAfter(MVChangeListener obj) {
     if(handleAfters == null)
       handleAfters = new Vector();
     if(handleAfters.contains(obj))
       return;
     else
       handleAfters.addElement(obj);
  }

        public void removeHandleAfter(MVChangeListener obj) {
                if(handleAfters == null)
                        return;
                handleAfters.removeElement(obj);
        }

  /*
   * Broadcasting of change descriptions
   *
   */

  public boolean responding = false;

  public MVChangeDescr broadcastBefore(MVChangeDescr c) {
    // tell all listen before components about a change...

    MVChangeDescr new_c = beforeChange(c,this,"this");
      // send to self before everything else gets a chance to look at it...
      
    if(new_c == null)
      return null;
    
    if(macro_change != null) {
      // if in a macro, add this change description to it (if not responding to another
      //  change description)
      if(!responding)
        macro_change.addSubChangeDescr(new_c);
    }

    boolean old_responding = responding;
      // note that any more change descriptions we get
      // from other comps will be in response to this one until
      // broadcastAfter() resets responding flag...
    
    if(listenBefores != null) {
      Enumeration e = listenBefores.elements();
      responding = true; 

      while(new_c != null && e.hasMoreElements())
        new_c = ((MVChangeListener) e.nextElement()).beforeChange(new_c,this);

      responding = old_responding;
    }

    return new_c;
  }

  public MVChangeDescr broadcastAfter(MVChangeDescr c) {
    // tell all listen afters about a change...
    boolean old_responding = responding;
    MVChangeDescr new_c = c;
      
    if(listenAfters != null) {
      Enumeration e = listenAfters.elements();
      responding = true; 

      while(new_c != null && e.hasMoreElements())
        new_c = ((MVChangeListener) e.nextElement()).afterChange(new_c,this);

      responding = old_responding;
    }
    
    if(new_c != null)
      return afterChange(new_c,this,"this");
    else
      return null;
      
      // send to self after everything else has looked at it. This is the time it gets
      // stored by the component that generated it...
  }
  
  public MVChangeDescr last_change = null;
    // don't store same change twice in a row - sometimes attempt to do so 
    // occurs with hierarchical structures...
    
  public MVVersionRecord newVersionRecord()
  {
      MVVersionRecord versionRecord = new MVVersionRecord();
      versionRecord.establishOneToMany("VersionRecord",this);
      setAggregateRel("VersionRecord");
      versionRecord.setTitle("Changes for: "); 
      
      return versionRecord;
  }
  
  public void storeChange(MVChangeDescr change) {
    // store a change description in this component's current version record
                MVVersionRecord versionRecord = getVersionRecord();
    
    if(versionRecord == null)
        versionRecord = newVersionRecord();
        
    if (!responding && change != last_change) {
      if(macro_change != null) {
        if(change.target != this)
          macro_change.addSubChangeDescr(change);
        // if this is the target then will already be in macro change list
      } else
                versionRecord.add_change(change);
      
      last_change = change;
    }
  }
  
  public MVChangeDescr beforeChange(MVChangeDescr c,
     MVComponent from, String rel_name) {
    // receive listen before change description...
    // this sends the change to any handle befores that exist

    if(handleBefores != null) {
      MVChangeDescr new_c = c;
      Enumeration e = handleBefores.elements();

      while(new_c != null && e.hasMoreElements())
        new_c = ((MVChangeListener) e.nextElement()).beforeReceive(new_c,from,rel_name,this);
      
      return new_c;
    } else      
      return c;
  }

  public MVChangeDescr afterChange(MVChangeDescr c, 
    MVComponent from, String rel_name) {
    // receive listen after change description
    // this sends the change to any handle afters that exist

    // Add this code in specialisations for them to store their updates
    // in version records:
    //
    //    storeChange(c); // remember our own change descriptions

    if(handleAfters != null) {
      MVChangeDescr new_c = c;
      Enumeration e = handleAfters.elements();

      while(new_c != null && e.hasMoreElements())
        new_c = ((MVChangeListener) e.nextElement()).afterReceive(new_c,from,rel_name,this);

      return new_c;
    } else      
      return c;
  }
  
  public MVChangeDescr beforeReceive(MVChangeDescr c, 
    MVComponent from, String rel_name, MVComponent sent_from, String sent_rel) {
    // receive change from component that is about to receive a change
    // i.e. this is a handle before component
    
    return c;
  }
  
  public MVChangeDescr afterReceive(MVChangeDescr c, 
    MVComponent from, String rel_name, MVComponent sent_from, String sent_rel) {
    // receive change from component that has received a change
    // i.e. this is a handle after component
    
    return c;
  }
  
  /*
   * Undo/redo suppport
   *
   */
  
  public void undo() {
    // reverse last stored change
    
    getVersionRecord().undo_last();
  }
  
  public void redo() {
    // redo last stored change
  
    getVersionRecord().redo_last();
  }
  
        public void getAggregatesRelated(Vector comps, Vector rel) {
                if(!comps.contains(this)) {
                        comps.addElement(this);

                        Enumeration rels = getRelationships().elements();

                        while(rels.hasMoreElements()) {
                                MVRelItem r = (MVRelItem) rels.nextElement();
System.out.println("checking rel item "+r.name+" for "+compID);
                                if(r.aggregate) {
System.out.println(" adding aggregates!!");
                                        Enumeration items = r.elements();
                                        while(items.hasMoreElements()) {
                                                ((MVComponent) items.nextElement()).getAggregatesRelated(comps,rel);
                                        }
                                } else {
System.out.println(" adding related!!");
                                        Enumeration items = r.elements();
                                        while(items.hasMoreElements()) {
                                                MVComponent c = (MVComponent) items.nextElement();
                                                if(c instanceof MVRelationship) {
                                                        if(((MVRelationship) c).isParent(this)) {
                                                                comps.addElement(c);
                                                                Enumeration rel_items = ((MVRelationship) c).children();
                                                                while(rel_items.hasMoreElements()) {
                                                                        MVComponent rc = (MVComponent) rel_items.nextElement();
                                                                        if(!comps.contains(rc) && !rel.contains(rc))
                                                                                rel.addElement(rc);
                                                                }
                                                        }
                                                } else
                                                        if(!comps.contains(c) && !rel.contains(c)) {
                                                                rel.addElement(c);
                                                        }
                                        }
                                }
                        }
                }
        }

    public BBWPropertySheetPanel getPropertySheetPanel()
    {
        BBWPropertySheet ps = new BBWPropertySheet(this,getEditableProperties());
        return ps.getPanel();
    }


  public void showPropertySheet() {
                new PropSheetAdaptor(new BBWPropertySheet(compKind()+" Property Sheet",this,getEditableProperties(),10,10));
        }

        /**
         * An inner class listener adaptor, which passes JViews component SetValue
         * changes through to the PropertySheet.  If the property sheet is
         * invisible (when it's disposed of???), the adaptor finishes.
         */

  class PropSheetAdaptor implements MVChangeListener {
                PropSheetAdaptor(BBWPropertySheet propertySheet) {
                        this.propertySheet = propertySheet;
                        MVComponent.this.addListenAfter(this);
                }

                public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent comp) {
                        return c;
                }

                public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent sent_from,
                                String sent_rel, MVComponent comp) {
                        return c;
                }

                public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent sent_from, 
                                String sent_rel, MVComponent comp) {
                        return c;
                }

                public MVChangeDescr afterChange(MVChangeDescr c, MVComponent comp) {
                        if(c.targets(MVComponent.this) && propertySheet.isVisible())
                                propertySheet.wasModified(null);
                        if(!propertySheet.isVisible())
                        MVComponent.this.removeListenAfter(this);

                                return c;
                        }

                        private BBWPropertySheet propertySheet;
        }

        public String [] getEditableProperties() {
                Vector attrs = getAttributes();
                String ss[] = new String[attrs.size()];
                int i = 0;
                Enumeration e = attrs.elements();

                while(e.hasMoreElements()) {
                        String attrName = ((MVAttribute) e.nextElement()).getPropertyName();
                        ss[i++] = smallFirstLetter(attrName);
                }

                return ss;
        }
        
  private String smallFirstLetter(String s) {
                char chars[] = s.toCharArray();
                chars[0] = Character.toLowerCase(chars[0]);
                return new String(chars);
  }
  
  public void runMessage(MVMessage mesg)
  {

    try {
            Object args[] = mesg.getArgs();
            Class params[] = new Class[args.length];
 
 System.out.print("Calling: "+mesg.getTarget()+userName()+"."+mesg.getName()+"(");           
            int i;
            for(i=0;i<args.length;i++) {
                params[i] = args[i].getClass();
      System.out.print(args[i].toString()+",");
            }
   System.out.println(")");
            
            Method method = mesg.getTarget().getClass().getMethod(mesg.getName(),params);
          System.out.println("About to run: "+method);  
            Object result = method.invoke(mesg.getTarget(), args);
            mesg.setResult(result);
        } catch (Exception e) {
          System.out.println("MVMessage.execute() got: "+e);
            mesg.setException(e.toString());
            throw(new MVFatalException("MVMessage.execute() got: "+e));
        }
    }
    
    public MVAspects getAspects()
        // return MVAspects structure for this component
        // should modify to allow this to be obtained from a
        // class of the form compKind()+"AspectInfo", like BeanInfo
        // classes...
    {
        MVAspects aspects = new MVAspects(this);
        
        // default is to just use introspection & JViews design patterns
        // to grab property & relationship info
        //
        // subclasses should override to add their own custom property,
        // relationship, human interface, distribution, persistence,
        // etc. aspects...
        
        aspects.getDefaultInfo();
        
        return aspects; 
    }
    
}

