package JViews;

import java.io.*;

public class MVInputBuffer {

    public MVInputBuffer() {

    }

    public MVInputBuffer(StreamTokenizer input_stream) {
        input = input_stream;
    }

    public MVInputBuffer(byte bytes[]) {
        buffer = new ByteArrayInputStream(bytes);
        input = new StreamTokenizer(new InputStreamReader(buffer));
        input.eolIsSignificant(false);
        input.whitespaceChars(0,32);
        input.wordChars(33,127);
        input.quoteChar('"');
    }

    protected ByteArrayInputStream buffer;

    protected StreamTokenizer input;

  // token reading support functions...

    public int nextToken() throws IOException {
            return input.nextToken();
    }

    public void pushBack() {
        input.pushBack();
    }

  public void readToken(String value) throws IOException {
    // read a string token
    
   input.nextToken();
   if(input.sval == null)
        syntaxError("Expected "+value+", got non-token");
   else if(input.sval.equals(value))
        return;
    syntaxError(value+" expected - got "+input.sval);
  }
  
  public void syntaxError(String msg) {
    System.out.println("Syntax error on line "+input.lineno()+": "+msg);
    throw(new MVSyntaxErrorException("syntax error"));
  }
  
  public String getStringToken() throws IOException {
    // return read string token
    
    if(input.nextToken() != '"')
      syntaxError("string value expected - got "+input.sval);
      
    return input.sval;
  }
  
  public String getToken() throws IOException {
    // return read some token
    
    if((input.nextToken() == input.TT_EOF) || (input.sval == null))
      syntaxError("token value expected - got EOF");
      
    return input.sval;
  }

  public int getIntToken() throws IOException {
    if(input.nextToken() != input.TT_NUMBER)
      syntaxError("wanted int value - got "+input.sval);
    return (int) input.nval;
  }

    public boolean checkNextToken(String wanted) throws IOException {
        int t = nextToken();
        pushBack();
        if(t == input.TT_WORD && input.sval.equals(wanted))
            return true;
        return false;
    }

    public boolean checkNotEOF() throws IOException {
        int t = nextToken();
        pushBack();
        return (t == input.TT_EOF);
    }

    public boolean getBooleanToken() throws IOException {
        String t = getToken();
        if(t.equals("true"))
            return true;
        if(t.equals("false"))
            return false;
        syntaxError("wanted boolean token - got "+input.sval);

        return false;
    }

}

