
package JViews;

import java.util.*;
import java.awt.*;
import java.awt.event.*;

public abstract class MVAspect
{

    public MVAspect()
    {
    
    }
    
    public abstract String getAspectKind();
    
    public abstract String toString();
    
    public void showAspectInfo()
    {
        MVAspectFrame f = new MVAspectFrame(this);
        f.setVisible(true);
    }
    
    public abstract Vector getAspectInfos();
    
    public String validate(MVAspects as)
    {
        return null;
    }

}


class MVAspectFrame extends Frame  implements ActionListener
{

    MVAspect as;
    
    List aspects = new List();
    Panel p1 = new Panel();
    TextArea extraInfo = new TextArea("",2,50);
    Button close = new Button("Close");

    public MVAspectFrame(MVAspect as)
    {
        super(as.getAspectKind()+" aspect information");
        this.as = as;
        
        setLayout(new GridLayout(2,1));
        add(aspects);
        aspects.addActionListener(this);
        add(p1);
        p1.setLayout(new GridLayout(2,1));
        p1.add(extraInfo);
        p1.add(close);
        close.addActionListener(this);
        
        Enumeration e = as.getAspectInfos().elements();
        while(e.hasMoreElements()) {
            MVAspectInfo info = (MVAspectInfo) e.nextElement();
            aspects.addItem(info.getBasicInfo());
        }
        
        setSize(200,300);
        pack();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == close)
            setVisible(false);
        else if(e.getSource() == aspects) {
            MVAspectInfo a = (MVAspectInfo) as.getAspectInfos().elementAt((aspects.getSelectedIndex()));
            extraInfo.setText(a.getInfo());
        }
    }

}
