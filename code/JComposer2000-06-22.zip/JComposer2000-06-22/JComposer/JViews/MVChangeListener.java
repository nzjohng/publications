package JViews;

public interface MVChangeListener {

  public abstract MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from);
        // listener gets change description before state change done

  public abstract MVChangeDescr afterChange(MVChangeDescr c, MVComponent from);
        // listener gets change description after state change done

  public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent sent_from, 
      String sent_rel, MVComponent from);
        // listener gets change before listening component from gets it

  public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent sent_from, 
      String sent_rel, MVComponent from);
        // listener gets change after component from gets it

}

