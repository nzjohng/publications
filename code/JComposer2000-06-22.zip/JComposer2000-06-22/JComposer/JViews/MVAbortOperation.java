package JViews;

class MVAbortOperation extends MVException {

  public MVAbortOperation() {
    super("MVAbortOperation");
  }

}
