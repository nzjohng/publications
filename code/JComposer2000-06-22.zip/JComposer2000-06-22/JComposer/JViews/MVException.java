package JViews;

public class MVException extends RuntimeException {

  public String message;
  
  public MVException(String message) {
    this.message = message;
  }
  
  public String toString()
  {
    return message;
  }

}
