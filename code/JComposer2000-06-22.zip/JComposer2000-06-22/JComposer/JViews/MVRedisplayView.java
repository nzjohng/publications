
package JViews;

public class MVRedisplayView extends MVViewEvent
{

    public MVRedisplayView(MVViewLayer v)
    {
        super(v);
    }   
    
    public void execute() { }
    
    public void undo() { }
    
    public void redo() { }
    
    public String toString()
    {
        return "RedisplayView "+view.getName();
    }

}
