package JViews;

import java.awt.*;
import java.awt.event.*;
import bbw.*;

public class MVViewFrame extends Frame implements ActionListener, WindowListener, ComponentListener {
  public MVViewLayer view;
  
  public MVViewFrame(MVViewLayer view) {
    super();
    this.view = view;
    setTitle(view.getName());
    addFrameMenus();
    setMenuBar(menuBar);
    if(view.getWidth() > 0 && view.getHeight() > 0)
        setBounds(new Rectangle(view.getX(),view.getY(),view.getWidth(),view.getHeight()));
    else
        setBounds(new Rectangle(0,0,500,500));
    addWindowListener(this);
    addComponentListener(this);
  }
  
  protected MenuBar menuBar = new MenuBar();
    
    protected MenuItem saveProject = new MenuItem("Save Project");
    protected MenuItem exportView = new MenuItem("Export View to File");
    protected MenuItem importView = new MenuItem("Import View from File");
    
    protected MenuItem undoItem = new MenuItem("Undo");
    protected MenuItem redoItem = new MenuItem("Redo");
    protected MenuItem hideHandles = new MenuItem("Hide All Handles");
    protected MenuItem showHandles = new MenuItem("Show All Handles");
    protected MenuItem cleanup = new MenuItem("*Clean Up*");
    

    protected MenuItem newView = new MenuItem("New View");
    protected MenuItem chooseView = new MenuItem("Choose View");
    protected MenuItem renameView = new MenuItem("Rename View");
    protected MenuItem deleteView = new MenuItem("Delete View");
    protected MenuItem inspectView = new MenuItem("Inspect View");
    protected MenuItem visViewPrev = new MenuItem("Visualise View in Prev");
    protected MenuItem visViewNew = new MenuItem("Visualise View in New");
    protected MenuItem visBasePrev = new MenuItem("Visualise Base in Prev");
    protected MenuItem visBaseNew = new MenuItem("Visualise Base in New");

    protected MenuItem showChanges = new MenuItem("Show Changes");
    protected MenuItem importChanges = new MenuItem("Import Changes from File");

protected MenuItem addListener = new MenuItem("Add Listener");
protected MenuItem chooseComp = new MenuItem("Choose Component");

  public void addFrameMenus() {
System.out.println("adding MVViewFrame menus...");
        // File menu
    Menu fileMenu = new Menu("File");
        fileMenu.add(saveProject);
        fileMenu.add(exportView);
        fileMenu.add(importView);
        saveProject.addActionListener(this);
        exportView.addActionListener(this);
        importView.addActionListener(this);

    Menu editMenu = new Menu("Edit");
    editMenu.add(undoItem);
    undoItem.addActionListener(this);
    editMenu.add(redoItem);
    redoItem.addActionListener(this);
    editMenu.add("-");
    editMenu.add(hideHandles);
    hideHandles.addActionListener(this);
    editMenu.add(showHandles);
    showHandles.addActionListener(this);
    editMenu.add("-");
    editMenu.add(cleanup);
    cleanup.addActionListener(this);

        // View menu
    Menu viewMenu = new Menu("View");
    viewMenu.add(newView);
        newView.addActionListener(this);
    viewMenu.add(chooseView);
        chooseView.addActionListener(this);
    viewMenu.add(renameView);
        renameView.addActionListener(this);
    viewMenu.add(deleteView);
        deleteView.addActionListener(this);
        viewMenu.addSeparator();
        viewMenu.add(inspectView);
        inspectView.addActionListener(this);
        viewMenu.add(visViewPrev);
        visViewPrev.addActionListener(this);
        viewMenu.add(visViewNew);
        visViewNew.addActionListener(this);
        viewMenu.add(visBasePrev);
        visBasePrev.addActionListener(this);
        viewMenu.add(visBaseNew);
        visBaseNew.addActionListener(this);
        
        viewMenu.add(addListener);
        addListener.addActionListener(this);
        viewMenu.add(chooseComp);
        chooseComp.addActionListener(this);

        // Changes menu
        Menu changesMenu = new Menu("Changes");
        changesMenu.add(showChanges);
        showChanges.addActionListener(this);
        changesMenu.add(importChanges);
        importChanges.addActionListener(this);

        // Menu bar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(viewMenu);
        menuBar.add(changesMenu);

        view.recordUpdate(new MVAddedViewMenus(view));
  }

    public void addMenu(Menu m) {
        menuBar.add(m);
    }

    public boolean addMenuItem(String menu, MenuItem item)
    {
        for(int i = 0; i < menuBar.getMenuCount(); i++) {
            if(menuBar.getMenu(i).getLabel().equals(menu)) {
                menuBar.getMenu(i).add(item);
                return true;
            }
        }

        return false;
    }
    
    protected Label messagePanel = new Label("");
    
    public void setMessage(String mesg)
    {
        messagePanel.setText(mesg);
    }
  
    public void windowClosing(WindowEvent e) {
    System.out.println(e);
        setVisible(false);
        
    }
  
  public void windowActivated(WindowEvent e) {
    view.makeCurrent();
  }
    
  public void windowOpened(WindowEvent e) {}
  public void windowClosed(WindowEvent e) {}
  public void windowDeactivated(WindowEvent e) {}
  
  public void windowDeiconified(WindowEvent e) {}
  public void windowIconified(WindowEvent e) {} 
  
  public void componentHidden(ComponentEvent e) {}
  
  public void componentMoved(ComponentEvent e) {
    Rectangle b = getBounds();
    if(b.x < 1500 && b.y < 1500) {
        view.startMacroChange(new MVMacroChangeDescr(view,"Moved window"));
        view.setX(b.x);
        view.setY(b.y); 
        view.endMacroChange(); 
    }
  }
  
  public void componentResized(ComponentEvent e) {
    Rectangle b = getBounds();
    view.startMacroChange(new MVMacroChangeDescr(view,"Resized window"));
    view.setWidth(b.width);
    view.setHeight(b.height);
    view.endMacroChange();
  }
   
  public void componentShown(ComponentEvent e) {}

  public void actionPerformed(ActionEvent e) {
        if(e.getSource() == saveProject)
            view.getBaseLayer().getProject().save();
                else if(e.getSource() == exportView)
                    view.exportViewToFile();
                else if(e.getSource() == importView)
                    view.importViewFromFile();
        else if (e.getSource() == newView)
          view.newView();
        else if (e.getSource() == chooseView)
          view.getBaseLayer().chooseView();
        else if (e.getSource() == renameView)
          view.renameView();
        else if (e.getSource() == deleteView)
          System.out.println("Delete View selected");
                else if (e.getSource() == inspectView)
                    view.inspectView();
                else if(e.getSource() == showChanges)
                    view.showChanges();
                else if(e.getSource() == importChanges)
                    view.importChanges();
                else if(e.getSource() == visViewPrev)
                    view.visualisePrev();
                else if(e.getSource() == visViewNew)
                    view.visualiseNew();
                else if(e.getSource() == visBasePrev)
                    view.visualiseBasePrev();
                else if(e.getSource() == visBaseNew)
                    view.visualiseBaseNew();
                else if(e.getSource() == undoItem)
                    view.doUndoItem();
                else if(e.getSource() == redoItem)
                    view.doRedoItem();
                else if(e.getSource() == hideHandles)
                    view.hideHandles();
                else if(e.getSource() == showHandles)
                    view.showHandles();
                else if(e.getSource() == cleanup)
                    view.cleanup();
                    
                else if(e.getSource() == addListener)
                {
                System.out.println("add listener...");
                    Actions.JCASimpleListenerWizard1 wiz = new Actions.JCASimpleListenerWizard1();
                    wiz.addView(view);
                    wiz.wizardSetUp();
                }
                else if(e.getSource() == chooseComp)
                {
                    Actions.JCASimpleChooserWizard1 wiz = new Actions.JCASimpleChooserWizard1();
                    wiz.addView(view);
                    wiz.wizardSetUp();
                }
    }

    public void addedViewComp(MVViewComp c) {

    }

    public void viewRenamed() {
System.out.println("View renamed to: "+view.getName());
        setTitle(view.getName());
    }

    public BBWContainer getBBWContainer()
    {
		BBWContainer cont= null;

		Component comps[] = getComponents();

		for(int i=0;i<comps.length;i++) {
			if(comps[i] instanceof BBWGeneralPanel)
				return ((BBWGeneralPanel) comps[i]).getPanel().getTopContainer();
		}

		return cont;
    }

}

/*
class MVMessagePanel extends Panel
{
    MVViewFrame frame;
    Label label = new Label();

    public MVMessagePanel(MVViewFrame f)
    {
        frame = f;
        
        add(label);
    }
    
    public void setMessage(String mesg)
    {
        label.setText(mesg);
    }


  
}
*/
