package JViews;

import java.util.*;
import java.io.*;

/*
 * Simple persistency - write all data to a text file
 *
 */

public class MVSimplePersistency extends MVPersistency {

  public MVSimplePersistency(MVProject project) {
    super(project);
  }
  
    protected OutputStream outFile = null;
  protected BufferedOutputStream output = null;
  // protected PrintStream output = null;
  
  public boolean prepareToSave(String file_name, String path) {
    if(file_name == null)
      return false;
      
    try {
            outFile = new FileOutputStream(new File(path,file_name));
      output = new BufferedOutputStream(outFile);
      
      return true;
    } catch (Exception e) {
      System.out.println("Couldn't open file "+file_name);
    }
    
    return false;
  }

  public void finishedSaving() {
  
  System.out.println("");
  
    try {
      output.flush();
      outFile.flush();
      outFile.close();
    } catch (Exception e) {
       throw(new MVFatalException(
         "Can't close file in MVSimplePersistency.finishedSaving()"));
    }
  }
  
    protected MVOutputBuffer buffer = new MVOutputBuffer();

    int numSaved = 0;

  public void saveComponent(MVComponent comp) throws IOException {
    // save component data as text to a file...
    MVRelItem r;

numSaved++;
if(numSaved % 10 == 0)  
    System.out.print(" "+numSaved);

            buffer.reset();
            comp.serialize(buffer);
            byte bytes[] = buffer.getBytes();
            output.write(bytes,0,bytes.length);
  }
  
  public void saveProjectData(MVProject project) {

        try {                                                                           
            buffer.reset();
        buffer.writeln("project "+'"'+project.getName()+'"'+" "+project.getIDCounter()+"  "+project.getIncrement());
            byte bytes[] = buffer.getBytes();
            output.write(bytes,0,bytes.length);
    
            Enumeration e = project.components.elements();

            while(e.hasMoreElements()) {
                // SimplePersistency writes entire list of components out to start of save
                // file (as does export/import of component...
                // More sophisticated approaches would have a file-based data structure
                // to store this info persistently & so it can be easily looked up on demand
                MVComponent c = (MVComponent) e.nextElement();
                buffer.reset();
                buffer.write(c.compID);
                buffer.write(' ');
                buffer.write(c.copiedFrom);
                buffer.write(' ');
                buffer.write(c.compKind());
                buffer.write(' ');
                buffer.write('"');
                buffer.write(c.userName());
                buffer.writeln('"');
                bytes = buffer.getBytes();
                output.write(bytes,0,bytes.length);
            }

  numSaved = 0;
    
        } catch (IOException ex) {
            throw(new MVFatalException("IO error writing project data"));
        }
  }
  
  protected FileInputStream inputFile = null;
  protected BufferedInputStream input = null;
    protected MVInputBuffer2 input_buffer  = null;
  
  public boolean loadProject() {
    String file_name = project.getFileName();
    if(file_name == null)
      return false;

    try {
          project.setLoading(true);
          MVApplication.application.makeCurrent(project,null,null);

      inputFile = new FileInputStream(
        new File(project.directory_name,file_name));

        input = new BufferedInputStream(inputFile,4096);
/*      
      input = new StreamTokenizer(new InputStreamReader(
                new BufferedInputStream(inputFile,4096)));
      input.eolIsSignificant(false);
      input.whitespaceChars(0,32);
      input.wordChars(33,127);
      input.quoteChar('"');
  */
      
      // reload project data...

            input_buffer = new MVInputBuffer2(input);
      
      String name = readProjectData();

numSaved = 0;

      while(!input_buffer.EOF()) {
        MVComponent c = readComponent();

numSaved++;
if(numSaved % 10 == 0)
    System.out.print(" "+numSaved);

                if(c instanceof MVBaseLayer) {
                    project.addBaseLayer((MVBaseLayer) c);
                    //input_buffer.nextToken();
                    //input_buffer.pushBack();
                }
      }

System.out.println("");
    
      inputFile.close();
      project.setLoading(false);
      if(project.getName().equals(""))
        project.setName(name);
        
System.out.println(project);
      
      return true;
    } catch (FileNotFoundException e) {
      System.out.println("Couldn't open file "+file_name);
            return false;
    } catch (IOException e) {
      System.out.println("IO exception while reading from "+file_name);
            return false;
    } catch (Exception e) {
            System.out.println("Exception while reading from "+file_name);
e.printStackTrace();
            return false;
    }
    
  }

  // read project data in
  
  private String readProjectData() throws IOException {
    input_buffer.readToken("project");
    String name = input_buffer.getStringToken();
        int id = input_buffer.getIntToken();
        int left = input_buffer.getIntToken();
        
        project.setIDCounter(id);
        project.setIncrement(left);
System.out.println("reading in project "+name);

        while(input_buffer.nextIsInt()) {
            // read in component info & recreate...
            int compID = input_buffer.getIntToken();
            int copyID = compID;
            if(input_buffer.nextIsInt())
                copyID = input_buffer.getIntToken();
            String compKind = input_buffer.getToken();
            String userName = input_buffer.getStringToken();
            project.findOrCreateComp(compID,copyID,compKind);
        }
        
        return name;

  }
  
  
  // read in a persistent component's saved state
  // and reconstruct the component in memory
  //
  // relationship links all restored here
  // could modify to be incremental by reading string for each relationship's
  // links & looking them up dynamically when required...
  
  private MVComponent readComponent() throws Exception {
    input_buffer.readToken("component");
    String compKind = input_buffer.getToken();
    int compID = input_buffer.getIntToken();
    int copyID = input_buffer.getIntToken();
    MVComponent c = project.findOrCreateComp(compID,copyID,compKind);
    try {
        c.deserialize(input_buffer,project);
    } catch (Exception e) {
        System.out.println("Exception while restoring "+compKind+" "+compID+" "+copyID);
        throw(e);
    }
    
    return c;
  }
  
    public void writeBufferToFile(MVOutputBuffer buffer, String file_name, String path) {
        if(prepareToSave(file_name,path)) {
          byte bytes[] = buffer.getBytes();
            try {
            output.write(bytes,0,bytes.length);
            } catch (IOException e) {
                throw(new MVFatalException("Error on writing buffer"));
            }
          finishedSaving();
        }
    }

    public MVInputBuffer2 readBufferFromFile(String file_name, String path) {
        try {
      inputFile = new FileInputStream(
        new File(path,file_name));
      
      input = new BufferedInputStream(inputFile,4096);

      
      // reload project data...

            input_buffer = new MVInputBuffer2(input);
      
            return input_buffer;
    } catch (FileNotFoundException e) {
      System.out.println("Couldn't open file "+path+" "+file_name);
            return null;
        }
    }

}

