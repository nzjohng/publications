package JViews;

import java.io.*;

public class MVBooleanAttribute extends MVAttribute {
  public boolean value;

  public MVBooleanAttribute(String init_name, boolean init_value) {
    name = init_name;
    value = init_value;
  }
  
  public void setValue(boolean new_value) {
    value = new_value;
  }

    public boolean isValue() {
        return value;
    }

  public String toString() {
    return (name+" = "+value);
  }
  
  public boolean isBlank() {
    return !value;
  }
  
  public void setCompValue(MVComponent c) {
    c.setValue(name,value);
  }
}
