package JViews;

import java.util.*;

public class MVVectorRel extends MVRelationship {
    // Vector relationship components

  private MVComponent parent_comp;
  private Vector child_comps = new Vector();

  public MVVectorRel(String rel_name) {
    super(rel_name);
  }
  
  public MVVectorRel() {
    super();
  }
  
  public MVVectorRel(String rel_name, MVComponent parent_comp) {
    super(rel_name);
    this.parent_comp = parent_comp;
    parent_comp.addRelationship(this.relName(),MVComponent.MVRelLinksChildren,this);
  }

  public Enumeration parents() {
    // parents linked by this relationship comp.
    Vector v = new Vector();

        if(parent_comp != null)
        v.addElement(parent_comp);

    return v.elements();
  }

  public Enumeration children() {
    // children linked by this relationship comp.

     return child_comps.elements();
    }

  public void establish(MVComponent parent, MVComponent child) {
    boolean changed = false;
    MVEstablishRel cd;
    
    if(parent != null && parent_comp != parent)
      changed = true;
    else if(child != null && !child_comps.contains(child))
      changed = true;
    
    if(changed) {
      cd = new MVEstablishRel(this,parent,child);
      recordUpdate(cd);
    }
  }

    public void dissolve(MVComponent parent, MVComponent child) {
        if(child != null) {
            if(child_comps.contains(child)) {
                MVDissolveChild cd = new MVDissolveChild(this,parent,child);
                recordUpdate(cd);
            }
        }
    }

  public void addParent(MVComponent parent) {
    parent_comp = parent;
  }

  public void addParent(String key, MVComponent parent) {
    parent_comp = parent;
  }

  public void removeParent(MVComponent parent) {
    parent_comp = null;
  }

  public void addChild(MVComponent child) {
    if(!child_comps.contains(child))
      child_comps.addElement(child);
  }

  public void addChild(String key, MVComponent child) {
    if(!child_comps.contains(child))
      child_comps.addElement(child);
  }

    public void removeChild(MVComponent child) {
        child_comps.removeElement(child);
    }

}
