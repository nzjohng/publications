package JViews;

public abstract class MVAspectInfo
{

    String info = "";
        // human-readable description of this aspect info item

    public MVAspectInfo()
    {
    
    }
    
    public MVAspectInfo(String info)
    {
        this.info = info;   
    }
    
    public abstract String toString();
    
    public String getInfo()
    {
        return info;
    }

    public abstract String getBasicInfo();

}


