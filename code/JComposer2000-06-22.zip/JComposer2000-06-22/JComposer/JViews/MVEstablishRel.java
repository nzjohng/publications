package JViews;

import java.io.*;
import java.util.*;

public class MVEstablishRel extends MVChangeDescr {
  public MVComponent parent;
  public MVComponent child;

  public MVEstablishRel(MVRelationship init_target, MVComponent init_parent,
    MVComponent init_child) {
    target = init_target;
    parent = init_parent;
    child = init_child;
  }

    public MVEstablishRel() {
        super();
    }

  public MVRelationship relTarget() {
    return (MVRelationship) target;
  }

    public MVComponent getParent() {
        return parent;
    }

    public MVComponent getChild() {
        return child;
    }

  public void execute() {
    // establish links from rel comp. to parent/child & from parent/child to rel comp.
        if(parent != null)
        parent.broadcastBefore(this);
        if(child != null)
        child.broadcastBefore(this);
        if(parent != null)
        relTarget().addParent(parent);
        if(child != null)
        relTarget().addChild(child);
        if(parent != null)
        parent.addRelationship(relTarget().relName(),MVComponent.MVRelLinksChildren,target);
        if(child != null)
        child.addRelationship(relTarget().relName(),MVComponent.MVRelLinksParents,target);
        if(parent != null)
        parent.broadcastAfter(this);
        if(child != null)
        child.broadcastAfter(this);
    done = true;
  }

  public void undo() {
    relTarget().dissolve(parent,child);
  }

  public void redo() {
    relTarget().establish(parent,child);
  }

  public String toString() {
    return ("EstablishRel "+relTarget().relName()+" "+parent.userName()+" to "+child.userName());
  }
  
  public boolean targets(MVComponent c) {
    if(target == c)
      return true;
    if(parent == c)
      return true;
    if(child == c)
      return true;
      
    return false;
  }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        super.getAggregatesRelated(aggs,rel);
        if(!rel.contains(parent))
            rel.addElement(parent);
        if(!rel.contains(child))
            rel.addElement(child);
    }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(parent);
        output.writeln(child);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        int pid = input.getIntToken();
        int cid = input.getIntToken();
        parent = locator.findOrCreateComp(pid,0,"");
        child = locator.findOrCreateComp(cid,0,"");
    }

    public boolean isValid()
    {
        return super.isValid() && (parent != null && child != null);
    }


}
