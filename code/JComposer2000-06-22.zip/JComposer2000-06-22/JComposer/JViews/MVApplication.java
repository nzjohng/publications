package JViews;


/*
 * MVApplication
 *
 * Organises all projects open at one time for
 * a JViews environment
 *
 * Only one instance of MVApplication (or its specialisations) are
 * ever created for a JViews environment.
 *
 */

import java.awt.List;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

public class MVApplication {

  protected String user = null;
    // user's name
    
  protected int port = 0;
    // port ID for their server
    
  protected MVCollabServer collabServer = null;
  
  protected String registrar = null;
  
  protected int regPort = 0;

  public static MVApplication application = null;
     // THE application object for a JViews environment - only can be one of these

  public static MVProject current_project = null;
     // the currently-selected project. Determined by which view layer is
     // the "front" window

  public static MVBaseLayer current_base = null;

  public static MVViewLayer current_view = null;
   
  public Vector projects = new Vector();
     // all currently open projects

  public Vector getProjects()
  {
	return projects;
  }

   public MVProjectsFrame projects_frame;
  
   public MVApplication() {
     MVApplication.application = this;
   
     // open projects window...
   
     projects_frame = new MVProjectsFrame("Projects");
     
     collabServer = createCollabServer();
   }
   
   public MVCollabServer createCollabServer()
   {
        return new MVCollabServer(this);
   }
   
   public void setUserName(String name)
   {
        user = name;
   }
   
   public void setPort(int p)
   {
        port = p;
   }
   
   public void setRegistrar(String host)
    {
        registrar = host;
    }
    
    public void setRegPort(int p)
    {
        regPort = p;
    }
    
    public String getUserName()
    {
        return user;
    }    
    
    public String getHost()
    {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            System.out.println(e);
            return null;   
        }
    }
    
    public int getPort()
    {
        return port;
    }
    
   protected int startID = 1;
   protected int increment = 1;
 
   public boolean register()
   {
        if(regPort == 0)
            return false;
            
        try {
            MVClient c = new MVClient();
            if(c.connect(user,"",registrar,regPort)) {
                c.sendRequest("registration");
                c.sendRequest(user);
                c.sendRequest(InetAddress.getLocalHost().getHostName());
                c.sendRequest(""+port);
                startID = Integer.parseInt(c.getStringReply());
                if(startID > 0)
                    increment = Integer.parseInt(c.getStringReply());
                c.sendRequest("DONE");
                c.close();
                
                if(startID > 0)
                    return true;
                else {
                    System.out.println("*** Registration server rejected request!!");
                    // single-user project mode...
                    startID = 1;
                    increment = 1;
                    return false;
                }
            } 
        } catch  (UnknownHostException e) {
            System.out.println("Registration: "+e);
        }
        
        return false;
   }
   
   public boolean getUserInfo(MVProject p)
   {   
        if(regPort == 0)
            return false;
                 
        try {
            MVClient c = new MVClient();
            if(c.connect(user,"",registrar,regPort)) {
                c.sendRequest("getUserList");
                boolean done = false;
                while(!done) {
                    String name = c.getStringReply();
                    if(name.equals("DONE"))
                        done = true;
                    else {
                        String host = c.getStringReply();
                        int port = Integer.parseInt(c.getStringReply());
                        p.addCollabUserInfo(name,host,port);
                    }
                }
                c.sendRequest("DONE");
                c.close();
                return true;
            } 
        } catch  (Exception e) {
            System.out.println("getUserInfo: "+e);
        }
        
        return false;
   
   }
     
   public void suspendServer()
   {
        collabServer.suspend();     
   }
   
   public void resumeServer()
   {
        collabServer.resume();
   }
   
   public String getDefaultName()
   {
        return "john";
   }    
   
   public String getDefaultPort()
   {
        return "5000";
   }
   
   public String getDefaultServerHost()
   {
        return "johngvp.cs.waikato.ac.nz";
   }
   
   public String getDefaultServerPort()
   {
        return "5010";
   }
   
   public void addProject(MVProject p) {
     projects.addElement(p);
   }
   
   public MVProject findProjectName(String name) {
        Enumeration e = projects.elements();
        
        while(e.hasMoreElements()) {
            MVProject p = (MVProject) e.nextElement();
            if(p.getName().equals(name))
                return p;
        }
        
        return null;
   }
   
   public void makeCurrent(MVProject project, MVBaseLayer base, MVViewLayer view) {
     current_project = project;
     current_base = base;
     current_view = view;
     // inform prev. project of change in status??
   }

   public MVViewLayer getCurrentView()
   {
        return current_view;
   }   
   
   public void allocID(MVComponent comp) {
     if(comp instanceof MVProject) {
       comp.setCompID(0);
       comp.setCopiedFrom(0);
     } else if(current_project != null && !current_project.loading)
       current_project.allocCompID(comp);
   } 

   public MVProject newProject() {
     return new MVProject("");
   }

}

class MVProjectsFrame extends Frame implements WindowListener {
  MVProjectsListPanel listPanel = new MVProjectsListPanel();
//  MVBaseListPanel basePanel = new MVBaseListPanel();
//  MVViewListPanel viewPanel = new MVViewListPanel();
  TextField nameField = new TextField("ProjectName");
  MVProjectsButtonPanel buttonPanel = new MVProjectsButtonPanel(this);
 
  public MVProjectsFrame(String title) {
    super(title);
    addWindowListener(this);
    setLayout(new BorderLayout());
    add("North",listPanel);
//    add(basePanel);
//    add(viewPanel);
    add("Center",nameField);
    add("South",buttonPanel);
//    setSize(300,250);
    pack();
    setVisible(true);
  }
  
  public void windowClosing(WindowEvent e) {
  System.out.println(e);
    setVisible(false);
  }
  
  public void windowActivated(WindowEvent e) {}  
  public void windowOpened(WindowEvent e) {}
  public void windowClosed(WindowEvent e) {}
  public void windowDeactivated(WindowEvent e) {}
  public void windowDeiconified(WindowEvent e) {}
  public void windowIconified(WindowEvent e) {} 
  
  public void redisplayProjects() {
    // redisplay info after project manipulations...
    
    listPanel.setListValues(MVApplication.application);
    validate();
  }
  
  public void redisplayBaseLayers() {
  
  }
  
  public void redisplayViewLayers() {
  
  }
  
  public void doNew() {
    // create a new project
    // need to ask for name & file name to store data in
    
    MVProject p = MVApplication.application.newProject();
    p.setName(nameField.getText());
    p.openProjectInfo();
    MVApplication.application.addProject(p);
    MVApplication.application.makeCurrent(p,null,null);
    
    redisplayProjects();
  }
  
  public void doOpen() {
    // open an existing JViews project file

    MVProject p = MVApplication.application.newProject();
    
    if(p.openProject()) {
      p.openProjectInfo();
        MVApplication.application.addProject(p);
        MVApplication.application.makeCurrent(p,null,null);
        redisplayProjects();
    }
  }
  
  public void doSave() {
    MVApplication.application.current_project.save(); 
  }
  
  public void doNewView() {
  
  }
  
  public void doShowView() {
  
  }
  
  public void doClose() {
System.out.println("doClose");  
  }
  
  public void doQuit() {
System.out.println("doQuit");  
  
  }

}

class MVProjectsListPanel extends Panel {
  List projectsList = new List();
  
  public MVProjectsListPanel() {
    setLayout(new GridLayout(1,1,3,3));
    //add(new Label("Projects:"));
    add(projectsList);
    //projectsList.addItemListener(this);
  }
  
  public Vector comps = new Vector();
  
  public void setListValues(MVApplication application) {
    Enumeration e = application.projects.elements();
    MVProject p;
        
    projectsList.removeAll();
    
    while(e.hasMoreElements()) {
      p = (MVProject) e.nextElement();
      projectsList.addItem(p.getName());
    }

  }
/*  
  public void itemStateChanged(ItemEvent e)  
  {
        if(e.getStateChange() == ItemEvent.SELECTED)
        {
            int i = projectsList.projectsList.getSelectedIndex();
            try {
                MVProject p = (MVProject) projects.elementAt(index);
                if(p != MVApplication.application.current_project)  {
                
                }                    
            } catch (Exception e) {
                
            }
        }
  }  
*/  
  public Dimension getMinimumSize() {
    return new Dimension(250,170);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,170);
  }

  public MVProject findSelectedProject(Vector projects) {    
    int index = projectsList.getSelectedIndex();
    
    try {
      return (MVProject) projects.elementAt(index);
    } catch (Exception e) {
      return null;
    }
  }
  
}

class MVProjectsButtonPanel extends Panel implements ActionListener {
  Button newButton = new Button("New");
  Button openButton = new Button("Open");
  Button saveButton = new Button("Save");
  Button closeButton = new Button("Close");
//  Button newBase = new Button("New Base");
//  Button newView = new Button("New View");
//  Button showView = new Button("Show View");
  Button quitButton = new Button("Quit");
  
  MVProjectsFrame frame;
  
  public MVProjectsButtonPanel(MVProjectsFrame frame) {
    setLayout(new GridLayout(1,5,3,3));
    add(newButton);
        newButton.addActionListener(this);
    add(openButton);
        openButton.addActionListener(this);
    add(saveButton);
        saveButton.addActionListener(this);
    add(closeButton);
        closeButton.addActionListener(this);
/*
    add(newBase);
    newBase.addActionListener(this);
    add(newView);
    newView.addActionListener(this);
    add(showView);
    showView.addActionListener(this);
*/
    add(quitButton);
        quitButton.addActionListener(this);
    this.frame = frame;
  }
  
  public Dimension getMinimumSize() {
    return new Dimension(250,20);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,20);
  }

  public void actionPerformed(ActionEvent e) {
  
    if(e.getSource() == newButton)
      frame.doNew();
    else if(e.getSource() == openButton)
      frame.doOpen();
    else if(e.getSource() == saveButton)
      frame.doSave();
    else if(e.getSource() == closeButton)
      frame.doClose();
/*    else if(e.getSource() == newBase)
        frame.doNewBase();
    else if(e.getSource() == newView)
        frame.doNewView();
    else if(e.getSource() == showView)
        frame.doShowView();  */
    else if(e.getSource() == quitButton)
      frame.doQuit();
      
  }

}


