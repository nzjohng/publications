package JViews;

// Wrapper for MVServerListen class
public class ServerTest {

  public static void main( String args[] ) {

    ServerMultTest1 l = new ServerMultTest1(5000);    // Create a Listen object
    l.start();          // Start server thread running 

    ServerMultTest1 l2 = new ServerMultTest1(5001);    // Create a Listen object
    l2.start();  // Start server thread running 
    System.out.println( "Thread started" );

    // Join with server thread
    try {
      l.join();
    } catch ( InterruptedException e ) {
      System.out.println( "join interrupted: " + e );
      System.exit( 1 );     // Exit with error
    }

    l = null;
  }

}
