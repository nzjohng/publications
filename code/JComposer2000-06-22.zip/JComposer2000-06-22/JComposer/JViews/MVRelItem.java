package JViews;

import java.util.*;

public class MVRelItem extends Vector implements MVChangeListener {
  protected String name;
  protected int kind;
  
  public Vector keys = null;

  public MVRelItem(String init_name, int init_kind) {
    super(1,3); // vector with initial capacity of 1, increment of 3
    name = init_name;
    kind = init_kind;
  }

  public MVRelItem(String init_name, String init_kind, String flags) {
    super(1,3); // vector with initial capacity of 1, increment of 3
    name = init_name;
    kind = stringToKind(init_kind);
    parseFlags(flags);
  }

  public boolean matches(int a_kind, String a_name) {
    // does this RelItem match selection criteria?
    if(a_kind == kind && name == a_name)
      return true;
    else
      return false;
  }

    public String getName() {
        return name;
    }

    public int getKind() {
        return kind;
    }
  
  protected boolean aggregate = false;

  public void setAggregate(boolean agg) {
    aggregate = agg;
  }
  
  public boolean isAggregate() {
    return aggregate;
  }
  
  public boolean listenBefore = false;
  public boolean listenAfter = false;
  public boolean handleBefore = false;
  public boolean handleAfter = false;

    public String getFlags() {
        String value = "";
        if(listenBefore)
            value = value + "lb ";
        if(listenAfter)
            value = value + "la ";
        if(handleBefore)
            value = value + "hb ";
        if(handleAfter)
            value = value + "ha ";
        if(aggregate)
            value = value + "agg ";

        return value;
    }

    public void parseFlags(String flags) {
        StringTokenizer buf = new StringTokenizer(flags);

        while(buf.hasMoreTokens()) {
            String s = buf.nextToken();
            if(s.equals("lb"))
                listenBefore = true;
            else if(s.equals("la"))
                listenAfter = true;
            else if(s.equals("hb"))
                handleBefore = true;
            else if(s.equals("ha"))
                handleAfter = true;
            else if(s.equals("agg"))
                aggregate = true;
        }

    }

  public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from) {
    // notify all components before a change occurs
    MVChangeDescr new_c = c;

    Enumeration e = elements();
    while(new_c != null && e.hasMoreElements()) {
      new_c = ((MVComponent) e.nextElement()).beforeChange(new_c,from,name);
    }

    return new_c;
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from) {
    // notify all components after a change has occured
    MVChangeDescr new_c = c;

    Enumeration e = elements();
    while(new_c != null && e.hasMoreElements()) {
      new_c = ((MVComponent) e.nextElement()).afterChange(new_c,from,name);
    }
    
    return new_c;
  }
  
  public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent sent_from, 
      String sent_rel, MVComponent from) {
    // notify all components before a change receiving occurs
    MVChangeDescr new_c = c;

    Enumeration e = elements();
    while(new_c != null && e.hasMoreElements()) {
      new_c = ((MVComponent) e.nextElement()).beforeReceive(new_c,from,name,sent_from,sent_rel);
    }

    return new_c;
  }

  public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent sent_from, 
      String sent_rel, MVComponent from) {
    // notify all components after a change receiving has occured
    MVChangeDescr new_c = c;

    Enumeration e = elements();
    while(new_c != null && e.hasMoreElements()) {
      new_c = ((MVComponent) e.nextElement()).afterReceive(new_c,from,name,sent_from,sent_rel);
    }
    
    return new_c;
  }

  public String itemKind() {
    switch(kind) {
      case MVComponent.MVOneToMany :
        return "one-to-many";
      case MVComponent.MVReverseOneToMany :
        return "reverse-one-to-many";
      case MVComponent.MVRelLinksChildren :
        return "rel-comp-children";
      case MVComponent.MVRelLinksParents :
        return "rel-comp-parents";
    }
    
    return "";
  }
  
  public int stringToKind(String name) {
    if(name.equals("one-to-many"))
      return MVComponent.MVOneToMany;
    if(name.equals("reverse-one-to-many"))
      return MVComponent.MVReverseOneToMany;
    if(name.equals("rel-comp-children"))
      return MVComponent.MVRelLinksChildren;
    if(name.equals("rel-comp-parents"))
      return MVComponent.MVRelLinksParents;
      
    return 0;
  }
}
