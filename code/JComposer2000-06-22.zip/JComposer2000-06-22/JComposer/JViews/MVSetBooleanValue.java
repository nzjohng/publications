package JViews;

import java.io.*;

public class MVSetBooleanValue extends MVSetValue {
  public boolean old_value;
  public boolean new_value;

  public MVSetBooleanValue(MVComponent target, String name,
      boolean old_value, boolean new_value, MVBooleanAttribute attribute) {
    done = false;
    this.target = target;
    setPropertyName(name);
    this.old_value = old_value;
    this.new_value = new_value;
    this.attribute = attribute;
  }

    public MVSetBooleanValue() {
        super();
    }

    public boolean getNewValue()
    {
        return new_value;
    }

  public void execute() {
    ((MVBooleanAttribute) attribute).setValue(new_value);
      // don't generate change description
    done = true;
  }

  public void undo() {
    target.setValue(getPropertyName(),old_value);
      // generate change description
  }

  public void redo() {
    target.setValue(getPropertyName(),new_value);
      // generate change description
  }

  public String toString() {
    return ("SetBooleanValue "+getPropertyName()+" "+old_value+" "+new_value);
  }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(old_value);
        output.writeln(new_value);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator)
        throws IOException {
        super.deserialize(input,locator);
        old_value = input.getBooleanToken();
        new_value = input.getBooleanToken();
    }

}
