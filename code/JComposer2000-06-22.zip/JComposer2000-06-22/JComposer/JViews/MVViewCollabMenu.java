package JViews;                          

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

public class MVViewCollabMenu extends MVComponent implements MVSenderComp, ActionListener, MouseMotionListener, WindowListener {

    public MVViewCollabMenu() {
        super();
        madeBy = MVApplication.application.getUserName();
        
        // make sure have broadcaster running
        createClientSender();
    }

    protected MenuItem addCollab = new MenuItem("Add Collaborator");
    protected Menu currCollab = new Menu("Current Collaborators");
    protected MenuItem sep1 = new MenuItem("-");
    
    protected MVCollabReceiveChangesMenu requestChanges = new MVCollabReceiveChangesMenu(this,"Request New Changes");
    protected MVCollabRequestViewMenu requestView = new MVCollabRequestViewMenu(this,"Request New View");

    

    public void addedView(MVComponent comp) {
        Menu collabMenu = new Menu("Collaboration");
        collabMenu.add(addCollab);
        addCollab.addActionListener(this);
        collabMenu.add(currCollab);
        collabMenu.add(sep1);
        collabMenu.add(requestChanges);
        collabMenu.add(requestView);
       
        if(comp instanceof MVViewLayer)        
           ((MVViewLayer) comp).getViewFrame().addMenu(collabMenu);
        //else if(comp instanceof MVViewComp)
        //   ((MVViewComp) comp).getBBWShape().addPopupMenuItem(collabMenu);
        
        establishOneToMany("MVCollabMenu",comp);        
        // get told when update on view or one of view's components about to occur
        getListened().setHandleBeforeRel("MVCollabMenu");
        // get told when view stores change in its version record
        establishOneToMany("collabMenu",getListened().getVersionRecord());
        getListened().getVersionRecord().setListenBeforeRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");
        getListened().getVersionRecord().setListenAfterRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");            getListened().getVersionRecord().setListenAfterRel("collabMenu");

        getListened().getVersionRecord().setSaveChanges(true);

//System.out.println(getListened().getVersionRecord().toString());
        
        ((MVPanelInfo) getListened().getVersionRecord().getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).addComponent(new Button("Check in"));
        ((MVPanelInfo) getListened().getVersionRecord().getAspects().getHumanInterfaceAspect().findHumanInterfaceInfo("buttons panel")).addComponent(new Button("Check out"));
      
        // listen to window's frame events
        // used by telepointers...
/*
        MVViewFrame f = ((MVViewLayer) getListened()).getViewFrame();
        f.addWindowListener(this);
        f.addMouseMotionListener(this);
*/

/*
		// Add telepointer comp & highlighter comp...

		MVTelepointerComp tcomp = new MVTelepointerComp();
		tcomp.init(comp);
		//MVHighlighterComp hcomp = new MVHighlighterComp();
		//hcomp.init(comp);


tcomp.mouseMoved("mark", 100, 100);
tcomp.mouseMoved("bill", 150, 150);

*/
    }
    
    public MVComponent getListened()
    {
        return (MVComponent) getOneRelated("MVCollabMenu",MVChildren);
    }
    
    public Vector getCollaborators()
    {
        return getRelationship("collaborators",MVChildren);
    }
    
    public void establishCollaborators(MVCollabUser c)
    {
        establishOneToMany("collaborators",c);
    }
    
    public void dissolveCollaborators(MVCollabUser c)
    {
        dissolveOneToMany("collaborators",c);
    }
    
    protected Vector clients = new Vector();
        // list of clients this view wants to write to i.e. when
        // broadcasting changes for notify/pres/action/sync editing
    
    protected static MVClientMultSend sender = null;
    
    public static void createClientSender() {
        if(sender == null)
        {   
            sender = new MVClientMultSend();
            sender.start();
        }
    } 
    
    public static MVClientMultSend getSender()
    {
        return sender;
    }   
    
    synchronized public void addCollabUser(boolean fromSelf, String user, int level)
    {
        // add a new collaborator or change an existing
        // collaborator level...
        
        MVCollabUser c = findCollabUser(user);
        MVProject project = ((MVViewLayer) getListened()).getBaseLayer().getProject();
        MVCollabUserInfo info = project.findCollabUser(user);
        
        if(info == null) {
            MVApplication.application.getUserInfo(project);
            info = project.findCollabUser(user);
        }
        
        if(c == null) {
            c = new MVCollabUser(user,-1);
            establishCollaborators(c);
        }

        if(level > 0)
            setUserInfo(c);       
        
        int old_level = c.getLevel();
        c.setLevel(level);
             
            String levelName = "async";
            switch(level) {
            case 1 : levelName = "async"; break;
            case 2 : levelName = "action"; break;
            case 3 : levelName = "present"; break;
            case 4 : levelName = "action"; break;
            case 5 : levelName = "sync"; break;
            }

            if(level > 0) {
                message("Added collaborator "+user+"("+levelName+") at: "+info.getHost()+" port "+info.getPort());
                
                int i = currCollab.getItemCount() - 1;
                while(i >= 0) {
                    MVCollabLevelMenu m = (MVCollabLevelMenu) currCollab.getItem(i);
                    if(m.user.equals(user))
                        m.setLevel(level);
                    i -= 1;
                } 
            } else
                message("Removed collaborator "+user);
            
                MVClient cl = sender.addServer(user,info.getHost(),info.getPort());
                String reply = "";
                
if(cl == null)
System.out.println("cl is null!"); 
                
                
                if(cl != null) {
                    // cl.sendRequest(MVApplication.application.getUserName()); 
                    if(fromSelf) {
                        cl.sendRequest("regCollabEdit");
                        cl.sendRequest(MVApplication.application.getUserName());
                        cl.sendRequest(MVApplication.application.current_project.getName());
                        // really need to send "look-up info" i.e. compKInd,
                        // compID, userName, other info to help find right
                        // component in other users' projects.
                        cl.sendRequest(getListened().userName());
                        cl.sendRequest(""+level);
                        reply = cl.getStringReply();  
                    }
System.out.println("heer2");

                    if(reply.equals("sendView"))
                        sendView(user);
                
                    //if(level > 1 && sender == null)
                    //    createClientSender();
                    
                        if(level < 2) {
                            if(clients.contains(cl))
                                clients.removeElement(cl);
                        } else {
                            clients.addElement(cl);
                            c.setClient(cl);
                        }
         
System.out.println("here4");             
                    if(level == 3) {
                        if(getSentChanges() == null) {
                            addSentChanges();
                        }    
                        getSentChanges().displayRecords();
                    }
             
                } else {
                    message("NO RESPONSE from collaborator "+user+"'s server...");
                    //
                    //collabMenus.removeElementAt(index);
                    //currCollab.remove(index);

                    if(cl != null && clients.contains(cl))
                        clients.removeElement(cl);
                    c.setLevel(1);
                                        
                    int index = getCollaborators().indexOf(c);
                    MVCollabLevelMenu m = (MVCollabLevelMenu) currCollab.getItem(index);
                    m.setLevel(1);
                }

        
        if(level == 0)
            removeUserInfo(c);
    }
    
    public void setUserInfo(MVCollabUser c)
    {
            Color col = Color.black;
            int colour = c.getColour(); 
            
            int j = currCollab.getItemCount() - 1;
            while(j >= 0) {
                MVCollabLevelMenu m = (MVCollabLevelMenu) currCollab.getItem(j);
                if(m.user.equals(c.getUser()))
                    return;
                j--;
            }
            
            if(colour == 0) {
                int i = 0;
                for(i=0;i<5;i++) {
                    boolean used = false;
                    Enumeration e = getCollaborators().elements();
                    while(e.hasMoreElements()) {
                        MVCollabUser other = (MVCollabUser) e.nextElement();
                        if(other.getColour() == i)
                            used = true;    
                    }
                    if(!used)
                        break;
                }          
                
                c.setColour(i);
            }
            
        
                MVCollabLevelMenu cmenu = new MVCollabLevelMenu(this,c.getUser(),c.getLevel(),colour);
                MenuItem l0 = new MenuItem("0 - none");
                l0.setActionCommand("0");
                l0.addActionListener(cmenu);
                MenuItem l1 = new MenuItem("1 - async");
                l1.setActionCommand("1");
                l1.addActionListener(cmenu);
                MenuItem l2 = new MenuItem("2 - notify");
                l2.setActionCommand("2");
                l2.addActionListener(cmenu);
                MenuItem l3 = new MenuItem("3 - present");
                l3.setActionCommand("3");
                l3.addActionListener(cmenu);
                MenuItem l4 = new MenuItem("4 - action");
                l4.setActionCommand("4");
                l4.addActionListener(cmenu);
                MenuItem l5 = new MenuItem("5 - sync");
                l5.setActionCommand("5");
                l5.addActionListener(cmenu);
                cmenu.add(l0);
                cmenu.add(l1);
                cmenu.add(l2);
                cmenu.add(l3);
                cmenu.add(l4);
                cmenu.add(l5);
                               
                currCollab.add(cmenu);
               
                MenuItem svitem = new MenuItem(c.getUser());
                requestChanges.add(svitem);
                svitem.addActionListener(requestChanges);
                MenuItem rvitem = new MenuItem(c.getUser());
                requestView.add(rvitem);
                rvitem.addActionListener(requestView);
        }
        
    public void removeUserInfo(MVCollabUser u)
    {
            int index = getCollaborators().indexOf(u);
            
            currCollab.remove(index);
            dissolveCollaborators(u);
            if(u.getClient() != null && clients.contains(u.getClient()))
                clients.removeElement(u.getClient());
            requestChanges.remove(index);
            requestView.remove(index);
    }
    
    public String allocColourName(int c)
    {
            String colour;
            
            switch(c)
            {
            case 1 :    colour = "cyan"; break;
            case 2 :    colour = "green"; break;
            case 3 :    colour = "orange";  break;
            case 4 :    colour = "red"; break;
            default:    colour = "red"; break;
            }
            
            return colour;
    }  
    
    public Color allocColour(int c)
    {
            Color col;
            
            switch(c)
            {
            case 1 :    col = Color.cyan; break;
            case 2 :    col = Color.green; break;
            case 3 :    col = Color.orange;  break;
            case 4 :    col = Color.red;  break;
            default:    col = Color.red; break;
            }
            
            return col;
    }    
    
    public void viewRedisplayed()
    {
        // add back view menus

        Enumeration e = getCollaborators().elements();
        
        while(e.hasMoreElements()) {
            MVCollabUser u = (MVCollabUser) e.nextElement();
            u.setLevel(1); // async since disconnected! :-)
            setUserInfo(u);
        } 
  
    }
    
    synchronized public void collaborationRequest(boolean from_self, String user, int level)
    {
        addCollabUser(from_self,user,level);
    }
    
    public MVCollabUser findCollabUser(String name)
    {   
        Enumeration e = getCollaborators().elements();
        
        while(e.hasMoreElements()) {
            MVCollabUser u = (MVCollabUser) e.nextElement();
            if(u.getUser().equals(name))
                return u;
        }
        
        return null;
    }
        
    synchronized public void actionPerformed(ActionEvent e) {
        if(e.getSource() == addCollab)
            doAddCollab();
        
    }   
        
    public void doAddCollab()
    {
        MVCollabFrame f = new MVCollabFrame(this);
    }   
    
    protected MVOutputBuffer buffer = new MVOutputBuffer();

    protected String madeBy;
    
    synchronized public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent from, String rel_name,
            MVComponent sent_from, String sent_rel) {
    
        // block all processing of server requests
        // this (hopefully!!) ensures no concurrent update of JViews data
        // structures. Resure server thread at end of afterReceive()
        // synchronized methods in this class should ensure if already
        // processing change sends/collab requests from another user,
        // beforeReceive will block until done with this processing
        //
        // At some stage need to add locking protocol stuff here too i.e.
        // for sync edits (level 5), check no one else trying to change this
        // view/view component by propagating lock requests to other collaborators
        // @ level 5.
        //
        MVApplication.application.suspendServer();

        // view reopened
        if(c instanceof MVRedisplayView)
            viewRedisplayed();
   
        return super.beforeReceive(c,from,rel_name, sent_from, sent_rel);   
    }

    // annotate change BEFORE view's version record stores (and displays) it
    //    
    synchronized public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel_from)
    {
    
        // add annotation to change description
        //
        c.setAnnotation("user",madeBy);
        if(!madeBy.equals(MVApplication.application.getUserName()))
            c.setAnnotation("header","["+madeBy+"]");
    
        return super.beforeChange(c,from,rel_from);
    }

    // View's version record notifies us that change description now stored
    //
    // Now need to send this change to other users' environments via their
    // collaborative servers...
    //
    synchronized public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {
            
        // filter out changes to foreground colour (for now!)
        if(c instanceof MVSetStringValue &&
           ((MVSetStringValue) c).getPropertyName().equals("foreground")) {
           MVApplication.application.resumeServer();
           return super.afterChange(c,from,rel_name);
        }
         
        MVComponent comp = c.getTarget();
        MVCollabUser u = findCollabUser(madeBy);
        if(!madeBy.equals(MVApplication.application.getUserName())) {
            if(comp instanceof MVViewComp)
                if(((MVViewComp) comp).getBBWShape() != null)
                    ((MVViewComp) comp).getBBWShape().setForeground(allocColour(u.getColour()));
        } else {
            if(comp instanceof MVViewComp)
                if(((MVViewComp) comp).getBBWShape() != null)
                    ((MVViewComp) comp).getBBWShape().setForeground(Color.black);
        }    
                    
        if(from != this) {
                c.setCount(getListened().getVersionRecord().getCount());
        
//System.out.println("Sending change...");
//System.out.println("CHANGE user = "+c.getAnnotation("user"));
//System.out.println("change # = "+c.getCount());
            // if(sender.connect("lucy.cs.waikato.ac.nz",4545)) {
                
            
                Vector v = new Vector();
                v.addElement(c);
                buffer.reset();
                MVApplication.application.current_project.exportChanges(v,buffer);

                // Need to send info about project, component THEN change info...
                sender.sendRequest(this,clients,"collabEdit");
                sender.sendRequest(this,clients,MVApplication.application.getUserName());
                sender.sendRequest(this,clients,MVApplication.application.current_project.getName());
                sender.sendRequest(this,clients,getListened().userName());
                sender.sendRequest(this,clients,buffer.getBytes());
        } //else
            //System.out.println("*** Sender propagated "+c);

        MVApplication.application.resumeServer();

        return super.afterChange(c,from,rel_name);
    }
    
    protected MVImportViewChangesLocator locator = null;

    // change received from another user's environment
    // need to action appropriately for mode of collaboration with
    // that user...
    //
    synchronized public void changeReceived(String user,byte bytes[])
    {
//System.out.println("received change from "+user);

        MVViewLayer view = (MVViewLayer) getListened();
        MVProject p = view.getBaseLayer().getProject();
        MVInputBuffer2 buffer = new MVInputBuffer2(bytes);

        if(locator == null)
            locator = new MVImportViewChangesLocator(view);
        Vector change = p.importChanges(buffer, locator);
        if(change.size() > 0) {            
            MVChangeDescr c = (MVChangeDescr) change.firstElement();
System.out.println("Got change from "+user+": "+c);
//System.out.println("Change made by: "+c.getAnnotation("user"));
//System.out.println("Change number = "+c.getNumber());
            String cuser = c.getAnnotation("user");

            if(cuser != null && cuser.equals(MVApplication.application.getUserName()))
                System.out.println("***** ORIGINALLY FROM SELF!!!");
            else {
                c.setAnnotation("user",user);
                c.setAnnotation("header","["+user+"]");
            
                MVCollabUser u = findCollabUser(user);
                u.setLastChange(c.getNumber());
                switch(u.getLevel())
                {
                case 2 : broadcastAfter(c); break;
                case 3 : getSentChanges().add_change(c); break;
                case 4 : 
                     // need to synchronise with
                     // i) user updates on view and
                     // ii) other view updates propagated via
                     //     MVViewRel relationships
                     doRedo(user,c);
                     c.redo();
                     doneRedo(user,c);
                     break;
                case 5 : 
                     // need to ensure have lock on view/view comp
                     // BEFORE action change i.e. need beforeChange()
                     // or handleBefore()
                     // functionality in this component... 
                     doRedo(user,c);
                     c.redo();
                     doneRedo(user,c);
                     break;
                }            
            }
        }   
    }
    
    public void doRedo(String user, MVChangeDescr c)
    {
        madeBy = user;
System.out.println("doRedo: madeBy set to "+madeBy);
    }
    
    public void doneRedo(String user, MVChangeDescr c)
    {       
        madeBy = MVApplication.application.getUserName();
System.out.println("doneRedo: madeBy set to "+madeBy);    
    }
    
    public MVCollabPresentChanges getSentChanges()
    {
        return (MVCollabPresentChanges) getOneRelatedOrNull("sent",MVChildren);
    }
    
    public void addSentChanges()
    {
        MVCollabPresentChanges presented = new MVCollabPresentChanges();
        presented.setTitle("Sent changes: "+getListened().userName());
        presented.setSaveChanges(true);
        establishOneToMany("sent",presented);    
    }
    
    public void changesReceived(String user, int lastNum, byte bytes[])
    {
    
        message("Received changes from "+user+"...");
System.out.println("lastNum = "+lastNum);    
        if(getSentChanges() == null) {
            addSentChanges();
        }
        
        MVViewLayer view = (MVViewLayer) getListened();
        MVProject p = view.getBaseLayer().getProject();
        MVInputBuffer2 buffer = new MVInputBuffer2(bytes);
        
        if(locator == null)
            locator = new MVImportViewChangesLocator(view);
        Vector changes = p.importChanges(buffer, locator);
        if(changes != null) {
            Enumeration e = changes.elements();
            while(e.hasMoreElements()) {
                MVChangeDescr c = (MVChangeDescr) e.nextElement();
                // if already has user set - don't change (in case by someone else??)

                String cuser = c.getAnnotation("user");

                if(cuser != null && cuser.equals(MVApplication.application.getUserName()))
                    System.out.println("***** ORIGINALLY FROM SELF!!!");
                else {
                    c.setAnnotation("user",user);
                    c.setAnnotation("header","["+user+"]");
            
                    getSentChanges().add_change(c);
                }
            }
            
            MVCollabUser u = findCollabUser(user);
            u.setLastChange(lastNum);
            getSentChanges().displayRecords();
        }
    }
    
    public void sendChanges(String user, int num)
    {
        MVCollabUser u = findCollabUser(user);
        MVProject p = ((MVViewLayer) getListened()).getBaseLayer().getProject();
        MVCollabUserInfo info = p.findCollabUser(user);

        MVClient c = new MVClient();
        // message("Sending changes to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        if(c.connect(MVApplication.application.getUserName(),user,info.getHost(),info.getPort())) {
            //c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest("changesSend");
            c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest(p.getName());
            // c.sendRequest(p.current_base_layer.getName());
            c.sendRequest(getListened().userName());
        
            MVOutputBuffer buffer = new MVOutputBuffer();
        
            MVVersionRecord v = getListened().getVersionRecord();
            Vector changes = v.getChangesFrom(num+1);
            c.sendRequest(""+v.getCount());
            // u.setLastChange(v.getCount());
        
            p.exportChanges(changes,buffer);
       
            c.sendRequest(buffer.getBytes());
            c.sendRequest("DONE");
            c.close();
            // message("");
        } else {
            message("Couldn't connect to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        }
    }
    
    public void sendView(String user)
    {    
        MVCollabUser u = findCollabUser(user);
        MVProject p = ((MVViewLayer) getListened()).getBaseLayer().getProject();
        MVCollabUserInfo info = p.findCollabUser(user);

        message("Sending view to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        MVClient c = new MVClient();
        if(c.connect(MVApplication.application.getUserName(),user,info.getHost(),info.getPort())) {
            //c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest("compSend");
            c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest(p.getName());
            c.sendRequest(p.current_base_layer.getName());
            c.sendRequest(getListened().userName());
            // should do this if version record sent!: u.setLastChange(getListened().getVersionRecord().getCount());
        
            MVOutputBuffer buffer = new MVOutputBuffer();
            p.exportComponent(getListened(),buffer);
            byte bytes[] = buffer.getBytes();      
            c.sendRequest(bytes);

            c.sendRequest("DONE");
            c.close();
            message("View sent to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        } else {
            message("Couldn't connect to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        }
    }
    
    public void message(String mesg)
    {
        ((MVViewLayer) getListened()).setMessage(mesg);
    }

    public void requestUserView(String user)
    {
        MVCollabUser u = findCollabUser(user);
        MVProject p = ((MVViewLayer) getListened()).getBaseLayer().getProject();
        MVCollabUserInfo info = p.findCollabUser(user);
        String name = getListened().userName();
        message("Request view list from "+user+" at "+info.getHost()+"("+info.getPort()+")");
        
        MVClient c = new MVClient();
        message("Request view '"+name+"' from "+user+" at "+info.getHost()+"("+info.getPort()+")");
        if(c.connect(MVApplication.application.getUserName(),user,info.getHost(),info.getPort())) {
        //c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest("compRequest");
            c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest(p.getName());
            // c.sendRequest(p.current_base_layer.getName());
            c.sendRequest(name);
            c.sendRequest("DONE");
            c.close(); 
        } else {
            message("Couldn't connect to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        }         
    }
    
    public void requestNewChanges(String user)
    {
        MVCollabUser u = findCollabUser(user);
        MVProject p = ((MVViewLayer) getListened()).getBaseLayer().getProject();
        MVCollabUserInfo info = p.findCollabUser(user);

        message("Request changes from "+user+" at "+info.getHost()+"("+info.getPort()+")");
        MVClient c = new MVClient();
        if(c.connect(MVApplication.application.getUserName(),user,info.getHost(),info.getPort())) {
        //c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest("changesRequest");
            c.sendRequest(MVApplication.application.getUserName());
            c.sendRequest(p.getName());
            // c.sendRequest(p.current_base_layer.getName());
            c.sendRequest(getListened().userName());
System.out.println("requesting from "+u.getLastChange());       
            c.sendRequest(""+u.getLastChange());
            c.sendRequest("DONE");
            c.close(); 
        } else {
            message("Couldn't connect to "+user+" at "+info.getHost()+"("+info.getPort()+")");
        }           
    }
    
    public void removeServer(MVClient c)
    {
        Enumeration e = getCollaborators().elements();
        
        while(e.hasMoreElements()) {
            MVCollabUser u = (MVCollabUser) e.nextElement();
            if(u.getClient() == c) {
                u.setLevel(1);
                    // need to change level!
                int index = getCollaborators().indexOf(u);
                MVCollabLevelMenu m = (MVCollabLevelMenu) currCollab.getItem(index);
                m.setLevel(1);
                message("Lost contact with "+u.getUser()+"'s server");
                break;
            }
        }
        clients.removeElement(c);
    }
    
    int lastX = 0;
    int lastY = 0;
    
    public void mouseDragged(MouseEvent e) {
        lastX = e.getX();
        lastY = e.getY();
    }
    
    public void mouseMoved(MouseEvent e) {
        lastX = e.getX();
        lastY = e.getY();
    }
    
    public void windowActivated(WindowEvent e) {
        // turn telepointers on?
        
    }    

    public void windowDeactivated(WindowEvent e) {
        // turn telepointers off?
        
    }  
    
    public void windowClosing(WindowEvent e) {} 
    public void windowOpened(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {} 
    

}

class MVCollabUser extends MVComponent {

    public MVCollabUser(String name, int level)
    {
        setUser(name);
        setLevel(level);   
    }
    
    public MVCollabUser()
    {
    
    }
    
    public void setUser(String u)
    {
        setValue("user",u);
    }
        
    public void setLevel(int l)
    {
        setValue("level",l);
    }
    
    public int getLevel()
    {
        return getIntValue("level");
    }
    
    public String getUser()
    {
        return getStringValue("user");
    }
    
    public int getLastChange()
    {   
        return getIntValue("lastChange");
    }
    
    public void setLastChange(int i)
    {
        setValue("lastChange",i);
    }
    
    public int getColour()
    {
        return getIntValue("colour");
    }
    
    public void setColour(int c)
    {
        setValue("colour",c);
    }
    
    MVClient client = null;
    
    public MVClient getClient()
    {
        return client;
    }
    
    public void setClient(MVClient c)
    {
        client = c;
    }

} 

class MVCollabFrame extends Frame  implements ActionListener
{

    protected MVViewCollabMenu menu;
    protected List names = new List();
    protected MVCollabFrameButtonPanel buttons = new MVCollabFrameButtonPanel();
    MVProject project;
    
    public MVCollabFrame(MVViewCollabMenu m)
    {
        super("Add Collaborator");
        menu = m;
        setLayout(new GridLayout(2,1));
        add(names);
        add(buttons);
        buttons.addCollab.addActionListener(this);
        buttons.queryUsers.addActionListener(this);
        buttons.cancel.addActionListener(this);
        project = ((MVViewLayer) m.getListened()).getBaseLayer().getProject();
        getUserNames();
        setSize(300,250);
        pack();
        setVisible(true);
    }
    
    public void getUserNames()
    {
        // MVApplication.application.getUserInfo(project);
        Vector users = project.getCollabUsers();
        String myname = MVApplication.application.getUserName();
        names.removeAll();
        
            Enumeration e = users.elements();
            
            while(e.hasMoreElements()) {
                MVCollabUserInfo info = (MVCollabUserInfo) e.nextElement();
                String name = info.getUser();
                if(!name.equals(myname))
                    names.add(name);
            }
            
        names.validate();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == buttons.addCollab) {
            String user = names.getSelectedItem();
            menu.addCollabUser(true,user,1);
            setVisible(false);
        } else if(e.getSource() == buttons.queryUsers) {
            MVApplication.application.getUserInfo(project);
            getUserNames();  
        } else if(e.getSource() == buttons.cancel)
            setVisible(false);
    }
    
}

class MVCollabFrameButtonPanel extends Panel
{
    protected Button addCollab = new Button("Add");
    protected Button queryUsers = new Button("Query for Users");
    protected Button cancel = new Button("Cancel");

    public MVCollabFrameButtonPanel()
    {
        setLayout(new GridLayout(3,1));
        add(addCollab);
        add(queryUsers);
        add(cancel);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(250,40);
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(250,40);
    }

}



class MVCollabReceiveChangesMenu  extends Menu implements ActionListener
{
    protected MVViewCollabMenu menu;

    public MVCollabReceiveChangesMenu(MVViewCollabMenu m, String label)
    {
        super(label);
        menu = m;
    }
    
    public void actionPerformed(ActionEvent e)
    {
        MenuItem i = (MenuItem) e.getSource();
        menu.requestNewChanges(i.getLabel());
    }
}

class MVCollabRequestViewMenu  extends Menu implements ActionListener
{
    protected MVViewCollabMenu menu;

    public MVCollabRequestViewMenu(MVViewCollabMenu m, String label)
    {
        super(label);
        menu = m;
    }
    
    public void actionPerformed(ActionEvent e)
    {
        MenuItem i = (MenuItem) e.getSource();
        menu.requestUserView(i.getLabel());
    }
}

class MVCollabLevelMenu extends Menu implements ActionListener
{
    protected MVViewCollabMenu menu;
    protected String user;
    protected int level;
    protected int colour;

    public MVCollabLevelMenu(MVViewCollabMenu m, String u, int l, int c)
    {
        super(u+" (async,"+m.allocColourName(c)+")");
        menu = m;
        user = u;
        level = l;
        colour = c;
    }
    
    public void actionPerformed(ActionEvent e)
    {
        MenuItem i = (MenuItem) e.getSource();
        int new_level = Integer.parseInt(i.getActionCommand());
        setLevel(new_level);
        menu.addCollabUser(true,user,new_level);
    }
    
    public void setLevel(int new_level)
    {
        String col = menu.allocColourName(colour);

        switch(new_level)
        {
        case 1 : setLabel(user+" (async,"+col+")"); break;
        case 2 : setLabel(user+" (notify,"+col+")"); break;
        case 3 : setLabel(user+" (present,"+col+")"); break;
        case 4 : setLabel(user+" (action,"+col+")"); break;
        case 5 : setLabel(user+" (sync,"+col+")"); break;
        }
        level = new_level;        
    }
}

class MVCollabPresentChanges  extends MVVersionRecord
{
    public MVCollabPresentChanges()
    {
    
    }
    
    public MVViewCollabMenu getMenu()
    {
        return (MVViewCollabMenu) getOneRelated("sent",MVParents);
    }
    
/*    
    public String displayString(MVChangeDescr c)
    {
       String value = super.displayString(c);
       String user = c.getAnnotation("user");

       if(user != null)
        return "["+user+"] "+value;
       else
        return value;         
    }
*/    
    public void doUndo(MVChangeDescr c)
    {
        // colour target of change?
        
        super.doUndo(c);
    }
    
    public void doRedo(MVChangeDescr c)
    {
        // colour target of change?
        // set "lastChangedBy" field of changed component??
if(c == null)
    System.out.println("c is null!");
else
    System.out.println("c = "+c);
        String user = c.getAnnotation("user");
System.out.println("user = "+user);
if(getMenu() == null)
   System.out.println("menu is null!");
        
        getMenu().doRedo(user,c);
                //try {
            c.redo();
        //} catch(MVFatalException e) {
        //    System.out.println("doRedo: exception: "+e);
        //}
        
        getMenu().doneRedo(user,c);
    }

}
