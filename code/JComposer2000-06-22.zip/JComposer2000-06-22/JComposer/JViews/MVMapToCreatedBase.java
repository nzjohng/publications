package JViews;

import java.io.*;

public class MVMapToCreatedBase extends MVMacroChangeDescr {

  public MVBaseComp base_comp;
  
  public MVMapToCreatedBase(MVViewComp target, MVBaseComp base_comp) {
    super(target,"MapToCreatedBase");
    this.base_comp = base_comp;
  }

    public MVMapToCreatedBase() {
        super();
    }

    public MVViewComp getViewComp() {
        return (MVViewComp) target;
    }
  
  public void execute() {  
    MVViewRel view_rel = base_comp.findViewRel(getViewComp().viewRelKind());
    
    if(view_rel == null)
      view_rel = getViewComp().newViewRel();
      
    view_rel.establish(base_comp,getViewComp());
    view_rel.downloadAttributes(base_comp,getViewComp());
  }
  
  // undo = target.unmapFromBase() ??
  // && base_comp.delete()
  
  // redo = target.mapToCreatedBase(base_comp) ??
  // && base_comp.undelete()

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(base_comp);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        int id = input.getIntToken();
        base_comp = (MVBaseComp) locator.findOrCreateComp(id,0,"");
    }
    
    public boolean isValid()
    {
        return super.isValid() && (base_comp != null);
    }


}
