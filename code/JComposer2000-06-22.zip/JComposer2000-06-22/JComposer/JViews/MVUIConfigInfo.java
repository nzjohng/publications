package JViews;

import java.awt.*;

public class MVUIConfigInfo extends MVConfigurationInfo
{

    public MVUIConfigInfo()
    {
    
    }
    
    public MVUIConfigInfo(String name, int kind, String aspects[], String info)
    {
        super(name,kind,aspects,info);
    }

    public String getName()
    {
        return name;
    }
    
    public void configure()
    {
        // example of configure dialogue...

        MVUIConfigDialogue frame = new MVUIConfigDialogue();
    }
    
}

class MVUIConfigDialogue extends Frame
{

    Label l1 = new Label("Alternative Interfaces:");
    List alt = new List();
    Label l2 = new Label("Visibility");
    List vis = new List();
    Label l3 = new Label("UI Configuration properties:");
    Label l4 = new Label("Colour"); TextField t4 = new TextField("Black");
    Label l5 = new Label("Highlight"); TextField t5 = new TextField("Red");
    Label l6 = new Label("Font"); TextField t6 = new TextField("Courier");

    Panel p1, p2, p3;

    public MVUIConfigDialogue()
    {
        super("Preferences for Itinerary Item");
    
        p1 = new Panel();
        p1.setLayout(new GridLayout(2,1));
        p1.add(l1);
        p1.add(alt);
        alt.add("Property sheet");
        alt.add("Horizontal grid");

        p2 = new Panel();
        p2.setLayout(new GridLayout(2,1));
        p2.add(l2);
        p2.add(vis);
        vis.add("Simple only");
        vis.add("Expert only");
        vis.add("All fields");

        p3 = new Panel();
        p3.setLayout(new GridLayout(4,2));
        p3.add(l3);
        p3.add(new Label(""));
        p3.add(l4); p3.add(t4);
        p3.add(l5); p3.add(t5);
        p3.add(l6); p3.add(t6);

        setLayout(new GridLayout(3,1));
        add(p1); add(p2); add(p3);
        setSize(300,300);
        pack();
        setVisible(true);
    }

}
