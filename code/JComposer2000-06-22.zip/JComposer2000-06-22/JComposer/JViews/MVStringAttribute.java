package JViews;

import java.io.*;

public class MVStringAttribute extends MVAttribute {
  public String value;

  public MVStringAttribute(String init_name, String init_value) {
    name = init_name;
    value = init_value;
  }
  
  public void setValue(String new_value) {
    value = new_value;
  }

    public String getValue() {
        return value;
    }

  public String toString() {
    return (name+" = "+'"'+value+'"');
  }

  public boolean isBlank() {
    return (value.equals(MVComponent.MVStringBlank));
  }
  
  public void setCompValue(MVComponent c) {
    c.setValue(name,value);
  }
}
