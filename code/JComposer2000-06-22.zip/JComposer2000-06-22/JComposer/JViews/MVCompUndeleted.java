package JViews;

public class MVCompUndeleted extends MVChangeDescr {

    public MVCompUndeleted() {
        super();
    }

    public MVCompUndeleted(MVComponent comp) {
        super(comp);
    }

   public void execute() {
        target.doUndelete();
    }

    public void undo() {
        target.delete();
    }

    public void redo() {
        target.undelete();
    }

    public String toString() {
        return "MVCompUndeleted: "+getTarget().userName();
    }

}

