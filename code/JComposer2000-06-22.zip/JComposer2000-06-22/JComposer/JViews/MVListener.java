package JViews;

// The generic Filter/Action class of JViews components
//

import java.util.*;

public class MVListener extends MVBaseComp implements MVListenerProxy {

    public MVListener() {
        super();
    }

    public String kindName() {
        return "Filter/Action "+compKind();
    }

    public String userName() {
        return kindName();
    }

    public void init()
    // called when create listener
    {

    }

    public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel) {
        if(!rel.equals("this")) { // don't propagate from self!
            super.beforeChange(c,from,rel);
            return performFilterAction(c,from,rel);
        } else
            return c;
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel) {
        if(!rel.equals("this")) { // don't propagate from self!
            super.afterChange(c,from,rel);
            return performFilterAction(c,from,rel);
        } else
            return c;
    }

    public MVChangeDescr beforeReceive(MVChangeDescr c, MVComponent from, String rel,
            MVComponent sent_from, String sent_rel) {
        if(!rel.equals("this")) { // don't propagate from self!
            super.beforeReceive(c,from,rel,sent_from,sent_rel);
            return performFilterAction(c,from,rel);
        } else
            return c;
    }

    public MVChangeDescr afterReceive(MVChangeDescr c, MVComponent from, String rel,
            MVComponent sent_from, String sent_rel) {
        if(!rel.equals("this")) { // don't propagate from self!
            super.afterReceive(c,from,rel,sent_from,sent_rel);
            return performFilterAction(c,from,rel);
        } else
            return c;
    }

    public MVChangeDescr performFilterAction(MVChangeDescr event, MVComponent from, String rel) {
// System.out.println("*** Filter/action "+userName()+" got "+event);

        return event;
    }

    public void propagateEvent(MVChangeDescr event) {
        propagateEvent(event,"");
    }
    
    public String getAttributeValue(String name)
    {
        // if has proxy, get value from proxy
        
        MVListenerProxy proxy = getProxy();
        
        if(proxy != null) {
            String value = proxy.getAttributeValue(name);
            if(value != null)
                return value;
        }
        
        return getStringValue(name); 
    }
    
    public void setAttributeValue(String name, String value)
    {
        // if has proxy, set proxy attribute??
        
        MVListenerProxy proxy = getProxy();
        
        if(proxy != null && proxy.getAttributeValue(name) != null) {
            proxy.setAttributeValue(name,value);
            return;
        }
        
        setValue(name,value);
    }
    
    public MVComponent getInputComp(String rel)
    {
        // if proxy...
        MVComponent c = null;
        
        if(getProxy() != null) {
           c = getProxy().getInputComp(rel); 
           if(c != null)
            return c;               
        }
        
        // get comp linked to this comp with rel name of "rel"
        
        c = getOneRelatedOrNull(rel,MVParents);
        if(c != null)
            return c;
        
        // get comp linked to this comp with rel name of form "Out->rel"
        
        Enumeration e = getRelationships().elements();
        while(e.hasMoreElements()) {
            MVRelItem i = (MVRelItem) e.nextElement();
            if(matchesInputRel(i.getName(),rel)) {
                c = getOneRelatedOrNull(i.getName(),MVParents);
                if(c != null)
                    return c;   
            }
        }
        
        return null;
    }
    
    public boolean matchesInputRel(String fullName, String wanted)
    {
        char bytes[] = fullName.toCharArray();
        int i = 0;
        
        while(i < bytes.length) {
            i++;
            if(i < bytes.length && ((i+1) < bytes.length) && bytes[i] == '>' && bytes[i-1] == '-')
                return (new String(bytes,i+1,bytes.length-i-1)).equals(wanted);    
        }
        
        return false;
    }

    // find all comps this comp attached to by given name for 
    // sending of events
    
    public Vector getOutputComps(String rel)
    {
        // if proxy...
         
        if(getProxy() != null) {
           Vector comps = getProxy().getOutputComps(rel); 
           if(comps.size() > 0)
            return comps;               
        }
        
        // get any comps related to this comp with rel name of "rel"
        
        Vector comps = getRelationship(rel,MVChildren);
        //if(comps.size() > 0)
        //    return comps;
        
        // get any comps related to this comp with rel of form "rel->In", Ok
        
        Enumeration e = getRelationships().elements();
        while(e.hasMoreElements()) {
            MVRelItem i = (MVRelItem) e.nextElement();
            if(matchesOutputRel(i.getName(),rel)) {
                Vector cs = getRelationship(i.getName(),MVChildren);
                Enumeration e2 = cs.elements();
                while(e2.hasMoreElements())
                    comps.addElement(e2.nextElement());   
            }
        }
        
        return comps;
    }
    
    public boolean matchesOutputRel(String fullName, String wanted)
    {
        char bytes[] = fullName.toCharArray();
        int i = 0;
        
        while(i < bytes.length) {
            i++;
            if(i < bytes.length && ((i+1) < bytes.length) && bytes[i] == '>' && bytes[i-1] == '-')
                return (new String(bytes,0,i-2)).equals(wanted);    
        }
        
        return false;
    }

    // propagate to SELECTED output comp, not general broadcast...
    
    public void propagateEvent(MVChangeDescr c, String rel)
    {
        // if proxy, send to proxy comp
        MVListenerProxy proxy = getProxy();
        if(proxy != null) {
            ((MVComponent) proxy).afterChange(c,this,rel);
        }
        
        // send to all rels:
        //  match rel value
        //  of form "Out->In"  where Out matches rel value
        //  if rel == "", send to all rels
        
        if(rel.equals(""))
            broadcastAfter(c);
        else {
            // do selective broadcast to only comps linked to
            // this comp with name of "rel" of name of form "rel->In"
        
            Vector comps = getOutputComps(rel);
            Enumeration e = comps.elements();
            while(e.hasMoreElements()) {
                MVComponent comp = (MVComponent) e.nextElement();
                comp.afterChange(c,this,rel); 
            }
        }
    }
    
    public MVListenerProxy getProxy()
    {
        return (MVListenerProxy) getOneRelatedOrNull("listener_proxy",MVChildren);
    }
    
    public void addProxy(MVListenerProxy proxy)
    {
        establishOneToMany("listener_proxy",(MVComponent) proxy);
    }
    
    public MVProject getProject()
    {
        if(getProxy() != null)
            return ((MVBaseComp) getProxy()).getBaseLayer().getProject();
        else
            return getBaseLayer().getProject();
    }
    
}

