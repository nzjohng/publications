package JViews;

public abstract class MVAttribute {
  public String name;
  public abstract String toString();
  
  public boolean isBlank() {
    return true;
  }
  
  public abstract void setCompValue(MVComponent c);

    public void setPropertyName(String name) {
        this.name = name;
    }

    public String getPropertyName() {
        return name;
    }
}
