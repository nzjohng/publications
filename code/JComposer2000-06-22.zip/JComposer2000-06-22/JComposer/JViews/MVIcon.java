package JViews;

import java.beans.*;

public class MVIcon extends MVViewComp {

  public MVIcon(MVViewLayer view) {
    super(view);
  }

  public MVIcon() {
    super();
  }
  
  
    public void propertyChange(PropertyChangeEvent evt) {

// need to do this at START and END of BBW transaction, as (x,y) values change when dragging...
//
// want to create a e.g. MVChangeOrigin change description, whose execute() does
// nothing, but we store the (DX,DY) values so undo() calls setX(getX()-DX) and setY(getY()-DY)
// and redo() calls setX(getX()+DX) and setY(getY()+DY)
    
    super.propertyChange(evt);

    }


// need to use getAttributesString() to put +origin_x = BBWShape.getOriginHandle().getX() etc.

// and setComponentData( ) to suck these out & reset BBW shape origin

// do same for rectangle top-left and bottom-right handles etc.

}
