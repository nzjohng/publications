package JViews;

public class MVImportViewItem {
    int oldCompID;
    int newCompID;
    int copiedFrom;
    MVComponent newComp;

    public MVImportViewItem(int oldCompID, int newCompID, int copiedFrom, MVComponent comp) {
        this.oldCompID = oldCompID;
        this.newCompID = newCompID;
        this.copiedFrom = copiedFrom;
        this.newComp = comp;
    }

}

