package JViews;

import java.awt.*;
import java.awt.event.*;
import bbw.*;
import bbw.shape.*;
import java.util.*;
import java.rmi.*;

public class MVTelepointerComp extends MVListener implements MouseMotionListener
{

	int last_x = 0;
	int last_y = 0;

	Vector telepointers = new Vector();

	boolean enabled = true;

	MVTelepointerSender sender = null;

	public MVTelepointerComp()
	{
	}
		
	MenuItem menu = new MenuItem("Telepointers");

	public void init(MVComponent comp)
	{
		try
		{
		MVTelepointerServer server = new MVTelepointerServer(this);
		} catch (Exception e) {
			System.err.println("Telepointer init: "+e);
		}
		
		try
		{
		System.out.println("tryint to locate: "+"//localhost/TelepointerComp_"+MVApplication.application.getUserName());
			Naming.lookup("//localhost/TelepointerComp_"+MVApplication.application.getUserName());
		} catch (Exception e) {
			System.err.println("Telepointer init: "+e);
		}
		
		establishOneToMany("telepointer_view",comp);

		MVViewFrame f = ((MVViewLayer) comp).getViewFrame();
		f.addMenuItem("Collaboration",menu);
        f.addMouseMotionListener(this);

        sender = new MVTelepointerSender(this);
        sender.start();
	}

	public MVViewLayer getView()
	{
		return (MVViewLayer) getOneRelated("telepointer_view", MVChildren);
	}

	public void mouseDragged(MouseEvent e) { }

	public void mouseMoved(MouseEvent e) {
		last_x = e.getX();
		last_y = e.getY();
	}

	public void mouseMoved(String user, int x, int y)
	{
		if(!enabled)
			return;
		
		MVTelepointerInfo info = null;
		TelepointerShape s;
		
		Enumeration e = telepointers.elements();
		while(e.hasMoreElements()) {
			info = (MVTelepointerInfo) e.nextElement();
			if(info.user.equals(user)) {
				break;
			}
		}
		
		if(info == null) {
			s = new TelepointerShape();
			s.setText(user);
			s.setWidth(30);
			s.setHeight(20);
			
			s.init(getView().getViewFrame().getBBWContainer(),x,y);
			info = new MVTelepointerInfo(x,y,user,s);
			telepointers.addElement(info);
			// should set to person's colour...

			s.setHandlesVisible(false);
		} else {
			s = info.shape;
		}

		s.setX(x);
		s.setY(y);

	}

	public synchronized void sendTelepointerInfo()
	{
        /*
        MVCollabUserInfo info = project.findCollabUser(user);
        
        if(info == null) {
            MVApplication.application.getUserInfo(project);
            info = project.findCollabUser(user);
        }
		*/
		
        MVViewCollabMenu menu = (MVViewCollabMenu) getView().getOneRelated("MVCollabMenu",MVParents);

System.out.println("trying telepointer info send...");

		Enumeration e = menu.getCollaborators().elements();
        while(e.hasMoreElements()) {
	        MVCollabUser other = (MVCollabUser) e.nextElement();
	        if(other.getLevel() < 4)
	        	continue; // only send to sync editing collaborators...
	        	
	        MVProject project = ((MVViewLayer) getView()).getBaseLayer().getProject();
        	MVCollabUserInfo info = project.findCollabUser(other.getUser());
        	try {

System.out.println("  sending to: "+other.getUser());
        	
// Need to separate all this out to use separate broadcasting comp
// & distribution aspects...

            	MVRemoteTelepointer rtele = (MVRemoteTelepointer) Naming.lookup(
	            	"//"+info.getHost()+"/TelepointerComp_"+info.getUserName());

				rtele.mouseMoved(MVApplication.application.getUserName(),last_x,last_y);
	        } catch (Exception ex) { System.err.println("Telepointer: "+ex); }
        }

          
	}

}

class MVTelepointerServer extends java.rmi.server.UnicastRemoteObject implements MVRemoteTelepointer
{
	MVTelepointerComp comp;
	public MVTelepointerServer(MVTelepointerComp comp) throws java.rmi.RemoteException
	{
		this.comp = comp;

		try {
 		    Naming.rebind("//localhost/TelepointerComp_"+MVApplication.application.getUserName(),this);		
             System.out.println("Telepointer server bound in RMI registry");
		} catch (Exception e) {
			System.err.println("TelepointerServer init: "+e);
		}
		
	}

	public void mouseMoved(String user, int x, int y) throws RemoteException
	{
		comp.mouseMoved(user,x,y);
	}

}

class MVTelepointerSender extends Thread
{

	MVTelepointerComp comp;
	int secs = 1000;
	boolean finished = false;
	
	public MVTelepointerSender(MVTelepointerComp comp)
	{
		this.comp = comp;
	}

	public void run()
	{
		while(!finished)
		{
			try {
				sleep(secs); // send every 1 sec
				comp.sendTelepointerInfo();
			} catch (Exception e)
			{
				System.err.println("Telepointer sender: "+e);
			}
		}
	}

	public void setWait(int value)
	{
		this.secs = value;
	}

	public void setFinished(boolean value)
	{
		this.finished = value;
	}

}

class MVTelepointerInfo
{

	int x;
	int y;
	String user;
	TelepointerShape shape;

	public MVTelepointerInfo(int x, int y, String user, TelepointerShape shape)
	{
		this.x = x;
		this.y = y;
		this.user = user;
		this.shape = shape;
	}


}
