
package JViews;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MVCollabServer extends MVServerMultListen {

    protected MVApplication app = null;

    public MVCollabServer(MVApplication a)
    {
        app = a;
        MVCollabServerFrame f = new MVCollabServerFrame(this);
    }
    
    public MVApplication getApplication()
    {
        return app;
    }
    
    public synchronized void processRequest(MVServerProcess client, String req)
    {
        if(req.equals("regCollabEdit"))
            processRegCollabEdit(client);
        else if(req.equals("collabEdit"))
            processCollabEdit(client);
        else if(req.equals("compSend"))
            processCompSend(client);
        else if(req.equals("changesSend"))
            processChangesSend(client);
        else if(req.equals("changesRequest"))
            processChangesRequest(client);
        //else if(req.equals("viewsList"))
        //    processViewsList(client);
        else if(req.equals("compRequest"))
            processCompRequest(client);
        else if(req.equals("checkConnection"))
            processCheckConnection(client);
        else if(req.equals("remoteChangeSend"))
            processRemoteChangeSend(client);
        else
            System.out.println("*** CollabServer received invalid message "+req+" from "+client.getName());    
    }
    
    public void processRegCollabEdit(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String comp = client.getStringRequest();
        int level = Integer.parseInt(client.getStringRequest());
        
        System.out.println("Collab server received collab edit request for "+project+" "+comp);

        if(user.equals(app.getUserName()))
            System.out.println("Can't collabortively edit with self!!");
        else {
            MVProject p = app.findProjectName(project);
            // need to receive more "look-up info", not just userName()
            // for now we'll assume an MVViewLayer hence use findView()
            // functionality of Project's base layers...
            if(p != null) {
                MVViewLayer v = p.findViewByName(comp);
                if(v != null) {
                    MVViewCollabMenu m = (MVViewCollabMenu) v.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                    m.collaborationRequest(false,user,level);
                    client.sendReply("done");    
                } else {
                    // need to ask other person's environment for
                    // a copy of this view as we don't have it!
                    if(level > 0) {
                        client.sendReply("sendView");
                    } else
                        client.sendReply("done");
                }
            }
        }
    }
    
    public void processCollabEdit(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String comp = client.getStringRequest();
        byte bytes[] = client.getBytesRequest();
        
        System.out.println("Collab server received collab edit from "+user+" for "+project+" "+comp);
        
        MVProject p = app.findProjectName(project);
        // need to receive more "look-up info", not just userName()
        // for now we'll assume an MVViewLayer hence use findView()
        // functionality of Project's base layers...
        if(p != null) {
            MVViewLayer v = p.findViewByName(comp);
                
            if(v != null) {
                MVViewCollabMenu m = (MVViewCollabMenu) v.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                m.changeReceived(user,bytes);
            }    
        }
    }
    
    public void processCompSend(MVServerProcess client)
    {       
        String user = client.getStringRequest();
        String projectName = client.getStringRequest();
        String baseName = client.getStringRequest();
        String userName = client.getStringRequest();
        byte bytes[] = client.getBytesRequest();
        
        System.out.println("Collab server got comp "+projectName+" "+baseName+" "+userName);
System.out.println("bytes.length = "+bytes.length);
        
        MVInputBuffer2 buffer = new MVInputBuffer2(bytes);
        
        MVProject p = app.findProjectName(projectName);
        
        if(p != null) {
            // need to extend to other types of comp later...
            //
            MVBaseLayer b = p.findBaseByName(baseName);
            
            if(b != null) {
                MVViewLayer new_comp = (MVViewLayer) p.importComponent(buffer,new MVImportViewLocator(b));
                             
                MVViewLayer old_view = b.findViewByName(new_comp.getName());
                if(old_view != null) {
                    old_view.setName(old_view.getName()+" ("+b.getViewName()+")");
                    b.setViewName(b.getViewName()+1);
                    MVViewCollabMenu m = (MVViewCollabMenu) old_view.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                    m.collaborationRequest(false,user,0); // remove collaboration from old view
                }
                b.addView(new_comp);
                new_comp.setAggregateRel("viewComponents"); // should be done by deserialize...
                new_comp.createFrame();
                new_comp.remapComponents();
                new_comp.show();
                MVViewCollabMenu m = (MVViewCollabMenu) new_comp.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                m.collaborationRequest(true,user,1);                    
             } else
                System.out.println("*** Can't find base layer "+baseName);
            
        } else
            System.out.println("*** Can't find project "+projectName);          
        
    }
    
    public void processChangesSend(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String comp = client.getStringRequest();
        int lastNum = Integer.parseInt(client.getStringRequest());
        byte bytes[] = client.getBytesRequest();
        
        System.out.println("Collab server received changes send for "+project+" "+comp);
        
        MVProject p = app.findProjectName(project);
        // need to receive more "look-up info", not just userName()
        // for now we'll assume an MVViewLayer hence use findView()
        // functionality of Project's base layers...
        if(p != null) {
            MVViewLayer v = p.findViewByName(comp);
            if(v != null) {
                MVViewCollabMenu m = (MVViewCollabMenu) v.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                m.changesReceived(user,lastNum,bytes);
            } else   
                System.out.println("*** Can't find view "+comp);
        }  else
            System.out.println("*** Can't find project "+project);
    
    }
    
    public void processChangesRequest(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String comp = client.getStringRequest();
        int num = Integer.parseInt(client.getStringRequest());
        
        System.out.println("Collab server received changes request for "+project+" "+comp);
        
        MVProject p = app.findProjectName(project);
        // need to receive more "look-up info", not just userName()
        // for now we'll assume an MVViewLayer hence use findView()
        // functionality of Project's base layers...
        if(p != null) {
            MVViewLayer v = p.findViewByName(comp);
            if(v != null) {
                MVViewCollabMenu m = (MVViewCollabMenu) v.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                m.sendChanges(user,num);
            } else   
                System.out.println("*** Can't find view "+comp);
        }  else
            System.out.println("*** Can't find project "+project);
    
    }
    
    public void processCompRequest(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String comp = client.getStringRequest();
        
        System.out.println("Collab server received view request for "+project+" "+comp);
        
        MVProject p = app.findProjectName(project);
        // need to receive more "look-up info", not just userName()
        // for now we'll assume an MVViewLayer hence use findView()
        // functionality of Project's base layers...
        if(p != null) {
            MVViewLayer v = p.findViewByName(comp);
            if(v != null) {
                MVViewCollabMenu m = (MVViewCollabMenu) v.getOneRelated("MVCollabMenu",MVComponent.MVParents);
                m.sendView(user);
            } else   
                System.out.println("*** Can't find view "+comp);
        }  else
            System.out.println("*** Can't find project "+project);
    
    }    
    
/*    
    public void processViewsList(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String name = client.getStringRequest();
        
        MVProject p = app.findProjectName(project);
        
        if(p != null) {
            MVBaseLayer b = p.findBaseByName(base);
            MVBaseViewsRel r = b.getViewsRel();
            Enumeration e = r.children();
            while(e.hasMoreElements()) {
                MVViewLayer v = (MVViewLayer) e.nextElement();
                // should check private or not??
                client.sendReply(v.getName());
            }
            client.sendReply("DONE");
            
        } else
            System.out.println("*** Unknown project "+project+" for viewsList request");
    }
*/    
    public void processCheckConnection(MVServerProcess client)
    {
        System.out.println("MVCollabServer got checkConnection request from "+client.getName());
        //client.sendReply("done");
    }

    public void processRemoteChangeSend(MVServerProcess client)
    {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        String from = client.getStringRequest();
        String to = client.getStringRequest();
        byte bytes[] = client.getBytesRequest();
        
        System.out.println("Collab server received remote change send for "+project+" "+to+" from "+from);
        
        MVProject p = app.findProjectName(project);
        // need to receive more "look-up info", not just userName()
        // for now we'll assume an MVViewLayer hence use findView()
        // functionality of Project's base layers...
        if(p != null) {
            MVRemoteChangeReceiver rec = (MVRemoteChangeReceiver) p.findCompByName("JViews.MVRemoteChangeReceiver",to);
            if(rec != null)
            {
                rec.receiveRemoteChange(user,from,bytes);
            } // say can't find receiver for change??
            else
                System.out.println("*** Can't find component "+to+" to pass change to!!");
        } // tell sender can't find project (i.e. not open)??
    }

    public void setUser(String name)
    {
        app.setUserName(name);
    }
    
    public void setPort(int p)
    {
        app.setPort(p);
        super.setPort(p);
        this.start();
    }
    
    public void setRegistrar(String host)
    {
        app.setRegistrar(host);
    }
    
    public void setRegPort(int p)
    {
        app.setRegPort(p);
    }    
 
    public boolean register()
    {
        return app.register();
    }
    
}

class MVCollabServerFrame extends Frame implements ActionListener
{
      
      protected MVCollabServer server;
      
      Label l1 = new Label("Enter your name:");
      TextField f1 = new TextField("john");
      Label l2 = new Label("Enter port # for your server:");
      TextField f2 = new TextField("5001");
      
      Label l3 = new Label("Enter JViews Registration Server host:");
      TextField f3 = new TextField("johngvp.cs.waikato.ac.nz");
      Label l4 = new Label("Enter port # for Registration Server:");
      TextField f4 = new TextField("5000");
      
      Button reg = new Button("Register");
      Button offline = new Button("Off-line");
      
      public MVCollabServerFrame(MVCollabServer s)
      {
        super("User Registration");
        server = s;
        setLayout(new GridLayout(10,1));
        add(l1);
        add(f1);
        f1.setText(s.getApplication().getDefaultName());
        add(l2);
        add(f2);
        f2.setText(s.getApplication().getDefaultPort());
        add(l3);
        add(f3);
        f3.setText(s.getApplication().getDefaultServerHost());
        add(l4);
        add(f4);
        f4.setText(s.getApplication().getDefaultServerPort());
        add(reg);
        reg.addActionListener(this);
        add(offline);
        offline.addActionListener(this);
        setSize(300,280);
        pack();
        setVisible(true);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if(e.getSource() == reg) {
        String user = f1.getText();
        server.setUser(user);
        
        String reg_host = f3.getText();
        int rport = Integer.parseInt(f4.getText());
        
        server.setRegistrar(reg_host);
        server.setRegPort(rport);    
        
        int port = Integer.parseInt(f2.getText());
        server.setPort(port);
        
        if(server.register()) {                        
            setVisible(false);
        } else 
            System.out.println("Can't connect to registration server!!");
            
    } else if(e.getSource() == offline) {
        String user = f1.getText();
        server.setUser(user);
        server.setRegistrar("");
        server.setRegPort(0);
        int port = Integer.parseInt(f2.getText());
        server.setPort(port);
        setVisible(false);  
    }
  }
  
  
}


