
package JViews;

import java.util.*;
import java.io.*;

public class MVMessage extends MVChangeDescr
    // A MVMessage is used by filters and actions to invoke
    // methods belonging to other filters/actions.
    //
    // The key advantage of using a MVMessage vs. a straight
    // method invocation is that messages can be queued,
    // sent to distributed environments, etc.
{

    String name;
    String exception;
    Object args[];
    Object result;

    public MVMessage()
    {
        super();
    }
    
    public MVMessage(MVComponent target, String name)
        // any "nice" way to pass args to constructor...???
    {
        super(target);
        this.name = name;
    }
    
    public MVMessage(MVComponent target, String name, Object arg1)
        // 1-argument call...
    {
        super(target);
        this.name = name;
        addArg(arg1);
    }
    
    public MVMessage(MVComponent target, String name,
        Object arg1, Object arg2)
        // 2-argument call...
    {
        super(target);
        this.name = name;
        addArg(arg1);
        addArg(arg2);
    }
    
    public void addArg(Object arg)
    {
        Object new_args[];
        
        if(args == null) {
            args = new Object[1];
            new_args = new Object[1];
        } else
            new_args = new Object[args.length+1];
            
        System.arraycopy(args,0,new_args,0,args.length);
        new_args[new_args.length-1] = arg;
        args = new_args;
    }
    
    public String getName()
    {
        return name;
    }                 
    
    public Object[] getArgs()
    {
        return args;   
    }
    
    public Object getResult()
    {
        return result;
    }
    
    public void setResult(Object result)
    {
        this.result = result;
    }
    
    public String getException()
    {
        return exception;
    }   
    
    public void setException(String exception)
    {
        this.exception = exception;
    }
    
    public void execute()
    {
        getTarget().runMessage(this);
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    public String toString() 
    {
        String value = "MVMessage "+getTarget().userName()+"."+name+"(";
        
        int i;
        for(i=0;i<args.length;i++) {
            value = value + args[i].toString()+" ";
        }
        
        return value+")";
    }

    public void serialize(MVOutputBuffer output)
    {
        super.serialize(output);
        
        // serialise name + args
    }
    
    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException
    {
        super.deserialize(input,locator);
        
        // deserialise name + args
    }

}

