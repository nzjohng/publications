package JViews;

import java.io.*;
import java.util.*;

public class MVSetStringValue extends MVSetValue {
  public String old_value;
  public String new_value;

    public MVSetStringValue() {
        super();
    }

  public MVSetStringValue(MVComponent target, String name,
      String old_value, String new_value, MVStringAttribute attribute) {
        done = false;
    this.target = target;
        setPropertyName(name);
    this.old_value = old_value;
        this.new_value = new_value;
        this.attribute = attribute;
  }

    public String getOldValue() {
        return old_value;
    }

    public String getNewValue() {
        return new_value;
    }

  public void execute() {
    ((MVStringAttribute) attribute).setValue(new_value);
      // don't generate change description
    done = true;
  }

  public void undo() {
    target.setValue(getPropertyName(),old_value);
      // generate change description
  }

  public void redo() {
    target.setValue(getPropertyName(),new_value);
      // generate change description
  }

  public String toString() {
    return ("SetStringValue "+target.userName()+":"+getPropertyName()+" "+old_value+" to "+new_value);
  }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writelnQuoted(old_value);
        output.writelnQuoted(new_value);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator)
        throws IOException {
        super.deserialize(input,locator);
        old_value = input.getStringToken();
        new_value = input.getStringToken();
    }

}
