package JViews;

import bbw.*;

public class MVSubIcon extends MVIcon {

  public MVSubIcon() {
    super();
  }

    public void init(MVViewLayer view) {
        super.init(view);

    }
  
    public MVViewComp getOwner() {
        return (MVViewComp) getOneRelated("IconOwner",MVChildren);
    }
    
    public boolean hasOwner() {
        if(getRelationship("IconOwner",MVChildren).size() > 0)
            return true;
        else
            return false;
    }

    public void setOwner(MVViewComp comp) {
        establishOneToMany("IconOwner",comp);
        comp.setAggregateRel("IconOwner");
    }

    public BBWComponent getBBWParent() {
        return getOwner().getBBWShape();
    }
  
    public boolean canBeDrawn()
    {
        if(super.canBeDrawn() && getOneRelatedOrNull("IconOwner",MVChildren) != null)
            return true;
        else
            return false;
    }
    
/*    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
    {
        if(c instanceof MVEstablishOneToMany) {
            if(((MVEstablishOneToMany) c).getName().equals("IconOwner")) {
                if(getBBWShape() == null && getBBWParent() != null)
System.out.println("sending MVAddComponent to view's frame for MVSubIcon");
                    MVAddComponent a = new MVAddComponent(view(),compKind(),this);
                    view().getViewFrame().addedViewComp(a);
            }
        }
    
        return super.afterChange(c,from,rel);
    }
    
*/

}
