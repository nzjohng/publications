package JViews;

import java.io.*;

public class ClientTest
{

    public static void main(String argv[])
    {
        MVClientMultSend ct = new MVClientMultSend(); 
        ct.start();
        
        MVClient c1 = ct.addServer("",5000);
        System.out.println("here1");
        c1.sendRequest("john");
        
        MVClient c2 = ct.addServer("",5001);
        c2.sendRequest("john");
        
        System.out.println("here2");
        ct.sendRequest("r1");
        System.out.println("here5");
        System.out.println("here6");
        ct.sendRequest("r2");
        System.out.println("here7");
        // ct.sendRequest("r2");
        
        System.out.println("suspending...");
        c1.getStringReply();
    }

}
