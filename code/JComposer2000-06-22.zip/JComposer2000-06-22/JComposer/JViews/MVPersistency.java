package JViews;

import java.io.*;

/*
 * Basic persistency management interface
 *
 * Specialised to provide additional capabilities:
 * - incremental store/load
 * - broadcasting change descriptions to others
 * - heterogeneous, distributed storage
 *
 */

public class MVPersistency {

  protected MVProject project;
    // project to save for
  
  public MVPersistency(MVProject project) {
    this.project = project;
  }

  public void setProject(MVProject project) {
    this.project = project;
  }
  
  public void saveComponent(MVComponent comp) throws IOException {
    
  }
  
  public boolean prepareToSave(String file_name, String path) {
  
    return false;
  }
  
  public void finishedSaving() {
  
  }
  
  public void saveProjectData(MVProject project) {
  
  }
  
  public boolean loadProject() {
    return false;
  }

    public void writeBufferToFile(MVOutputBuffer output, String file_name, String path) {

    }

    public MVInputBuffer2 readBufferFromFile(String file_name, String path) {
        return null;
    }

}

