package JViews;

import java.io.*;

public class MVInputBuffer2 {

    public MVInputBuffer2() {

    }

    public MVInputBuffer2(InputStream input_stream) {
        input = input_stream;
        lineno = 1;
    }

    public MVInputBuffer2(byte bytes[]) {
        input = new ByteArrayInputStream(bytes);
        lineno = 1; 
        /* input = new StreamTokenizer(new InputStreamReader(buffer));
        input.eolIsSignificant(false);
        input.whitespaceChars(0,32);
        input.wordChars(33,127);
        input.quoteChar('"'); */
    }

    protected InputStream input;
    
    protected static final int BUFFER_SIZE = 2048;
    protected byte buffer[] = new byte[BUFFER_SIZE]; 
    protected byte value[] = new byte[128];   
    protected int pos = 0;    
    protected int size = 0; 
    protected int lineno = 0;
    
    public int readBytes() throws IOException
    {
        size = input.read(buffer,0,BUFFER_SIZE);
        pos = 0;
        
        return size;
    }

  // token reading support functions...

    public byte skipWhitespace() throws IOException
    {
        if(pos >= size)
            if(readBytes() == -1)
                return (byte) -1;
                
        while(buffer[pos] <= 32) {
            if(buffer[pos] == 13) {
                lineno++;
                pos++;
                if(pos >= size)
                    if(readBytes() == -1)
                        return (byte) -1;
                if(buffer[pos] == 10)
                    pos++;
            } else if(buffer[pos] == 10) {
                lineno++;
                pos++;
                if(pos >= size)
                    if(readBytes() == -1)
                        return (byte) -1;
                if(buffer[pos] == 13)
                    pos++;
            } else
                pos++;
            if(pos >= size)
                if(readBytes() == -1)
                    return (byte) -1;
        }       
        
        return buffer[pos];
    }   
    
    /*
    public int nextToken() throws IOException {
        return skipWhitespace();
    }
    */
    
    public char nextChar() throws IOException
    {
        // look at next input char
        
        if(skipWhitespace() < 0)
            return (char) -1;
            
        return (char) buffer[pos];
    }
        
    public boolean nextIsString() throws IOException
    {
        if(skipWhitespace() < 0)
            return false;
        return (buffer[pos] == '"');
    }
    
    public boolean nextIsInt() throws IOException
    {
        if(skipWhitespace() < 0)
            return false;
        return ((buffer[pos] >= '0' && buffer[pos] <= '9') || buffer[pos] == '-');
    }
    
  public void readToken(char value) throws IOException {
    char c = (char) skipWhitespace();
    
    if(c < 0)
        syntaxError("Expected "+value+", got EOF");
        
    if(value != c)
        syntaxError("Expected "+value+", got "+c);
        
    pos++;
  }
  
  protected char token[] = new char[32];

  public void readToken(String v) throws IOException {
    // read a string token
    
    if(skipWhitespace() < 0)
        syntaxError("Expected "+value+", got EOF");
    
    int len = v.length();
    v.getChars(0,len,token,0);
    
    int i = 0;
    while(i < len && token[i++] == (char) buffer[pos++]) {
        if(pos >= size)
            if(readBytes() < 0)
                syntaxError("Expected "+value+", got EOF");    
    }
    if(i == len && buffer[pos] <= 32)
        return;
        
    syntaxError(v+" expected");
  }
        
  public void syntaxError(String msg) {
    System.out.println("Syntax error on line "+lineno+": "+msg);
    throw(new MVSyntaxErrorException("syntax error"));
  }
  
  public String getStringToken() throws IOException {
    // return read string token
    
    byte c = skipWhitespace();
    
    if(c < 0)
        syntaxError("string value expected - got EOF");

    if(((char) c) != '"') 
        syntaxError("string value expected - got '"+(char) c+"'");
        
    int i = 0;
    pos++;
    if(pos >= size)
            if(readBytes() < 0)
                syntaxError("Expected string, got EOF");
    c = '-';

    while(c != '"') {
        if(pos >= size)
            if(readBytes() < 0)
                syntaxError("Expected string, got EOF");
        c = buffer[pos];
        if(c != '"')
            value[i++] = buffer[pos];
        pos++;
    }
      
    return new String(value,0,i);
  }
  
  public String getToken() throws IOException {
    // return read some token
    
    if(skipWhitespace() < 0) 
      syntaxError("token value expected - got EOF");
      
    int i = 0;
    byte c = 33;
    while(c > ' ') {
        if(pos >= size)
            if(readBytes() < 0)
                syntaxError("Expected token, got EOF");
        c = buffer[pos];
        if(c > ' ')
            value[i++] = buffer[pos];
        pos++;
    }  
    
    return new String(value,0,i);
  }

  public int getIntToken() throws IOException {
    // return int
    
    if(skipWhitespace() < 0) 
      syntaxError("int value expected - got EOF");

    byte c = buffer[pos];
    int i = 0;
    boolean neg = false;
    if(c == '-') {       
        neg = true;
        pos++;
        if(pos >= size)
            if(readBytes() < 0)
                syntaxError("int value expected - got EOF");
        c = buffer[pos];
    }
    
    if(!(c >= '0' && c <='9'))
        syntaxError("int value expected - got "+getToken());
     
    while(c > 32) {
        if(pos >= size)
            if(readBytes() < 0)
                syntaxError("Expected token, got EOF");
        c = buffer[pos];
         if((c >= '0' && c <='9'))  {
            i *= 10;
            i += (buffer[pos] - '0');
         }
        pos++;
     }
        
     return i;
  }

/*
    public boolean checkNextToken(String wanted) throws IOException {
        // "look ahead" read...
        
        if(skipWhitespace() < 0) 
            syntaxError(wanted+" value expected - got EOF");
      
        int len = wanted.length();
        wanted.getChars(0,len,token,0);
        
        int i = 0;
        byte c = 33;
        while(c > ' ') {
            if(pos >= size)
                if(readBytes() < 0)
                    syntaxError("Expected "+wanted+", got EOF");
            c = buffer[pos];
            if(c > ' ')
                value[i++] = buffer[pos];
            pos++;
        }          
            
        int j = 0;
        while(j < len && j < i && value[j] == token[j])
            j++;
        if((j == i) && (j== len)) {
            
            return true;
        }
        
        syntaxError("Expectd "+wanted+", got "+new String(value,0,i));
        return false;
    }
*/

    public boolean EOF() throws IOException {
        if(skipWhitespace() < 0)
            return true;
        else
            return false;
    }

    public boolean getBooleanToken() throws IOException {
        String t = getToken();
         
        if(t.equals("true"))
            return true;
        if(t.equals("false"))
            return false;
            
        syntaxError("wanted boolean token - got "+t);

        return false;
    }

}

