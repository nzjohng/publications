package JViews;

public class MVPropertyInfo extends MVAspectInfo
{

    String name;
    String type;
    boolean dynamic = false;

    public MVPropertyInfo()
    {
    
    }
    
    public String getBasicInfo()
    {
        if(dynamic)
            return "(dynamic) "+name+" : "+type;
        else
            return name+" : "+type;
    }
    
    public String toString()
    {
        return getBasicInfo()+" ("+getInfo()+")";
    }
    
    public MVPropertyInfo(String name, String type)
    {
        this.name = name;
        this.type = type;
    }
    
    public MVPropertyInfo(String name, String type, boolean dynamic)
    {
        this.name = name;
        this.type = type;
        this.dynamic = dynamic;
    }
    
    public MVPropertyInfo(String name, String type, String info)
    {
        super(info);
        this.name = name;
        this.type = type;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getType()
    {
        return type;
    }

    public boolean isSet()
    {
        // is this property value set for this component???
        
        return false;
    }
    
}
