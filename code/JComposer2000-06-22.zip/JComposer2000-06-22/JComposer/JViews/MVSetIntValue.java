package JViews;

import java.io.*;

public class MVSetIntValue extends MVSetValue {
  public int old_value;
  public int new_value;

  public MVSetIntValue(MVComponent target, String name,
      int old_value, int new_value, MVIntAttribute attribute) {
    done = false;
    this.target = target;
        setPropertyName(name);
    this.old_value = old_value;
        this.new_value = new_value;
        this.attribute = attribute;
  }

    public MVSetIntValue() {
        super();
    }
    
    public int getNewValue()
    {
        return new_value;
    }

    public int getOldValue()
    {
		return old_value;
    }

  public void execute() {
    ((MVIntAttribute) attribute).setValue(new_value);
      // don't generate change description
    done = true;
  }

  public void undo() {
    target.setValue(getPropertyName(),old_value);
      // generate change description
  }

  public void redo() {
    target.setValue(getPropertyName(),new_value);
      // generate change description
  }

  public String toString() {
    return "SetIntValue "+target.userName()+":"+getPropertyName()+" "+old_value+" to "+new_value;
  }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(old_value);
        output.writeln(new_value);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator)
        throws IOException {
        super.deserialize(input,locator);
        old_value = input.getIntToken();
        new_value = input.getIntToken();
    }

}
