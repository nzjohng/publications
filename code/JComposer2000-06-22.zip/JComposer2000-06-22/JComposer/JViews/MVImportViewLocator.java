package JViews;

import java.util.*;

class MVImportViewLocator implements MVCompLocator {

    MVProject project;
    MVBaseLayer base;
    Vector table = new Vector();

    public MVImportViewLocator(MVBaseLayer b) {
        project = b.getProject();
        base = b;
    }

    public MVComponent findOrCreateComp(int compID, int copiedFrom, String compKind) {
        // does no creation - only looks up compID/copiedFrom in table

        MVImportViewItem i = findViewItem(compID,copiedFrom);
        if(i != null)
            return i.newComp;

        return null;
    }
    
    public MVImportViewItem findViewItem(int compID, int copiedFrom)
    {
        Enumeration e = table.elements();
        while(e.hasMoreElements()) {
            MVImportViewItem item = (MVImportViewItem) e.nextElement();
            if(item.oldCompID == compID)
                return item;
            else if(item.copiedFrom == copiedFrom)
                return item;
        }
        
        return null;
    }

    public MVComponent findOldComp(int compID, int copiedFrom, String compKind, String userName) {
        MVImportViewItem i = findViewItem(compID,copiedFrom);
        if(i != null)
            return i.newComp;

        return null;
    }

    public MVComponent createNewComp(int compID, int copiedFrom, String compKind) {
        MVComponent newComp = project.createNewComp(compID,copiedFrom,compKind);
        table.addElement(new MVImportViewItem(compID,newComp.compID,copiedFrom,newComp));
        return newComp;
    }

    public MVChangeDescr createNewChange(String changeKind) {
        return project.createNewChange(changeKind);
    }

    public void reestablishRel(MVComponent otherComp, MVRelItem locatorRel,
        MVComponent locatorComp) {
        // does nothing when importing a view...

    }

}


