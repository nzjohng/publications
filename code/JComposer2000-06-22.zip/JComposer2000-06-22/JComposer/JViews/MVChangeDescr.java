package JViews;

import java.util.*;
import java.io.*;

public abstract class MVChangeDescr implements Cloneable {
  public MVComponent target;
    // thing that was modified/to be modified
    
    public MVChangeDescr(MVComponent c)
    {
        setTarget(c);
    }

    public String changeKind() {
        return getClass().getName();
    }

    public MVComponent getTarget() {
        return target;
    }

    public void setTarget(MVComponent value) {
        target = value;
    }

   public boolean done = false;
    // has change description been actioned? (i.e. "do" been called)
    
  public int number;
    // used when storing change descriptions
    
  public MVMacroChangeDescr parent = null;
    // parent if this is part of a macro change description

  public MVChangeDescr() {
    done = false;
  }
  
  public int getNumber()
  {
    return number;
  }
  
  public boolean getDone()
  {
    return done;
  }

  public abstract void execute();
    // apply chamge descr (operation) to target

  public abstract void undo();
    // undo effect(s) of change description

  public abstract void redo();
    // redo effect(s) of change description

  public abstract String toString();
    // convert change description data into human-readable form

  public void discard()
    // called when version record throws away change description
    // can also be called if change description is not stored
    // put e.g. remove deleted comp from project's registry etc.
    // here
  {
  
  }
    
  public void setCount(int count) {
    number = count;
  }

    public int getCount() {
        return number;
    }
  
  public boolean targets(MVComponent c) {
    // does this change description "target" this component?
    // for e.g. establish/dissolve rel, all involved comps are "targets"
    return (c == target);  
  }
  
  public MVChangeDescr copyChangeDescr() {
    MVChangeDescr new_c = null;
    
    try {
      new_c = (MVChangeDescr) clone();
      new_c.parent = null;
    } catch (Exception e) {
      throw(new MVFatalException("couldn't clone change description"));
    }

    return(new_c);
  }

    public String summaryString() {
        return toString();
    }

    public void serialize(MVOutputBuffer output) {
        output.write("change ");
        output.write(changeKind());
        output.write(' ');
        output.write(target.compID);
        output.write(' ');
        output.writeln(number);
        if(annotations != null) {
            output.write("[ ");
            Enumeration e = annotations.elements();
            while(e.hasMoreElements()) {
                MVChangeAnnotation a = (MVChangeAnnotation) e.nextElement();
                output.write("  "+a.name+" = ");
                output.writelnQuoted(a.value);
            }
            output.writeln(" ]");
        } else {
            output.writeln("[ ]");
        }
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) 
        throws IOException {
        int compID = input.getIntToken();
        number = input.getIntToken();

        input.readToken('[');

        while(input.nextChar() != ']') {
            String name = input.getToken();
            if(annotations == null)
                annotations = new Vector();
            input.readToken('=');
            String value = input.getStringToken();
            MVChangeAnnotation a = new MVChangeAnnotation(name,value);
            annotations.addElement(a);
        }
        
        input.readToken(']');
        
        target = locator.findOldComp(compID,0,"","");
 /*
 if(target != null)
 System.out.println("target "+compID+" for change set to "+target.compID);
 else
 System.out.println("couldn't find match for target "+compID);
*/
    }
    
    public boolean isValid()
    {
        return (target != null);
    }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        if(!rel.contains(target))
            rel.addElement(target);
    }
    
    protected Vector annotations = null;
    
    public String getAnnotation(String name)
    {
        if(annotations != null) {
            Enumeration e = annotations.elements();
            
            while(e.hasMoreElements()) {
                MVChangeAnnotation a = (MVChangeAnnotation) e.nextElement();
                if(a.name.equals(name))
                    return a.value;
            }
        }
        
        return null;
    }

   public void setAnnotation(String name, String value)
    {
        if(annotations != null) {
            Enumeration e = annotations.elements();
            
            while(e.hasMoreElements()) {
                MVChangeAnnotation a = (MVChangeAnnotation) e.nextElement();
                if(a.name.equals(name)) {
                    a.value = value;
                    return;
                }
            }
            
            MVChangeAnnotation a = new MVChangeAnnotation(name,value);
            annotations.addElement(a);
        } else {
            annotations = new Vector();
            MVChangeAnnotation a = new MVChangeAnnotation(name,value);
            annotations.addElement(a);
        }
    }  
}

class MVChangeAnnotation {

    public String name;
    public String value;

    public MVChangeAnnotation(String n, String v)
    {
        name = n;
        value = v;
    }

}
