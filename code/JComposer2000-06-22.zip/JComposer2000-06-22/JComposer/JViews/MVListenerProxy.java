package JViews;

import java.util.Vector;

public interface MVListenerProxy
{

    public String getAttributeValue(String name);
    
    public void setAttributeValue(String name, String value);
    
    public MVComponent getInputComp(String rel);
    
    public Vector getOutputComps(String rel);

}
