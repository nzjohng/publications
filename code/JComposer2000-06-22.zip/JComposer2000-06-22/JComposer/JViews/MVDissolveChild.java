package JViews;

import java.io.*;

public class MVDissolveChild extends MVChangeDescr {
  public MVComponent parent;
  public MVComponent child;

  public MVDissolveChild()
  {
  }

  public MVDissolveChild(MVRelationship init_target, MVComponent init_parent,
    MVComponent init_child) {
    target = init_target;
    parent = init_parent;
    child = init_child;
  }

  public MVRelationship relTarget() {
    return (MVRelationship) target;
  }

  public void execute() {
    // dissolve links from rel comp. to parent/child & from parent/child to rel comp.
    parent.broadcastBefore(this);
    child.broadcastBefore(this);
    relTarget().removeChild(child);
    child.removeRelationship(relTarget().relName(),MVComponent.MVRelLinksParents,target);
    parent.broadcastAfter(this);
    child.broadcastAfter(this);
    done = true;
  }

  public void undo() {
    relTarget().establish(parent,child);
  }

  public void redo() {
    relTarget().dissolve(parent,child);
  }

  public String toString() {
    return ("DissolveRel "+relTarget().relName()+" "+parent.userName()+" to "+child.userName());
  }
  
  public boolean targets(MVComponent c) {
    if(target == c)
      return true;
    if(parent == c)
      return true;
    if(child == c)
      return true;
      
    return false;
  }

    public boolean isValid()
    {
        return super.isValid() && (parent != null && child != null);
    }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.writeln(parent);
        output.writeln(child);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator) throws IOException {
        super.deserialize(input,locator);
        int pid = input.getIntToken();
        int cid = input.getIntToken();
        parent = locator.findOrCreateComp(pid,0,"");
        child = locator.findOrCreateComp(cid,0,"");
    }


}
