package JViews;

import java.io.*;
import java.util.*;

public class MVChangeKey extends MVChangeDescr {

    protected String oldName;
    protected String newName;
    protected MVComponent item;

    public MVChangeKey() {
        super();
    }

    public MVChangeKey(MVRelationship rel, String oldName, String newName, MVComponent item) {
        this.target = rel;
        this.oldName = oldName;
        this.newName = newName;
        this.item = item;
    }

    public MVRelationship getRelationship() {
        return (MVRelationship) target;
    }

    public String getNewName() {
        return newName;
    }

    public String getOldName() {
        return oldName;
    }

    public void execute() {
        getRelationship().doChangeKey(oldName,newName,item);
    }

    public void undo() {
        getRelationship().changeKey(newName,oldName,item);
    }

    public void redo() {
        getRelationship().changeKey(oldName,newName,item);
    }

    public String toString() {
        return "MVChangeKey "+getRelationship().userName()+": "+oldName+" to "+newName+" for "+item.userName();
    }

    public void serialize(MVOutputBuffer output) {
        super.serialize(output);
        output.write("change ");
        output.writeln(changeKind());
        output.writeQuoted(oldName);
        output.writeQuoted(newName);
        output.writeln(item);
    }

    public void deserialize(MVInputBuffer2 input, MVCompLocator locator)
        throws IOException {
        super.deserialize(input,locator);
        oldName = input.getStringToken();
        newName = input.getStringToken();
        int compID = input.getIntToken();
        item = locator.findOldComp(compID,0,"","");
    }

    public void getAggregatesRelated(Vector aggs, Vector rel) {
        super.getAggregatesRelated(aggs,rel);
        if(!rel.contains(item))
            rel.addElement(item);
    }

    public boolean targets(MVComponent comp) {
        if(comp == item)
            return true;
        else
            return super.targets(comp);
    }
            
    public boolean isValid()
    {
        return super.isValid() && (item != null);
    }

  
}

