package JViews;

/*
 * Base views relationship
 *
 */
 
import java.util.*;

public class MVBaseViewsRel extends MVHashtableRel {

  public String userName() {
    return "views";
  }

  public MVBaseViewsRel() {
    super();
  }

  public MVBaseViewsRel(String name, MVComponent parent) {
    super(name,parent);
        setAggregate(true);
  }

  public String extractKey(MVComponent view) {
    return ((MVViewLayer) view).getName();
  }

    public void establish(MVComponent parent, MVComponent child) {
        super.establish(parent,child);
        child.setListenBeforeRel(relName());
        child.setListenAfterRel(relName());
    }

  public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel_name) {
    // receive listen before change description
    
// Move detection of duplicates to "UniqueValues" listener

        if(c instanceof MVEstablishRel) {
            if(get(((MVViewLayer) ((MVEstablishRel) c).getChild()).getName()) != null)
                    throw(new MVDuplicateKey("Duplicate key "+((MVViewLayer) ((MVEstablishRel) c).getChild()).getName()+" for relationship "+userName()));
        }

        if(c instanceof MVChangeKey) {
            if(get(((MVChangeKey) c).getNewName()) != null)
                throw(new MVDuplicateKey("Duplicate key "+((MVChangeKey) c).getNewName()+" for relationship "+userName()));
        }

// Move update of key to "UpdateKey" listener??

        if(c instanceof MVSetStringValue) {
            if(((MVSetStringValue) c).getPropertyName().equals("Name") && contains(from)) {
                String oldName = ((MVSetStringValue) c).getOldValue();
                String newName = ((MVSetStringValue) c).getNewValue();
                changeKey(oldName,newName,from);
            }
        }
    
    
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
  {
        if(from instanceof MVViewLayer) {
            Enumeration e = parents();
            while(e.hasMoreElements()) {
                MVBaseLayer bl = (MVBaseLayer) e.nextElement();
                bl.broadcastAfter(c);
            }
        
        }
            

        return super.afterChange(c,from,rel);
  }
  
}
