
package JViews;

public class MVCantFindCompException extends MVException
{
    protected int compID;
    protected int copiedFrom;
    protected String compKind;
    
    public MVCantFindCompException(int comp, int copy, String kind)
    {
        super("Can't locate component "+comp+" "+kind);
        compID = comp;
        copiedFrom = copy;
        compKind = kind;
    }
}
