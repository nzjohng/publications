package JViews;

import java.io.*;

public class MVIntAttribute extends MVAttribute {
  public int value;

  public MVIntAttribute(String init_name, int init_value) {
    name = init_name;
    value = init_value;
  }

  public void setValue(int new_value) {
    value = new_value;
  }

  public String toString() {
    return (name+" = "+value);
  }
  
  public boolean isBlank() {
    return (value == MVComponent.MVIntBlank);
  }
  
  public void setCompValue(MVComponent c) {
    c.setValue(name,value);
  }
}
