
public class MVBBWSetProperty extends MVSetProperty {

	public MVBBWSetProperty(MVComponent target, String propertyName,
			Object old_value, Object new_value) {
		super(target,propertyName,old_value,new_value);
	}

	public void execute() {
		// already generated so don't try and do doSetPropertyValue()...
		done = true;
	}

}

