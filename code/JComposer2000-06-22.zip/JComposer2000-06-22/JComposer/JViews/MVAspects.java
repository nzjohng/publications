
package JViews;

import java.lang.reflect.*;
import java.util.*;
import java.beans.*;
import java.awt.*;
import java.awt.event.*;


public class MVAspects 
{

    MVComponent comp;   
    Vector aspects = new Vector();

    public MVAspects(MVComponent comp)
    {
        this.comp = comp;
    }
    
    public MVComponent getComp()
    {
        return comp;
    }
    
    public Vector getAspects()
    {
        return aspects;
    }
    
    public MVPropertyAspect getPropertyAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVPropertyAspect)
                return (MVPropertyAspect) a;                    
        }
        
        MVPropertyAspect pas = newPropertyAspect();
        aspects.addElement(pas);
        return pas;
    }
    
    public MVPropertyAspect newPropertyAspect()
    {
        return new MVPropertyAspect();
    }
        
    public MVRelationshipAspect getRelationshipAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVRelationshipAspect)
                return (MVRelationshipAspect) a;                    
        }
        
        
        MVRelationshipAspect ras = newRelationshipAspect();
        aspects.addElement(ras);
        return ras;
    }
    
    public MVRelationshipAspect newRelationshipAspect()
    {
        return new MVRelationshipAspect();
    }

    public MVConfigurationAspect getConfigurationAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVConfigurationAspect)
                return (MVConfigurationAspect) a;                    
        }
        
        MVConfigurationAspect cas = newConfigurationAspect();
        aspects.addElement(cas);
        return cas;
    }
    
    public MVConfigurationAspect newConfigurationAspect()
    {
        return new MVConfigurationAspect();
    }
        
    public MVHumanInterfaceAspect getHumanInterfaceAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVHumanInterfaceAspect)
                return (MVHumanInterfaceAspect) a;                    
        }
        
        MVHumanInterfaceAspect hias = newHumanInterfaceAspect();
        aspects.addElement(hias);
        return hias;
    }
    
    public MVHumanInterfaceAspect newHumanInterfaceAspect()
    {
        return new MVHumanInterfaceAspect();
    }
    
            
    public MVPersistencyAspect getPersistencyAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVPersistencyAspect)
                return (MVPersistencyAspect) a;                    
        }
        
        MVPersistencyAspect hias = newPersistencyAspect();
        aspects.addElement(hias);
        return hias;
    }
    
    public MVPersistencyAspect newPersistencyAspect()
    {
        return new MVPersistencyAspect();
    }  

    public MVCollaborationAspect getCollaborationAspect()
    {
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()){
            MVAspect a = (MVAspect) e.nextElement();
            if(a instanceof MVCollaborationAspect)
                return (MVCollaborationAspect) a;                    
        }
        
        MVCollaborationAspect hias = newCollaborationAspect();
        aspects.addElement(hias);
        return hias;
    }
    
    public MVCollaborationAspect newCollaborationAspect()
    {
        return new MVCollaborationAspect();
    }  
    
    public void getDefaultInfo()
    {
        // get "static" properties via get/set methods
        
        // get "dynamic" properties via component attributes Vector...
        
        getCompAttributes();
        
        // get "static" relationships via getp, getc, etc. methods
            
        // get "dynamic" relationships via component relationships Vector
        
        getCompRelationships();
        
        // if MVViewComp, create MVHumanInterfaceInfo for
        // pop-up menu?? Or add in MVViewComp class...
        
        // if MVViewLayer, create MVHumanInterfaceInfo for
        // menu bar?? Or add in MVViewLayer class...
        
            
        
    }
    
    public void getCompAttributes()
    {
        PropertyDescriptor props[] = null;
        Object targ = null;
        MVPropertyInfo pa = null;
        
        MVPropertyAspect pas = getPropertyAspect();
    
        try {
            Class c = comp.getClass();
            BeanInfo bi = Introspector.getBeanInfo(c);
            props = bi.getPropertyDescriptors();
        } catch (IntrospectionException ex) {
            throw(new MVFatalException("Couldn't introspect "+comp.userName()));
        } catch(Exception e) {
            System.out.println("getCompAttributes() got: "+e);
        }

    try {
        for (int i = 0; i < props.length; i++) {
            // Don't copy hidden or expert properties.
            if (props[i].isHidden() || props[i].isExpert()) {
                continue;
            }

            String name = props[i].getName();
            Class type = props[i].getPropertyType();
            Method getter = props[i].getReadMethod();
            Method setter = props[i].getWriteMethod();

            // Only copy read/write properties.
            if (getter == null || setter == null) {
                continue;
            }

            if(pas.findPropertyInfo(name) == null) {
                pa = new MVPropertyInfo(name,type.getName());
                pas.addPropertyInfo(pa);
            }   
        }

        }
        catch(Exception e) {
            System.out.println("getCompAttributes() got: "+e);
            e.printStackTrace();
        }
       
        // find dynamic properites
        Enumeration e1 = comp.getAttributes().elements();
        while(e1.hasMoreElements()) {
            MVAttribute a = (MVAttribute) e1.nextElement();
            
            if(pas.findPropertyInfo(a.getPropertyName()) == null) {
                String type = "";
                if(a instanceof MVStringAttribute)
                    type = "java.lang.String";
                if(a instanceof MVIntAttribute)
                    type = "int";  
                if(a instanceof MVBooleanAttribute)
                    type = "boolean";  
                pa = new MVPropertyInfo(a.getPropertyName(),type,true);
                pas.addPropertyInfo(pa);
            }
        }      

    }
    
    /* Get the component's relationships via introspection of method names */
    
    public void getCompRelationships()
    {
        MethodDescriptor methods[] = null;
        Object targ = null;
        MVRelationshipInfo ra = null;
        
        MVRelationshipAspect ras = getRelationshipAspect();
               
        // find dynamic relationships
        
        Enumeration e1 = comp.getRelationships().elements();
        while(e1.hasMoreElements()) {
            MVRelItem ri = (MVRelItem) e1.nextElement();
            
            if(ras.findRelationshipInfo(ri.getName()) == null) {
                ra = new MVRelationshipInfo(ri.getName(),"0:n",ri.getKind(),ri.getFlags(),ri.isAggregate(),"MVComponent",true);
                ras.addRelationshipInfo(ra);
            }
        }            
 
        // find static relationships
        
        try {
            Class c = comp.getClass();
            BeanInfo bi = Introspector.getBeanInfo(c);
            methods = bi.getMethodDescriptors();
        } catch (IntrospectionException ex) {
            throw(new MVFatalException("Couldn't introspect "+comp.userName()));
        } catch(Exception e) {
            System.out.println("getCompRelationships() got: "+e);
        }

    try {
        for (int i = 0; i < methods.length; i++) {
            // Don't analyse hidden or expert methods.
            if (methods[i].isHidden() || methods[i].isExpert()) {
                continue;
            }
            
            ra = ras.findRelationshipInfo(relNameFromMethodName(methods[i].getMethod().getName()));
            if(ra == null) {
                ra = determineRelMethod(methods[i].getMethod());
                if(ra != null)
                    ras.addRelationshipInfo(ra);
            } else  {
                // kind of linked comp might be determined from method return value...
                String links = methods[i].getMethod().getReturnType().getName();  
                if(!links.equals("java.lang.Vector"))
                    ra.setLinks(links);
                ra.setDynamic(false);
            }
        }

        }
        catch(Exception e) {
            System.out.println("getCompRelationships() got: "+e);
            e.printStackTrace();
        }   
    
    }
    
    public MVRelationshipInfo determineRelMethod(Method m)
    {
        MVRelationshipInfo ri = null;
        
        String name = relNameFromMethodName(m.getName());
        if(name == null)
            return null;
            
        char chars[] = m.getName().toCharArray();
        String f4 = new String(chars,0,4);
        String f5 = new String(chars,0,5);
        
        String returnType = m.getReturnType().getName();
        String arity = "0:1";
        if(returnType.equals("java.util.Vector"))
            arity = "0:n";

        if(f5.equals("getpc"))
            ri = new MVRelationshipInfo(name,arity,MVComponent.MVRelLinksParents,"",false,returnType,false);
        if(f5.equals("getcc"))
            ri = new MVRelationshipInfo(name,arity,MVComponent.MVRelLinksChildren,"",false,returnType,false);
        if(f4.equals("getp"))
            ri = new MVRelationshipInfo(name,arity,MVComponent.MVReverseOneToMany,"",false,returnType,false);
        if(f4.equals("getc"))
            ri = new MVRelationshipInfo(name,arity,MVComponent.MVOneToMany,"",false,returnType,false);
        
        return ri;
        
    }
    
    public String relNameFromMethodName(String mName)
    {
        char chars[] = mName.toCharArray();
        
        if(chars.length < 5)
            return null;
            
        String f4 = new String(chars,0,4);
        String f5 = new String(chars,0,5);
        
        if(f5.equals("getpc") || f5.equals("getcc"))
            return new String(chars,5,chars.length-5);
        else if(f4.equals("getp") || f4.equals("getc"))
            return new String(chars,4,chars.length-4);
        else
            return null;
    }
    
    // methods for querying this component's aspect info
    // for information about properties, relationships,
    // human interface affordances, persistency mechanisms,
    // distribution mechanisms, collaborative editing etc.
    


    public String toString()
    {
        String value = "Aspect info for "+comp.userName()+"\n";
        
        Enumeration e = aspects.elements();
        while(e.hasMoreElements()) {
            MVAspect a = (MVAspect) e.nextElement();
            value = value+a.toString()+"\n";
        }
        
        return value;
    }
    
    public void showAspectInfo()
    {
        MVAspectsFrame f = new MVAspectsFrame("Aspects for: "+comp.userName(),this);
        f.setVisible(true);   
    }
}


class MVAspectsFrame extends Frame implements ActionListener
{

    MVAspects as;
    List aspects = new List();
    Button moreInfo = new Button("More Info");
    Button validate = new Button("Validate");
    Button close = new Button("Close");
    
    Panel p1 = new Panel();

    public MVAspectsFrame(String title, MVAspects as)
    {
        super(title);
        this.as = as;
        setLayout(new GridLayout(2,1));
        add(aspects);
        add(p1);
        p1.setLayout(new GridLayout(3,1));
        p1.add(moreInfo);
        moreInfo.addActionListener(this);
        p1.add(validate);
        validate.addActionListener(this);
        p1.add(close);
        close.addActionListener(this);
        
        Enumeration e = as.getAspects().elements();
        while(e.hasMoreElements()) {
            MVAspect a = (MVAspect) e.nextElement();
            aspects.addItem(a.getAspectKind());
        }
        
        setSize(200,200);
        pack();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == moreInfo) {
            try {
                MVAspect a = (MVAspect) as.getAspects().elementAt((aspects.getSelectedIndex()));
                a.showAspectInfo();
            } catch (Exception ex) {
                System.out.println("MVAspectsFrame.actionPerformed(): "+ex);
            }
        } else if(e.getSource() == validate) {
            doValidate();
        } else if(e.getSource() == close)
            setVisible(false);
    }
    
    public void doValidate()
    {
        String valid = null;
        
        Enumeration e = as.getAspects().elements();
        while(e.hasMoreElements()) {
            MVAspect a = (MVAspect) e.nextElement();
            valid = a.validate(as);

System.out.println("Msg: "+valid);
            
            if(valid != null) {
                new MVValidationErrorMsg(as.getComp().userName(),valid);
                return;
            }
        }
        
        new MVValidationOkMsg(as.getComp().userName());
    }

}
 
class MVValidationErrorMsg extends Frame
{
    TextArea t;
    
    public MVValidationErrorMsg(String title, String msg)
    {
        super("Validation error for "+title);
        setLayout(new GridLayout(1,1));
        t = new TextArea(msg);
        add(t);
        setVisible(true);
    }
}

class MVValidationOkMsg extends Frame
{
    TextArea t;
    
    public MVValidationOkMsg(String title)
    {
        super("No validation errors for "+title);
        setLayout(new GridLayout(1,1));
        t = new TextArea("No validation errors");
        add(t);
        setVisible(true);
    }
}

