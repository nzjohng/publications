package JViews;
                            
import java.io.*;
import java.net.*;

public class MVServerMultListen implements Runnable {
  Thread t = null;      // Server thread

  public MVServerMultListen() {
  }
  
  public MVServerMultListen(int port) {
    setPort(port);
  }

  public void destroy( ) {
    System.out.println( "MVServerListen::destroy called" );
  }

  // Start thread running (allocing if needed)
  public synchronized void start( ) {

    if( t == null ) {
      t = new Thread( this );
      t.setPriority( Thread.MAX_PRIORITY / 4 );
      t.start();
    }
  }

  // Stop thread from running if it exists
  public synchronized void stop( ) {

    if( t != null ) {
      t.stop( );
      t = null;
    }
  }

  // Allow join with our thread
  public final void join( ) 
    throws java.lang.InterruptedException 
  {
    try {
      if( t != null ) {
    t.join();
      } 
    } catch ( InterruptedException e ) {
      throw e;
    }

    return;
  }
  
  public void suspend()
  {
    t.suspend();
  }
  
  public void resume()
  {
    t.resume();
  }

    //
  // Run method to be started by Thread
    //

    protected ServerSocket s = null;  // Socket we're listening to.
    
    // need to override for specific ports...
    //
    
    protected int port = 5000;
    
    public int getPort() {
        return port;
    }
    
    public void setPort(int p)
    {
        port = p;
    }

    protected int localPort = 0;

  public void run( ) {
  
   Socket con = null;      // Current connection
            
    // Open a new server socket on port or die
    try {
      s = new ServerSocket(getPort(),20,InetAddress.getByName("localhost"));
      localPort = s.getLocalPort();
    } catch ( Exception e ) {
      System.out.println( "Exception:\n" + e );
      throw(new MVFatalException(e.toString()));
    }   

    // Print out our socket
    System.out.println( "ServerSocket: " + s );

    // While the thread is running . . .
    while( t != null ) {
      // Accept an incomming connection
      try {
                con = s.accept( );
      } catch ( Exception e ) {
                System.out.println( "error on accept: " + e );
                throw(new MVFatalException(e.toString()));
      }

        // Start new server processing thread
        MVServerProcess pr = new MVServerProcess(this,con);
        pr.start();
       System.out.println("MVServerMultListen: accepted connection");
      }
   }  
   
   public synchronized void processRequest(MVServerProcess client, String req)
   {
        
   }    
    
}


