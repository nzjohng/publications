package JViews;

import java.util.*;
import java.beans.*;

public interface MVProcessBBWChange {
    public void propertyChange(PropertyChangeEvent evt);
    public void processBBWEvent(EventObject evt);
}

