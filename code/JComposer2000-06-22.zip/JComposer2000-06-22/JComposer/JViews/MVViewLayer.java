package JViews;
 
import java.util.*;
import java.io.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import beanbox.*;
import JCVisualise.*;

public class MVViewLayer extends MVLayer implements BBWTransactionListener, PropertyChangeListener, MVProcessBBWChange  {

  public MVViewLayer(MVBaseLayer base_layer, String name) {
    // initialise view layer component
    
    base_layer.viewCompCreated(this);
    setName(name);
    base_layer.addView(this);
    establishOneToMany("viewComponents",null);
    setAggregateRel("viewComponents");
  }
  
  public MVViewLayer() {
    super();
  }
  
  public Enumeration components() {
    return (getRelationship("viewComponents",MVChildren)).elements();
  }
  
  public void addLayerComponent(MVLayerComp comp) {
    establishOneToMany("viewComponents",comp);
  }
  
  public void removeLayerComponent(MVLayerComp comp) {
    dissolveOneToMany("viewComponents", comp);
  }
  public String userName() {
    return getName();
  }
  
  public MVBaseLayer getBaseLayer() {
    return (MVBaseLayer) getOneRelated("views",MVParents);
  }
  
  public void setX(int value)
  {
    setValue("x",value);
  }
  
  public int getX()
  {
    return getIntValue("x");
  }
  
  public void setY(int value)
  {
    setValue("y",value);
  }
  
  public int getY()
  {
    return getIntValue("y");
  }
  
  public void setWidth(int value)
  {
    setValue("width",value);
  }

  public int getWidth()
  {
    return getIntValue("width");
  }
  
  public void setHeight(int value)
  {
    setValue("height",value);
  }

  public int getHeight()
  {
    return getIntValue("height");
  }
    
  public void makeCurrent() {
    // make this view layer the current view for base layer
    
    getBaseLayer().makeCurrent(this);
  }
  
  public MVChangeDescr firstUpdate = null;
    // first change description sent to view
    // used by view to ignore change descriptions generated
    // in reponse to the target view component's update

  public MVChangeDescr beforeChange(MVChangeDescr c, 
    MVComponent from, String rel_name) {
    // receive listen before change description...

    if(!redisplaying && !responding && firstUpdate == null && rel_name.equals("viewComponents")) {
      firstUpdate = c;
    }
      
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c, 
    MVComponent from, String rel_name) {
    // view stores its own & its view component change descriptions

     if(redisplaying)
        return super.afterChange(c,from,rel_name);

     if(!processingBBWChange) {
        MVViewComp comp = null;
        
        if(c.target instanceof MVViewComp)
            comp = (MVViewComp) c.target;
        else if(c instanceof MVEstablishOneToMany &&
            ((MVEstablishOneToMany) c).getChild() instanceof MVViewComp)
            comp = (MVViewComp) ((MVEstablishOneToMany) c).getChild();
            
        if(frame != null && comp != null && comp.getBBWShape() == null && comp.canBeDrawn()) {

System.out.println("Adding BBW shape after JViews comp addition...");

            startJViewsChange();
            frame.addedViewComp(comp);
            endJViewsChange();  
        }
    }       

        if(c instanceof MVSetStringValue) {
            if(((MVSetStringValue) c).getPropertyName().equals("Name")) {
                if(frame != null)
                    frame.viewRenamed();
                // base view's Views rel should update its own index value...
            }
        }

    if(!responding && !(c instanceof MVViewEvent)) {
      if(c == firstUpdate) {
          // store change to view component
          storeChange(c);
        firstUpdate = null;
      } else if(firstUpdate == null) {
        if(c.targets(this)) {
            // change to view layer component
            storeChange(c);
        }
            }
    }

    return super.afterChange(c,from,rel_name);
  }
  
  /*
   * View's frame
   *
   */
   
  protected MVViewFrame frame = null;
   
  public void createFrame() {
  
  }
  
   public MVViewFrame getViewFrame() {
        return frame;
    }

  public void show() {
    if(frame == null) {
        createFrame();
        redisplayView(); 
    }

    makeCurrent();
    frame.setVisible(true);
  }
  
  public void hide() {
    frame.setVisible(false);
  }
  
    public void setSpying(boolean spying) {
      this.spying = spying;
    }
  
    protected boolean spying = false;

    /*
     * Redisplay of view's components
     *
     */
     
   protected boolean redisplaying = false;

    public void redisplayView() {
        Enumeration e = components();
        MVViewComp c;

System.out.println("Redisplaying view...");

        startJViewsChange();
        redisplaying = true;
        while(e.hasMoreElements()) {
            c = (MVViewComp) e.nextElement();
            frame.addedViewComp(c); // force recreation of BBW shape...
        }
        redisplaying = false;
        endJViewsChange();
        
        recordUpdate(new MVRedisplayView(this));
    }

  /*
   * Listener methods to handle BBW transactions & property changes
   *
   */

    public void transaction(BBWTransactionEvent evt) {    
            if(evt.isBeginning()) {
System.out.println("starting BBW trans...");
                startBBWChange();
                clearBBWEvents();
                processingBBWEvents = false;
            } else {
                processingBBWEvents = true;
                processBBWEvents();
                processingBBWEvents = false;
                clearBBWEvents();
                endBBWChange();
System.out.println("...ending BBW trans");
            }
    }
  
    public void propertyChange(PropertyChangeEvent evt) {
            if(!processingBBWEvents)
                addBBWEvent(this,evt);
    }

        public void processBBWEvent(EventObject evt) {
            if(!processingBBWEvents)
                addBBWEvent(this,evt);
        }
    
    public boolean processingBBWChange = false;
    
    public boolean startBBWChange() {
            boolean old = processingBBWChange;

      processingBBWChange = true;

            return old;
    }
    
    public void endBBWChange() {
      processingBBWChange = false;
    }

        public boolean inBBWTransaction() {
            if(processingBBWChange)
                return true;
            else
                return false;
        }

    protected boolean processingJViewsChange = false;
    
    public void startJViewsChange() {
      processingJViewsChange = true;
    }
    
    public void endJViewsChange() {
      processingJViewsChange = false;
    }
    
    public MVViewComp findBBWViewComp(BBWComponent s) {
      // locate the JVIews view component which is linked to this BBW component...
      
      Enumeration e = components();
      MVViewComp v;

      while(e.hasMoreElements()) {
        v = (MVViewComp) e.nextElement();
        if(v.getBBWShape() == s)
          return v;
      }
      
      return null;
    }

        public MVViewComp findViewComp(int id) {
            Enumeration e = components();

            while(e.hasMoreElements()) {
                MVViewComp v = (MVViewComp) e.nextElement();
                if(v.compID == id)
                    return v;
                // else check copyID...
            }

            return null;
        }

        public MVViewComp findViewComp(int id, int copiedFrom) {
            Enumeration e = components();

            while(e.hasMoreElements()) {
                MVViewComp v = (MVViewComp) e.nextElement();
                if(v.compID == id)
                    return v;
                else if(v.copiedFrom == copiedFrom)
                    return v;
            }

            return null;
        }
        
        protected Vector BBWEvents = new Vector();
        
        public boolean processingBBWEvents = false;

        public void addBBWEvent(MVProcessBBWChange c, EventObject e) {
            if(c instanceof MVComponent) {
            
            MVBBWEvt ev = new MVBBWEvt(c,e);
            BBWEvents.addElement(ev);

if(e instanceof PropertyChangeEvent &&
        ((PropertyChangeEvent) e).getSource() instanceof BBWComponent) {
    MVViewComp comp = findBBWViewComp((BBWComponent) ((PropertyChangeEvent) e).getSource());   
    
    String name = ((PropertyChangeEvent) e).getPropertyName();
    
    if(comp.getMacroChange() == null && (name.equals("x") || name.equals("y")))
        comp.startMacroChange(new MVMacroChangeDescr(comp,"Move "+comp.userName()));
    else if(comp.getMacroChange() == null && (name.equals("width") || name.equals("height")))
        comp.startMacroChange(new MVMacroChangeDescr(comp,"Resize "+comp.userName()));
    }       
}

        }

        public void clearBBWEvents() {
            BBWEvents.removeAllElements();
        }

        public void processBBWEvents() {
            // process BBW events after BBW transaction finished...

            int i = BBWEvents.size();
            Vector events = new Vector();
            Vector endMacros = new Vector();

System.out.println("processing BBW events...!!");

            // remove duplicate property change events...

            while(i > 0) {
                MVBBWEvt ev = (MVBBWEvt) BBWEvents.elementAt(i-1);
                if(ev.evt instanceof PropertyChangeEvent) {
                    Enumeration e = events.elements();
                    boolean store = true;

                    while(e.hasMoreElements()) {
                        // if duplicate property change, throw prior one away...
                        MVBBWEvt ev2 = (MVBBWEvt) e.nextElement();
                        if(ev2.evt instanceof PropertyChangeEvent &&
                            (ev.evt.getSource() == ev2.evt.getSource()) &&
                             ((PropertyChangeEvent) ev2.evt).getPropertyName().equals(
                                 ((PropertyChangeEvent) ev.evt).getPropertyName())) {
                                store = false;
                                break;
                            }
                    }
                    if(store)
                        events.addElement(ev);
                } else
                    events.addElement(ev);
                i--;
            }

            Enumeration e2 = events.elements();
            MVViewComp vc;

            while(e2.hasMoreElements()) {
                MVBBWEvt ev = (MVBBWEvt) e2.nextElement();

                if(ev.evt instanceof PropertyChangeEvent) {
                        ev.component.propertyChange((PropertyChangeEvent) ev.evt);
                        if(((MVComponent) ev.component).getMacroChange() != null
                            && !endMacros.contains(ev.component))
                            endMacros.addElement(ev.component);
                } else {
                        ev.component.processBBWEvent(ev.evt);
                }
            }
            
            Enumeration e3 = endMacros.elements();
            while(e3.hasMoreElements()) {
                MVComponent comp = (MVComponent) e3.nextElement();
                comp.endMacroChange();
            }
            
        }

    public void exportViewToFile() {
System.out.println("export view to file...");
        MVOutputBuffer buffer = new MVOutputBuffer();
        String file_name;
        String path;

    FileDialog dialog = new FileDialog(getViewFrame(),"Exported view save file",FileDialog.SAVE);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    path = dialog.getDirectory();
System.out.println("file_name="+file_name);
System.out.println("path="+path);
    dialog.setVisible(false);

        getBaseLayer().getProject().exportComponent(this,buffer);
        getBaseLayer().getProject().writeBufferToFile(buffer,file_name,path);
System.out.println("exported view!");
    }


    public void importViewFromFile() {
System.out.println("import view from file...");
        // get file & path
        String file_name;
        String path;

    FileDialog dialog = new FileDialog(getViewFrame(),"Imported view load file",FileDialog.LOAD);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    path = dialog.getDirectory();
System.out.println("file_name="+file_name);
System.out.println("path="+path);
    dialog.setVisible(false);

        if(file_name != null) {
            MVInputBuffer2 buffer = getBaseLayer().getProject().readBufferFromFile(file_name,path);
            if(buffer != null) {
                MVViewLayer new_view = (MVViewLayer) getBaseLayer().getProject().importComponent(buffer,new MVImportViewLocator(getBaseLayer()));
        // need to remap all components to base & then try and remap them all...
        // also need to add imported view to base layer's views relationship & then redisplay view
                if(new_view != null) {
                    System.out.println("imported view: "+new_view);
                    if(getBaseLayer().findViewByName(new_view.getName()) != null) {
                        new_view.setName(new_view.getName()+" ("+getBaseLayer().getViewName()+")");
                        getBaseLayer().setViewName(getBaseLayer().getViewName()+1);
                    }
                    getBaseLayer().addView(new_view);
                    new_view.setAggregateRel("viewComponents"); // should be done by deserialize...
                    new_view.createFrame();
                    new_view.remapComponents();
                    new_view.show();
                }
            }
        }
    }

    public void remapComponents() {
        for(int i=0;i<=2;i++) {
            Enumeration e = components();

            while(e.hasMoreElements()) {
                MVViewComp v = (MVViewComp) e.nextElement();
                
                if(v.getBBWShape() == null) {
                    startJViewsChange();
                    frame.addedViewComp(v);
                    endJViewsChange();
                }
                    
                if(v.baseComp() == null)
                    v.mapComponent(true);
            }
        }
    }

    public void showChanges() {
        MVVersionRecord r = getVersionRecord();
        if(r != null)
            r.displayRecords();
    }

    public void importChanges() {
System.out.println("import changes from file...");
        // get file & path
        String file_name;
        String path;

    FileDialog dialog = new FileDialog(getViewFrame(),"Imported changes load file",FileDialog.LOAD);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    path = dialog.getDirectory();
System.out.println("file_name="+file_name);
System.out.println("path="+path);
    dialog.setVisible(false);
        MVVersionRecord v = new MVVersionRecord();
        v.setTitle("Imported changes for: "+userName());

        if(file_name != null) {
            MVInputBuffer2 buffer = getBaseLayer().getProject().readBufferFromFile(file_name,path);
            if(buffer != null) {
                Vector changes = getBaseLayer().getProject().importChanges(buffer, new MVImportViewChangesLocator(this));
                if(changes != null) {
                    Enumeration e = changes.elements();
                    while(e.hasMoreElements()) {
                        MVChangeDescr c = (MVChangeDescr) e.nextElement();
                        v.add_change(c);
                    }
                    v.displayRecords();
                }
            }
        }
    }

    public void renameView() {
        // ask user for new view name...
        showPropertySheet();
    }

    public String [] getEditableProperties() {
        String ss[] = {"name"};

        return ss;
    }
    
    public void inspectView() {
        getBaseLayer().inspect(this);
    }

    public void visualiseNew() {
        JCVisBaseLayer.visualiseNew(getBaseLayer(),this);
    }

    public void visualisePrev() {
        JCVisBaseLayer.visualisePrev(getBaseLayer(),this);
    }

    public void visualiseBaseNew() {
        JCVisBaseLayer.visualiseNew(getBaseLayer(),getBaseLayer());
    }

    public void visualiseBasePrev() {
        JCVisBaseLayer.visualisePrev(getBaseLayer(),getBaseLayer());
    }
    
    public void doUndoItem()
    {
        getVersionRecord().undo_last();
    }
    
    public void doRedoItem()
    {
        getVersionRecord().redo_last();
    }

    public void hideHandles()
    {
        Enumeration e = components();
        while(e.hasMoreElements())
        {
            MVViewComp c = (MVViewComp) e.nextElement();
            if(c.getBBWShape() != null)
                c .getBBWShape().setHandlesVisible(false);
        }
    }
    
    public void showHandles()
    {
        Enumeration e = components();
        while(e.hasMoreElements())
        {
            MVViewComp c = (MVViewComp) e.nextElement();
            if(c.getBBWShape() != null)
                c .getBBWShape().setHandlesVisible(true);
        }
    }
    
    public void cleanup()
    {
        // after a crash!
        
        if(macro_change != null)
            endMacroChange();
        responding = false;
        firstUpdate = null;
        MVApplication.application.resumeServer();
    }
    
    public void setMessage(String mesg)
    {
        if(frame != null)
            frame.setMessage(mesg);
    }

    public void newView()
    {
        System.out.println("New View selected");
    }

}

class MVBBWEvt {
    
    public MVProcessBBWChange component;
    public EventObject evt;

    public MVBBWEvt(MVProcessBBWChange c, EventObject e) {
        component = c;
        evt = e;
    }

}


