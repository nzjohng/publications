package JViews;

import java.util.*;

/*
 * MVGlue
 *
 * Glue links view components with rendered "glue"
 *
 * Can also be mapped to base components (but NOT "base" relationships
 * as in old MViews...
 *
 */

public class MVGlue extends MVViewComp {

  public MVGlue() {
    super();
  }
  
  public MVGlue(MVViewLayer view_layer) {
    super(view_layer);
  }
  
  public MVGlue(MVViewLayer view_layer, MVViewComp parent) {
    super(view_layer);
    addParent(parent);
  }
  
  public MVGlue(MVViewLayer view_layer, MVViewComp parent, MVViewComp child) {
    super(view_layer);
    addParent(parent);
    addChild(child);
  }
  
  public Vector getParents() {
    return getRelationship("Parent",MVChildren);
  }
  
  public Vector getChildren() {
    return getRelationship("Child",MVChildren);
  }

  public void addParent(MVViewComp parent) {
    establishOneToMany("Parent",parent);
    parent.setListenBeforeRel("Parent");
  }

  public void addChild(MVViewComp child) {
    establishOneToMany("Child",child);
    child.setListenBeforeRel("Child");    
  }
  
  public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel)
  {
    if(!deleted && c instanceof MVCompDeleted &&
        (rel.equals("Parent") || rel.equals("Child"))) {
        // parent or child of this relationship deleted => need
        // to delete this & dispose of its BBW shape   
System.out.println("deleting glue");         
        c.getTarget().setDeleted(true);
        delete();
        c.getTarget().setDeleted(false);
    }
    
     if(deleted && c instanceof MVCompUndeleted &&
        (rel.equals("Parent") || rel.equals("Child"))) {
        // parent or child of this relationship undeleted => need
        // to undelete this & redisplay its BBW shape   
System.out.println("undeleting glue");        
        c.getTarget().setDeleted(false);  // not nec??
        undelete();
        c.getTarget().setDeleted(true);   // not nec??
    }   
    
    return super.beforeChange(c,from,rel);
  }
  
}
