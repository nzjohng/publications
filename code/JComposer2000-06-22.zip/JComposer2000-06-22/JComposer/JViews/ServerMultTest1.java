
package JViews;

public class ServerMultTest1 extends MVServerMultListen
{
    public ServerMultTest1()
    {
        
    }
    
    public ServerMultTest1(int p)
    {
        super(p);
    }
    
    public synchronized void processRequest(MVServerProcess client, String req)
    {
        System.out.println("Got request "+req+" from client "+client.getName());
        
        if(req.equals("req1"))
            client.sendReply("reply1");
        else if(req.equals("req2"))
            client.sendReply("reply2");
        
        System.out.println("Finished request "+req+" for client "+client.getName());
    }
}
