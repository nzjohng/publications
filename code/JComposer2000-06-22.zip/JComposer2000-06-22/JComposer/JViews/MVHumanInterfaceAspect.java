package JViews;

import java.util.*;

public class MVHumanInterfaceAspect extends MVAspect
{

    public MVHumanInterfaceAspect()
    {
    
    }
    
    Vector hcis = new Vector();
    
    public void addHumanInterfaceInfo(MVHumanInterfaceInfo info)
    {
        MVHumanInterfaceInfo i = findHumanInterfaceInfo(info.getName());
        if(i != null)
            hcis.removeElement(i);
        hcis.addElement(info);
    }
    
    public MVHumanInterfaceInfo findHumanInterfaceInfo(String name)
    {
        Enumeration e = hcis.elements();
        while(e.hasMoreElements()) {
            MVHumanInterfaceInfo info = (MVHumanInterfaceInfo) e.nextElement();
            if(info.getName().equals(name))
                return info;
        }
        
        return null;
    }
    
    public String toString()
    {
        String value = " Human interfaces:\n";
        
        Enumeration e = hcis.elements();
        while(e.hasMoreElements()) {
            MVHumanInterfaceInfo info = (MVHumanInterfaceInfo) e.nextElement();
            value = value+"  "+info.toString()+"\n";
        }
        
        return value;
     }
     
     public String getAspectKind()
     {
        return "Human interfaces";
     }
     
          
         
    public Vector getAspectInfos()
    {
        return hcis;
    }
    
}


