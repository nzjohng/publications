package JViews;

import java.util.*;

public class MVHashtableRel extends MVRelationship {
    // Vector relationship components
    
  /*
   * parent & children of relationship
   *
   */

  private MVComponent parent_comp;
 public Hashtable child_comps = new Hashtable();
  
  public MVHashtableRel() {
    super("");
  }
  
  public MVHashtableRel(String rel_name, MVComponent parent_comp) {
    super(rel_name);
    this.parent_comp = parent_comp;
    parent_comp.addRelationship(this.relName(),MVComponent.MVRelLinksChildren,this);
  }

    public void init(MVComponent parent_comp) {
    this.parent_comp = parent_comp;
    parent_comp.addRelationship(this.relName(),MVComponent.MVRelLinksChildren,this);
    }
    
    public void init(String rel_name,MVComponent parent_comp)
    {
        setRelName(rel_name);
        this.parent_comp = parent_comp;
        parent_comp.addRelationship(this.relName(),MVComponent.MVRelLinksChildren,this);    
    }

  public Enumeration parents() {
    // parents linked by this relationship comp.
    Vector v = new Vector();

        if(parent_comp != null)
        v.addElement(parent_comp);

    return v.elements();
  }

  public Enumeration children() {
    // children linked by this relationship comp.

     return child_comps.elements();
    }

  public String extractKey(MVComponent item) {
    // extract the key to use in the hashtable from item
    // default is to use its userName() value
    
    return item.userName();
  }
  
  /*
   * establish/dissolve functionality
   *
   */

  public void establish(MVComponent parent, MVComponent child) {
    boolean changed = false;
    MVEstablishRel cd;
    
    if(parent != null && parent_comp != parent)
      changed = true;
    else if(child != null && !child_comps.contains(child))
      changed = true;
    
    if(changed) {
      cd = new MVEstablishRel(this,parent,child);
      recordUpdate(cd);
    }
  }

  public void addParent(MVComponent parent) {
    parent_comp = parent;
  }

  public void removeParent(MVComponent parent) {
    parent_comp = null;
  }

  public void addParent(String key, MVComponent parent) {
    parent_comp = parent;
  }

  public void addChild(MVComponent child) {
    if(!child_comps.contains(child)) {
      child_comps.put(extractKey(child),child);
    }
  }

  public void addChild(String key, MVComponent child) {
    if(!child_comps.contains(child)) {
      child_comps.put(key,child);
    }
  }

    public void removeChild(MVComponent child) {
        child_comps.remove(extractKey(child));
    }
    
    public void removeChild(String name, MVComponent child)
    {
        child_comps.remove(name);
    }
    
    public void remove(MVComponent child)
        // removes child from hashtable if extractKey()
        // no longer returns key value in hashtable
        // e.g. component renamed via property change or rel
        // est/dissolve...
    {
        String old_key = findOldKey(child);
        removeChild(old_key,child);
    }
    
    public String findOldKey(MVComponent comp)
    {
        Enumeration e = child_comps.keys();
        while(e.hasMoreElements()) {
            String key = (String) e.nextElement();
            if(child_comps.get(key) == comp) {
                return key;
            }
        }
        
        return null;
    }
  
  public void dissolve(MVComponent parent, MVComponent child) {
        if(child != null) {
            if(child_comps.get(extractKey(child)) != null) {
                MVDissolveChild cd = new MVDissolveChild(this,parent_comp,child);
                recordUpdate(cd);
            }
        }
  }
  
  /*
   * extra search capabilities from Hashtable
   *
   */
   
  public boolean containsKey(String key) {
    // lookup component via its key
    
    return(child_comps.containsKey(key));
  }
  
  public boolean contains(MVComponent item) {
    // is component in children??
System.out.println("checking if contains item...");    
    return(child_comps.contains(item));
  }
  
  public MVComponent get(String key) {
    // lookup object via its key
    
    return((MVComponent) child_comps.get(key));
  }

    public void changeKey(String oldName, String newName, MVComponent item) {
        MVChangeKey c = new MVChangeKey(this,oldName,newName,item);
        
        recordUpdate(c);
    }
    
    public void changeKey(String newName, MVComponent item)
    {
    
    System.out.println("Doing change key");
    System.out.println("Old key = "+findOldKey(item));
        changeKey(findOldKey(item),newName,item);
    }

    public void doChangeKey(String oldName, String newName, MVComponent item) {

        child_comps.remove(oldName);
        child_comps.put(newName,item);
    }
      
}
