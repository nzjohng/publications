package JViews;

import java.io.*;
import java.util.*;

/*
 * Implements MViews layers - base layers & view layers
 *
 */

public abstract class MVLayer extends MVComponent {

  public void renameLayer(String new_name) {
    setName(new_name);
  }

    public String getName() {
        return getStringValue("Name");
    }

    public void setName(String name) {
        setValue("Name",name);
    }
    
  /*
   * layer component management
   *
   */

  public abstract Enumeration components();
  
  public abstract void addLayerComponent(MVLayerComp comp);
  
  public abstract void removeLayerComponent(MVLayerComp comp);
  
  public void compCreated(MVComponent comp) {
    MVAddComponent c = new MVAddComponent(this,comp.compKind(),comp);
    
    recordUpdate(c);
  }
  
}
