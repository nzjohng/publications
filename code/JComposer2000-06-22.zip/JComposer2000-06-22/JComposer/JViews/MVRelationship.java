package JViews;

import java.util.*;

public abstract class MVRelationship extends MVComponent {
    // relationship components class
    
  private String rel_name = null;
  
  public MVRelationship() { }
  
  public MVRelationship(String rel_name) {
    if(!rel_name.equals(""))
      this.rel_name = rel_name;
    else
      rel_name = null;
  }
  
  public void setRelName(String name) {
    rel_name = name;
  }

  public String relName() {
    // name of relationship this rel component implements
    
    if(rel_name != null)
      return rel_name;
    else
      return compKind();
  }
  
  public String getRelName()
  {
    return relName();
  }
  
  public abstract Enumeration parents();
    // parents linked by this relationship comp.

  public abstract Enumeration children();
    // children linked by this relationship comp.

  public abstract void establish(MVComponent parent, MVComponent child);
    // establish a relationship between parent and child components

  public abstract void dissolve(MVComponent parent, MVComponent child);
    // dissolve a relationship between a parent and child

//   public abstract void establishParent(MVComponent parent);
    // establish relationship to parent comp only

//   public abstract void establishChild(MVComponent child);
    // establish relationship to child comp only

  public abstract void addParent(MVComponent parent);
    // add a parent to parents data structure

  public abstract void addParent(String key, MVComponent parent);
    // add a parent to keyed parents data structure

    public abstract void removeParent(MVComponent child);
        // remove a parent from this relationship

  public abstract void addChild(MVComponent parent);
    // add a parent to children data structure
    
  public abstract void addChild(String key, MVComponent child);
    // add a child to keyed children data structure

    public abstract void removeChild(MVComponent child);
        // remove a child from this relationship
    
  public boolean isParent(MVComponent c) {
    // is this component a parent of this relationship?
    Enumeration e = parents();
    
    while(e.hasMoreElements()) {
      if((MVComponent) e.nextElement() == c)
        return true;
    }
    
    return false;
  }
    
  public boolean isChild(MVComponent c) {
    // is this component a child of this relationship?
    Enumeration e = children();
    
    while(e.hasMoreElements()) {
      if((MVComponent) e.nextElement() == c)
        return true;
    }
    
    return false;
  }
  
  /*
   * For save/load and printing out data...
   *
   */
    
    public void writeAttributesString(MVOutputBuffer output) {
        super.writeAttributesString(output);
        if(rel_name != null) {
            output.write("  +rel_name = ");
            output.writelnQuoted(relName());
            output.writeln("");
        }
    }

  public void writeRelationshipsString(MVOutputBuffer output) {
    super.writeRelationshipsString(output);
    MVComponent c;
    
    output.writeln("  rel-comp-parents "+'"'+"+parents"+'"'+" "+'"'+'"'+" =");    
    output.write("    [ ");

    for(Enumeration e = parents(); e.hasMoreElements(); ) {
      c = (MVComponent) e.nextElement();
      output.write(c.compID);
      output.write(' ');
    }
    output.writeln(']');

    output.writeln("  rel-comp-children "+'"'+"+children"+'"'+" "+'"'+'"'+" =");
    output.write("    [ ");

    for(Enumeration e = children(); e.hasMoreElements(); ) {
      c = (MVComponent) e.nextElement();
      String key = extractKey(c);
      if(key == null) {
        output.write(c.compID);
        output.write(' ');
      } else  {
        output.writeln("    "+'"'+key+'"'+" "+c.compID+' ');
      }
    }
    
    output.writeln(']');
  }
  
  public String extractKey(MVComponent c) {
    return null;
  }

/*
  public String toString() {
    String value = super.toString();

    value = value + "\nParents: ";
    for(Enumeration e = parents(); e.hasMoreElements(); )
      value = value + ((MVComponent) e.nextElement()).compID+" ";

    value = value + "\n\nChildren: ";
    for(Enumeration e = children(); e.hasMoreElements(); )
      value = value + ((MVComponent) e.nextElement()).compID+" ";
    value = value + "\n";

    return value;
  }
*/

  /*
   * Restore component data after reload
   *
   */
   
    public void addAttribute(MVAttribute a) {
        if(a.getPropertyName().equals("+rel_name"))
            rel_name = ((MVStringAttribute) a).getValue().intern();
        else
            super.addAttribute(a);
    }
    
    public void addRelItem(MVRelItem r, MVCompLocator locator, String relName,String key,MVComponent c) {
      if(relName.equals("+parents")) {
        if(!key.equals(""))
            addParent(key,c);
        else
            addParent(c);
      } else if(relName.equals("+children")) {
        if(!key.equals(""))
            addChild(key,c);
        else
            addChild(c);
      } else
            super.addRelItem(r,locator,relName,key,c);
    }

    public void setChildAttributes(MVAttribute a) {
        Enumeration e = children();

        while(e.hasMoreElements()) {
            a.setCompValue(((MVComponent)e.nextElement()));
        }
    }

    public void setParentAttributes(MVAttribute a) {
        Enumeration e = parents();

        while(e.hasMoreElements()) {
            a.setCompValue(((MVComponent)e.nextElement()));
        }
    }

    public void getAggregatesRelated(Vector comps,Vector rel) {
        super.getAggregatesRelated(comps,rel);
        Enumeration e = children();
        while(e.hasMoreElements()) {
            MVComponent c = (MVComponent) e.nextElement();
            c.getAggregatesRelated(comps,rel);
        }
    }

    public void changeKey(String oldName, String newName, MVComponent item) {

    }

    public void doChangeKey(String oldName, String newName, MVComponent item) {

    }

    public void doDelete() {
        super.doDelete();

        Enumeration e1 = parents();
        while(e1.hasMoreElements()) {
            MVComponent c = (MVComponent) e1.nextElement();
            if(!c.deleted)
                c.removeRelationship(relName(),MVRelLinksChildren,this);
        }

        Enumeration e2 = children();
        while(e2.hasMoreElements()) {
            MVComponent c = (MVComponent) e2.nextElement();
            if(!c.deleted)
                if(aggregate)
                    c.delete();
                else
                    c.removeRelationship(relName(),MVRelLinksParents,this);
        }

    }

    public void doUndelete() {
        deleted = false;

        Enumeration e1 = parents();
        while(e1.hasMoreElements()) {
            MVComponent c = (MVComponent) e1.nextElement();
            if(!c.deleted)
                c.addRelationship(relName(),MVRelLinksChildren,this);
        }

        Enumeration e2 = children();
        while(e2.hasMoreElements()) {
            MVComponent c = (MVComponent) e2.nextElement();
            if(aggregate && c.deleted)
                    c.undelete();
            else
                if(!c.deleted)
                    c.addRelationship(relName(),MVRelLinksParents,this);
        }

        super.doUndelete();
    }

    protected boolean aggregate = false;

    public void setAggregate(boolean value) {
        aggregate = value;
    }

    public boolean isAggregate() {
        return aggregate;
    }

    public Vector getRelationship(String rel_name, int rel_kind) {
        if(rel_name.equals("+parents")) {
            Vector p = new Vector();
            Enumeration e = parents();
            while(e.hasMoreElements()) {
                p.addElement(e.nextElement());
            }
            return p;
        } else if(rel_name.equals("+children")) {
            Vector c = new Vector();
            Enumeration e = children();
            while(e.hasMoreElements()) {
                c.addElement(e.nextElement());
            }
            return c;
        } else
            return super.getRelationship(rel_name,rel_kind);
    }

}
