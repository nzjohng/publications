package JViews;

import java.util.*;

public class MVRelationshipAspect extends MVAspect
{

    public MVRelationshipAspect()
    {
    
    }
    
    public String getAspectKind()
    {
        return "Relationships";
    }
    
    Vector properties = new Vector();
    
    public void addRelationshipInfo(MVRelationshipInfo info)
    {
        MVRelationshipInfo i = findRelationshipInfo(info.getName());
        if(i != null)
            properties.removeElement(i);
        properties.addElement(info);
    }
    
    public MVRelationshipInfo findRelationshipInfo(String name)
    {
        Enumeration e = properties.elements();
        while(e.hasMoreElements()) {
            MVRelationshipInfo info = (MVRelationshipInfo) e.nextElement();
            if(info.getName().equals(name))
                return info;
        }
        
        return null;
    }
    
    public String toString()
    {
        String value = " Relationships:\n";
        
        Enumeration e = properties.elements();
        while(e.hasMoreElements()) {
            MVRelationshipInfo info = (MVRelationshipInfo) e.nextElement();
            value = value+"  "+info.toString()+"\n";
        }
        
        return value;
     }
     
         
    public Vector getAspectInfos()
    {
        return properties;
    }
    
}
