package JViews;

import java.util.*;

public class MVViewRel extends MVVectorRel {

  public MVViewRel(String rel_name) {
    super(rel_name);
  }
  
  public MVViewRel() {
    super();
  }
  
  public String userName() {
    return "View Rels";
  }

    public final String relName() {
        return "MVViewRel";
    }
    
  public String getViewRelKind() {
    return compKind();
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {
  
    if(c.target == this && c instanceof MVEstablishRel)
      doneEstablishRel((MVEstablishRel) c,from);
      
    if(c instanceof MVCompDeleted && isParent(from)) {
System.out.println("ViewRel sending delete to veiw comps");
        Enumeration e = children();
        
        while(e.hasMoreElements()) {
            MVViewComp comp = (MVViewComp) e.nextElement();
            comp.baseDeleted((MVBaseComp) c.target);
        }
        
        delete();
    }
    
    if(c instanceof MVCompUndeleted && isParent(from)) {
System.out.println("ViewRel sending undelete to veiw comps");
        undelete();
        
        Enumeration e = children();
        
        while(e.hasMoreElements()) {
            MVViewComp comp = (MVViewComp) e.nextElement();
            comp.baseUndeleted((MVBaseComp) c.target);
        }
        

    }
      
/*
    if(isParent(from)) 
      updateFromParent(c,from);
    else if(isChild(from))
      updateFromChild(c,from);
*/

    return c;
  }

  public void doneEstablishRel(MVEstablishRel c, MVComponent from) {
    MVAttribute parent_attr, child_attr;
    
    // make this a dependent of both base & view comp
    // i.e. view rel always sent change descriptions from these comps...
    
    c.parent.setListenAfterRel(relName());
    c.child.setListenAfterRel(relName());
        c.parent.setAggregateRel(relName());
    ((MVBaseComp)c.parent).addViewComp((MVViewComp) c.child);
    
    // uplift base comp attributes to view comp & download view comp
    // attributes to base comp...
    //
    // assumes parent & child comps initialise ALL their attributes
    // to blank values on creation
    
System.out.println("done establish MVViewRel");

/*

    Enumeration e = c.parent.getAttributes().elements();
    
    while(e.hasMoreElements()) {
      parent_attr = (MVAttribute) e.nextElement();
      child_attr = c.child.getAttribute(parent_attr.name);
      if(child_attr != null) {
        if(!child_attr.isBlank() && !parent_attr.isBlank())
          // if both not blank, then set view comp value to base comp value
          parent_attr.setCompValue(c.child);
        if(child_attr.isBlank() && !parent_attr.isBlank())
          parent_attr.setCompValue(c.child);
        if(!child_attr.isBlank() && parent_attr.isBlank())
          child_attr.setCompValue(c.parent);          
      }
    }
*/

  }
  
  public void updateFromParent(MVChangeDescr c, MVComponent parent) {
    // change description received from a parent component
  
    /*
    if(c instanceof MVSetValue) {
      // base attribute updated...
      
System.out.println("MVViewRel got: "+c);
      
      Enumeration e = children();
      MVComponent child;
      MVAttribute child_attr;
      MVAttribute parent_attr = parent.getAttribute(((MVSetValue) c).name);
      
      while(e.hasMoreElements()) {
        child = (MVComponent) e.nextElement();
        child_attr = child.getAttribute(((MVSetValue) c).name);
        if(child_attr != null)
          parent_attr.setCompValue(child);
      }
    }
*/
    
  }
  
  public void updateFromChild(MVChangeDescr c, MVComponent child) {
    // change description received from a child component
  
/*
    if(c instanceof MVSetValue) {
      // view attribute updated...
      
System.out.println("MVViewRel got: "+c);
      
      Enumeration e = parents();
      MVComponent parent;
      MVAttribute parent_attr;
      MVAttribute child_attr = child.getAttribute(((MVSetValue) c).name);
      
      while(e.hasMoreElements()) {
        parent = (MVComponent) e.nextElement();
        parent_attr = parent.getAttribute(((MVSetValue) c).name);
        if(parent_attr != null)
          child_attr.setCompValue(parent);
      }
    }
 */   
  
  }

    public void upliftAttributes(MVBaseComp base_comp, MVViewComp view_comp) {
        // copy attributes fro base -> newly created view comp

    }

    public void downloadAttributes(MVBaseComp base_comp, MVViewComp view_comp) {
        // copy attributes from view comp -> newly created base comp

    }
  

}
