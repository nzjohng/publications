
package JViews;

public class MVDialogueInfo extends MVHumanInterfaceInfo
{
    String openMethod;

    public MVDialogueInfo(String name, boolean provides, boolean requires, int kind, String info, String openMethod)
    {
        super(name,provides,requires,MVDialogueHIAspect,info);
        this.openMethod = openMethod;
    }
    
    public void open(MVComponent comp)
    {
             
    }
}
