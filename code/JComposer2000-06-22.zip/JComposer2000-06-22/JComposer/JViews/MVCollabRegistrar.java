
package JViews;

import java.util.*;
import java.io.*;

public class MVCollabRegistrar extends MVServerMultListen
{

    public MVCollabRegistrar()
    {
        super();   
    }
    
    public static int portID = 5000;
    public static int numUsers = 0;
    
    public static void main(String argv[])
    {        
        if(argv.length > 0) {
            int i = 0;
            while(i < argv.length) {
                //if(argv[i].equals("-i")) {
                //    System.out.println("Start ID = "+argv[i+1]);
                //    int startID = Integer.parseInt(argv[i+1]);
                //    MVRegUser.last_id = startID;
                //    i++;
                if(argv[i].equals("-p")) {
                    System.out.println("Registrar port = "+argv[i+1]);
                    portID = Integer.parseInt(argv[i+1]);
                    i++;
                }
                i++;
            }
        }
        
        MVCollabRegistrar reg = new MVCollabRegistrar();
        reg.readData();
        reg.setPort(portID);
        reg.start();
        System.out.println("Registrar Running");
        try {
            reg.join();
        } catch ( InterruptedException e ) {
            System.out.println( "Registrar Terminated: " + e );
            System.exit( 1 );     // Exit with error
        }
    }
    
    public void readData()
    {
        try {
            FileReader file = new FileReader("registrar"+portID+".reg");
            StreamTokenizer input = new StreamTokenizer(file);
            input.eolIsSignificant(false);
            input.whitespaceChars(0,32);
            input.wordChars(33,127);
            input.quoteChar('"');
            input.nextToken();
            numUsers = (int) input.nval;
            System.out.println("Num users = "+numUsers);
            int token = input.nextToken();
            while(!(token == input.TT_EOF))
            {
                MVRegUser u = new MVRegUser();
                u.loadData(input);
                users.addElement(u);
                token = input.nextToken();
     System.out.println("user = "+u.getUser()+" "+u.getHost()+" "+u.getPort());
            }
            file.close();
        } catch(FileNotFoundException e) {
            System.out.println("No registrar file!");
            System.exit(1);
        } catch(IOException e) {
            System.out.println("Got IO exception: "+e);
            System.exit(1);
        }
    
    }
    
    public void processRequest(MVServerProcess client, String req)
    {
        if(req.equals("registration"))
            processRegistration(client);
        else if(req.equals("getUserList"))
            processGetUserList(client);
        else
            System.out.println("*** Registrar got invalid request "+req+" from client "+client.getName());
            
    }
    
    public void processRegistration(MVServerProcess client) {
        writeFile("registrar"+portID+".BAK");        
        String user = client.getStringRequest();
        String host = client.getStringRequest();
        int port = Integer.parseInt(client.getStringRequest());
        
        MVRegUser u = updateUser(user,host,port);
        if(u == null) {
            client.sendReply(""+0);
System.out.println("Attempted bad registration from "+user+" host "+host+" port "+port);
        } else {
            client.sendReply(""+u.getStartID());
            client.sendReply(""+numUsers);
System.out.println("Got registration from "+user+" host "+host+" port "+port);
            writeFile("registrar"+portID+".reg");
        }
    }
    
    public void processGetUserList(MVServerProcess client)
    {
        Enumeration e = users.elements();
        
        while(e.hasMoreElements())
        {
            MVRegUser r = (MVRegUser) e.nextElement();
            client.sendReply(r.getUser());
            client.sendReply(r.getHost());
            client.sendReply(""+r.getPort());
        }
        client.sendReply("DONE");
    }

/*    
    public void processGetUserInfo(MVServerProcess client)
    {
        String user = client.getStringRequest();
        MVRegUser r = findUserName(user);
        if(r == null)
            client.sendReply("NO SUCH USER");
        else {
            client.sendReply(r.getHost());
            client.sendReply(""+r.getPort());
        }
    }
    
    public void processAllocIDs(MVServerProcess client) {
        String user = client.getStringRequest();
        String project = client.getStringRequest();
        MVRegUser r = findUserName(user);
        int next_id = r.allocNextID(project);
        int id_count = r.allocIDCount(project);
        client.sendReply(""+next_id);
        client.sendReply(""+id_count);
        
System.out.println("Allocated IDs "+next_id+" to "+(next_id+id_count-1)+" to "+user);
        try {
            FileWriter file = new FileWriter("registrar"+portID+".reg");
            PrintWriter output = new PrintWriter(file);
            output.println(MVRegUser.last_id);
            // should really extend to read (ProjectName, ID) pairs...
            output.flush();
            file.flush();
            file.close();
        } catch(IOException e) {
            System.out.println("Got IO exception: "+e);
            System.exit(1);
        }
    }
*/

    public void writeFile(String name)
    {
        try {
            FileWriter file = new FileWriter(name);
            PrintWriter output = new PrintWriter(file);
            output.println(numUsers);
            Enumeration e = users.elements();
            while(e.hasMoreElements()) {
                MVRegUser u = (MVRegUser) e.nextElement();
                u.saveData(output);
            }
            output.flush();
            file.flush();
            file.close();
        } catch(IOException e) {
            System.out.println("Got IO exception: "+e);
            System.exit(1);
        }
    }
    
    protected Vector users = new Vector();
    
    public MVRegUser updateUser(String user, String host, int port)
    {
    
        MVRegUser r = findUserName(user);
        if(r != null) {
    System.out.println("REGISTRAR: added user "+user+" host "+host+" port "+port);
            r.setHost(host);
            r.setPort(port);
        }
        
        return r;
    }
    
    public MVRegUser findUserName(String user)
    {
        Enumeration e = users.elements();
        
        while(e.hasMoreElements())
        {
            MVRegUser r = (MVRegUser) e.nextElement();
            if(r.getUser().equals(user))
                return r;
        }
        
        return null;
    }

}

class MVRegUser {

    protected String user;
    protected String host;
    protected int port;
    
    public int start_id; 

    public MVRegUser(String u, String h, int p, int s)
    {
        user = u;
        host = h;
        port = p;
        start_id = s;
    }
    
    public MVRegUser()
    {
                                
    }
    
    public String getUser()
    {
        return user;
    }
    
    public String getHost()
    {
        return host;
    }
    
    public int getPort()
    {
        return port;
    }
    
    public int getStartID()
    {
        return start_id;
    }

    public void setHost(String h)
    {
        host = h;
    }
    
    public void setPort(int p)
    {
        port = p;
    }
    
    public void saveData(PrintWriter output)
    {
        output.println(user+" "+start_id+" "+'"'+host+'"'+" "+port);
    }
    
    public void loadData(StreamTokenizer input) throws IOException
    {
        user = input.sval;
        input.nextToken();
        start_id = (int) input.nval;
        input.nextToken();
        host = input.sval;
        input.nextToken();
        port = (int) input.nval;
    }
    
}


