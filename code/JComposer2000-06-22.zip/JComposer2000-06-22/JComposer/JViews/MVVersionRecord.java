package JViews;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class MVVersionRecord extends MVComponent {
  public String title = "Changes for: ";
  private int count;
  private int current;  //current undo_redo position
  private int high_tide;//high_tide position for redo (undo may add changes after this)
  boolean undo_redo;
  private Vector changes = new Vector();
  boolean saveChanges = false;
  
  public MVVersionRecord() {
      super();
      init();
  }
  
  public void init() {
    this.count = -1;
    this.current = -1;
    this.high_tide = -1;
    this.undo_redo = false;
  }
  
  public MVComponent getComponent()
  {
    return (MVComponent) getOneRelatedOrNull("VersionRecord",MVChildren);
  }
    
    public int getCurrent() {
        return current;
    }
    
    public int getCount() {
        return count;
    }
    
    public boolean isSaveChanges()
    {
        return saveChanges;
    }
    
    public void setSaveChanges(boolean value)
    {
        saveChanges = value;
    }

    public void setTitle(String new_title) {
        title = new_title;
        if(frame != null)
            if(getComponent() != null)
                frame.setTitle(new_title+getComponent().userName());
            else
                frame.setTitle(new_title);
    }

  public void add_change(MVChangeDescr change) {
    MVChangeDescr copied_change = change.copyChangeDescr();
    MVChangeDescr new_change = broadcastBefore(copied_change);
    if(new_change != null) {
        count++;
        new_change.setCount(count);
        changes.addElement(new_change);
        if(frame != null)
            frame.addChange(new_change);
        if (!undo_redo) {current = count; high_tide = count;}

        broadcastAfter(new_change);
    }        
  }
  
  public void remove_change(int number) {
        Enumeration e = changes.elements();

        while(e.hasMoreElements()) {
            MVChangeDescr c = (MVChangeDescr) e.nextElement();
            if(c.getCount() == number) {
                // should we generate some change descr to say
                // version record is being updated???
                //
                // MVChangeDescr new_change = broadcastBefore(c);
                //if(new_change != null) {
                    try {
                        c.discard();
                    } catch (Exception ex) {
                        System.out.println("*** Exception when discarding: "+ex);
                    }
                    if(frame != null)
                        frame.removeChange(changes.indexOf(c));
                    changes.removeElement(c);
                    // broadcastAfter(c);
                //}
                return;
            }
        }
  }
  
  public MVChangeDescr get_change(int number) {
        Enumeration e = changes.elements();

        while(e.hasMoreElements()) {
            MVChangeDescr c = (MVChangeDescr) e.nextElement();
            if(c.getCount() == number) {
                return c;
            }
        }

        return null;
  }
  
  public Enumeration get_changes_forwards() {
    return changes.elements();
  }
  
  public Vector getChangesFrom(int change) {
    Vector selection =  new Vector();
    
    Enumeration e = changes.elements();
    while(e.hasMoreElements()) {
        MVChangeDescr c = (MVChangeDescr) e.nextElement();
        if(c.getCount() >= change)
            selection.addElement(c);
    }
    
    return selection;
  }
  
// undo current record, if there is one, and find previous one
  
  public void undo_last() {
    if (current != -1) {
      undo_redo = true;
      get_change(current).undo();
      set_current_previous();
      undo_redo = false;
    }
  }
      
// redo from next record after current, if there is one
    
  public void redo_last() {
    undo_redo = true;
    int new_current = find_next_current();
    if (new_current <= high_tide) {
      current = new_current;
      get_change(current).redo();
    }
    undo_redo = false;
  }
  
  public void set_current_previous() {
    do {
      current--;
    } while (current != -1 && get_change(current) == null);
  }
  
  public int find_next_current() {
    int new_current = current;
    do {
      new_current++;
    } while (new_current <= high_tide && get_change(new_current) == null);
    return new_current;
  }
  
  public String toString() {
    MVChangeDescr sc;
    String value = title+"\n";
    value = value + "Count: "+count+" Current: "+current+" High Tide: "+high_tide+"\n";
    Enumeration cs = get_changes_forwards();
    while (cs.hasMoreElements()) {
      sc = (MVChangeDescr)cs.nextElement();
      value = value +"Change no: "+sc.number+" "+sc.toString()+"\n";
    }
    value = value + "\n";
    return super.toString()+"\n"+value;
  }
    
    public MVVersionFrame frame;
    
    public MVVersionFrame getFrame()
    {
        return frame;
    }
    
    public void createFrame()
    {
        frame = new MVVersionFrame(this); 
        frame.redisplayRecords();  
    }

    public void displayRecords() {
        // open up a viewing frame...

        if(frame == null) {
            createFrame();
            recordUpdate(new MVNewFrameEvent(this,frame));
                // so those comps that extend this VR frame can do so...
        }
        setTitle(title);
        frame.setVisible(true);
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        //if(frame != null)
        //    frame.redisplayRecords();

        return super.afterChange(c,from,rel_name);
    }
    
    public String displayString(MVChangeDescr c)
    {
       String header = c.getAnnotation("header");
       if(header != null)
        return header+" "+c.getCount()+ " "+c.summaryString();
       else
        return c.getCount()+". "+c.summaryString();  
    }
    
    public void doUndo(MVChangeDescr c)
    {
        //try {
            c.undo();
        //} catch (Exception e) {
         //   System.out.println("error in undoing changes:"+e);
         //   throw(new MVFatalException("error in undoing changes:"+e));
        //}
    }
    
    public void doRedo(MVChangeDescr c)
    {
        //try {
            c.redo();
        //} catch (Exception e) {
        //    System.out.println("error in redoing changes:"+e);
        //    throw(new MVFatalException("error in redoing changes:"+e));
        //}
    }
    
    public MVComponent getRecordFor()
    {
        return getOneRelatedOrNull("VersionRecord",MVChildren);
    }
    
    public void writeSpecialStuff(MVOutputBuffer output)
    {
        super.writeSpecialStuff(output);
        
        // serialize version record data & change descriptions
        
        output.writeln("special");
        output.write(count);
        output.write(' ');
        output.write(saveChanges);
        output.writeln("  [");
        
        if(saveChanges) {
            Enumeration e = changes.elements();
            while(e.hasMoreElements()) {
                MVChangeDescr ch = (MVChangeDescr) e.nextElement();
                ch.serialize(output);
            }
        }
        
        output.writeln("  ]");
        
    }
    
    public void readSpecialStuff(MVInputBuffer2 input, MVCompLocator locator) throws IOException
    {
        super.readSpecialStuff(input,locator);
        
        // read version record data & change descriptions
    
        if(input.nextIsInt()) {
            count = input.getIntToken();
            saveChanges = input.getBooleanToken();
            input.readToken('[');
        
            if(saveChanges) {
                while(input.nextChar() != ']') {
                    input.readToken("change");
                    String changeKind = input.getToken();
                    MVChangeDescr cd = locator.createNewChange(changeKind);
                    cd.deserialize(input,locator);
                    if(cd.isValid()) {
 //System.out.println("  reloaded "+changeKind+" "+cd.getCount());
                        changes.addElement(cd);
                    // if doesn't remap - just ignore???
                    // or save string & insert "comment" CD?                
                    } else
                        System.out.println("  *** Invalid change "+changeKind);                
                }
            }
        
            input.readToken(']');         
            input.readToken("end_comp");
        
        }  
 //       System.out.println(toString());     
    }
    
    public MVAspects getAspects()
    {
        MVAspects aspects = super.getAspects();
        
        // attributes
        
        MVPropertyAspect pas = aspects.getPropertyAspect();
        pas.addPropertyInfo(new MVPropertyInfo("count","int","This is the change description record counter"));
        pas.addPropertyInfo(new MVPropertyInfo("title","String","The title of this version record's dialogue"));       
                
        // relationships
        
        MVRelationshipAspect ras = aspects.getRelationshipAspect();
        ras.addRelationshipInfo(new MVRelationshipInfo("VersionRecord","1:1",MVRelationshipInfo.MVAnyInputRel,true,"Component which stores changes in this version record component"));

        // user interface
        
        if(frame == null)
            createFrame();
        
        MVHumanInterfaceAspect hias = aspects.getHumanInterfaceAspect();
        hias.addHumanInterfaceInfo(new MVDialogueInfo("changes dialogue",true,false,MVHumanInterfaceInfo.MVDialogueHIAspect,"Dialogue provided to show changes held by version record","displayRecords"));
        hias.addHumanInterfaceInfo(new MVPanelInfo("buttons panel",true,false,MVHumanInterfaceInfo.MVPanelHIAspect,"Button affordances which can be disabled/added to by other components to add extra functionality",getFrame().getButtonsPanel()));
               
        // collaboration
         
        MVCollaborationAspect cas = aspects.getCollaborationAspect();
        
        // persistency management provision/requirements
        
        MVPersistencyAspect peras = aspects.getPersistencyAspect();
        
        
        // how about comp to forward "errors" to? Ok sends to??
            // "error" & "ok" ??
        
        // configuration info - what required to work etc.??
          // info this case ALL properties and at least one input comp's rel
      
        /*
        MVConfigurationAspect cas = aspects.getConfigurationAspect();
        String config_names[] = {"localName","remoteUser","remoteName","<sender>"};
        cas.addConfigurationInfo(new MVConfigurationInfo("required attributes/rels",MVConfigurationInfo.MVRequiredSettings,config_names,"Must set all these attributes & have at least one input component for this remote change sender to work. Must also have remoteUser/remoteName on-line and named"));
        */
        
        
        
        return aspects;
    }  

}

class MVVersionFrame extends Frame {
  MVVersionListPanel listPanel;
  MVVersionButtonPanel buttonPanel = new MVVersionButtonPanel(this);

    protected MVVersionRecord record;
  
  public MVVersionFrame(MVVersionRecord v) {
    super("");
    record = v;
    listPanel = new MVVersionListPanel(v);
    setLayout(new BorderLayout());
    add("Center",listPanel);
    add("South",buttonPanel);
    setSize(300,300);
    pack();
  }
  
  public MVVersionButtonPanel getButtonsPanel()
  {                     
    return buttonPanel;
  }
  
  public void processEvent(AWTEvent e) {
        if(e instanceof WindowEvent) {
            if(e.getID() == WindowEvent.WINDOW_CLOSED) {
                record.frame = null;
                setVisible(false);
            }
        }
        super.processEvent(e);
  }
  
  public void redisplayRecords() {
    // redisplay info after project manipulations...
    
    listPanel.setListValues(record);
    MVChangeDescr c = record.get_change(record.getCurrent());
    if(c != null)
        listPanel.highlightRecord(c);
    validate();
  }
  
  public void addChange(MVChangeDescr c)
  {
    listPanel.addChange(record,c);
    MVChangeDescr ch = record.get_change(record.getCurrent());
    if(ch != null)
        listPanel.highlightRecord(ch);
    validate();    
  }
  
  public void removeChange(int index)
  {
    listPanel.removeChange(index);
    MVChangeDescr c = record.get_change(record.getCurrent());
    if(c != null)
        listPanel.highlightRecord(c);
    validate();  
  }
  
    public void doUndo() {
        Vector changes = listPanel.findSelectedChanges();

        if(changes.size() != 0) {
            for(int i=changes.size();i>0;i--) {
                MVChangeDescr c = (MVChangeDescr) changes.elementAt(i-1);
                System.out.println("undo: "+c);
                record.doUndo(c);
            }
        } else {
            System.out.println("undo last");
            record.undo_last();
        }
    }

    public void doRedo() {
        Vector changes = listPanel.findSelectedChanges();

        if(changes.size() != 0) {
            for(int i=0;i<changes.size();i++) {
                    MVChangeDescr c = (MVChangeDescr) changes.elementAt(i);
                    System.out.println("redo: "+c);
                    record.doRedo(c);
            }
        } else {
            System.out.println("redo last");
            record.redo_last();
        }
    }

    public void doExport() {
        Vector changes = listPanel.findSelectedChanges();
        MVOutputBuffer buffer = new MVOutputBuffer();
        String file_name;
        String path;

    FileDialog dialog = new FileDialog(MVApplication.application.projects_frame,"Exported changes save file",FileDialog.SAVE);
    dialog.setVisible(true);
    file_name = dialog.getFile();
    path = dialog.getDirectory();
System.out.println("file_name="+file_name);
System.out.println("path="+path);
    dialog.setVisible(false);

        MVApplication.application.current_project.exportChanges(changes,buffer);
        MVApplication.application.current_project.writeBufferToFile(buffer,file_name,path);
System.out.println("exported changes!");

    }

  public void doClose() {
    record.frame = null;
        setVisible(false);
  }
  
  public void deselectAll()
  {
    listPanel.deselectAll(); 
  }
  
    public void doView()
    {
        Enumeration e = listPanel.findSelectedChanges().elements();
        while(e.hasMoreElements())
        {
            MVChangeDescr c = (MVChangeDescr) e.nextElement();
            // should put in dialogue...
            System.out.println(c);
        }
    }
    
    public void doDeselectAll()
    {
          deselectAll();
    }
    
    public void doDelete()
    {
        Enumeration e = listPanel.findSelectedChanges().elements();
        while(e.hasMoreElements())
        {
            MVChangeDescr c = (MVChangeDescr) e.nextElement();
            record.remove_change(c.getCount());
        }
    
    }  
  
}

class MVVersionListPanel extends Panel {
  List recordsList = new List();
  MVVersionRecord record;
  
  public MVVersionListPanel(MVVersionRecord r) {
    record = r;
    setLayout(new GridLayout(1,1,3,3));
        recordsList.setMultipleMode(true);
    add(recordsList);
  }
  
  public Vector records = new Vector();
  
  public void setListValues(MVVersionRecord v) {
    Enumeration e = v.get_changes_forwards();
        
    recordsList.removeAll();
        records.removeAllElements();
    
    while(e.hasMoreElements()) {
                MVChangeDescr c = (MVChangeDescr) e.nextElement();
                
                records.addElement(c);
        recordsList.addItem(record.displayString(c));
    }

  }
  
  public void addChange(MVVersionRecord r, MVChangeDescr c)
  {
    deselectAll();
    recordsList.addItem(record.displayString(c));
    records.addElement(c);
  }
  
  public void removeChange(int index)
  {
    recordsList.remove(index);
    records.removeElementAt(index);
  }

    public void highlightRecord(MVChangeDescr c) {
        int i = records.indexOf(c);
        if(i > 0) {
            recordsList.select(i);
            recordsList.makeVisible(i);
        }
    }
    
  public void deselectAll()
  {
    int indexes[] = recordsList.getSelectedIndexes();
    for(int i=0;i<indexes.length;i++)
        recordsList.deselect(indexes[i]);
    recordsList.makeVisible(recordsList.getItemCount()-1);
  }

  public Dimension getMinimumSize() {
    return new Dimension(250,170);
  }

  public Dimension getPreferredSize() {
    return new Dimension(250,170);
  }

    /*
  public MVChangeDescr findSelectedChange() {
    int index = recordsList.getSelectedIndex();
    
    try {
      return (MVChangeDescr) records.elementAt(index);
    } catch (Exception e) {
      return null;
    }
  }
    */

    public Vector findSelectedChanges() {
        int indexes[] = recordsList.getSelectedIndexes();
        Vector changes = new Vector();

        for(int i = 0; i < indexes.length;i++) {
            try {
                changes.addElement(records.elementAt(indexes[i]));
            } catch (Exception e) {
                return null;
            }
        }

        return changes;
    }
  
}

class MVVersionButtonPanel extends Panel implements ActionListener, MVExtensiblePanel {
  Button undoButton = new Button("Undo");
  Button redoButton = new Button("Redo");
    Button exportButton = new Button("Export");
  Button closeButton = new Button("Close");
  Button viewButton = new Button("View");
  Button deselButton = new Button("Deselect");
  Button deleteButton = new Button("Delete");
  
  MVVersionFrame frame;
  
  public Frame getFrame()
  {
    return frame;
  }
  
  public MVVersionButtonPanel(MVVersionFrame frame) {
    setLayout(new GridLayout(2,4,2,2));
    add(undoButton);
        undoButton.addActionListener(this);
    add(redoButton);
        redoButton.addActionListener(this);
        add(exportButton);
        exportButton.addActionListener(this);
    add(viewButton);    
    viewButton.addActionListener(this);
    add(deleteButton);
    add(deselButton);
    deselButton.addActionListener(this);
    deleteButton.addActionListener(this);    
    add(closeButton);
        closeButton.addActionListener(this);
    this.frame = frame;
  }
  
  Dimension min = new Dimension(250,40);
  
  public Dimension getMinimumSize() {
    return min;
  }

  public Dimension getPreferredSize() {
    return min;
  }

  public void actionPerformed(ActionEvent e) {
  
    if(e.getSource() == undoButton)
      frame.doUndo();
    else if(e.getSource() == redoButton)
      frame.doRedo();
        else if(e.getSource() == exportButton)
            frame.doExport();
    else if(e.getSource() == closeButton)
      frame.doClose();
    else if(e.getSource() == viewButton)
        frame.doView();
    else if(e.getSource() == deselButton)
        frame.doDeselectAll();
    else if(e.getSource() == deleteButton)
        frame.doDelete();
  }
  
  // extensible panel stuff
  
  public Component findComponent(String name)
  {
    Component comps[] = getComponents();
    for(int i=0;i<comps.length;i++) {
        Component comp = comps[i];
        if(comp instanceof Button)
            if(((Button) comp).getLabel().equals(name))
                return comp;
    }
    
    return null;
  }
  
  public void addComponent(Component comp)
  {
    GridLayout l = (GridLayout) getLayout();
    if(l.getRows() == 2) {
        setLayout(new GridLayout(3,4,2,2));
        min = new Dimension(250,60);
    }
    add(comp);
    getFrame().validate();
  }
  
  public void removeComponent(Component comp)
  {
  
  }

}

