package JViews;

public class MVCompDeleted extends MVChangeDescr {

    public MVCompDeleted() {
        super();
    }

    public MVCompDeleted(MVComponent comp) {
        setTarget(comp);
        done = false;
    }

    public void execute() {
        target.doDelete();
    }

    public void undo() {
        target.undelete();
    }

    public void redo() {
        target.delete();
    }

    public String toString() {
        return "MVCompDeleted: "+getTarget().userName();
    }
    
}

