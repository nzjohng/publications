
package JViews;

public abstract class MVViewEvent extends MVChangeDescr
{

    MVViewLayer view;

    public MVViewEvent(MVViewLayer v)
    {
        view = v;
    }  

}
