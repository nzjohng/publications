package JViews;

import java.util.*;       

public class MVImportDefaultLocator implements MVCompLocator {

    MVProject project;
    Vector table = new Vector();
    
    public MVImportDefaultLocator(MVProject p) {
        project = p;
    }

    public MVComponent findOrCreateComp(int compID, int copiedFrom, String compKind) {
        // looks for comp in view...

//System.out.println("Trying to locate match for "+compID+" "+copiedFrom);
        // use look-up table first    
        MVImportViewItem i = findDefaultItem(compID,copiedFrom);
        if(i != null) {
//System.out.println("found item "+i.newComp.compID);
            return i.newComp;
        }

        // is the component the project itself??
        if(compID == 0) {
//System.out.println("found view "+view.compID);
            return project;
        }

System.out.println("Couldn't find a match for "+compID+" "+copiedFrom);

        return null;      
    }  
    
    public MVImportViewItem findDefaultItem(int compID, int copiedFrom)
    {
        Enumeration e = table.elements();
        while(e.hasMoreElements()) {
            MVImportViewItem item = (MVImportViewItem) e.nextElement();
//System.out.println("looking for "+compID+"("+copiedFrom+") - checking "+item.oldCompID+"->"+item.newComp.compID+"("+item.copiedFrom+")");
            if(item.oldCompID == compID)
                return item;
            else if(item.copiedFrom == copiedFrom) {
                table.addElement(new MVImportViewItem(compID,item.newComp.compID,item.newComp.copiedFrom,item.newComp));
                return item;
            }
        }
        
        return null;
    }

    public MVComponent findOldComp(int compID, int copiedFrom, String compKind, String userName) {
        MVComponent c = findOrCreateComp(compID,copiedFrom,compKind);
        if(c != null)
            return c;
            
        c = project.findCompID(compID,copiedFrom,compKind,userName);
        if(c != null) {
            table.addElement(new MVImportViewItem(compID,c.compID,c.copiedFrom,c));
            return c;
        }
        
        c = project.findCompByName(compKind,userName);
        if(c != null) {
            table.addElement(new MVImportViewItem(compID,c.compID,c.copiedFrom,c));       
            return c;
        }
        
        return c;
    }

    public MVComponent createNewComp(int compID, int copiedFrom, String compKind) {
        MVComponent c = project.findCopiedComp(copiedFrom);

        if(c != null)
            return c;

        c = project.createNewComp(compID,copiedFrom,compKind);
        table.addElement(new MVImportViewItem(compID,c.compID,copiedFrom,c));

        return c;
    }

    public MVChangeDescr createNewChange(String changeKind) {
        return project.createNewChange(changeKind);
    }

    public void reestablishRel(MVComponent otherComp, MVRelItem locatorRel,
        MVComponent locatorComp) {
        // does nothing when importing changes...

    }

}


