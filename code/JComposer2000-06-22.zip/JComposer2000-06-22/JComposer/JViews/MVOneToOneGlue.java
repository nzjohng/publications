package JViews;

import java.util.*;
import bbw.*;
import java.awt.*;

/*
 * MVOneToOneGlue
 *
 * One-to-one glue links one view component with another with rendered "glue"
 *
 */

public class MVOneToOneGlue extends MVGlue {

  public MVOneToOneGlue(MVViewLayer view, MVViewComp parent, MVViewComp child) {
    super(view);
    addParent(parent);
    addChild(child);
  }
  
  public MVOneToOneGlue() {
    super();
  }

    public void init(MVViewLayer view, MVViewComp parent, MVViewComp child) {
        super.init(view);
System.out.println("MVOneToOneGlue.init - parent="+parent.compID+" child="+child.compID);
        addParent(parent);
        addChild(child);
    }
  
  public MVViewComp getParent() {
    return (MVViewComp) getOneRelated("Parent",MVChildren);
  }

  public MVViewComp getChild() {
    return (MVViewComp) getOneRelated("Child",MVChildren);
  
  }
  
  public boolean canBeDrawn()
    {
        if(super.canBeDrawn() && getOneRelatedOrNull("Child",MVChildren) != null && getOneRelatedOrNull("Parent",MVChildren) != null)
            return true;
        else
            return false;
    }

  
  public void addParent(MVViewComp parent) {
    if(getParents().size() != 0)
      dissolveOneToMany("Parent",getParent());
    super.addParent(parent);
  }

  public void addChild(MVViewComp child) {
    if(getChildren().size() != 0)
      dissolveOneToMany("Child",getChild());
    super.addChild(child);
    
  }

    public RectangularShape getBBWParent() {
        return (RectangularShape) getParent().getBBWShape();
    }

    public RectangularShape getBBWChild() {
        return (RectangularShape) getChild().getBBWShape();
    }

    public boolean hasParent() {
        if(getParents().size() > 0)
            return true;
        return false;
    }

    public boolean hasChild() {
        if(getChildren().size() > 0)
            return true;
        return false;
    }
    
    // *** delete this when BBW connector dispose() working!!
    public void deleteBBWShape()
    {
        getBBWShape().setVisible(false);
    }
}
