
package JViews;

public interface MVRemoteChangeReceiver
{

    public void receiveRemoteChange(String user, String from, byte bytes[]);
        // received change, still needing deserialisation, from user/component

}
