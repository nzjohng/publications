
package JViews;

public class MVBaseCompDeleted extends MVChangeDescr
{

    public MVBaseCompDeleted(MVViewComp c)
    {
        super(c);
    }
    
    public MVBaseCompDeleted()
    {
        super();
    }
    
    public MVViewComp getViewComp()
    {
        return (MVViewComp) target;
    }
    
    public void execute()
    {
        MVBaseComp bc = getViewComp().getBaseComp();
        getViewComp().delete();
        if(bc != null) 
            bc.delete();
    }
    
    public void undo()
    {
        MVBaseComp bc = getViewComp().getBaseComp();
        if(bc != null)
            bc.undelete();
        getViewComp().undelete();
    }
    
    public void redo()
    {
        getViewComp().deleteBaseComp();
    }
    
    public String toString()
    {
        return "BaseCompDeleted: "+getViewComp().userName();
    }

}
