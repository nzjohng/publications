package JViews;

import java.io.*;

public class MVOutputBuffer {

    protected ByteArrayOutputStream buffer = new ByteArrayOutputStream(1024);

    protected PrintWriter output = new PrintWriter(buffer);
    
    public MVOutputBuffer()
    {
    
    }

    public int size() {
        return buffer.size();
    }

    public void reset() {
        output.flush();
        buffer.reset();
    }

    public byte[] getBytes() {
        output.flush();
        return buffer.toByteArray();
    }

    public void write(String s) {
        output.print(s);
    }

    public void write(char c) {
        output.print(c);
    }

    public void write(int i) {
        output.print(i);
    }
    
    public void write(boolean b) {
        output.print(b);
    }

    public void write(Object o) {
        
    }
    
    public void write(byte bytes[]) {
        output.flush();
        buffer.write(bytes,0,bytes.length);
    }

    public void writeQuoted(String s) {
        output.print(' ');
        output.print('"');
        output.print(s);
        output.print('"');
        output.print(' ');
    }
    
    public void nl()
    {
        output.flush();
        buffer.write('\n'); // new line
    }

    public void writelnQuoted(String s) {
        output.print(' ');
        output.print('"');
        output.print(s);
        output.print('"');
        nl();
    }

    public void writeln(int i) {
        output.print(i);
        nl();
    }

    public void writeln(String s) {
        output.print(s);
        nl();
    }

    public void writeln(MVComponent c) {
        output.print(c.compID);
        nl();
    }

    public void writeln(boolean b) {
        output.print(b);
        nl();
    }

    public void writeln(char c) {
        output.print(c);
        nl();
    }

    public void flush() {
        output.flush(); 
    }

}

