package JViews;

import java.awt.*;

public class MVNewFrameEvent extends MVChangeDescr
{
    Frame frame;

    public MVNewFrameEvent()
    {
        super();
    }
    
    public MVNewFrameEvent(MVComponent target,Frame f)
    {
        super(target);
        frame = f;
    }
    
    public String toString()
    {
        return "New Frame Event";
    }
    
    public void execute()
    {
    
    }
    
    public void undo()
    {
    
    }
    
    public void redo()
    {
    
    }
    
    

}

