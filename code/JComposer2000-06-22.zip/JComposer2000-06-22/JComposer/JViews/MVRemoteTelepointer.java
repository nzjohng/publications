package JViews;

public interface MVRemoteTelepointer extends java.rmi.Remote
{

	public void mouseMoved(String user, int x, int y) throws java.rmi.RemoteException;
		// tell other users about mouse move event...

}
