package JCVisualise;

import JViews.*;

public class JCVisBaseLayer extends MVBaseLayer {

  public JCVisBaseLayer() {
    super();
  }

  public JCVisBaseLayer(String name) {
    super(name);
  }

  public String userName() {
    return getName();
  }

    public void initialise() {

    }

    public static JCVisBaseLayer getVisualiser(MVBaseLayer base_layer) {
        JCVisBaseLayer visualiser = (JCVisBaseLayer) 
            base_layer.getOneRelatedOrNull("Visualiser",MVChildren);

        if(visualiser == null) {
            visualiser = new JCVisBaseLayer("Visualiser");
            base_layer.establishOneToMany("Visualiser",visualiser);
            base_layer.getProject().addBaseLayer(visualiser);
        }
        
        return visualiser;
    }

    public static void visualisePrev(MVBaseLayer base_layer, MVComponent comp) {
        getVisualiser(base_layer).doVisualisePrev(comp);
    }

    public void doVisualisePrev(MVComponent comp) {
        if(prevView == null)
            doVisualiseNew(comp);
        else {
            // need to check if already being spied???
            // need to auto-expand links to currently-spied components???

            JCVisCompIcon vis_icon = new JCVisCompIcon();
            vis_icon.init(prevView);
            vis_icon.spyComponent(comp);

        }
    }

    public static void visualiseNew(MVBaseLayer base_layer, MVComponent comp) {
        getVisualiser(base_layer).doVisualiseNew(comp);
    }

    public void doVisualiseNew(MVComponent comp) {
        JCVisDiagram view = new JCVisDiagram(this,nextViewName());
        view.show();

        JCVisCompIcon vis_icon = new JCVisCompIcon();
        vis_icon.init(view);
        vis_icon.spyComponent(comp);
        
        prevView = view;
    }

    protected JCVisDiagram prevView = null;

    public void makeCurrent(MVViewLayer view) {
        if(view instanceof JCVisDiagram)
            prevView = (JCVisDiagram) view;

        super.makeCurrent(view);
    }

    public String nextViewName() {
        int num = getViewName();
        setViewName(num+1);

        return "Visualisation "+num;
    }


}

