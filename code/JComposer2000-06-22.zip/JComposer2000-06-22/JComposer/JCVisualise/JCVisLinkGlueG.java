package JCVisualise;

import JViews.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCVisLinkGlueG extends MVOneToOneGlue {

    /* Constructors */

    public JCVisLinkGlueG() {
        super();
    }

    /* Attributes */

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }

    public String getChoiceFrom() {
        return getStringValue("choiceFrom");
    }

    public void setChoiceFrom(String value) {
        setValue("choiceFrom",value);
    }

    public String getChoiceTo() {
        return getStringValue("choiceTo");
    }

    public void setChoiceTo(String value) {
        setValue("choiceTo",value);
    }

    public JCArrowArity getJCArrowArity() {
        return (JCArrowArity) getBBWShape();
    }

    public boolean isChildListenBefore() {
        return getBooleanValue("childListenBefore");
    }

    public void setChildListenBefore(boolean value) {
        setValue("childListenBefore",value);
    }

    public boolean isChildListenAfter() {
        return getBooleanValue("childListenAfter");
    }

    public void setChildListenAfter(boolean value) {
        setValue("childListenAfter",value);
    }

    public boolean isParentListenBefore() {
        return getBooleanValue("parentListenBefore");
    }

    public void setParentListenBefore(boolean value) {
        setValue("parentListenBefore",value);
    }

    public boolean isParentListenAfter() {
        return getBooleanValue("parentListenAfter");
    }

    public void setParentListenAfter(boolean value) {
        setValue("parentListenAfter",value);
    }

    /* Relationships */

    /* Methods */

    public abstract String userName();

    /* Read/write methods */

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCArrowArity().setNameText(getNameText());
            } else if(name.equals("choiceFrom")) {
                getJCArrowArity().setChoiceFrom(getChoiceFrom());
            } else if(name.equals("choiceTo")) {
                getJCArrowArity().setChoiceTo(getChoiceTo());
            } else if(name.equals("childListenBefore")) {
                getJCArrowArity().setChildListenBefore(isChildListenBefore());
            } else if(name.equals("childListenAfter")) {
                getJCArrowArity().setChildListenAfter(isChildListenAfter());
            } else if(name.equals("parentListenBefore")) {
                getJCArrowArity().setParentListenBefore(isParentListenBefore());
            } else if(name.equals("parentListenBefore")) {
                getJCArrowArity().setParentListenAfter(isParentListenAfter());
            }
            
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {

        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

System.out.println(evt);
System.out.println(evt.getPropertyName());

        if(evt.getPropertyName().equals("name")) {
            setNameText(getJCArrowArity().getNameText());
        } else if(evt.getPropertyName().equals("choiceFrom")) {
            setChoiceFrom(getJCArrowArity().getChoiceFrom());
        } else if(evt.getPropertyName().equals("choiceTo")) {
            setChoiceTo(getJCArrowArity().getChoiceTo());
        } else if(evt.getPropertyName().equals("childListenBefore")) {
            setChildListenBefore(getJCArrowArity().isChildListenBefore());
        } else if(evt.getPropertyName().equals("childListenAfter")) {
            setChildListenAfter(getJCArrowArity().isChildListenAfter());
        } else if(evt.getPropertyName().equals("parentListenBefore")) {
            setParentListenBefore(getJCArrowArity().isParentListenBefore());
        } else if(evt.getPropertyName().equals("parentListenAfter")) {
            setParentListenAfter(getJCArrowArity().isParentListenAfter());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCArrowArity().getNameText());
        setChoiceFrom(getJCArrowArity().getChoiceFrom());
        setChoiceTo(getJCArrowArity().getChoiceTo());
        setChildListenBefore(getJCArrowArity().isChildListenBefore());
        setChildListenAfter(getJCArrowArity().isChildListenAfter());
        setParentListenBefore(getJCArrowArity().isParentListenBefore());
        setParentListenAfter(getJCArrowArity().isParentListenAfter());
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        if(getAttribute("nameText") != null)
            getJCArrowArity().setNameText(getNameText());
        else
            setNameText(getJCArrowArity().getNameText());
        if(getAttribute("choiceFrom") != null)
            getJCArrowArity().setChoiceFrom(getChoiceFrom());
        else
            setChoiceFrom(getJCArrowArity().getChoiceFrom());
        if(getAttribute("choiceTo") != null)
            getJCArrowArity().setChoiceTo(getChoiceTo());
        else
            setChoiceTo(getJCArrowArity().getChoiceTo());
        if(getAttribute("childListenBefore") != null)
            getJCArrowArity().setChildListenBefore(isChildListenBefore());
        else
            setChildListenBefore(getJCArrowArity().isChildListenBefore());
        if(getAttribute("childListenAfter") != null)
            getJCArrowArity().setChildListenAfter(isChildListenAfter());
        else
            setChildListenAfter(getJCArrowArity().isChildListenAfter());
        if(getAttribute("parentListenBefore") != null)
            getJCArrowArity().setParentListenBefore(isParentListenBefore());
        else
            setParentListenBefore(getJCArrowArity().isParentListenBefore());
        if(getAttribute("parentListenAfter") != null)
            getJCArrowArity().setParentListenAfter(isParentListenAfter());
        else
            setParentListenAfter(getJCArrowArity().isParentListenAfter());
    }

}

