package JCVisualise;

import JViews.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import bbw.*;

public class JCVisLinkIcon extends JCVisLinkIconG implements ActionListener {

    public JCVisLinkIcon() {
        super();
    }

    public JCVisLinkIcon(MVViewLayer v) {
        super(v);
    }

    public String userName() {
        return getNameText();
    }

    public MVBaseComp mapComponent(boolean do_map) {
        return null;
    }

    public void spyComponent(MVComponent c) {
        establishSpying(c);
    }

    public void establishSpying(MVComponent c) {
        MVComponent other = getcSpying();
        if(other != null) {
            dissolveOneToMany("Spying",other);
        }

        establishOneToMany("Spying",c);
        c.setListenAfterRel("Spying");
    }

    public MVComponent getcSpying() {
        return (MVComponent) getOneRelatedOrNull("Spying",MVChildren);
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue) {
System.out.println("JCVisLinkIcon got "+c);
            }

            if(c instanceof MVEstablishOneToMany) {
                if(((MVEstablishOneToMany) c).getName().equals("Spying")) {
                    updateLinkedComps();
                }
            }

            if(from == getcSpying())
                updateLinkedComps();

            return super.afterChange(c,from,rel_name);
        }

    public void addJViewsPopups(BBWComponent shape) {
        super.addJViewsPopups(shape);
        shape.addPopupMenuItem(itemsMenu);
    }

    protected Vector linked = new Vector();
    protected Vector items = new Vector();
    protected Menu itemsMenu = new Menu("Show Linked...");

    public void updateLinkedComps() {
        Vector lcomps = getcSpying().getRelationship(getNameText(),getLinkKind());
        Enumeration e = lcomps.elements();

        int i = 0;

        while(e.hasMoreElements()) {
            MVComponent c = (MVComponent) e.nextElement();
            String label = c.userName();
            if(label.equals(""))
                continue;

            if(i < items.size()) {
    // problems with thread alarms!!!
                // linked.setElementAt(c,i);
                // ((MenuItem) items.elementAt(i)).setLabel(label);
            } else {
                linked.addElement(c);
System.out.println("Adding "+c.userName()+" to link icon menu");
                MenuItem nitem = new MenuItem(label);
                items.addElement(nitem);
                itemsMenu.add(nitem);
                nitem.addActionListener(this);
            }
            i++;
        }

    }

    public void actionPerformed(ActionEvent e) {
            int itemIndex = items.indexOf(e.getSource());
            if(itemIndex > -1) {
                MVComponent c = (MVComponent) linked.elementAt(itemIndex);
System.out.println("trying to expand comp for "+c.userName());
                if(!hasLinkGlueTo(c))
                    ((JCVisDiagram) view()).showLinkedComp(this,c);
            }
    }

    public boolean hasLinkGlueTo(MVComponent c) {
        Enumeration e1 = getRelationship("Parent",MVParents).elements();

        while(e1.hasMoreElements()) {
            JCVisLinkGlue g = (JCVisLinkGlue) e1.nextElement();
            if(g.getChild().getOneRelatedOrNull("Spying",MVChildren) == c)
                return true;
        }

        Enumeration e2 = getRelationship("Child",MVParents).elements();

        while(e2.hasMoreElements()) {
            JCVisLinkGlue g = (JCVisLinkGlue) e2.nextElement();
            if(g.getParent().getOneRelatedOrNull("Spying",MVChildren) == c)
                return true;
        }
        
        return false;
    }

}

