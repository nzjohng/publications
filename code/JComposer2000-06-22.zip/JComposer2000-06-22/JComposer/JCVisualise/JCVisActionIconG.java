package JCVisualise;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import jComposer.*;

public abstract class JCVisActionIconG extends MVIcon {

  public JCVisActionIconG() {
    super();
    establishListeners();
  }

  public JCVisActionIconG(MVViewLayer v) {
    super(v);
    establishListeners();
  }

  public String kindName() {
    return "Action Icon";
  }

  public abstract String userName();

    public String getText() {
        return getStringValue("text");
    }

    public void setText(String value) {
        setValue("text",value);
    }

    public String getParentName() {
        return getStringValue("parentName");
    }

    public void setParentName(String value) {
        setValue("parentName",value);
    }

  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }

  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }

    public boolean isGenerateCode() {
        return getBooleanValue("generateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("generateCode",value);
    }

  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }

  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
        setValue("width",value);
  }

  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
        setValue("height",value);
  }


    public JCRelnShadedShape getJCRelnShadedShape() {
        return (JCRelnShadedShape) getBBWShape();
    }

  public void establishListeners() {
  }

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("text")) {
                getJCRelnShadedShape().setText(getText());
            } else if(name.equals("parentName")) {
                getJCRelnShadedShape().setParentName(getParentName());
            } else if(name.equals("foreground")) {
                getJCRelnShadedShape().setForeground(java_awt_Color_fromString(getForeground()));
            } else if(name.equals("background")) {
                getJCRelnShadedShape().setBackground(java_awt_Color_fromString(getBackground()));
            } else if(name.equals("x")) {
                getJCRelnShadedShape().setX(getX());
            } else if(name.equals("y")) {
                getJCRelnShadedShape().setY(getY());
            } else if(name.equals("width")) {
                getJCRelnShadedShape().setWidth(getWidth());
            } else if(name.equals("height")) {
                getJCRelnShadedShape().setHeight(getHeight());
            } else if(name.equals("generateCode"))
                getJCRelnShadedShape().setGenerateCode(isGenerateCode());
            // etc.
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("text")) {
            setText(getJCRelnShadedShape().getText());
        }
        if(evt.getPropertyName().equals("parentName")) {
            setParentName(getJCRelnShadedShape().getParentName());
        }
        if(evt.getPropertyName().equals("foreground")) {
            setForeground(java_awt_Color_toString(getJCRelnShadedShape().getForeground()));
        }
        if(evt.getPropertyName().equals("background")) {
            setBackground(java_awt_Color_toString(getJCRelnShadedShape().getBackground()));
        }
        if(evt.getPropertyName().equals("x")) {
            setX(getJCRelnShadedShape().getX());
        }
        if(evt.getPropertyName().equals("y")) {
            setY(getJCRelnShadedShape().getY());
        }
        if(evt.getPropertyName().equals("width")) {
            setWidth(getJCRelnShadedShape().getWidth());
        }
        if(evt.getPropertyName().equals("height")) {
            setHeight(getJCRelnShadedShape().getHeight());
        }
        if(evt.getPropertyName().equals("generateCode")) {
            setGenerateCode(getJCRelnShadedShape().isGenerateCode());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setText(getJCRelnShadedShape().getText());
        setParentName(getJCRelnShadedShape().getParentName());
        setForeground(java_awt_Color_toString(getJCRelnShadedShape().getForeground()));
        setBackground(java_awt_Color_toString(getJCRelnShadedShape().getBackground()));
        setX(getJCRelnShadedShape().getX());
        setY(getJCRelnShadedShape().getY());
        setWidth(getJCRelnShadedShape().getWidth());
        setHeight(getJCRelnShadedShape().getHeight());
        setGenerateCode(getJCRelnShadedShape().isGenerateCode());
        // etc.
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        getJCRelnShadedShape().setText(getText());
        if(getAttribute("parentName") != null)
            getJCRelnShadedShape().setParentName(getParentName());
        else
            setParentName(getJCRelnShadedShape().getParentName());
        if(getAttribute("foreground") != null)
            getJCRelnShadedShape().setForeground(java_awt_Color_fromString(getForeground()));
        else
            setForeground(java_awt_Color_toString(getJCRelnShadedShape().getForeground()));
        if(getAttribute("background") != null)
            getJCRelnShadedShape().setBackground(java_awt_Color_fromString(getBackground()));
        else
            setBackground(java_awt_Color_toString(getJCRelnShadedShape().getBackground()));
        if(getAttribute("x") != null)
            getJCRelnShadedShape().setX(getX());
        else
            setX(getJCRelnShadedShape().getX());
        if(getAttribute("y") != null)
            getJCRelnShadedShape().setY(getY());
        else
            setY(getJCRelnShadedShape().getY());
        if(getAttribute("width") != null)
            getJCRelnShadedShape().setWidth(getWidth());
        else
            setWidth(getJCRelnShadedShape().getWidth());
        if(getAttribute("height") != null)
            getJCRelnShadedShape().setHeight(getHeight());
        else
            setHeight(getJCRelnShadedShape().getHeight());
        if(getAttribute("generateCode") != null)
            getJCRelnShadedShape().setGenerateCode(isGenerateCode());
        else
            setGenerateCode(getJCRelnShadedShape().isGenerateCode());

    }

}

