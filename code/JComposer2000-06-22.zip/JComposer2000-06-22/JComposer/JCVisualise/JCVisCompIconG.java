package JCVisualise;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import java.awt.*;
import jComposer.*;

public abstract class JCVisCompIconG extends MVIcon {

  public JCVisCompIconG() {
    super();
    establishListeners();
  }

    public void init(MVViewLayer v) {
        super.init(v);
    }

  public String kind() {
    return "Component Visualisation";
  }

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }

    public String getKindText() {
        return getStringValue("kindText");
    }

    public void setKindText(String value) {
        setValue("kindText",value);
    }

    public String getParentText() {
        return getStringValue("parentText");
    }

    public void setParentText(String value) {
        setValue("parentText",value);
    }

    public String getBbwShapeText() {
        return getStringValue("bbwShapeText");
    }

    public void setBbwShapeText(String value) {
        setValue("bbwShapeText",value);
    }

  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }

  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }

    public boolean isGenerateCode() {
        return getBooleanValue("generateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("generateCode",value);
    }

  public boolean isVisible() {
    return getBooleanValue("visible");
  }

  public void setVisible(boolean value) {
    setValue("visible",value);
  }

  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }

  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
        setValue("width",value);
  }

  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
        setValue("height",value);
  }

  public abstract String userName();

    public JCComponent getJCComponent() {
        return (JCComponent) getBBWShape();
    }

  public void establishListeners() {
  }

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(getJCComponent() == null)
            return c;

        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCComponent().setNameText(getNameText());
            } else if(name.equals("bbwShapeText")) {
                getJCComponent().setBbwShapeText(getBbwShapeText());
            } else if(name.equals("kindText")) {
                getJCComponent().setKindText(getKindText());
            } else if(name.equals("parentText")) {
                getJCComponent().setParentText((getParentText()));
            } else if(name.equals("foreground")) {
                getJCComponent().setForeground(java_awt_Color_fromString(getForeground()));
            } else if(name.equals("background")) {
                getJCComponent().setBackground(java_awt_Color_fromString(getBackground()));
            } else if(name.equals("x")) {
                getJCComponent().setX(getX());
            } else if(name.equals("y")) {
                getJCComponent().setY(getY());
            } else if(name.equals("width")) {
                getJCComponent().setWidth(getWidth());
            } else if(name.equals("height")) {
                getJCComponent().setHeight(getHeight());
            } else if(name.equals("generateCode")) {
                getJCComponent().setGenerateCode(isGenerateCode());
            }
            // etc.
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("nameText")) {
            setNameText(getJCComponent().getNameText());
        }
        if(evt.getPropertyName().equals("parentText")) {
            setParentText(getJCComponent().getParentText());
        }
        if(evt.getPropertyName().equals("kindText")) {
            setKindText(getJCComponent().getKindText());
        }
        if(evt.getPropertyName().equals("bbwShapeText")) {
            setBbwShapeText(getJCComponent().getBbwShapeText());
        }
        if(evt.getPropertyName().equals("foreground")) {
            setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
        }
        if(evt.getPropertyName().equals("background")) {
            setBackground(java_awt_Color_toString(getJCComponent().getBackground()));
        }
        if(evt.getPropertyName().equals("x")) {
            setX(getJCComponent().getX());
        }
        if(evt.getPropertyName().equals("y")) {
            setY(getJCComponent().getY());
        }
        if(evt.getPropertyName().equals("width")) {
            setWidth(getJCComponent().getWidth());
        }
        if(evt.getPropertyName().equals("height")) {
            setHeight(getJCComponent().getHeight());
        }
        if(evt.getPropertyName().equals("generateCode")) {
            setGenerateCode(getJCComponent().isGenerateCode());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCComponent().getNameText());
        setParentText(getJCComponent().getParentText());
        setKindText(getJCComponent().getKindText());
        setBbwShapeText(getJCComponent().getBbwShapeText());
        setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
        setBackground(java_awt_Color_toString(getJCComponent().getBackground()));
        setX(getJCComponent().getX());
        setY(getJCComponent().getY());
        setWidth(getJCComponent().getWidth());
        setHeight(getJCComponent().getHeight());
        setGenerateCode(getJCComponent().isGenerateCode());
        // etc.
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        if(getAttribute("nameText") != null)
            getJCComponent().setNameText(getNameText());
        else
            setNameText(getJCComponent().getNameText());
        if(getAttribute("parentText") != null)
            getJCComponent().setParentText(getParentText());
        else
            setParentText(getJCComponent().getParentText());
        if(getAttribute("kindText") != null)
            getJCComponent().setKindText(getKindText());
        else
            setKindText(getJCComponent().getKindText());
        if(getAttribute("bbwShapeText") != null)
            getJCComponent().setBbwShapeText(getBbwShapeText());
        else
            setBbwShapeText(getJCComponent().getBbwShapeText());
        if(getAttribute("foreground") != null)
            getJCComponent().setForeground(java_awt_Color_fromString(getForeground()));
        else
            setForeground(java_awt_Color_toString(getJCComponent().getForeground()));
        if(getAttribute("background") != null)
            getJCComponent().setBackground(java_awt_Color_fromString(getBackground()));
        else
            setBackground(java_awt_Color_toString(getJCComponent().getBackground()));
        if(getAttribute("x") != null)
            getJCComponent().setX(getX());
        else
            setX(getJCComponent().getX());
        if(getAttribute("y") != null)
            getJCComponent().setY(getY());
        else
            setY(getJCComponent().getY());
        if(getAttribute("width") != null)
            getJCComponent().setWidth(getWidth());
        else
            setWidth(getJCComponent().getWidth());
        if(getAttribute("height") != null)
            getJCComponent().setHeight(getHeight());
        else
            setHeight(getJCComponent().getHeight());
        if(getAttribute("generateCode") != null)
            getJCComponent().setGenerateCode(isGenerateCode());
        else
            setGenerateCode(getJCComponent().isGenerateCode());

    }

}

