package JCVisualise;

import JViews.*;
import bbw.*;
import bbw.shape.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;

public class JCVisCompIcon extends JCVisCompIconG implements ActionListener {

  public JCVisCompIcon() {
    super();
  }

    public MVBaseComp mapComponent(boolean do_map) {
        return null;
    }

    public String userName() {
        return getNameText();
    }

    public void spyComponent(MVComponent c) {
        establishSpying(c);
        setNameText(Integer.toString(c.compID));
        setParentText(c.compKind());

    }

    public void showAllAttributes() {
        // show component attributes/values in icon

        MVComponent c = getcSpying();
        Enumeration e = c.getAttributes().elements();

        while(e.hasMoreElements()) {
            String value = ((MVAttribute) e.nextElement()).toString();
System.out.println("adding attr "+value+" to JCVisCompIcon...");
            getJCComponent().addElement();
            Vector fields = getJCComponent().getFields();
            TextFieldShape field = (TextFieldShape) fields.lastElement();
            field.setText(value);
        }
    }

    public void showAttribute(String name) {
        Vector fields = getJCComponent().getFields();

        Enumeration e2 = fields.elements();
        while(e2.hasMoreElements()) {
            TextFieldShape s = (TextFieldShape) e2.nextElement();
            if(getAttrName(s.getText()).equals(name)) {
                redisplayValue(name);
                return;
            }
        }

        getJCComponent().addElement();
        Vector fields2 = getJCComponent().getFields();
        TextFieldShape field = (TextFieldShape) fields2.lastElement();
        field.setText(getcSpying().getAttribute(name).toString());
    }

    public void establishSpying(MVComponent c) {
        establishOneToMany("Spying",c);
        c.setListenBeforeRel("Spying");
        c.setListenAfterRel("Spying"); 
        updateAttrPopups();
        updateRelPopups();       
    }
    
    public void addedViewComp(BBWComponent b)
    {      
        // if reloaded, set up pop-ups
        super.addedViewComp(b);
        if(getcSpying() != null) {
            updateAttrPopups();
            updateRelPopups();
        }
    }

/*    
    public void addedBBWShape(BBWComponent b)
    {
        // if interactively added, add pop-ups
        supetr.addedBBWShape(b);
        updateAttrPopups();
        updateRelPopups();
    }
*/

    public MVComponent getcSpying() {
        return (MVComponent) getOneRelatedOrNull("Spying",MVChildren);
    }
    
    public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel_name)
    {
        if(c.targets(getcSpying())&& c instanceof MVCompDeleted) {
            // indicate spied comp deleted
            deleted = true; // so don't lose link to spied comp!
            setForeground("255 0 0");
        }
        if(c.targets(getcSpying()) && c instanceof MVCompUndeleted) {
            // indicate spied comp undeleted
            setForeground("0 0 0");
        }
        
        return super.beforeChange(c,from,rel_name);
    }
    
    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {

        if(c instanceof MVSetValue) {
System.out.println("JCVisCompIcon got "+c);
            if(getcSpying() != null)
                redisplayValue(((MVSetValue) c).getPropertyName());
            else
                if(((MVSetValue) c).getPropertyName().equals("parentText") &&
                    !getParentText().equals("")) {
                    // create new instance of component

System.out.println("creating instance of "+getParentText());

                    try {
                        Class pclass = Class.forName(getParentText());
                        MVComponent new_comp = (MVComponent) pclass.newInstance();
                        // how do we init the component for the base view...???

                        spyComponent(new_comp);
                    } catch(ClassNotFoundException e) {
                        System.out.println("*** No such class "+getParentText());
                    } catch(IllegalAccessException e) {
                        System.out.println("*** Class "+getParentText()+" can't have instances!");
                    } catch(Exception e) {
                        System.out.println("*** Couldn't create instance of class "+getParentText()+": "+e);
                    }

                }
        }

        if(c.targets(getcSpying())) {
            if(c instanceof MVSetValue)
                updateAttrPopups();
            else
                updateRelPopups();
                
            if(c instanceof MVCompDeleted)
                deleted = false;
        }

        return super.afterChange(c,from,rel_name);
    }

    public void expandLinks(JCVisDiagram v) {
System.out.println("expanding links for "+compID);

    }

    public void addElement(String name) {
        System.out.println("Added attribute "+name+" to JCVisCompIcon");
    }

    public void redisplayValue(String attr) {
        if(getJCComponent() == null)
            return;
    
        Vector fields = getJCComponent().getFields();

        Enumeration e2 = fields.elements();
        while(e2.hasMoreElements()) {
            TextFieldShape s = (TextFieldShape) e2.nextElement();
            String name = getAttrName(s.getText());
            if(name.equals(attr)) {
                s.setText(getcSpying().getAttribute(attr).toString());
                return;
            }
        }

    }

    public String getAttrName(String value) {
        char chars[] = value.toCharArray();
        int i = 0;

        while(i<chars.length) {
            if(chars[i] == '=')
                return new String(chars,0,i-1);
            i++;
        }

        return value;
    }

    protected MenuItem printSpyed = new MenuItem("Print Component");
    protected MenuItem inspectSpyed = new MenuItem("Inspect Component");
    protected MenuItem allAttrs = new MenuItem("Show All Attributes");
    protected MenuItem propSheet = new MenuItem("Show Comp Property Sheet");
    protected MenuItem deleteComp = new MenuItem("Delete Comp");
    protected MenuItem undeleteComp = new MenuItem("Undelete Comp");

    protected Menu showAttrMenu = new Menu("Show attribute...");
    protected Menu showLinkMenu = new Menu("Show link...");
    
    MenuItem aspectInfo = new MenuItem("Show Aspect Info");
    MenuItem initComp = new MenuItem("Initialise Comp");

    protected Vector attrItems = new Vector();
    protected Vector relItems = new Vector();

    public void addJViewsPopups(BBWComponent shape) {
        shape.addPopupMenuItem(new MenuItem("-"));
        shape.addPopupMenuItem(printSpyed);
        printSpyed.addActionListener(this);
        shape.addPopupMenuItem(inspectSpyed);
        inspectSpyed.addActionListener(this);
        shape.addPopupMenuItem(deleteComp);
        deleteComp.addActionListener(this);
        shape.addPopupMenuItem(undeleteComp);
        undeleteComp.addActionListener(this);
        shape.addPopupMenuItem(allAttrs);
        allAttrs.addActionListener(this);
        shape.addPopupMenuItem(propSheet);
        propSheet.addActionListener(this);
        shape.addPopupMenuItem(showAttrMenu);
        shape.addPopupMenuItem(showLinkMenu);
        shape.addPopupMenuItem(aspectInfo);
        aspectInfo.addActionListener(this);
        shape.addPopupMenuItem(initComp);
        initComp.addActionListener(this);
    }

    public void updateAttrPopups() {
        BBWComponent shape = getBBWShape();
        
        if(shape == null)
            return;

        Enumeration e1 = getcSpying().getAttributes().elements();
        int i = 0;
        while(e1.hasMoreElements()) {
            MVAttribute a = (MVAttribute) e1.nextElement();
            if(i >= attrItems.size()) { 
                MenuItem item = new MenuItem("Show "+a.getPropertyName());
                showAttrMenu.add(item);
                item.addActionListener(this);
                attrItems.addElement(item);
            } else {
                // ((MenuItem) attrItems.elementAt(i)).setLabel("Show "+a.getPropertyName());
            }
            i++;
        }
    }

    public void updateRelPopups() {
    
System.out.println("UPDATING POPUPS for JCVisCompIcon...");
    
        BBWComponent shape = getBBWShape();
        
        if(shape == null)
            return;

        Enumeration e2 = getcSpying().getRelationships().elements();
        int i = 0;
        while(e2.hasMoreElements()) {
            MVRelItem r = (MVRelItem) e2.nextElement();
            if(i >= relItems.size()) {
                MenuItem item = new MenuItem("Show "+r.getName()+"("+r.itemKind()+")");
                showLinkMenu.add(item);
                item.addActionListener(this);
                relItems.addElement(item);
            } else {
                // ((MenuItem) relItems.elementAt(i)).setLabel("Show "+r.getName()+"("+r.itemKind()+")");
            }
            i++;
        }

        if(i >= relItems.size() && getcSpying() instanceof MVRelationship) {
            MenuItem item = new MenuItem("Show +parents");
            showLinkMenu.add(item);
            item.addActionListener(this);
            relItems.addElement(item);
            MenuItem item2 = new MenuItem("Show +children");
            showLinkMenu.add(item2);
            item2.addActionListener(this);
            relItems.addElement(item2);
        }
        
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == printSpyed) {
            System.out.println(getcSpying().toString());
        } else if(e.getSource() == inspectSpyed) {
            ((MVBaseLayer) view().getBaseLayer().getOneRelated("Visualiser",MVParents)).inspect(getcSpying());
        } else if(e.getSource() == allAttrs) {
            showAllAttributes();
        } else if(e.getSource() == propSheet) {
            getcSpying().showPropertySheet();
        } else if(e.getSource() == deleteComp) {
            getcSpying().delete();
            // delete();
        } else if(e.getSource() == undeleteComp) {
            getcSpying().undelete();
        } else if(e.getSource() == aspectInfo) {
            getcSpying().getAspects().showAspectInfo();
        } else if(e.getSource() == initComp) {
        	callInit();
        } else {

            int attrIndex = attrItems.indexOf(e.getSource());
            if(attrIndex > -1) {
                MVAttribute a = (MVAttribute) getcSpying().getAttributes().elementAt(attrIndex);
                showAttribute(a.getPropertyName());
            }
                
            int relIndex = relItems.indexOf(e.getSource());
            if(relIndex > -1) {
                MenuItem mitem = (MenuItem) relItems.elementAt(relIndex);
                if(mitem.getLabel().equals("Show +parents")) {
                    ((JCVisDiagram) view()).showLink(this,getcSpying(),"+parents","Child");
                } else if(mitem.getLabel().equals("Show +children")) {
                    ((JCVisDiagram) view()).showLink(this,getcSpying(),"+children","Parent");
                } else {
                    MVRelItem r = (MVRelItem) getcSpying().getRelationships().elementAt(relIndex);
                    String linkKind = "Child";
                    if(r.getKind() == MVOneToMany || r.getKind() == MVRelLinksParents)
                        linkKind = "Parent";
                    ((JCVisDiagram) view()).showLink(this,getcSpying(),r.getName(),linkKind);
                }
            }

        }

    }

    public void callInit()
    {
    	try {
			Class c = getcSpying().getClass();
        	Method m = c.getMethod("init",new Class[0]);
        	m.invoke(getcSpying(),new Object[0]);
       	} catch (Exception e) {
			System.err.println("callInit() exception: "+e);
       	}
    }

}

