package JCVisualise;

import JViews.*;
import bbw.*;
import jComposer.*;
import java.beans.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCVisEventGlueG extends MVOneToOneGlue {

    /* Constructors */

    public JCVisEventGlueG() {
        super();
    }

    /* Attributes */

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }

    public JCDirectedArc getJCDirectedArc() {
        return (JCDirectedArc) getBBWShape();
    }

    /* Relationships */

    /* Methods */

    public abstract String userName();

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCDirectedArc().setNameText(getNameText());
            }
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("nameText")) {
            setNameText(getJCDirectedArc().getNameText());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCDirectedArc().getNameText());
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        if(!getNameText().equals(""))
            getJCDirectedArc().setNameText(getNameText());
        else
            setNameText(getJCDirectedArc().getNameText());
    }

}

