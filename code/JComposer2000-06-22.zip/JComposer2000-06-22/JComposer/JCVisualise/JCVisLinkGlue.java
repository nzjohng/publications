package JCVisualise;

import JViews.*;
import bbw.*;


/* hand-written stuff */

public class JCVisLinkGlue extends JCVisLinkGlueG {

    public JCVisLinkGlue() {
        super();
    }

    public String userName() {
        if(hasParent())
            return getParent().userName()+"->"+getNameText();
        else
            return "->"+getNameText();
    }

    public MVBaseComp mapComponent(boolean do_map) {
        return null;
    }

    public void spyComponent(MVComponent c) {
        establishSpying(c);
        setNameText(Integer.toString(c.compID));
    }

    public void establishSpying(MVComponent c) {
        establishOneToMany("Spying",c);
        c.setListenAfterRel("Spying");
    }

    public MVComponent getcSpying() {
        return (MVComponent) getOneRelated("Spying",MVChildren);
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue) {
System.out.println("JCVisLinkGlue got "+c);
                String property = ((MVSetValue) c).getPropertyName();

                if(c.target == this && hasParent() && property.equals("nameText")) {
                    establishLink();
                }

                if(c.target == this && hasParent() && ( property.equals("childListenBefore") ||
                        property.equals("childListenAfter") || property.equals("parentListenBefore") ||
                        property.equals("parentListenAfter") ) )
                    setListeners();

            }

            return super.afterChange(c,from,rel_name);
        }

        public void establishLink() {
            MVComponent parent = getlinkParent();
            MVComponent child = getlinkChild();
            String rel_name = getlinkName();

            if(parent != null && child != null & !rel_name.equals("")) {
    System.out.println("Establishing link between "+parent.compID+" and "+child.compID+" named "+rel_name);

                if(parent instanceof MVRelationship) {
                    ((MVRelationship) parent).establish(null,child);
                } else if(child instanceof MVRelationship) {
                    ((MVRelationship) child).establish(parent,null);
                } else
                    parent.establishOneToMany(rel_name,child);
            }
        }

    public MVComponent getlinkParent() {
        MVComponent parent = null;

            if(getParent() instanceof JCVisLinkIcon) {
                // need to find parent of rel icon...           

            } else
                parent = getParent().getOneRelatedOrNull("Spying",MVChildren);

        return parent;
    }

    public MVComponent getlinkChild() {
        MVComponent child = null;

            if(getChild() instanceof JCVisLinkIcon) {
                // need to find child of rel icon...            

            } else
                child = getChild().getOneRelatedOrNull("Spying",MVChildren);

        return child;
    }

    public String getlinkName() {
        String rel_name = getNameText();

        if(getParent() instanceof JCVisLinkIcon)
            rel_name = ((JCVisLinkIcon) getParent()).getNameText();
        if(getChild() instanceof JCVisLinkIcon)
            rel_name = ((JCVisLinkIcon) getChild()).getNameText();

        return rel_name;
    }

    public void setListeners() {
        MVComponent parent = getlinkParent();
        MVComponent child = getlinkChild();
        String rel_name = getlinkName();

        if(parent != null && child != null & !rel_name.equals("")) {

            if(isChildListenBefore())
                child.setListenBeforeRel(rel_name);
            if(isChildListenAfter())
                child.setListenAfterRel(rel_name);
            if(isParentListenBefore())
                parent.setListenBeforeRel(rel_name);
            if(isParentListenAfter())
                parent.setListenAfterRel(rel_name);
        }
        
    }

}

