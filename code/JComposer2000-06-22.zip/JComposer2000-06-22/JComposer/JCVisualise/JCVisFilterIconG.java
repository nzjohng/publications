package JCVisualise;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import jComposer.*;

public abstract class JCVisFilterIconG extends MVIcon {

  public JCVisFilterIconG() {
    super();
    establishListeners();
  }

  public JCVisFilterIconG(MVViewLayer v) {
    super(v);
    establishListeners();
  }

  public String kindName() {
    return "Filter Icon";
  }

  public abstract String userName();

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }
    
    public String getParentName() {
        return getStringValue("parentName");
    }

    public void setParentName(String value) {
        setValue("parentName",value);
    }

    public boolean isGenerateCode() {
        return getBooleanValue("generateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("generateCode",value);
    }

  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }

  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }

  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }

  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
        setValue("width",value);
  }

  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
        setValue("height",value);
  }


    public JCFilter getJCFilter() {
        return (JCFilter) getBBWShape();
    }

  public void establishListeners() {
  }

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCFilter().setNameText(getNameText());
            } else if(name.equals("parentName")) {
                getJCFilter().setParentName(getParentName());
            } else if(name.equals("foreground")) {
                getJCFilter().setForeground(java_awt_Color_fromString(getForeground()));
            } else if(name.equals("background")) {
                getJCFilter().setBackground(java_awt_Color_fromString(getBackground()));
            } else if(name.equals("x")) {
                getJCFilter().setX(getX());
            } else if(name.equals("y")) {
                getJCFilter().setY(getY());
            } else if(name.equals("width")) {
                getJCFilter().setWidth(getWidth());
            } else if(name.equals("height")) {
                getJCFilter().setHeight(getHeight());
            } else if(name.equals("generateCode")) {
                getJCFilter().setGenerateCode(isGenerateCode());
            }
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("nameText")) {
            setNameText(getJCFilter().getNameText());
        }
        if(evt.getPropertyName().equals("parentName")) {
            setParentName(getJCFilter().getParentName());
        }
        if(evt.getPropertyName().equals("foreground")) {
            setForeground(java_awt_Color_toString(getJCFilter().getForeground()));
        }
        if(evt.getPropertyName().equals("background")) {
            setBackground(java_awt_Color_toString(getJCFilter().getBackground()));
        }
        if(evt.getPropertyName().equals("x")) {
            setX(getJCFilter().getX());
        }
        if(evt.getPropertyName().equals("y")) {
            setY(getJCFilter().getY());
        }
        if(evt.getPropertyName().equals("width")) {
            setWidth(getJCFilter().getWidth());
        }
        if(evt.getPropertyName().equals("height")) {
            setHeight(getJCFilter().getHeight());
        }
        if(evt.getPropertyName().equals("generateCode")) {
            setGenerateCode(getJCFilter().isGenerateCode());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCFilter().getNameText());
        setParentName(getJCFilter().getParentName());
        setForeground(java_awt_Color_toString(getJCFilter().getForeground()));
        setBackground(java_awt_Color_toString(getJCFilter().getBackground()));
        setX(getJCFilter().getX());
        setY(getJCFilter().getY());
        setWidth(getJCFilter().getWidth());
        setHeight(getJCFilter().getHeight());
        setGenerateCode(getJCFilter().isGenerateCode());
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        getJCFilter().setNameText(getNameText());
        if(getAttribute("parentName") != null)
            getJCFilter().setParentName(getParentName());
        else
            setParentName(getJCFilter().getParentName());
        if(getAttribute("foreground") != null)
            getJCFilter().setForeground(java_awt_Color_fromString(getForeground()));
        else
            setForeground(java_awt_Color_toString(getJCFilter().getForeground()));
        if(getAttribute("background") != null)
            getJCFilter().setBackground(java_awt_Color_fromString(getBackground()));
        else
            setBackground(java_awt_Color_toString(getJCFilter().getBackground()));
        if(getAttribute("x") != null)
            getJCFilter().setX(getX());
        else
            setX(getJCFilter().getX());
        if(getAttribute("y") != null)
            getJCFilter().setY(getY());
        else
            setY(getJCFilter().getY());
        if(getAttribute("width") != null)
            getJCFilter().setWidth(getWidth());
        else
            setWidth(getJCFilter().getWidth());
        if(getAttribute("height") != null)
            getJCFilter().setHeight(getHeight());
        else
            setHeight(getJCFilter().getHeight());
        if(getAttribute("generateCode") != null)
            getJCFilter().setGenerateCode(isGenerateCode());
        else
            setGenerateCode(getJCFilter().isGenerateCode());

    }

}

