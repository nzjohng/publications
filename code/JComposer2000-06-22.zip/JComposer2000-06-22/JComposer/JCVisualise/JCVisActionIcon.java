package JCVisualise;

import JViews.*;
import java.beans.*;
import java.awt.*;
import bbw.*;
import java.awt.event.*;

public class JCVisActionIcon extends JCVisActionIconG {

  public JCVisActionIcon() {
    super();
  }

    public JCVisActionIcon(MVViewLayer v) {
        super(v);
    }

    public String userName() {
        return getText();
    }

    public MVBaseComp mapComponent(boolean do_map) {
        return null;
    }

    public void spyComponent(MVComponent c) {
        establishSpying(c);
        setText(c.compKind()+" ("+c.compID+")");
        setParentName(c.compKind());
    }

    public void establishSpying(MVComponent c) {
        establishOneToMany("Spying",c);
        c.setListenAfterRel("Spying");
    }

    public MVComponent getcSpying() {
        return (MVComponent) getOneRelatedOrNull("Spying",MVChildren);
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue) {
System.out.println("JCVisActionIcon got "+c);

                if(c.target == this && ((MVSetValue) c).getPropertyName().equals("parentName") && 
                        !getParentName().equals("") && getcSpying() == null) {
System.out.println("creating action instance...");

                    try {
                        Class pclass = Class.forName(getParentName());
                        MVComponent new_comp = (MVComponent) pclass.newInstance();
                        if(new_comp instanceof MVListener) {
                            ((MVListener) new_comp).init(view().getBaseLayer());
                            spyComponent(new_comp);
                        } else {
                            System.out.println("*** "+getParentName()+" not an action component!!");
                            setText("");
                        }
                    } catch(ClassNotFoundException e) {
                        System.out.println("*** No such class "+getParentName());
                    } catch(IllegalAccessException e) {
                        System.out.println("*** Class "+getParentName()+" can't have instances!");
                    } catch(Exception e) {
                        System.out.println("*** Couldn't create instance of class "+getParentName()+": "+e);
                    }
                }


            }

            return super.afterChange(c,from,rel_name);
        }

    // need pop-up so can access spyed action component's attributes...

    protected MenuItem printSpyed = new MenuItem("Print Component");
    protected MenuItem inspectSpyed = new MenuItem("Inspect Component");
    protected MenuItem propSheet = new MenuItem("Show Comp Property Sheet");
    protected MenuItem deleteComp = new MenuItem("Delete Comp");
    protected MenuItem undeleteComp = new MenuItem("Undelete Comp");

    public void addJViewsPopups(BBWComponent shape) {
        shape.addPopupMenuItem(printSpyed);
        printSpyed.addActionListener(this);
        shape.addPopupMenuItem(inspectSpyed);
        inspectSpyed.addActionListener(this);
        shape.addPopupMenuItem(deleteComp);
        deleteComp.addActionListener(this);
        shape.addPopupMenuItem(undeleteComp);
        undeleteComp.addActionListener(this);
        shape.addPopupMenuItem(propSheet);
        propSheet.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == printSpyed) {
            System.out.println(getcSpying().toString());
        } else if(e.getSource() == inspectSpyed) {
            ((MVBaseLayer) view().getBaseLayer().getOneRelated("Visualiser",MVParents)).inspect(getcSpying());
        } else if(e.getSource() == propSheet) {
            getcSpying().showPropertySheet();
        } else if(e.getSource() == deleteComp) {
            getcSpying().delete();
            // delete();
        } else if(e.getSource() == undeleteComp) {
            getcSpying().undelete();
        }

    }

}

