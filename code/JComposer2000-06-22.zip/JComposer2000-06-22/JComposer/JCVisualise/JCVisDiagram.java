package JCVisualise;

import JViews.*;
import bbw.*;
import bbw.shape.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.beans.*;
import jComposer.*;

public class JCVisDiagram extends MVViewLayer implements BBWTransactionListener, JCListener, PropertyChangeListener {

  public JCVisDiagram(MVBaseLayer base_layer, String name) {
    super(base_layer,name);
    setSpying(true);
  }

  public JCVisDiagram() {
    super();
  }
  
  public void createFrame() {
    frame = new JCVisFrame(this);
/*    MVViewCollabMenu collab = (MVViewCollabMenu) getOneRelatedOrNull("view",MVParents);
        if(collab == null) {
            collab = new MVViewCollabMenu();
        collab.establishOneToMany("view",this);
        }
        collab.addedView(this); */
  }
  
  public void transaction(BBWTransactionEvent evt) {
    if (spying)
      System.out.println(evt);
        super.transaction(evt);
    }

    public void processBBWEvent(EventObject evt) {
System.out.println("JCVisDiagram.processBBWEvent got "+evt);
        if(inBBWTransaction() && !processingBBWEvents) {
            super.processBBWEvent(evt);
            return;
        }

        boolean oldChange = startBBWChange();

        if(evt instanceof JCChangeEvent) {
            JCChangeEvent jcevt = (JCChangeEvent) evt;

System.out.println("got special event "+jcevt);

     if (jcevt instanceof JCNewComponentEvent) {
                 startMacroChange(new MVMacroChangeDescr(this,"Add Component"));
         JCVisCompIcon new_comp = new JCVisCompIcon();
         new_comp.addedBBWShape(((JCNewComponentEvent) jcevt).getComponent());
                 new_comp.init(this);
                 ((JCNewComponentEvent) jcevt).getComponent().showPropertySheet();
// new_comp.setNameText("EntityIcon");
// new_comp.setBbwShapeText("erTool.EREntity");
// new_comp.setBbwShapeText("");
// new_comp.setBbwShapeText("erTool.EREntity");
                 endMacroChange();
        }
            if(jcevt instanceof JCNewRelnEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Relationship"));
              JCVisLinkIcon new_comp = new JCVisLinkIcon();
              new_comp.addedBBWShape(((JCNewRelnEvent) jcevt).getRelnShape());
              new_comp.init(this);
                ((JCNewRelnEvent) jcevt).getRelnShape().showPropertySheet();
// new_comp.setNameText("BaseEntities");
              endMacroChange();
          }
          if(jcevt instanceof JCNewArrowArityEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Link"));
              JCVisLinkGlue new_comp = new JCVisLinkGlue();
              new_comp.addedBBWShape(((JCNewArrowArityEvent) jcevt).getArrowArity());
                MVViewComp p = findBBWViewComp(((JCNewArrowArityEvent) jcevt).getArrowArity().getFrom().getOwner());
                MVViewComp c = findBBWViewComp(((JCNewArrowArityEvent) jcevt).getArrowArity().getTo().getOwner());
              new_comp.init(this,p,c);
                new_comp.establishLink();
                ((JCNewArrowArityEvent) jcevt).getArrowArity().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewDirectedArcEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Event Flow"));
              JCVisEventGlue new_comp = new JCVisEventGlue();
              new_comp.addedBBWShape(((JCNewDirectedArcEvent) jcevt).getDirectedArc());
                MVViewComp p = findBBWViewComp(((JCNewDirectedArcEvent) jcevt).getDirectedArc().getFrom().getOwner());
                MVViewComp c = findBBWViewComp(((JCNewDirectedArcEvent) jcevt).getDirectedArc().getTo().getOwner());
              new_comp.init(this,p,c);
              new_comp.establishLink();
                ((JCNewDirectedArcEvent) jcevt).getDirectedArc().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewElementEvent) {
System.out.println("Adding new element to component...");
              startMacroChange(new MVMacroChangeDescr(this,"Add Element"));
/*
              JCVisAttrIcon new_comp = new JCVisAttrIcon();
                ((TextFieldShape) ((JCNewElementEvent) jcevt).getElement()).setFont(new Font("Helvetica",0,8));
              new_comp.addedBBWShape(((JCNewElementEvent) jcevt).getElement());
              new_comp.init(this);
*/
                MVViewComp comp_icon = findBBWViewComp((BBWComponent) ((JCNewElementEvent) jcevt).getSource());
System.out.println("adding new element to "+comp_icon.userName());
                ((JCVisCompIcon) comp_icon).addElement(((TextFieldShape) ((JCNewElementEvent) jcevt).getElement()).getText());
/*
                new_comp.setOwner(comp_icon);
*/
              endMacroChange();
          }
          if(jcevt instanceof JCNewRelnShadedEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Action"));
              JCVisActionIcon new_comp = new JCVisActionIcon();
              new_comp.addedBBWShape(((JCNewRelnShadedEvent) jcevt).getRelnShadedShape());
              new_comp.init(this);
                ((JCNewRelnShadedEvent) jcevt).getRelnShadedShape().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewFilterEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Filter"));
              JCVisFilterIcon new_comp = new JCVisFilterIcon();
              new_comp.addedBBWShape(((JCNewFilterEvent) jcevt).getFilter());
              new_comp.init(this);
              endMacroChange();
          }
          
        }

        if(!oldChange)
            endBBWChange();
    
  }

  public void propertyChange(PropertyChangeEvent evt) {
    if (spying)
      System.out.println(evt);
        super.propertyChange(evt);
    }

  public void jcChange(JCChangeEvent evt) {
    if (spying)
      System.out.println("JCVisDiagram.jcChange got "+evt);
      
      if(!processingJViewsChange)
                processBBWEvent(evt);
    }
   
   public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {
     

   
     return super.afterChange(c,from,rel_name);
   }

    /*
     * Visualisation stuff...
     *
     */

    public void showLink(JCVisCompIcon vis_comp, MVComponent comp, String rel_name,
        String linkKind) {

        // see if link already shown...

        Enumeration e = vis_comp.getRelationship(linkKind,MVParents).elements();
        while(e.hasMoreElements()) {
            // if already shown in view, return
            JCVisLinkGlue g = (JCVisLinkGlue) e.nextElement();
            if(g.getNameText() == rel_name)
                return;
        }

        // expand link

        JCVisLinkIcon linkIcon = new JCVisLinkIcon();
        JCVisLinkGlue linkGlue = new JCVisLinkGlue();
        if(linkKind.equals("Parent")) {
            linkGlue.addParent(vis_comp);
            linkGlue.addChild(linkIcon);
        } else {
            linkGlue.addChild(vis_comp);
            linkGlue.addParent(linkIcon);
        }
        linkIcon.init(this);
        linkGlue.init(this);

        linkIcon.setNameText(rel_name);
        linkIcon.setX(vis_comp.getX()+100);
        linkIcon.setY(vis_comp.getY()+100);
        linkGlue.setNameText("");

        linkIcon.establishSpying(comp);
        if(linkKind.equals("Parent"))
            linkIcon.setLinkKind(MVChildren);
        else
            linkIcon.setLinkKind(MVParents);

        // see what comp is linked to by this relationship...

        Vector lcomps;

        if(linkKind.equals("Parent"))
            lcomps = comp.getRelationship(rel_name,MVChildren);
        else
            lcomps = comp.getRelationship(rel_name,MVParents);

        // could see if we can link to already visualised comps in view??

        
        // auto-expand/link comp if one->one rel??

        if(lcomps.size() == 1)
            showLinkedComp(linkIcon,(MVComponent) lcomps.firstElement());
    }

    public void showLinkedComp(JCVisLinkIcon linkIcon, MVComponent comp) {
        MVViewComp vc = findVisualisedComp((MVComponent) comp);
            // is linked comp already in view???
            // if so, link straight to existing icon
        if(vc == null) {
            // create new vis icon for linked comp
            vc = createVisualisedComp(comp,
                linkIcon.getX()+100,linkIcon.getY()+100);
        }

        String linkKind;

        if(linkIcon.getLinkKind() == MVChildren)
            linkKind = "Parent";
        else
            linkKind = "Child";

        JCVisLinkGlue linkGlue2 = new JCVisLinkGlue();
        if(linkKind.equals("Parent")) {
            linkGlue2.addParent(linkIcon);
            linkGlue2.addChild(vc);
        } else {
            linkGlue2.addChild(linkIcon);
            linkGlue2.addParent(vc);
        }
        linkGlue2.init(this);
        linkGlue2.setNameText("");

        if(linkIcon.getLinkKind() == MVParents) {
            // change linkIcon to watch the PARENT of the link, not child...
            linkIcon.setLinkKind(MVChildren);
            linkIcon.establishSpying(comp);
        }

    }

    public MVViewComp findVisualisedComp(MVComponent comp) {
        Enumeration e = components();

        while(e.hasMoreElements()) {
            MVViewComp vc = (MVViewComp) e.nextElement();
            if(vc instanceof JCVisCompIcon && vc.getOneRelatedOrNull("Spying",MVChildren) == comp)
                return vc;
        }

        return null;
    }

    public MVViewComp createVisualisedComp(MVComponent comp,int x, int y) {
        // if comp is filter/action, use filter/action icons...???

        JCVisCompIcon newc = new JCVisCompIcon();
        newc.init(this);
        newc.spyComponent(comp);
        newc.setX(x);
        newc.setY(y);

        return newc;
    }
   
}

class JCVisFrame extends MVViewFrame implements ActionListener {

  public JCVisFrame(MVViewLayer view) {
    super(view);
  setLayout(new BorderLayout());
  add("Center", panel);
  add("North",spyingCheckbox);
  panel.addTransactionListener(view);
  panel.addJCChangeListener((JCVisDiagram) view);
  setSize(500,500);
  }

    protected MenuItem generate;
  
    public void addFrameMenus() {
        super.addFrameMenus();
        Menu compilationMenu = new Menu("Compilation");
        generate = new MenuItem("Generate Classes");
        compilationMenu.add(generate);
        generate.addActionListener(this);
        menuBar.add(compilationMenu);
    }

  public void actionPerformed(ActionEvent e) {
      if(e.getSource() == newView) {
        JCVisDiagram jc_view = new JCVisDiagram((JCVisBaseLayer)view.getBaseLayer(),"Diagram3");
        jc_view.show(); // show view's frame...
      } else
                super.actionPerformed(e);
    }

   public void addedViewComp(MVViewComp c) {
     // create BBW shapes when JViews icon/glue added...
     
     if(c instanceof JCVisCompIcon) {
        JCComponent new_comp = panel.newComponent(100,100,60,40);
       ((JCVisCompIcon) c).addedViewComp(new_comp);
     }
         if(c instanceof JCVisLinkIcon) {
            JCRelnShape new_comp = panel.newReln(100,100,60,40);
      ((JCVisLinkIcon) c).addedViewComp(new_comp);
         }
         if(c instanceof JCVisLinkGlue) {
            JCArrowArity new_comp = panel.newArrowArity(((JCVisLinkGlue) c).getBBWParent(),((JCVisLinkGlue) c).getBBWChild());
            ((JCVisLinkGlue) c).addedViewComp(new_comp);
         }
/*
        if(c.comp instanceof JCVisAttrIcon) {
            JCComponent comp = (JCComponent) ((JCVisAttrIcon) c.comp).getBBWParent();
            comp.addElement();
            Vector fields = comp.getFields();
            TextFieldShape field = (TextFieldShape) fields.lastElement();
            ((JCVisAttrIcon) c.comp).addedViewComp(field);
        }
*/
        if(c instanceof JCVisActionIcon) {
            JCRelnShadedShape new_action = panel.newRelnShaded(100,100,60,40);
            ((JCVisActionIcon) c).addedViewComp(new_action);
        }
        if(c instanceof JCVisFilterIcon) {
            JCFilter new_filter = panel.newFilter(100,100,60,40);
            ((JCVisFilterIcon) c).addedViewComp(new_filter);
        }
        if(c instanceof JCVisEventGlue) {
            JCDirectedArc new_comp = panel.newDirectedArc(((JCVisEventGlue) c).getBBWParent(),((JCVisEventGlue) c).getBBWChild());
            ((JCVisEventGlue) c).addedViewComp(new_comp);
        }
   }

        private JComposerPanel panel = new JComposerPanel();
  private Checkbox spyingCheckbox = new Checkbox("spy");
  private static int frameCount = 1;
  }

