package JComp;

import JViews.*;

public class JCAspectIconToBase extends JCAspectIconToBaseG {

  public JCAspectIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

