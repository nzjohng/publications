package JComp;

import JViews.*;
import bbw.*;

import java.util.*;

public abstract class JCCompIconToBaseG extends MVViewRel {

  public JCCompIconToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Comp Icon To Base Mapping";
  }
  
  public String getViewRelKind() {
    return "JCCompIconToBase";
  }

  public abstract String userName();

  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {


    if(c instanceof MVSetValue) {
      String name = ((MVSetValue) c).getPropertyName();
      if(isParent(c.target) && name.equals("Name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setNameText(((JCBaseComp)c.target).getName());
        }
      }
            else if(isChild(c.target) && name.equals("nameText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setName(((JCCompIcon)c.target).getNameText());
        }
      }
      
      if(isParent(c.target) && name.equals("prefix")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setPrefix(((JCBaseComp)c.target).getPrefix());
        }
      }
            else if(isChild(c.target) && name.equals("prefix")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setPrefix(((JCCompIcon)c.target).getPrefix());
        }
      }
            
            if(isParent(c.target) && name.equals("ShapeName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setBbwShapeText(((JCBaseComp)c.target).getShapeName());
        }
            }
            else if(isChild(c.target) && name.equals("bbwShapeText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setShapeName(((JCCompIcon)c.target).getBbwShapeText());
        }
            }

            if(isParent(c.target) && name.equals("ParentName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setParentText(((JCBaseComp)c.target).getParentName());
        }
            }
            else if(isChild(c.target) && name.equals("parentText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setParentName(((JCCompIcon)c.target).getParentText());
        }
            }

            if(isParent(c.target) && name.equals("KindName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setKindText(((JCBaseComp)c.target).getKindName());
        }
            }
            else if(isChild(c.target) && name.equals("kindText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setKindName(((JCCompIcon)c.target).getKindText());
        }
            }

            if(isParent(c.target) && name.equals("GenerateCode")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCCompIcon)e.nextElement()).setGenerateCode(((JCBaseComp)c.target).isGenerateCode());
        }
            }
            else if(isChild(c.target) && name.equals("generateCode")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setGenerateCode(((JCCompIcon)c.target).isGenerateCode());
        }
            }

        }
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
System.out.println("upliftAttributes!!");
        ((JCCompIcon) vc).setNameText(((JCBaseComp) bc).getName());
        ((JCCompIcon) vc).setBbwShapeText(((JCBaseComp) bc).getShapeName());
        ((JCCompIcon) vc).setParentText(((JCBaseComp) bc).getParentName());
        ((JCCompIcon) vc).setKindText(((JCBaseComp) bc).getKindName());
        ((JCCompIcon) vc).setGenerateCode(((JCBaseComp) bc).isGenerateCode());
        ((JCCompIcon) vc).setPrefix(((JCBaseComp) bc).getPrefix());
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseComp) bc).setName(((JCCompIcon) vc).getNameText());
        ((JCBaseComp) bc).setShapeName(((JCCompIcon) vc).getBbwShapeText());
        ((JCBaseComp) bc).setParentName(((JCCompIcon) vc).getParentText());
        ((JCBaseComp) bc).setKindName(((JCCompIcon) vc).getKindText());
        ((JCBaseComp) bc).setGenerateCode(((JCCompIcon) vc).isGenerateCode());
        ((JCBaseComp) bc).setPrefix(((JCCompIcon) vc).getPrefix());
    }

}

