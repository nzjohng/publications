package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseEventG extends MVBaseComp {

    /* Constructors */

    public JCBaseEventG() {
        super();
    }

    public JCBaseEventG(MVBaseLayer base_layer) {
        super(base_layer);

        setValue("Name",MVStringBlank);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    /* Relationships */

    public JCBaseComp getpEventParent() {
        return (JCBaseComp)getOneRelated("EventParent",MVParents);
    }

    public JCBaseComp getpEventChild() {
        return (JCBaseComp)getOneRelated("EventChild",MVParents);
    }

    /* Methods */

    public abstract String userName();

    public String kindName() {
        return "Base Event";
    }

    /* Read/write methods */

}

