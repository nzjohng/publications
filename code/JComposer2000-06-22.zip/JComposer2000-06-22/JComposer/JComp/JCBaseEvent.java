package JComp;

import JViews.*;
import bbw.*;


/*
 * hand-written code for Base Events
 *
 */

public class JCBaseEvent extends JCBaseEventG {

    public JCBaseEvent() {
        super();
    }

    public JCBaseEvent(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        return getStringValue("Name");
    }


}

