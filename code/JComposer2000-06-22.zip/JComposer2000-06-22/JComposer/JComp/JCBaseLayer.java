package JComp;

import JViews.*;
import bbw.*;


import java.util.*;
import java.io.*;

/*
 * hand-written bits for JComposer
 *
 * Base view
 *
 */

public class JCBaseLayer extends JCBaseLayerG {

    public JCBaseLayer() {
        super();
    }

    public JCBaseLayer(String name) {
        super(name);
    }

    public JCBaseComp findBaseComp(String name) {
        return (JCBaseComp) getcrBaseComps().get(name);
    }

    public JCBaseClass findBaseClass(String name) {
        JCBaseClass c = (JCBaseClass) getcrBaseClasses().get(name);
        if(c != null)
            return c;
        else
            return findBaseComp(name);
    }

    public String userName() {
        return getName();
    }

    public void initMVClasses() {
        // create the MViews framework class definitions
        // this should be loaded from a project file (eventually... :-)
        //

// ******
//
// Need to change this to a FULL component modelling of the JViews
// architecture i.e. model all below "classes" as "components",
// and specify all their links, rels, attributes, methods etc.
//
// Probably best to do this via JComposer itself when its going
// fully. Then when generalise a comp, copy down all inherited 
// data when used and DON'T regenerate inherited stuff.
//
// ******

        JCBaseClass baseComp = new JCBaseClass(this);
        baseComp.setName("MVBaseComp");
        establishBaseClasses(baseComp);

            JCBaseMethod baseCompc1 = new JCBaseMethod(this);
            baseCompc1.setName(baseComp.getName()); // constructor
            baseCompc1.addArg("base_layer","MVBaseLayer");
            baseComp.establishClassMethods(baseCompc1);

        JCBaseClass hashtableRel = new JCBaseClass(this);
        hashtableRel.setName("MVHashtableRel");
        establishBaseClasses(hashtableRel);

        JCBaseClass baseLayer = new JCBaseClass(this);
        baseLayer.setName("MVBaseLayer");
        establishBaseClasses(baseLayer);

        JCBaseClass viewLayer = new JCBaseClass(this);
        viewLayer.setName("MVViewLayer");
        establishBaseClasses(viewLayer);

        JCBaseClass graphicIcon = new JCBaseClass(this);
        graphicIcon.setName("MVIcon");
        establishBaseClasses(graphicIcon);

        JCBaseClass oneToOneGlue = new JCBaseClass(this);
        oneToOneGlue.setName("MVOneToOneGlue");
        establishBaseClasses(oneToOneGlue);

        JCBaseClass viewRel = new JCBaseClass(this);
        viewRel.setName("MVViewRel");
        establishBaseClasses(viewRel);

        // and so on...
    }

    public void initialise() {

        initMVClasses();
/*
    JCBaseComp entity = new JCBaseComp();
        entity.init(this);
        entity.setName("BaseEntity");
        entity.setParentName("MVBaseComp");
        entity.setKindName("Base Entity");
        entity.setGenerateCode(true);
        establishBaseComps(entity);
        entity.addAttribute("EntityName","String");

inspect(this);
*/
    // create graphical diagrammer view & entity icon...
    JCDiagram jc_view = new JCDiagram(this,nextViewName());
    jc_view.show(); // show view's frame...
    
    //jc_view.startMacroChange(new MVMacroChangeDescr(jc_view,"Add Comp"));
      // could put this into its own macro class & recordUpdate() it...
    //CompIcon comp_icon = new JCCompIcon();
    //  comp_icon.init(jc_view);
    //  comp_icon.mapToBase(entity);

    //jc_view.endMacroChange();

/*

JCBaseComp test_del = new JCBaseComp();
test_del.init(this);
test_del.setName("Test Delete");
establishBaseComps(test_del);

test_del.establishOneToMany("Rel1",entity);
entity.establishOneToMany("Rel2",test_del);

MVVectorRel r1 = new MVVectorRel();
r1.establish(entity,test_del);

MVVectorRel r2 = new MVVectorRel();
r2.establish(test_del,entity);

test_del.delete();
test_del.undelete();

System.out.println(test_del);
System.out.println(entity);
System.out.println(getcrBaseComps());
System.out.println(getCompsRel());
System.out.println(r1);
System.out.println(r2);
System.out.println(test_del.getVersionRecord());

*/



    }

    public void generateClasses(String path) {
        // generate .java files for all component classes defined...
        //
        // should we check syntactic/semantic consistency here, or
        // do this as we go...??

System.out.println("Generating class...");

        Enumeration e = getcrBaseComps().children();
        
        while(e.hasMoreElements()) {
            JCBaseComp c = (JCBaseComp)e.nextElement();
            c.generateClass(path);
        }
System.out.println("done!");
    }
    
/*
    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel) {

        if(c instanceof MVAddComponent) {
            if(((MVAddComponent) c).getComponent() instanceof JCBaseComp)
                establishBaseComps((JCBaseComp) ((MVAddComponent) c).getComponent());
        }
    
        return super.afterChange(c,from,rel);
    }

*/

    public String [] getEditableProperties() {
        String ss[] = {"name","prefix","package"};

        return ss;
    }

}

