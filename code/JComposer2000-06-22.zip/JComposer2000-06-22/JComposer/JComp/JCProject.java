package JComp;

import JViews.*;
import bbw.*;


public class JCProject extends MVProject {

  public JCProject(String name) {
    super(name);
  }

  public MVBaseLayer newBaseLayer() {
    return new JCBaseLayer("base #1");
  }
}

