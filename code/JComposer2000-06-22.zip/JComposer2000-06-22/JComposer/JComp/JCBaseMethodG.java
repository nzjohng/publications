package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseMethodG extends MVBaseComp {

    /* Constructors */

    public JCBaseMethodG() {
        super();
    }

    public JCBaseMethodG(JCBaseLayer base_layer) {
        super(base_layer);

        setName(MVStringBlank);
        setType(MVStringBlank);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    public String getType() {
    return getStringValue("Type");
    }

    public void setType(String value) {
        setValue("Type",value);
    }

    /* Relationships */

    public JCBaseClass getpClassMethods() {
        return (JCBaseClass)getOneRelated("ClassMethods",MVParents);
    }

    public Vector getcMethodArgs() {
        return getRelationship("MethodArgs",MVChildren);
    }

    public void establishMethodArgs(JCBaseArg comp) {
        establishOneToMany("MethodArgs",comp);
    }

    /* Methods */

    public String kindName() {
        return "Base Method";
    }

    public abstract String userName();

    /* Read/write methods */

}

