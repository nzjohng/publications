package JComp;

import JViews.*;
import bbw.*;


/* 
 * User-written code for JCBaseComps relationship
 *
 */

public class JCBaseClasses extends JCBaseClassesG {

    public JCBaseClasses() {
        super();
    }

    public JCBaseClasses(String rel_name, MVComponent parent_comp) {
        super(rel_name,parent_comp);
    }

    public String userName() {
        return "Base Classes";
    }

}
