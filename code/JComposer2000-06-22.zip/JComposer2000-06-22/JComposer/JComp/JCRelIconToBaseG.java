package JComp;

import JViews.*;
import bbw.*;
import java.util.*;

public abstract class JCRelIconToBaseG extends MVViewRel {

  public JCRelIconToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Rel Icon To Base Mapping";
  }

  public abstract String userName();


  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();

      if(isParent(c.target) && name.equals("Name")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCRelIcon)e.nextElement()).setNameText(((JCBaseRel)c.target).getName());
        }
      } else if(isChild(c.target) && name.equals("nameText")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseRel)e.nextElement()).setName(((JCRelIcon)c.target).getNameText());
        }
      }

            if(isParent(c.target) && name.equals("KindName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCRelIcon)e.nextElement()).setKindText(((JCBaseComp)c.target).getKindName());
        }
            }
            else if(isChild(c.target) && name.equals("kindText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setKindName(((JCRelIcon)c.target).getKindText());
        }
            }

            if(isParent(c.target) && name.equals("ParentName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCRelIcon)e.nextElement()).setParentText(((JCBaseComp)c.target).getParentName());
        }
            }
            else if(isChild(c.target) && name.equals("parentText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setParentName(((JCRelIcon)c.target).getParentText());
        }
            }

            if(isParent(c.target) && name.equals("GenerateCode")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCRelIcon)e.nextElement()).setGenerateCode(((JCBaseComp)c.target).isGenerateCode());
        }
            }
            else if(isChild(c.target) && name.equals("generateCode")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseComp)e.nextElement()).setGenerateCode(((JCRelIcon)c.target).isGenerateCode());
        }
            }

        if(isParent(c.target) && name.equals("aggregate")) {
            Enumeration e = children();
            while(e.hasMoreElements()) {
                ((JCRelIcon) e.nextElement()).setAggregate(((JCBaseRel) c.target).isAggregate());
            }
        } else if(isChild(c.target) && name.equals("aggregate")) {
            Enumeration e = parents();
            while(e.hasMoreElements()) {
                ((JCBaseRel) e.nextElement()).setAggregate(((JCRelIcon) c.target).isAggregate());
            }
        
        }


     }
        
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCRelIcon) vc).setNameText(((JCBaseRel) bc).getName());
        ((JCRelIcon) vc).setKindText(((JCBaseRel) bc).getKindName());
        ((JCRelIcon) vc).setParentText(((JCBaseRel) bc).getParentName());
        ((JCRelIcon) vc).setAggregate(((JCBaseRel) bc).isAggregate());
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseRel) bc).setName(((JCRelIcon) vc).getNameText());
        ((JCBaseRel) bc).setParentName(((JCRelIcon) vc).getParentText());
        ((JCBaseRel) bc).setKindName(((JCRelIcon) vc).getKindText());
        ((JCBaseRel) bc).setAggregate(((JCRelIcon) vc).isAggregate());
    }

}

