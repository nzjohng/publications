package JComp;
import JViews.*;
import java.util.*;

public abstract class JCAspectIconToBaseG extends MVViewRel
 {

  public JCAspectIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("aspectName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAspectInfoIcon)e.nextElement()).setAspectName(((JCBaseAspectInfo)c.target).getAspectName());
        }
      }
            else if(isChild(c.target) && name.equals("aspectName")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseAspectInfo)e.nextElement()).setAspectName(((JCAspectInfoIcon)c.target).getAspectName());
        }
      }
      if(isParent(c.target) && name.equals("aspectType")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAspectInfoIcon)e.nextElement()).setAspectType(((JCBaseAspectInfo)c.target).getAspectType());
        }
      }
            else if(isChild(c.target) && name.equals("aspectType")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseAspectInfo)e.nextElement()).setAspectType(((JCAspectInfoIcon)c.target).getAspectType());
        }
      }
      if(isParent(c.target) && name.equals("jviewsClass")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAspectInfoIcon)e.nextElement()).setJviewsClass(((JCBaseAspectInfo)c.target).getJviewsClass());
        }
      }
            else if(isChild(c.target) && name.equals("jviewsClass")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseAspectInfo)e.nextElement()).setJviewsClass(((JCAspectInfoIcon)c.target).getJviewsClass());
        }
      }
      if(isParent(c.target) && name.equals("designLevel")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAspectInfoIcon)e.nextElement()).setDesignLevel(((JCBaseAspectInfo)c.target).isDesignLevel());
        }
      }
            else if(isChild(c.target) && name.equals("designLevel")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseAspectInfo)e.nextElement()).setDesignLevel(((JCAspectInfoIcon)c.target).isDesignLevel());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "JCAspectIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((JCAspectInfoIcon)vc).setAspectName(((JCBaseAspectInfo)bc).getAspectName());
  ((JCAspectInfoIcon)vc).setAspectType(((JCBaseAspectInfo)bc).getAspectType());
  ((JCAspectInfoIcon)vc).setJviewsClass(((JCBaseAspectInfo)bc).getJviewsClass());
  ((JCAspectInfoIcon)vc).setDesignLevel(((JCBaseAspectInfo)bc).isDesignLevel());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((JCBaseAspectInfo)bc).setAspectName(((JCAspectInfoIcon)vc).getAspectName());
  ((JCBaseAspectInfo)bc).setAspectType(((JCAspectInfoIcon)vc).getAspectType());
  ((JCBaseAspectInfo)bc).setJviewsClass(((JCAspectInfoIcon)vc).getJviewsClass());
  ((JCBaseAspectInfo)bc).setDesignLevel(((JCAspectInfoIcon)vc).isDesignLevel());
  }

  public MVViewRel newViewRel() {
    return new JCAspectIconToBase();
  }

  public String getViewRelKind() {
    return "JCAspectIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

