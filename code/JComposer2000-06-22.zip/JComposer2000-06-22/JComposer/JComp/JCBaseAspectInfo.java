package JComp;

import JViews.*;
import java.util.*;

public class JCBaseAspectInfo extends JCBaseAspectInfoG {

  public JCBaseAspectInfo() {
    super();
  }


  public String userName() {
    return "Base Aspect Info";
  }
  
  public JCBaseAspectDetail findDetailName(String name)
  {
    Enumeration e = getcAspectDetails().elements();
    while(e.hasMoreElements()) {
        JCBaseAspectDetail ba = (JCBaseAspectDetail) e.nextElement();
        if(ba.getName().equals(name))
            return ba;
    }
    
    return null;
  }
  
  public MVVersionRecord newVersionRecord()
  {
    MVVersionRecord versionRecord = super.newVersionRecord();
    versionRecord.setSaveChanges(true);
    
    return versionRecord;
  }
  
  public JCBaseAspectDetail addAspectDetail(String name, String type, boolean provides)
  {
    JCBaseAspectDetail ba = new JCBaseAspectDetail(name,type,provides);
    establishAspectDetails(ba);
    ba.setListenAfterRel("aspectDetails");
    
    return ba;
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
  {
  
    if(c.getTarget() == this || c.getTarget() instanceof JCBaseAspectDetail) {
        if(getpAspectInfo() != null)
            getpAspectInfo().storeChange(c);
        storeChange(c);
    }
    
    return super.afterChange(c,from,rel);
  }

    public JCBaseComp getpAspectInfo() {
        return (JCBaseComp) getOneRelatedOrNull("AspectInfo",MVParents);
    }
    
    public void manageDetails()
    {
        // allows user to manage aspect details via a dialogue
    }

}

