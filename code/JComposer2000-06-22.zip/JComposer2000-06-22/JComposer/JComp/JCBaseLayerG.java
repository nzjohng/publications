package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated base layer class
 *
 */

public abstract class JCBaseLayerG extends MVBaseLayer {

    /* Constructors */

    public JCBaseLayerG() {
        super();
    }

  public JCBaseLayerG(String name) {
    super(name);

        /* initialise attributes */

        /* initialise relationships */

        JCBaseComps base_comps = new JCBaseComps("BaseComps",this);
        JCBaseClasses base_classes = new JCBaseClasses("BaseClasses",this);

        setAggregateRel("BaseClasses");
  }

    /* Attributes */

    public String getPrefix() {
    return getStringValue("prefix");
    }

    public void setPrefix(String value) {
        setValue("prefix",value);
    }
    
    public void setPackage(String value)
    {
        setValue("package",value);
    }
    
    public String getPackage()
    {
        return getStringValue("package");
    }

    /* Relationships */

    public JCBaseComps getcrBaseComps() {
        return (JCBaseComps) getOneRelated("BaseComps",MVChildRelComps);
    }

    public void establishBaseComps(JCBaseComp comp) {
        getcrBaseComps().establish(this,comp);
    }

    public void dissolveBaseComps(JCBaseComp comp) {
        getcrBaseComps().dissolve(this,comp);
    }

    /* can we generate a "findBaseComp" from JComposer?? */

    public JCBaseClasses getcrBaseClasses() {
        return (JCBaseClasses) getOneRelated("BaseClasses",MVChildRelComps);
    }

    public void establishBaseClasses(JCBaseClass comp) {
        getcrBaseClasses().establish(this,comp);
    }

    public void dissolveBaseClasses(JCBaseClasses comp) {
        getcrBaseClasses().dissolve(this,comp);
    }

    /* Methods */

    public String kindName() {
        return "JComposer Base Layer";
    }

    public abstract String userName();

    /* Read/write methods */

}

