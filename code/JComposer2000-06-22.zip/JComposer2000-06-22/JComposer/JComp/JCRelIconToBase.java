package JComp;

import JViews.*;
import bbw.*;

public class JCRelIconToBase extends JCRelIconToBaseG {

  public JCRelIconToBase() {
    super();
  }

    public String userName() {
        return "";
    }

}

