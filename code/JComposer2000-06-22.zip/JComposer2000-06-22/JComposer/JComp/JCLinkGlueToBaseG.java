package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

public abstract class JCLinkGlueToBaseG extends MVViewRel {

  public JCLinkGlueToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Link Glue To Base Mapping";
  }

  public abstract String userName();

  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue) c).getPropertyName();
      if(isParent(c.target) && name.equals("Name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCLinkGlue)e.nextElement()).setNameText(((JCBaseLink)c.target).getName());
        }
      }
            else if(isChild(c.target) && name.equals("nameText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseLink)e.nextElement()).setName(((JCLinkGlue)c.target).getNameText());
        }
      }

      if(isParent(c.target) && name.equals("ParentArity")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCLinkGlue)e.nextElement()).setChoiceFrom(((JCBaseLink)c.target).getParentArity());
        }
      }
            else if(isChild(c.target) && name.equals("choiceFrom")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseLink)e.nextElement()).setParentArity(((JCLinkGlue)c.target).getChoiceFrom());
        }
      }
            
      if(isParent(c.target) && name.equals("ChildArity")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCLinkGlue)e.nextElement()).setChoiceTo(((JCBaseLink)c.target).getChildArity());
        }
      }
            else if(isChild(c.target) && name.equals("choiceTo")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseLink)e.nextElement()).setChildArity(((JCLinkGlue)c.target).getChoiceTo());
        }
      }
            
      if(isParent(c.target) && name.equals("GenerateCode")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCLinkGlue)e.nextElement()).setGenerateCode(((JCBaseLink)c.target).isGenerateCode());
        }
      }
            else if(isChild(c.target) && name.equals("generateCode")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseLink)e.nextElement()).setGenerateCode(((JCLinkGlue)c.target).isGenerateCode());
        }
      }
            
      if(isParent(c.target) && name.equals("CreateLinked")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCLinkGlue)e.nextElement()).setCreateLinked(((JCBaseLink)c.target).isCreateLinked());
        }
      }
            else if(isChild(c.target) && name.equals("createLinked")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseLink)e.nextElement()).setCreateLinked(((JCLinkGlue)c.target).isCreateLinked());
        }
      }
      
      if(isParent(c.target) && name.equals("Aggregate")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setAggregate(((JCBaseLink) c.target).isAggregate());
        }
      } else if(isChild(c.target) && name.equals("aggregate")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setAggregate(((JCLinkGlue) c.target).isAggregate());
        }      
      }
      
      if(isParent(c.target) && name.equals("ChildListenBefore")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setChildListenBefore(((JCBaseLink) c.target).isChildListenBefore());
        }
      } else if(isChild(c.target) && name.equals("childListenBefore")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setChildListenBefore(((JCLinkGlue) c.target).isChildListenBefore());
        }      
      }
            
      if(isParent(c.target) && name.equals("ChildListenAfter")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setChildListenAfter(((JCBaseLink) c.target).isChildListenAfter());
        }
      } else if(isChild(c.target) && name.equals("childListenAfter")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setChildListenAfter(((JCLinkGlue) c.target).isChildListenAfter());
        }      
      }

       
      if(isParent(c.target) && name.equals("ChildHandleBefore")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setChildHandleBefore(((JCBaseLink) c.target).isChildHandleBefore());
        }
      } else if(isChild(c.target) && name.equals("childHandleBefore")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setChildHandleBefore(((JCLinkGlue) c.target).isChildHandleBefore());
        }      
      }
            
      if(isParent(c.target) && name.equals("ChildHandleAfter")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setChildHandleAfter(((JCBaseLink) c.target).isChildHandleAfter());
        }
      } else if(isChild(c.target) && name.equals("childHandleAfter")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setChildHandleAfter(((JCLinkGlue) c.target).isChildHandleAfter());
        }      
      }

      if(isParent(c.target) && name.equals("ParentListenBefore")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setParentListenBefore(((JCBaseLink) c.target).isParentListenBefore());
        }
      } else if(isChild(c.target) && name.equals("parentListenBefore")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setParentListenBefore(((JCLinkGlue) c.target).isParentListenBefore());
        }      
      }
            
      if(isParent(c.target) && name.equals("ParentListenAfter")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setParentListenAfter(((JCBaseLink) c.target).isParentListenAfter());
        }
      } else if(isChild(c.target) && name.equals("parentListenAfter")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setParentListenAfter(((JCLinkGlue) c.target).isParentListenAfter());
        }      
      }

       
      if(isParent(c.target) && name.equals("ParentHandleBefore")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setParentHandleBefore(((JCBaseLink) c.target).isParentHandleBefore());
        }
      } else if(isChild(c.target) && name.equals("parentHandleBefore")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setParentHandleBefore(((JCLinkGlue) c.target).isParentHandleBefore());
        }      
      }
            
      if(isParent(c.target) && name.equals("ParentHandleAfter")) {
        Enumeration e = children();
        while(e.hasMoreElements()) {
            ((JCLinkGlue) e.nextElement()).setParentHandleAfter(((JCBaseLink) c.target).isParentHandleAfter());
        }
      } else if(isChild(c.target) && name.equals("parentHandleAfter")) {
        Enumeration e = parents();
        while(e.hasMoreElements()) {
            ((JCBaseLink) e.nextElement()).setParentHandleAfter(((JCLinkGlue) c.target).isParentHandleAfter());
        }      
      }
 
   
        }
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
System.out.println("upliftAttributes!!");
        ((JCLinkGlue) vc).setNameText(((JCBaseLink) bc).getName());
        ((JCLinkGlue) vc).setChoiceFrom(((JCBaseLink) bc).getParentArity());
        ((JCLinkGlue) vc).setChoiceTo(((JCBaseLink) bc).getChildArity());
        ((JCLinkGlue) vc).setGenerateCode(((JCBaseLink) bc).isGenerateCode());
        ((JCLinkGlue) vc).setCreateLinked(((JCBaseLink) bc).isCreateLinked());
        ((JCLinkGlue) vc).setAggregate(((JCBaseLink)bc).isAggregate());
        ((JCLinkGlue) vc).setChildListenBefore(((JCBaseLink)bc).isChildListenBefore());
        ((JCLinkGlue) vc).setChildListenAfter(((JCBaseLink)bc).isChildListenAfter());
        ((JCLinkGlue) vc).setChildHandleBefore(((JCBaseLink)bc).isChildHandleBefore());
        ((JCLinkGlue) vc).setChildHandleAfter(((JCBaseLink)bc).isChildHandleAfter());
        ((JCLinkGlue) vc).setParentListenBefore(((JCBaseLink)bc).isParentListenBefore());
        ((JCLinkGlue) vc).setParentListenAfter(((JCBaseLink)bc).isParentListenAfter());
        ((JCLinkGlue) vc).setParentHandleBefore(((JCBaseLink)bc).isParentHandleBefore());
        ((JCLinkGlue) vc).setParentHandleAfter(((JCBaseLink)bc).isParentHandleAfter());
        
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseLink) bc).startMacroChange(new MVMacroChangeDescr(bc,"Initialise Attributes"));
        ((JCBaseLink) bc).setName(((JCLinkGlue) vc).getNameText());
        ((JCBaseLink) bc).setParentArity(((JCLinkGlue) vc).getChoiceFrom());
        ((JCBaseLink) bc).setChildArity(((JCLinkGlue) vc).getChoiceTo());
        ((JCBaseLink) bc).setGenerateCode(((JCLinkGlue) vc).isGenerateCode());
        ((JCBaseLink) bc).setCreateLinked(((JCLinkGlue) vc).isCreateLinked());
        ((JCBaseLink) bc).setAggregate(((JCLinkGlue) vc).isAggregate());
        ((JCBaseLink) bc).setChildListenBefore(((JCLinkGlue) vc).isChildListenBefore());
        ((JCBaseLink) bc).setChildListenAfter(((JCLinkGlue) vc).isChildListenAfter());
        ((JCBaseLink) bc).setChildHandleBefore(((JCLinkGlue) vc).isChildHandleBefore());
        ((JCBaseLink) bc).setChildHandleAfter(((JCLinkGlue) vc).isChildHandleAfter());
        ((JCBaseLink) bc).setParentListenBefore(((JCLinkGlue) vc).isParentListenBefore());
        ((JCBaseLink) bc).setParentListenAfter(((JCLinkGlue) vc).isParentListenAfter());
        ((JCBaseLink) bc).setParentHandleBefore(((JCLinkGlue) vc).isParentHandleBefore());
        ((JCBaseLink) bc).setParentHandleAfter(((JCLinkGlue) vc).isParentHandleAfter());
        ((JCBaseLink) bc).endMacroChange();    
    }

}

