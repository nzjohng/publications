package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseClassG extends MVBaseComp {

    /* Constructors */

    public JCBaseClassG() {
        super();
    }

    public JCBaseClassG(MVBaseLayer base_layer) {
        super(base_layer);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    public String getParentName() {
    return getStringValue("ParentName");
    }

    public void setParentName(String value) {
        setValue("ParentName",value);
    }

    /* Relationships */

/*
    public void establishParentClass(JCBaseClass comp) {
        establishOneToMany("ParentClass",comp);
    }
*/

    public Vector getcClassAttributes() {
        return getRelationship("ClassAttributes",MVChildren);
    }

    public void establishClassAttributes(JCBaseAttr comp) {
        establishOneToMany("ClassAttributes",comp);
        comp.setListenBeforeRel("ClassAttributes");
        comp.setListenAfterRel("ClassAttributes");
    }

    public void dissolveClassAttributes(JCBaseAttr comp) {
        dissolveOneToMany("ClassAttributes",comp);
    }

    public Vector getcClassMethods() {
        return getRelationship("ClassMethods",MVChildren);
    }

    public void establishClassMethods(JCBaseMethod comp) {
        establishOneToMany("ClassMethods",comp);
        comp.setListenBeforeRel("ClassMethods");
        comp.setListenAfterRel("ClassMethods");
    }

    /* Methods */

    public abstract String userName();

    public String kindName() {
        return "Base Class";
    }

    /* Read/write methods */

}

