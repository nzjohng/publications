package JComp;

import JViews.*;
import bbw.*;
import bbw.shape.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.beans.*;
import jComposer.*;

public class JCDiagram extends MVViewLayer implements BBWTransactionListener, JCListener, PropertyChangeListener {

  public JCDiagram(JCBaseLayer base_layer, String name) {
    super(base_layer,name);
    setSpying(true);
  }

  public JCDiagram() {
    super();
  }
  
  public void createFrame() {
    frame = new JCFrame(this);
    MVViewCollabMenu collab = (MVViewCollabMenu) getOneRelatedOrNull("MVCollabMenu",MVParents);
    if(collab == null)
        collab = new MVViewCollabMenu();
    collab.addedView(this);
  }
  
  public void transaction(BBWTransactionEvent evt) {
    if (spying)
      System.out.println(evt);
        super.transaction(evt);
    }

    public void processBBWEvent(EventObject evt) {
System.out.println("JCDiagram.processBBWEvent got "+evt);
        if(inBBWTransaction() && !processingBBWEvents) {
            super.processBBWEvent(evt);
            return;
        }

        boolean oldChange = startBBWChange();

        if(evt instanceof JCChangeEvent) {
            JCChangeEvent jcevt = (JCChangeEvent) evt;

System.out.println("got special event "+jcevt);

     if (jcevt instanceof JCNewComponentEvent) {
                 startMacroChange(new MVMacroChangeDescr(this,"Add Component"));
         JCCompIcon new_comp = new JCCompIcon();
         new_comp.init(this);
         new_comp.addedBBWShape(((JCNewComponentEvent) jcevt).getComponent());
         ((JCNewComponentEvent) jcevt).getComponent().showPropertySheet();
// new_comp.setNameText("EntityIcon");
// new_comp.setBbwShapeText("erTool.EREntity");
// new_comp.setBbwShapeText("");
// new_comp.setBbwShapeText("erTool.EREntity");
         endMacroChange();
        }
            if(jcevt instanceof JCNewRelnEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Relationship"));
              JCRelIcon new_comp = new JCRelIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewRelnEvent) jcevt).getRelnShape());            
              ((JCNewRelnEvent) jcevt).getRelnShape().showPropertySheet();
// new_comp.setNameText("BaseEntities");
              endMacroChange();
          }
          if(jcevt instanceof JCNewArrowArityEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Link"));
              JCLinkGlue new_comp = new JCLinkGlue();
                MVViewComp p = findBBWViewComp(((JCNewArrowArityEvent) jcevt).getArrowArity().getFrom().getOwner());
                MVViewComp c = findBBWViewComp(((JCNewArrowArityEvent) jcevt).getArrowArity().getTo().getOwner());
              new_comp.init(this,p,c);
              new_comp.addedBBWShape(((JCNewArrowArityEvent) jcevt).getArrowArity());
                ((JCNewArrowArityEvent) jcevt).getArrowArity().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewElementEvent) {
System.out.println("Adding new element to component...");
              startMacroChange(new MVMacroChangeDescr(this,"Add Element"));
              JCAttrIcon new_comp = new JCAttrIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewElementEvent) jcevt).getElement());
                MVViewComp comp_icon = findBBWViewComp((BBWComponent) ((JCNewElementEvent) jcevt).getSource());
System.out.println("adding new element to "+comp_icon.userName());
                new_comp.setOwner(comp_icon);
              endMacroChange();
          }
          if(jcevt instanceof JCNewRelnShadedEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Action"));
              JCActionIcon new_comp = new JCActionIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewRelnShadedEvent) jcevt).getRelnShadedShape());
              ((JCNewRelnShadedEvent) jcevt).getRelnShadedShape().showPropertySheet();             
              endMacroChange();
          }
          if(jcevt instanceof JCNewFilterEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Filter"));
              JCFilterIcon new_comp = new JCFilterIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewFilterEvent) jcevt).getFilter());
              ((JCNewFilterEvent) jcevt).getFilter().showPropertySheet();             
              endMacroChange();
          }
          if(jcevt instanceof JCNewDirectedArcEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Event Flow"));
              JCEventGlue new_comp = new JCEventGlue();
                MVViewComp p = findBBWViewComp(((JCNewDirectedArcEvent) jcevt).getDirectedArc().getFrom().getOwner());
                MVViewComp c = findBBWViewComp(((JCNewDirectedArcEvent) jcevt).getDirectedArc().getTo().getOwner());
              new_comp.init(this,p,c);
              new_comp.addedBBWShape(((JCNewDirectedArcEvent) jcevt).getDirectedArc());
              ((JCNewDirectedArcEvent) jcevt).getDirectedArc().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewEventInEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add EventIn"));
              JCEventInIcon new_comp = new JCEventInIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewEventInEvent) jcevt).getEventIn());
              ((JCNewEventInEvent) jcevt).getEventIn().showPropertySheet();             
              endMacroChange();
           }
           if(jcevt instanceof JCNewEventOutEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add EventOut"));
              JCEventOutIcon new_comp = new JCEventOutIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewEventOutEvent) jcevt).getEventOut());
              ((JCNewEventOutEvent) jcevt).getEventOut().showPropertySheet();             
              endMacroChange();
           }
           if(jcevt instanceof JCNewAspectInfoEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Aspect Info"));
              JCAspectInfoIcon new_comp = new JCAspectInfoIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewAspectInfoEvent) jcevt).getAspectInfo());            
              ((JCNewAspectInfoEvent) jcevt).getAspectInfo().showPropertySheet();
              endMacroChange();
          }
          if(jcevt instanceof JCNewAspectDetailEvent) {
              startMacroChange(new MVMacroChangeDescr(this,"Add Aspect Detail"));
              JCAspectDetailIcon new_comp = new JCAspectDetailIcon();
              new_comp.init(this);
              new_comp.addedBBWShape(((JCNewAspectDetailEvent) jcevt).getAspectDetail());
              MVViewComp comp_icon = findBBWViewComp((BBWComponent) ((JCNewAspectDetailEvent) jcevt).getSource());
              new_comp.setOwner(comp_icon);
              endMacroChange();
          }
  
        }

        if(!oldChange)
            endBBWChange();
    
  }
  
  public void propertyChange(PropertyChangeEvent evt) {
    if (spying)
      System.out.println(evt);
        super.propertyChange(evt);
    }

  public void jcChange(JCChangeEvent evt) {
    if (spying)
      System.out.println("JCDiagram.jcChange got "+evt);
      
      if(!processingJViewsChange)
                processBBWEvent(evt);
    }
   
   public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel_name) {

/*
     if(!processingBBWChange && c.target instanceof MVViewComp) {
        MVViewComp comp = (MVViewComp) c.target;
System.out.println("JCDiagram got change "+c+" from "+from.compID);
System.out.println("comp.getBBWShape() = "+comp.getBBWShape());
System.out.println("comp.canBeDrawn() = "+comp.canBeDrawn());       
        if(comp.getBBWShape() == null && comp.canBeDrawn()) {

System.out.println("Adding BBW shape after JViews comp addition...");

            startJViewsChange();
            ((JCFrame) frame).addedViewComp(comp);
            endJViewsChange();  
        }       
     }
*/
   
     return super.afterChange(c,from,rel_name);
   }
   
}

class JCFrame extends MVViewFrame implements ActionListener {

  public JCFrame(MVViewLayer view) {
    super(view);
  setLayout(new BorderLayout());
  add("Center", panel);
  //add("North",spyingCheckbox);
  add("North",messagePanel);
  panel.addTransactionListener(view);
  panel.addJCChangeListener((JCDiagram) view);
  }

    protected MenuItem generate;
    protected MenuItem set_data;
  
    public void addFrameMenus() {
        super.addFrameMenus();
        Menu compilationMenu = new Menu("Compilation");
        set_data = new MenuItem("Set Package Info");
        compilationMenu.add(set_data);
        set_data.addActionListener(this);
        generate = new MenuItem("Generate Classes");
        compilationMenu.add(generate);
        generate.addActionListener(this);
        menuBar.add(compilationMenu);
    }

  public void actionPerformed(ActionEvent e) {
      if(e.getSource() == newView) {
        JCDiagram jc_view = new JCDiagram((JCBaseLayer)view.getBaseLayer(),view.getBaseLayer().nextViewName());
        jc_view.show(); // show view's frame...
                // jc_view.renameView();
      } else if(e.getSource() == generate) {
                String path;
                
                FileDialog f = new FileDialog(view.getViewFrame(),"Specify folder to save to",FileDialog.SAVE);
                f.show();
                path = f.getDirectory();
                ((JCBaseLayer) view.getBaseLayer()).generateClasses(path);
      } else if(e.getSource() == set_data) {
        view.getBaseLayer().showPropertySheet();
      } else
                super.actionPerformed(e);
    }

   public void addedViewComp(MVViewComp c) {
     // create BBW shapes when JViews icon/glue added...
     
System.out.println("Adding "+c.compKind());
     
     if(c instanceof JCCompIcon) {
        JCComponent new_comp = panel.newComponent(100,100,60,40);
       ((JCCompIcon) c).addedViewComp(new_comp);
     }
         if(c instanceof JCRelIcon) {
            JCRelnShape new_comp = panel.newReln(100,100,60,40);
      ((JCRelIcon) c).addedViewComp(new_comp);
         }
         if(c instanceof JCLinkGlue) {
            JCArrowArity new_comp = panel.newArrowArity(((JCLinkGlue) c).getBBWParent(),((JCLinkGlue) c).getBBWChild());
            ((JCLinkGlue) c).addedViewComp(new_comp);
         }
        if(c instanceof JCAttrIcon) {
            JCComponent comp = (JCComponent) ((JCAttrIcon) c).getBBWParent();
            comp.addElement();
            Vector fields = comp.getFields();
            TextFieldShape field = (TextFieldShape) fields.lastElement();
            ((JCAttrIcon) c).addedViewComp(field);
        }
        if(c instanceof JCActionIcon) {
            JCRelnShadedShape new_action = panel.newRelnShaded(100,100,60,40);
            ((JCActionIcon) c).addedViewComp(new_action);
        }
        if(c instanceof JCFilterIcon) {
            JCFilter new_filter = panel.newFilter(100,100,60,40);
            ((JCFilterIcon) c).addedViewComp(new_filter);
        }
        if(c instanceof JCEventGlue) {
            JCDirectedArc new_comp = panel.newDirectedArc(((JCEventGlue) c).getBBWParent(),((JCEventGlue) c).getBBWChild());
            ((JCEventGlue) c).addedViewComp(new_comp);
        }
        
        if(c instanceof JCAspectInfoIcon) {
            JCAspectInfo new_comp = panel.newAspectInfo(100,100,60,40);
            ((JCAspectInfoIcon) c).addedViewComp(new_comp);
        }
     
        if(c instanceof JCAspectDetailIcon) {
            JCAspectInfo comp = (JCAspectInfo) ((JCAspectDetailIcon) c).getBBWParent();
            comp.addElement();
            Vector fields = comp.getFields();
            TextFieldShape field = (TextFieldShape) fields.lastElement();
            ((JCAspectDetailIcon) c).addedViewComp(field);
        }
   }

        private JComposerPanel panel = new JComposerPanel();
  private Checkbox spyingCheckbox = new Checkbox("spy");
  private static int frameCount = 1;
  }

