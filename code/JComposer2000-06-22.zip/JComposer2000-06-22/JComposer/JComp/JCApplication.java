package JComp;

import JViews.*;
import bbw.*;


public class JCApplication extends MVApplication {
  
  public JCApplication() {
    super();
  }

  public MVProject newProject() {
    return new JCProject("project #1");
  }


    public static void main(String argv[]) {
        JCApplication a = new JCApplication();

    }
}

