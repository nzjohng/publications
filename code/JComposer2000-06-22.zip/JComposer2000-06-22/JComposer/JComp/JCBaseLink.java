package JComp;

import JViews.*;
import bbw.*;


/*
 * hand-written code for Base Links
 *
 */

public class JCBaseLink extends JCBaseLinkG {

    public JCBaseLink() {
        super();
    }

    public JCBaseLink(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        if(hasParent())
            return getpLinkParent().userName()+"->"+getName();
        else
            return getName();
    }
    
    public boolean hasParent()
    {
        if(getRelationship("LinkParent",MVParents).size() > 0)
            return true;
        else
            return false;
    }

    public String getChildrenMethodName() {
        return "getc"+capitalize(getName());
    }

    public String getParentsMethodName() {
        return "getp"+capitalize(getName());
    }

    public String getEstablishChildrenMethodName() {
        return "establish"+capitalize(getName());
    }

    public String getDissolveChildrenMethodName() {
        return "dissolve"+capitalize(getName());
    }

  private String capitalize(String s) {
        char chars[] = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
  }

}

