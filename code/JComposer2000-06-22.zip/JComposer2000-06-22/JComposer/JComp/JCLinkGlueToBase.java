package JComp;

import JViews.*;
import bbw.*;


public class JCLinkGlueToBase extends JCLinkGlueToBaseG {

  public JCLinkGlueToBase() {
    super();
  }

    public String userName() {
        return "*unknown*";
    }

}

