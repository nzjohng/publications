package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEEndIconToBaseG extends MVViewRel
 {

  public SEEndIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEEndIcon)e.nextElement()).setText(((SEBaseEndStage)c.target).getName());
        }
      }
            else if(isChild(c.target) && name.equals("text")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseEndStage)e.nextElement()).setName(((SEEndIcon)c.target).getText());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "SEEndIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEEndIcon)vc).setText(((SEBaseEndStage)bc).getName());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEBaseEndStage)bc).setName(((SEEndIcon)vc).getText());
  }

  public MVViewRel newViewRel() {
    return new SEEndIconToBase();
  }

  public String getViewRelKind() {
    return "SEEndIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

