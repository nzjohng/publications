package JComp;

import JViews.*;
import bbw.*;


public class JCEventGlueToBase extends JCEventGlueToBaseG {

  public JCEventGlueToBase() {
    super();
  }

    public String userName() {
        return "*unknown*";
    }

}

