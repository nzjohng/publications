package JComp;

import JViews.*;
import bbw.*;


/* hand-written stuff */

public class JCBaseArg extends JCBaseArgG {

    public JCBaseArg() {
        super();
    }

    public JCBaseArg(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {

        return getpMethodArgs().userName()+"("+getName()+")";
    }

}

