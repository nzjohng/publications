package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * hand-written code
 *
 */

public class JCBaseMethod extends JCBaseMethodG {

    public JCBaseMethod() {
        super();
    }

    public JCBaseMethod(JCBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        return getpClassMethods().getName() +"."+ getName();
    }

    public void addArg(String name, String type) {
        JCBaseArg a = new JCBaseArg(getBaseLayer());
        a.setName(name);
        a.setType(type);
        establishMethodArgs(a);
    }

    public String fullArgs() {
        String value = "";
        Enumeration args = getcMethodArgs().elements();

        while(args.hasMoreElements()) {
            JCBaseArg arg = (JCBaseArg) args.nextElement();
            value = value+arg.getType()+" "+arg.getName();
            if(args.hasMoreElements())
                value = value + ", ";
        }

        return value;
    }

    public String argNames() {
        String value = "";
        Enumeration args = getcMethodArgs().elements();

        while(args.hasMoreElements()) {
            JCBaseArg arg = (JCBaseArg) args.nextElement();
            value = arg.getName();
            if(args.hasMoreElements())
                value = value + ", ";
        }

        return value;
    }

}

