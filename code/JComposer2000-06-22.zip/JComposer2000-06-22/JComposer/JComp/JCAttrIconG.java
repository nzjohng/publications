package JComp;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import jComposer.*;
import bbw.shape.*;

public abstract class JCAttrIconG extends MVSubIcon {

  public JCAttrIconG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Attribute Icon";
  }

    public String getText() {
        return getStringValue("text");
    }

    public void setText(String value) {
        setValue("text",value);
    }

  public abstract String userName();

    public TextFieldShape getTextFieldShape() {
        return (TextFieldShape) getBBWShape();
    }

  public JCAttrIconToBase getprCompIconToBase() {
    return (JCAttrIconToBase) getOneRelated("MVViewRel",MVParents);
  }

  public JCBaseAttr getpCompIconToBase() {
    return (JCBaseAttr) getOneRelated("MVViewRel",MVParentRelComps);
  }

  public void establishListeners() {
  }


    public String viewRelKind() {
        return "JCAttrIconToBase";
    }

    public MVViewRel newViewRel() {
        return new JCAttrIconToBase();
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("text")) {
                getTextFieldShape().setText(getText());
            }
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("text")) {
            setText(getTextFieldShape().getText());
        }

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setText(getTextFieldShape().getText());
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        if(getAttribute("text") != null)
            getTextFieldShape().setText(getText());
        else
            setText(getTextFieldShape().getText());

    }


}

