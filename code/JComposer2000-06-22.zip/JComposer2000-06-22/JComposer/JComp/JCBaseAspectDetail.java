package JComp;

import JViews.*;

public class JCBaseAspectDetail extends JCBaseAspectDetailG {

  public JCBaseAspectDetail() {
    super();
  }
  
  public JCBaseAspectDetail(String name, String type, boolean provides)
  {
    super();
    setName(name);
    setType(type);
    setProvides(provides);
  }


  public String userName() {
    return getName()+"("+getType()+")";
  }

}

