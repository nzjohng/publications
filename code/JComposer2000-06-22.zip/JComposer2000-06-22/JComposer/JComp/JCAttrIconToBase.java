package JComp;

import JViews.*;
import bbw.*;
import java.util.*;

public class JCAttrIconToBase extends JCAttrIconToBaseG {

  public JCAttrIconToBase() {
    super();
  }

    public String userName() {
        return "*unknown*";
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel) {
    if(c instanceof MVSetValue) {
      String name = ((MVSetValue) c).getPropertyName();
      if(isParent(c.target) && name.equals("Name") ||
                    name.equals("Type") ||
                    name.equals("MapToName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAttrIcon)e.nextElement()).setText(getText((JCBaseAttr) c.target));
        }
      }
            else if(isChild(c.target) && name.equals("text")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    JCBaseAttr a = (JCBaseAttr) e.nextElement();
                    a.setName(getName(((JCAttrIcon)c.target)));
                    a.setType(getType(((JCAttrIcon)c.target)));
                    a.setMapToName(getMapToName(((JCAttrIcon)c.target)));
        }
      }
        }
    return super.afterChange(c,from,rel);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCAttrIcon) vc).setText(getText((JCBaseAttr) bc));
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseAttr) bc).setName(getName((JCAttrIcon) vc));
        ((JCBaseAttr) bc).setType(getType((JCAttrIcon) vc));
        ((JCBaseAttr) bc).setMapToName(getMapToName((JCAttrIcon) vc));
    }

    public String getText(JCBaseAttr a) {
        String name = a.getName();
        String t = a.getType();
        String map = a.getMapToName();

        if(map.equals(""))
            return name+":"+t;
        else
            if(t.equals(""))
                return name+"="+map;
            else
                return name+":"+t+"="+map;
    }

    public String getName(JCAttrIcon a) {
        return a.getName();
    }

    public String getType(JCAttrIcon a) {
        return a.getType();
    }

    public String getMapToName(JCAttrIcon a) {
        return a.getMapToName();
    }

}

