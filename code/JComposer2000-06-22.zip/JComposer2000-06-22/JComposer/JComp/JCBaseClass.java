package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * Hand-written base class stuff
 *
 */

public class JCBaseClass extends JCBaseClassG {

    public JCBaseClass() {
        super();
    }

    public JCBaseClass(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        return getName();
    }

    public JCBaseAttr findAttributeName(String name) {
        Enumeration e = getcClassAttributes().elements();

        while(e.hasMoreElements()) {
            JCBaseAttr m = (JCBaseAttr) e.nextElement();

            if(m.getName().equals(name))
                return m;
        }

        return null;
    }

    public JCBaseMethod findMethodName(String name) {
        Enumeration e = getcClassMethods().elements();

        while(e.hasMoreElements()) {
            JCBaseMethod m = (JCBaseMethod) e.nextElement();

            if(m.getName().equals(name))
                return m;
        }

        return null;
    }

    public Vector getAllClassAttributes() {
        // get all class-defined AND inherited attributes...
        Vector attributes = getcClassAttributes();
        Enumeration inherited = getcParentClass().getAllClassAttributes().elements();

        while(inherited.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) inherited.nextElement();
            if(findAttributeName(a.getName()) != null)
                attributes.addElement(a);
        }

        return attributes;
    }

    public Vector getAllClassMethods() {
        // get all class-defined AND inherited methods...
        Vector methods = getcClassMethods();
        Enumeration inherited = getcParentClass().getAllClassMethods().elements();

        while(inherited.hasMoreElements()) {
            JCBaseMethod m = (JCBaseMethod) inherited.nextElement();
            if(findMethodName(m.getName()) != null)
                methods.addElement(m);
        }

        return methods;
    }

/*
    public Vector getParentConstructors() {
        // return all of parent's constructor methods

        return null;
    }
*/

    public String parentClassName() {
        return getParentName();
    }

    public JCBaseAttr addAttribute(String name, String type) {
        JCBaseAttr a = new JCBaseAttr(getBaseLayer());
        a.setName(name);
        a.setType(type);
        establishClassAttributes(a);
        return a;
    }

    public JCBaseClass getcParentClass() {
        if(getParentName().equals(""))
            return null;
        return ((JCBaseLayer) getBaseLayer()).findBaseClass(getParentName());
    }

}


