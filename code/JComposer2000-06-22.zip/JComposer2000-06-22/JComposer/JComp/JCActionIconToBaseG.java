package JComp;

import JViews.*;
import bbw.*;

import java.util.*;

public abstract class JCActionIconToBaseG extends MVViewRel {

  public JCActionIconToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Action Icon To Base Mapping";
  }

  public abstract String userName();


  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("Name")) {
            Enumeration e = children();
            while(e.hasMoreElements()) {
                    ((JCActionIcon)e.nextElement()).setText(((JCBaseListener)c.target).getName());
        }
      }
        else if(isChild(c.target) && name.equals("Text")) {
            Enumeration e = parents();
            while(e.hasMoreElements()) {
                    ((JCBaseListener)e.nextElement()).setName(((JCActionIcon)c.target).getText());
        }
      }

      if(isParent(c.target) && name.equals("ParentName")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCActionIcon)e.nextElement()).setParentName(((JCBaseListener)c.target).getParentName());
        }
      }
            else if(isChild(c.target) && name.equals("parentName")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseListener)e.nextElement()).setParentName(((JCActionIcon)c.target).getParentName());
        }
      }
        }
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCActionIcon) vc).setParentName(((JCBaseListener) bc).getParentName());
        ((JCActionIcon) vc).setText(((JCBaseListener) bc).getName());
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseListener) bc).setParentName(((JCActionIcon) vc).getParentName());
        ((JCBaseListener) bc).setName(((JCActionIcon) vc).getText());
    }

}

