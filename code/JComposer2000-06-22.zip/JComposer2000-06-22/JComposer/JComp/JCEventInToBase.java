package Serendipity;

import JViews.*;

public class SEStartIconToBase extends SEStartIconToBaseG {

  public SEStartIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

