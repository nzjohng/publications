package JComp;

import JViews.*;
import bbw.*;


/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseListenerG extends JCBaseComp {

    /* Constructors */

    public JCBaseListenerG() {
        super();
    }

    public JCBaseListenerG(MVBaseLayer base_layer) {
        super(base_layer);
    }

    /* Attributes */

    /* Relationships */

    /* Methods */

    public String kindName() {
        return "Base Listener";
    }

    /* Read/write methods */

}

