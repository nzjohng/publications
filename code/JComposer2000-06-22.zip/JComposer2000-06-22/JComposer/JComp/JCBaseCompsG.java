package JComp;

import JViews.*;
import bbw.*;


/* Generated */

public class JCBaseCompsG extends MVHashtableRel {

    public JCBaseCompsG() {
        super();
    }

    public JCBaseCompsG(String rel_name, MVComponent parent_comp) {
        super(rel_name,parent_comp);
    }

    public String kindName() {
        return "Base Components";
    }

}

