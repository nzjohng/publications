package JComp;
import JViews.*;
import java.util.*;

public abstract class JCBaseAspectInfoG extends MVBaseComp
 {

  public JCBaseAspectInfoG() {
    super();
  }

  public String kindName() {
    return "Base Aspect Info";
  }

  public abstract String userName();


  public String getAspectName() {
    return getStringValue("aspectName");
  }

  public void setAspectName(String value) {
    setValue("aspectName",value);
  }


  public String getAspectType() {
    return getStringValue("aspectType");
  }

  public void setAspectType(String value) {
    setValue("aspectType",value);
  }


  public boolean isDesignLevel() {
    return getBooleanValue("designLevel");
  }

  public void setDesignLevel(boolean value) {
    setValue("designLevel",value);
  }


  public String getJviewsClass() {
    return getStringValue("jviewsClass");
  }

  public void setJviewsClass(String value) {
    setValue("jviewsClass",value);
  }


  public Vector getcAspectDetails() {
    return getRelationship("aspectDetails",MVChildren);
  }

  public void establishAspectDetails(JCBaseAspectDetail comp) {
    establishOneToMany("aspectDetails",comp);
  }

  public void dissolveAspectDetails(JCBaseAspectDetail comp) {
    dissolveOneToMany("aspectDetails",comp);
  }

  public JCAspectIconToBase getcrAspectIconToBase() {
    return (JCAspectIconToBase) getOneRelated("MVViewRel",MVChildren);
  }

  public void establishAspectIconToBase(JCAspectInfoIcon comp) {
    getcrAspectIconToBase().establish(this,comp);
  }

  public void dissolveAspectIconToBase(JCAspectInfoIcon comp) {
    getcrAspectIconToBase().dissolve(this,comp);
  }

  public JCAspectInfoIcon getcAspectIconToBase() {
    return (JCAspectInfoIcon) getOneRelated("MVViewRel",MVChildRelComps);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

