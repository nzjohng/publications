package JComp;

import JViews.*;
import bbw.*;

import java.util.*;

public abstract class JCFilterIconToBaseG extends MVViewRel {

  public JCFilterIconToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Filter Icon To Base Mapping";
  }

  public abstract String userName();


  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("Name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCFilterIcon)e.nextElement()).setNameText(((JCBaseListener)c.target).getName());
        }
      }
        else if(isChild(c.target) && name.equals("nameText")) {
            Enumeration e = parents();
            while(e.hasMoreElements()) {
               ((JCBaseListener)e.nextElement()).setName(((JCFilterIcon)c.target).getNameText());
        }
      }
        }
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCFilterIcon) vc).setNameText(((JCBaseListener) bc).getName());
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseListener) bc).setName(((JCFilterIcon) vc).getNameText());
    }

}

