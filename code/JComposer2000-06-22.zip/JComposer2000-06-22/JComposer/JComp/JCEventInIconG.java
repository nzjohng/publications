package JComp;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class JCEventInIconG extends MVViewComp
 {

  public JCEventInIconG() {
    super();
  }

  public String kindName() {
    return "Start Stage Icon";
  }

  public abstract String userName();


  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
    setValue("width",value);
  }


  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
    setValue("height",value);
  }


  public String getText() {
    return getStringValue("text");
  }

  public void setText(String value) {
    setValue("text",value);
  }


  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }


  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }


  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }


  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
      if(((MVSetValue) c).getPropertyName().equals("width"))
        getJCEventIn().setWidth((getWidth()));
      if(((MVSetValue) c).getPropertyName().equals("height"))
        getJCEventIn().setHeight((getHeight()));
      if(((MVSetValue) c).getPropertyName().equals("text"))
        getJCEventIn().setText((getText()));
      if(((MVSetValue) c).getPropertyName().equals("foreground"))
        getJCEventIn().setForeground(java_awt_Color_fromString(getForeground()));
      if(((MVSetValue) c).getPropertyName().equals("background"))
        getJCEventIn().setBackground(java_awt_Color_fromString(getBackground()));
      if(((MVSetValue) c).getPropertyName().equals("y"))
        getJCEventIn().setY((getY()));
      if(((MVSetValue) c).getPropertyName().equals("x"))
        getJCEventIn().setX((getX()));
    }

    return super.afterChange(c,from,rel_name);
  }

  public String viewRelKind() {
    return "JCEventInToBase";
  }

//  public MVViewRel newViewRel() {
//    return new JCEventInToBase();
 // }


  public JCEventIn getJCEventIn() {
    return (JCEventIn) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

      if(evt.getPropertyName().equals("width"))
        setWidth((getJCEventIn().getWidth()));
      if(evt.getPropertyName().equals("height"))
        setHeight((getJCEventIn().getHeight()));
      if(evt.getPropertyName().equals("text"))
        setText((getJCEventIn().getText()));
      if(evt.getPropertyName().equals("foreground"))
        setForeground(java_awt_Color_toString(getJCEventIn().getForeground()));
      if(evt.getPropertyName().equals("background"))
        setBackground(java_awt_Color_toString(getJCEventIn().getBackground()));
      if(evt.getPropertyName().equals("y"))
        setY((getJCEventIn().getY()));
      if(evt.getPropertyName().equals("x"))
        setX((getJCEventIn().getX()));
    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
        setWidth((getJCEventIn().getWidth()));
        setHeight((getJCEventIn().getHeight()));
        setText((getJCEventIn().getText()));
        setForeground(java_awt_Color_toString(getJCEventIn().getForeground()));
        setBackground(java_awt_Color_toString(getJCEventIn().getBackground()));
        setY((getJCEventIn().getY()));
        setX((getJCEventIn().getX()));
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
        if(getAttribute("width") == null)
          setWidth((getJCEventIn().getWidth()));
        else
          getJCEventIn().setWidth((getWidth()));
        if(getAttribute("height") == null)
          setHeight((getJCEventIn().getHeight()));
        else
          getJCEventIn().setHeight((getHeight()));
        if(getAttribute("text") == null)
          setText((getJCEventIn().getText()));
        else
          getJCEventIn().setText((getText()));
        if(getAttribute("foreground") == null)
          setForeground(java_awt_Color_toString(getJCEventIn().getForeground()));
        else
          getJCEventIn().setForeground(java_awt_Color_fromString(getForeground()));
        if(getAttribute("background") == null)
          setBackground(java_awt_Color_toString(getJCEventIn().getBackground()));
        else
          getJCEventIn().setBackground(java_awt_Color_fromString(getBackground()));
        if(getAttribute("y") == null)
          setY((getJCEventIn().getY()));
        else
          getJCEventIn().setY((getY()));
        if(getAttribute("x") == null)
          setX((getJCEventIn().getX()));
        else
          getJCEventIn().setX((getX()));
  }

}

