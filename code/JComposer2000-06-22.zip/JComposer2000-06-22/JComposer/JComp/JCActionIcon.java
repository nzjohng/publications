package JComp;

import JViews.*;
import bbw.*;

public class JCActionIcon extends JCActionIconG {

  public JCActionIcon() {
    super();
  }

    public JCActionIcon(MVViewLayer v) {
        super(v);
    }

    public String userName() {
        return getText();
    }

    public MVBaseComp mapComponent(boolean do_map) {

System.out.println("in mapComponent()");
System.out.println(this);

        if(getText().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getText() = '"+getText()+"'");

        JCBaseLayer base_layer = (JCBaseLayer) view().getBaseLayer();
        JCBaseComp base_comp = base_layer.findBaseComp(getText());

        if(base_comp != null && !(base_comp instanceof JCBaseListener)) {
            // should generate error change description??
System.out.println("*** base component not a Listener!!");
return null;
        }

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = new JCBaseListener(base_layer);
                mapToCreatedBase(base_comp);
                base_layer.establishBaseComps(base_comp);
                return base_comp;
            }
        }
            else return base_comp;

    }


    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue)
                if(((MVSetValue) c).getPropertyName().equals("text") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for ActionIcon calling mapComponent...");
                        mapComponent(true);
                }

            return super.afterChange(c,from,rel_name);
        }

}

