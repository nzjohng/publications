package JComp;

import JViews.*;
import bbw.*;


/* hand-written stuff */

public class JCBaseListener extends JCBaseListenerG {

    public JCBaseListener() {
        super();
    }

    public JCBaseListener(MVBaseLayer base_layer) {
        super(base_layer);
    }

}

