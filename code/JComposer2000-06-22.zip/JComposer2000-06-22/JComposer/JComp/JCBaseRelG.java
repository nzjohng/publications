package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseRelG extends JCBaseComp {

    /* Constructors */

    public JCBaseRelG() {
        super();
    }

    public JCBaseRelG(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public void setAggregate(boolean value)
    {
        setValue("aggregate",value);
    }
    
    public boolean isAggregate()
    {
        return getBooleanValue("aggregate");
    }

    /* Relationships */


    /* Methods */

    public abstract String userName();

    public String kindName() {
        return "Base Relationship";
    }

    /* Read/write methods */

}

