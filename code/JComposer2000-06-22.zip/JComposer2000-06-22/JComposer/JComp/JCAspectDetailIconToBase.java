package JComp;

import JViews.*;
import bbw.*;
import java.util.*;

public class JCAspectDetailIconToBase extends JCAspectDetailIconToBaseG {

  public JCAspectDetailIconToBase() {
    super();
  }

    public String userName() {
        return "*unknown*";
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel) {
    if(c instanceof MVSetValue) {
      String name = ((MVSetValue) c).getPropertyName();
      if(isParent(c.target) && name.equals("Name") ||
                    name.equals("Type") ||
                    name.equals("Provides")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCAspectDetailIcon)e.nextElement()).setText(getText((JCBaseAspectDetail) c.target));
        }
      }
            else if(isChild(c.target) && name.equals("text")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    JCBaseAspectDetail a = (JCBaseAspectDetail) e.nextElement();
                    a.setName(getName(((JCAspectDetailIcon)c.target)));
                    a.setType(getType(((JCAspectDetailIcon)c.target)));
                    a.setProvides(isProvides(((JCAspectDetailIcon)c.target)));
        }
      }
        }
    return super.afterChange(c,from,rel);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCAspectDetailIcon) vc).setText(getText((JCBaseAspectDetail) bc));
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseAspectDetail) bc).setName(getName((JCAspectDetailIcon) vc));
        ((JCBaseAspectDetail) bc).setType(getType((JCAspectDetailIcon) vc));
        ((JCBaseAspectDetail) bc).setProvides(isProvides((JCAspectDetailIcon) vc));
    }

    public String getText(JCBaseAspectDetail a) {
        String name = a.getName();
        String t = a.getType();
        boolean pro = a.isProvides();

        if(pro)
            return "+"+name+":"+t;
        else
            return "-"+name+":"+t;
    }

    public String getName(JCAspectDetailIcon a) {
        return a.getName();
    }

    public String getType(JCAspectDetailIcon a) {
        return a.getType();
    }

    public boolean isProvides(JCAspectDetailIcon a) {
        return a.isProvides();
    }

}

