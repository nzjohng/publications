package JComp;

import JViews.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import bbw.*;

public class JCAspectInfoIcon extends JCAspectInfoIconG {

  public JCAspectInfoIcon() {
    super();
  }

  public MVViewComp getOwner()
  {
    Vector glue = getRelationship("Parent",MVParents);
    if(glue.size() > 1)
        System.out.println("*** error: aspect info with > 1 parent!");
        // should check for this & generate error change descr when create link to this comp??
    else {
        if(glue.size() == 1)
            return (MVViewComp) ((MVOneToOneGlue) glue.firstElement()).getChild();
        else
            return null;    
    }
    
    return null;
  }

  public String userName() {
    // should add owning comp name too??
    //if(getOwner() != null)
    //    return getOwner().userName()+": "+ getAspectName()+"("+getAspectType()+")";
    return getAspectName()+"("+getAspectType()+")";
  }
  
  public MVBaseComp mapComponent(boolean do_map)
  {
    if(getAspectName().equals(""))
        return null;
        
    if(getOwner() == null)
        return null;
        
    if(!(getOwner().baseComp() instanceof JCBaseComp)) {
        System.out.println("Owner is not a component!");
        return null;
    }
    
    JCBaseComp owner = (JCBaseComp) getOwner().baseComp();
    MVBaseLayer base_layer = owner.getpBaseComps();
    JCBaseAspectInfo baspect = owner.findAspectInfo(getAspectName());
    
    if(do_map) {
            if(baspect != null) {
                mapToBase(baspect);
                return baspect;
            } else {
                baspect = new JCBaseAspectInfo();
                mapToCreatedBase(baspect);
                baspect.init(base_layer);
                owner.establishAspectInfo(baspect);
                return baspect;
            }
        }
            else return baspect;    
  }

  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue) {
                if(baseComp() == null && hasView()) {
System.out.println("afterUpdate for AspectInfoIcon calling mapComponent...");
                        mapComponent(true);
                }
                
            }

            return super.afterChange(c,from,rel_name);
        }
              
   MenuItem details = new MenuItem("Manage Aspect Details");
   MenuItem showHide = new MenuItem("Show/hide Details");
    
    public void addJViewsPopups(BBWComponent shape)
    {
        super.addJViewsPopups(shape);
        shape.addPopupMenuItem(new MenuItem("-"));
        shape.addPopupMenuItem(details);
        details.addActionListener(this);
        shape.addPopupMenuItem(showHide);
        showHide.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource() == details)
            if(getBaseComp() != null)
                ((JCBaseAspectInfo) getBaseComp()).manageDetails();
        else if(e.getSource() == showHide)
            showHideDetails();
        else
            super.actionPerformed(e);
    }
    
    public void showHideDetails()
    {
        // allow user to show/hide details via a dialogue
        
    }
    
}

