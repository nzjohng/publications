package JComp;

import JViews.*;
import bbw.*;


/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseAttrG extends MVBaseComp {

    /* Constructors */

    public JCBaseAttrG() {
        super();
    }

    public JCBaseAttrG(MVBaseLayer base_layer) {
        super(base_layer);
        setName(MVStringBlank);
        setMapToName(MVStringBlank);
        setType(MVStringBlank);
        setBBWType(MVStringBlank);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    public String getMapToName() {
    return getStringValue("MapToName");
    }

    public void setMapToName(String value) {
        setValue("MapToName",value);
    }

    public String getType() {
    return getStringValue("Type");
    }

    public void setType(String value) {
        setValue("Type",value);
    }

    public String getBBWType() {
        return getStringValue("BBWType");
    }

    public void setBBWType(String value) {
        setValue("BBWType",value);
    }

    /* Relationships */

    public JCBaseClass getpClassAttributes() {
        return (JCBaseClass)getOneRelated("ClassAttributes",MVParents);
    }

    /* Methods */

    public String kindName() {
        return "Base Attribute";
    }

    public abstract String userName();

    /* Read/write methods */

}

