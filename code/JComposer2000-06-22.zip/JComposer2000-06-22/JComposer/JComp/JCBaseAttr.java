package JComp;

import JViews.*;
import bbw.*;


/*
 * hand-written code
 *
 */

public class JCBaseAttr extends JCBaseAttrG {

    public JCBaseAttr() {
        super();
    }

    public JCBaseAttr(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        return getpClassAttributes().getName() +":"+ getName();
    }

    public String getGetterName() {
        if(getType().equals("boolean"))
            return "is" + capitalize(getName());
        return "get"+capitalize(getName());
    }

    public String getSetterName() {
        return "set"+capitalize(getName());
    }

    public String getMapFromGetterName() {
        return getGetterName();
    }

    public String getMapToGetterName() {
        if(getType().equals("boolean"))
            return "is" + capitalize(getMapToName());
        return "get"+capitalize(getMapToName());
    }

    public String getMapFromSetterName() {
        return getSetterName();
    }

    public String getMapToSetterName() {
        return "set"+capitalize(getMapToName());
    }

    public String getMapFromName() {
        return getName();
    }

  private String capitalize(String s) {
        char chars[] = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
  }

    public String getToBBWType() {
        if(getBBWType().equals("") ||
            getBBWType().equals("String") ||
            getBBWType().equals("boolean") ||
            getBBWType().equals("int"))
            return "";

        char chars[] = getBBWType().toCharArray();
        for(int i=0;i<chars.length;i++)
            if(chars[i] == '.')
                chars[i] = '_';

        return new String(chars)+"_fromString";
    }

    public String getFromBBWType() {
        if(getBBWType().equals("") ||
            getBBWType().equals("String") ||
            getBBWType().equals("boolean") ||
            getBBWType().equals("int"))
            return "";

        char chars[] = getBBWType().toCharArray();
        for(int i=0;i<chars.length;i++)
            if(chars[i] == '.')
                chars[i] = '_';

        return new String(chars)+"_toString";
    }

    public String getJViewsType() {
        if(getType().equals("int"))
            return "Int";
        if(getType().equals("boolean"))
            return "Boolean";
        return "String";
    }

}

