package JComp;

import JViews.*;
import bbw.*;


public class JCAspectDetailIcon extends JCAspectDetailIconG {

  public JCAspectDetailIcon() {
    super();
  }
  
    public String viewRelKind() {
        return "JCAspectDetailIconToBase";
    }

    public MVViewRel newViewRel() {
        return new JCAspectDetailIconToBase();
    }

    public MVBaseComp mapComponent(boolean do_map) {

System.out.println("in AspectDetail.mapComponent()");
System.out.println(this);
System.out.println("getName() = '"+getName()+"'");

        if(getName().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getName() = '"+getName()+"'");

        JCBaseAspectInfo owner = (JCBaseAspectInfo) getOwner().baseComp();
        if(owner == null)
            return null;
            
System.out.println("adding aspect detail to "+owner.userName());

        JCBaseAspectDetail base_comp = owner.findDetailName(getName());

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = owner.addAspectDetail(getName(),getType(),isProvides());
                mapToCreatedBase(base_comp);
                return base_comp;
            }
        }
            else return base_comp;

    }

    public String userName() {
        if(hasOwner())
            return getOwner().userName()+":"+getName();
        else
            return ":"+getName();
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue)
                if(((MVSetValue) c).getPropertyName().equals("text") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for AspectDetail calling mapComponent...");
                        mapComponent(true);
                }

            return super.afterChange(c,from,rel_name);
        }

    
    public String getName() {
        char chars[] = getText().toCharArray();

        int i = 0;
        while(i < chars.length && (i == ' ' || i == '+' | i == '-'))
            i++;
        while(i < chars.length) {
            if(chars[i] == ':' || chars[i] == '=') 
                return new String(chars,0,i);
            i++;
        }
        return getText();
    }

    public String getType() {
        char chars[] = getText().toCharArray();

        int i = 0;
        while(i < chars.length && (i == ' ' || i == '+' | i == '-'))
            i++;
        while(i < chars.length) {
            if(chars[i] == ':') {
                int j = i + 1;
                while(j < chars.length) {
                    if(chars[j] == '=')
                        return new String(chars,i+1,j-i-1);
                    j++;
                }
                return new String(chars,i+1,chars.length - i - 1);
            }
            i++;
        }
        return "";
        
    }

    public boolean isProvides() {
        char chars[] = getText().toCharArray();

        int i = 0;
        while(i < chars.length) {
            if(chars[i] == '+')
                return true;
            else if(chars[i] == '-')
                return false;
            i++;
        }

        return false;
    }
    
    
}

