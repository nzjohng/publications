package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

public abstract class JCEventGlueToBaseG extends MVViewRel {

  public JCEventGlueToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Event Glue To Base Mapping";
  }

  public abstract String userName();

  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {


    if(c instanceof MVSetValue) {
      String name = ((MVSetValue) c).getPropertyName();
      if(isParent(c.target) && name.equals("Name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((JCEventGlue)e.nextElement()).setNameText(((JCBaseEvent)c.target).getName());
        }
      }
            else if(isChild(c.target) && name.equals("nameText")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((JCBaseEvent)e.nextElement()).setName(((JCEventGlue)c.target).getNameText());
        }
      }
        }
    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
System.out.println("upliftAttributes!!");
        ((JCEventGlue) vc).setNameText(((JCBaseEvent) bc).getName());
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
        ((JCBaseEvent) bc).setName(((JCEventGlue) vc).getNameText());
    }

}

