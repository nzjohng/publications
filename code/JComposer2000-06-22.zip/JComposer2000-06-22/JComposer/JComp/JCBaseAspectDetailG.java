package JComp;
import JViews.*;
import java.util.*;

public abstract class JCBaseAspectDetailG extends MVBaseComp
 {

  public JCBaseAspectDetailG() {
    super();
  }

  public String kindName() {
    return "";
  }

  public abstract String userName();


  public String getName() {
    return getStringValue("name");
  }

  public void setName(String value) {
    setValue("name",value);
  }


  public String getType() {
    return getStringValue("type");
  }

  public void setType(String value) {
    setValue("type",value);
  }


  public boolean isProvides() {
    return getBooleanValue("provides");
  }

  public void setProvides(boolean value) {
    setValue("provides",value);
  }


  public JCBaseAspectInfo getpAspectDetails() {
    return (JCBaseAspectInfo) getOneRelatedOrNull("aspectDetails",MVParents);
  }

  public void establishAspectDetails(JCBaseAspectInfo comp) {
    comp.establishAspectDetails((JCBaseAspectDetail) this);
  }

  public void dissolveAspectDetails(JCBaseAspectInfo comp) {
    comp.dissolveAspectDetails((JCBaseAspectDetail) this);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.afterChange(c,from,rel_name);
  }

}

