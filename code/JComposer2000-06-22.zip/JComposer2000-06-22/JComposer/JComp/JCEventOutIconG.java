package JComp;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class JCEventOutIconG extends MVViewComp
 {

  public JCEventOutIconG() {
    super();
  }

  public String kindName() {
    return "End Stage Icon";
  }

  public abstract String userName();


  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
    setValue("width",value);
  }


  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
    setValue("height",value);
  }


  public String getText() {
    return getStringValue("text");
  }

  public void setText(String value) {
    setValue("text",value);
  }


  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }


  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }


  public boolean isSelected() {
    return getBooleanValue("selected");
  }

  public void setSelected(boolean value) {
    setValue("selected",value);
  }


  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }


  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
      if(((MVSetValue) c).getPropertyName().equals("width"))
        getJCEventOut().setWidth((getWidth()));
      if(((MVSetValue) c).getPropertyName().equals("height"))
        getJCEventOut().setHeight((getHeight()));
      if(((MVSetValue) c).getPropertyName().equals("text"))
        getJCEventOut().setText((getText()));
      if(((MVSetValue) c).getPropertyName().equals("foreground"))
        getJCEventOut().setForeground(java_awt_Color_fromString(getForeground()));
      if(((MVSetValue) c).getPropertyName().equals("background"))
        getJCEventOut().setBackground(java_awt_Color_fromString(getBackground()));
      if(((MVSetValue) c).getPropertyName().equals("selected"))
        getJCEventOut().setSelected((isSelected()));
      if(((MVSetValue) c).getPropertyName().equals("y"))
        getJCEventOut().setY((getY()));
      if(((MVSetValue) c).getPropertyName().equals("x"))
        getJCEventOut().setX((getX()));
    }

    return super.afterChange(c,from,rel_name);
  }

  public String viewRelKind() {
    return "JCEventOutToBase";
  }

//  public MVViewRel newViewRel() {
//    return new JCEventOutToBase();
 // }


  public JCEventOut getJCEventOut() {
    return (JCEventOut) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

      if(evt.getPropertyName().equals("width"))
        setWidth((getJCEventOut().getWidth()));
      if(evt.getPropertyName().equals("height"))
        setHeight((getJCEventOut().getHeight()));
      if(evt.getPropertyName().equals("text"))
        setText((getJCEventOut().getText()));
      if(evt.getPropertyName().equals("foreground"))
        setForeground(java_awt_Color_toString(getJCEventOut().getForeground()));
      if(evt.getPropertyName().equals("background"))
        setBackground(java_awt_Color_toString(getJCEventOut().getBackground()));
      if(evt.getPropertyName().equals("selected"))
        setSelected((getJCEventOut().isSelected()));
      if(evt.getPropertyName().equals("y"))
        setY((getJCEventOut().getY()));
      if(evt.getPropertyName().equals("x"))
        setX((getJCEventOut().getX()));
    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
        setWidth((getJCEventOut().getWidth()));
        setHeight((getJCEventOut().getHeight()));
        setText((getJCEventOut().getText()));
        setForeground(java_awt_Color_toString(getJCEventOut().getForeground()));
        setBackground(java_awt_Color_toString(getJCEventOut().getBackground()));
        setSelected((getJCEventOut().isSelected()));
        setY((getJCEventOut().getY()));
        setX((getJCEventOut().getX()));
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
        if(getAttribute("width") == null)
          setWidth((getJCEventOut().getWidth()));
        else
          getJCEventOut().setWidth((getWidth()));
        if(getAttribute("height") == null)
          setHeight((getJCEventOut().getHeight()));
        else
          getJCEventOut().setHeight((getHeight()));
        if(getAttribute("text") == null)
          setText((getJCEventOut().getText()));
        else
          getJCEventOut().setText((getText()));
        if(getAttribute("foreground") == null)
          setForeground(java_awt_Color_toString(getJCEventOut().getForeground()));
        else
          getJCEventOut().setForeground(java_awt_Color_fromString(getForeground()));
        if(getAttribute("background") == null)
          setBackground(java_awt_Color_toString(getJCEventOut().getBackground()));
        else
          getJCEventOut().setBackground(java_awt_Color_fromString(getBackground()));
        if(getAttribute("selected") == null)
          setSelected((getJCEventOut().isSelected()));
        else
          getJCEventOut().setSelected((isSelected()));
        if(getAttribute("y") == null)
          setY((getJCEventOut().getY()));
        else
          getJCEventOut().setY((getY()));
        if(getAttribute("x") == null)
          setX((getJCEventOut().getX()));
        else
          getJCEventOut().setX((getX()));
  }

}

