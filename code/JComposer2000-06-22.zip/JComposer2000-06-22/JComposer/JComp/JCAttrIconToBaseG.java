package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

public abstract class JCAttrIconToBaseG extends MVViewRel {

  public JCAttrIconToBaseG() {
    super();
    establishListeners();
  }

  public String kindName() {
    return "Attr Icon To Base Mapping";
  }

  public abstract String userName();

  public void establishListeners() {
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    return super.afterChange(c,from,rel_name);
  }

    public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
    }

    public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
    }


}

