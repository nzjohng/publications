package JComp;

import JViews.*;
import bbw.*;


import java.util.*;
import java.io.*;

/*
 * hand-written Base Relationship code
 *
 */

public class JCBaseRel extends JCBaseRelG {

    public JCBaseRel() {
        super();
    }

    public JCBaseRel(MVBaseLayer base_layer) {
        super(base_layer);
    }

    public String userName() {
        return getStringValue("Name");
    }

    public String getChildrenMethodName() {
        return "getc"+getName();
    }

    public String getParentsMethodName() {
        return "getp"+getName();
    }

    public String getChildRelCompsMethodName() {
        return "getcr"+getName();
    }

    public String getParentRelCompsMethodName() {
        return "getpr"+getName();
    }

    public String getRelName() {
        if(getcParentClass().getName().equals("MVViewRel"))
            return "MVViewRel";

        return userClassName();
    }

    public JCBaseComp getcRelParent() {
        JCBaseLink l = getcrRelParent();

        if(l != null)
            return l.getpLinkParent();
        else
            return null;
    }

    public JCBaseComp getcRelChild() {
        JCBaseLink l = getcrRelChild();

        if(l != null)
            return l.getpLinkChild();
        else
            return null;
    }

    public JCBaseLink getcrRelParent() {
        Enumeration e = getcLinkChild().elements();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("parents"))
                return l;
        }

        return null;
    }

    public JCBaseLink getcrRelChild() {
        Enumeration e = getcLinkParent().elements();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("children"))
                return l;
        }

        return null;
    }

    public void printAfterChangeCode(PrintWriter output) {
        // print out mapping code if a mapping relationship is
        // attached to this relationship...
        Enumeration e = getMappings().elements();

        while(e.hasMoreElements()) {
            JCBaseComp m = (JCBaseComp) e.nextElement();

                output.println("");
                output.println("    if(c instanceof MVSetValue) {");
                output.println("      String name = ((MVSetValue)c).getPropertyName();");
                Enumeration e2 = m.getcClassAttributes().elements();

                while(e2.hasMoreElements()) {
                    JCBaseAttr map = (JCBaseAttr) e2.nextElement();

                    printUpdateChildrenAttr(output,map);
                    printUpdateParentsAttr(output,map);
                }
                output.println("    }");
            }
        super.printAfterChangeCode(output);
    }

    public Vector getMappings() {
        Vector v = new Vector();

        Enumeration e = getcLinkParent().elements();
        
        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getpLinkChild().getParentName().equals("Mapping"))
                v.addElement(l.getpLinkChild());
        }

        return v;
    }

        public void printUpdateChildrenAttr(PrintWriter output, JCBaseAttr m) {

                    output.println("      if(isParent(c.target) && name.equals("+'"'+
                        m.getMapFromName()+'"'+")) {");
                    output.println("                Enumeration e = children();");
                    output.println("        while(e.hasMoreElements()) {");
                    output.println("                    (("+getcRelChild().userClassName()+")e.nextElement())."+m.getMapToSetterName()+"((("+getcRelParent().userClassName()+")c.target)."+m.getMapFromGetterName()+"());");
                    output.println("        }");
                    output.println("      }");
        }

        public void printUpdateParentsAttr(PrintWriter output, JCBaseAttr m) {

                    output.println("            else if(isChild(c.target) && name.equals("+'"'+
                        m.getMapToName()+'"'+")) {");
                    output.println("                Enumeration e = parents();");
                    output.println("        while(e.hasMoreElements()) {");
                    output.println("                    (("+getcRelParent().userClassName()+")e.nextElement())."+m.getMapFromSetterName()+"((("+getcRelChild().userClassName()+")c.target)."+m.getMapToGetterName()+"());");
                    output.println("        }");
                    output.println("      }");
        }

    public String getEstablishChildrenMethodName() {
        return "establish"+getName();
    }

    public String getDissolveChildrenMethodName() {
        return "dissolve"+getName();
    }

  private String capitalize(String s) {
        char chars[] = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
  }

    public String getRelParentArity() {
        JCBaseLink l = getcrRelParent();    
        
        if(l != null)
            return l.getChildArity();
        else
            return "";
    }

    public String getRelChildArity() {
        JCBaseLink l = getcrRelChild(); 

        if(l != null)
            return l.getParentArity();
        else
            return "";
    }

    public String getParentArity() {
        JCBaseLink l = getcrRelParent();

        if(l != null)
            return l.getParentArity();
        else
            return "";
    }

    public String getChildArity() {
        JCBaseLink l = getcrRelChild();

        if(l != null)
            return l.getChildArity();
        else
            return "";

    }

    public void printOtherCode(PrintWriter output) {

        // print mapping code
        if(getParentName().equals("MVViewRel")) {  
            output.println("");
            output.println("  public String viewRelKind() {");
            output.println("    return "+'"'+userClassName()+'"'+";");
            output.println("  }");
            output.println("");

            output.println("  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {");


            Enumeration e1 = getMappings().elements();

            while(e1.hasMoreElements()) {
                JCBaseComp m = (JCBaseComp) e1.nextElement();
                Enumeration e2 = m.getcClassAttributes().elements();

                while(e2.hasMoreElements()) {
                    JCBaseAttr map = (JCBaseAttr) e2.nextElement();
                    output.println("  (("+getcRelChild().userClassName()+")vc)."+map.getMapToSetterName()+"((("+getcRelParent().userClassName()+")bc)."+map.getMapFromGetterName()+"());");
                }
            }

            output.println("  }");
            output.println("");

            output.println("  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {");
            Enumeration e3 = getMappings().elements();

            while(e3.hasMoreElements()) {
                JCBaseComp m = (JCBaseComp) e3.nextElement();
                Enumeration e4 = m.getcClassAttributes().elements();

                while(e4.hasMoreElements()) {
                    JCBaseAttr map = (JCBaseAttr) e4.nextElement();
                    output.println("  (("+getcRelParent().userClassName()+")bc)."+map.getMapFromSetterName()+"((("+getcRelChild().userClassName()+")vc)."+map.getMapToGetterName()+"());");
                }
            }

            output.println("  }");
            output.println("");

            output.println("  public MVViewRel newViewRel() {");
            output.println("    return new "+userClassName()+"();");
            output.println("  }");
            output.println("");
            output.println("  public String getViewRelKind() {");
            output.println("    return "+'"'+userClassName()+'"'+";");
            output.println("  }");
            output.println("");        
        }
        
        // set up listening 
        // (replace with afterChange code to do this...)    
    
        JCBaseLink parents = getcrRelParent();
        JCBaseLink children = getcrRelChild();
            
        output.println("");
        output.println("  public void establish(MVComponent parent, MVComponent child) {");
        output.println("    super.establish(parent,child);");
        if(isAggregate())
            output.println("    setAggregate(true);");
        
        if(parents.isAggregate())
            output.println("    parent.setAggregateRel("+'"'+getRelName()+'"'+");");    
    
        if(parents.isParentListenBefore())
            output.println("    setListenBeforeRel("+'"'+"+parents"+'"'+");");
        if(parents.isParentListenAfter())
            output.println("    setListenAfterRel("+'"'+"+parents"+'"'+");");
        if(parents.isParentHandleBefore())
            output.println("    setHandleBeforeRel("+'"'+"+parents"+'"'+");");
        if(parents.isParentHandleAfter())
            output.println("    setHandleAfterRel("+'"'+"+parents"+'"'+");");
    
        if(parents.isChildListenBefore())
            output.println("    parent.setListenBeforeRel(getRelName());");
        if(parents.isChildListenAfter())
            output.println("    parent.setListenAfterRel(getRelName());");
        if(parents.isChildHandleBefore())
            output.println("    parent.setHandleBeforeRel(getRelName());");
        if(parents.isChildHandleAfter())
            output.println("    parent.setHandleAfterRel(getRelName());");
        
        if(children.isParentListenBefore())
            output.println("    child.setListenBeforeRel(getRelName());");
        if(children.isParentListenAfter())
            output.println("    child.setListenAfterRel(getRelName());");
        if(children.isParentHandleBefore())
            output.println("    child.setHandleBeforeRel(getRelName());");
        if(children.isParentHandleAfter())
            output.println("    child.setHandleAfterRel(getRelName());");
    
        if(children.isChildListenBefore())
            output.println("    setListenBeforeRel("+'"'+"+children"+'"'+");");
        if(children.isChildListenAfter())
            output.println("    setListenAfterRel("+'"'+"+children"+'"'+");");
        if(children.isChildHandleBefore())
            output.println("    setHandleBeforeRel("+'"'+"+children"+'"'+");");
        if(children.isChildHandleAfter())
            output.println("    setHandleAfterRel("+'"'+"+children"+'"'+");");      
        
        output.println("  }");
        output.println("");
       
    }



}

