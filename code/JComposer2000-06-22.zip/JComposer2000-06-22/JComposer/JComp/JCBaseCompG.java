package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseCompG extends JCBaseClass {

    /* Constructors */

    public JCBaseCompG() {
        super();
    }

    public JCBaseCompG(MVBaseLayer base_layer) {
    super(base_layer);
    }

    /* Attributes */

    public String getKindName() {
        return getStringValue("KindName");
    }

    public void setKindName(String value) {
        setValue("KindName",value);
    }

    public boolean isGenerateCode() {
        return getBooleanValue("GenerateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("GenerateCode",value);
    }

    public String getShapeName() {
    return getStringValue("ShapeName");
    }

    public void setShapeName(String value) {
        setValue("ShapeName",value);
    }
    
    public String getPrefix() {
        return getStringValue("prefix");
    }
    
    public void setPrefix(String value)
    {
        setValue("prefix",value);
    }

    /* Relationships */

    public JCBaseLayer getpBaseComps() {
        return (JCBaseLayer) getOneRelated("BaseComps",MVParents);
    }

    public JCBaseComps getpcBaseComps() {
        return (JCBaseComps) getOneRelated("BaseComps",MVParentRelComps);
    }
    
    public Vector getcAspectInfo() {
        return getRelationship("AspectInfo",MVChildren);
    }
    
    public void establishAspectInfo(JCBaseAspectInfo comp)
    {
        establishOneToMany("AspectInfo",comp);
    }

    public Vector getcLinkParent() {
        return getRelationship("LinkParent",MVChildren);
    }

    public void establishLinkParent(JCBaseLink comp) {
        establishOneToMany("LinkParent",comp);
        comp.setListenBeforeRel("LinkParent");
        comp.setListenAfterRel("LinkParent");
    }

    public Vector getcLinkChild() {
        return getRelationship("LinkChild",MVChildren);
    }

    public void establishLinkChild(JCBaseLink comp) {
        establishOneToMany("LinkChild",comp);
        comp.setListenBeforeRel("LinkChild");
        comp.setListenAfterRel("LinkChild");
    }

    public void establishEventParent(JCBaseEvent comp) {
        establishOneToMany("EventParent",comp);
        comp.setListenBeforeRel("EventParent");
        comp.setListenAfterRel("EventParent");
    }

    public Vector getcEventParent() {
        return getRelationship("EventParent",MVChildren);
    }

    public void establishEventChild(JCBaseEvent comp) {
        establishOneToMany("EventChild",comp);
        comp.setListenBeforeRel("EventChild");
        comp.setListenAfterRel("EventChild");
    }

    public Vector getcEventChild() {
        return getRelationship("EventChild",MVChildren);
    }

    /* Methods */

    // listen before/after methods - abstract??

    public String kindName() {
        return "Base Component";
    }

    /* Read/write methods */


}

