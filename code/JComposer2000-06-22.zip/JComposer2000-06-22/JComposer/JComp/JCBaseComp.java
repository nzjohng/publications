
package JComp;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import java.io.*;
import java.lang.reflect.*;

/*
 * hand-written Base Component code
 *
 */

public class JCBaseComp extends JCBaseCompG {

    public JCBaseComp() {
        super();
    }

    public JCBaseComp(MVBaseLayer base_layer) {
        super(base_layer);
    }
    
      
  public MVVersionRecord newVersionRecord()
  {
    MVVersionRecord versionRecord = super.newVersionRecord();
    versionRecord.setSaveChanges(true);
    
    return versionRecord;
  }

    public String genClassName() {
        return userClassName()+"G";
    }

    public String userClassName() {
        return getClassPrefix()+getName();
    }

    public void generateClass(String path) {
        // generate component class text...

        if(!isGenerateCode())
            return;

        System.out.println("Generating classes for "+getName());

        try {
            FileOutputStream genFile = new FileOutputStream(new File(path,genClassName()+".java"));
            PrintWriter genOutput = new PrintWriter(new BufferedOutputStream(genFile,1024));

            printClassHeader(genOutput);
            printClassConstructors(genOutput);
            printClassNames(genOutput);
            printClassAttributes(genOutput);
            printClassLinkRels(genOutput);
            printClassRelationships(genOutput);
            // user-defined methods
            // persistency
            printBeforeChange(genOutput);
            printAfterChange(genOutput);
            printOtherCode(genOutput);
            printClassEnd(genOutput);

            genOutput.flush();
            genFile.close();
        } catch(IOException e) {
                throw(new MVFatalException("can't open file "+genClassName()+".java for writing"));
        }

        try {
            FileInputStream checkFile = new FileInputStream(new File(path,userClassName()+".java"));
            checkFile.close();
        } catch(FileNotFoundException e) {
            try {
                FileOutputStream userFile = new FileOutputStream(new File(path,userClassName()+".java"));
                PrintWriter userOutput = new PrintWriter(userFile);

                printUserClass(userOutput);

                userOutput.flush();
                userFile.close();
            } catch(IOException e2) {
                    throw(new MVFatalException("can't open file "+userClassName()+".java for writing"));
            }
        } catch(IOException e) {
            throw(new MVFatalException("Error while trying to open "+userClassName()+".java"));
        }

        if(isViewClass()) {
        try {
            FileInputStream checkFile = new FileInputStream(new File(path,panelClassName()+".java"));
            checkFile.close();
        } catch(FileNotFoundException e) {
            try {
                FileOutputStream panelFile = new FileOutputStream(new File(path,panelClassName()+".java"));
                PrintWriter panelOutput = new PrintWriter(panelFile);

                printUserPanelClass(panelOutput);

                panelOutput.flush();
                panelFile.close();
            } catch(IOException e2) {
                    throw(new MVFatalException("can't open file "+panelClassName()+".java for writing"));
            }
        } catch(IOException e) {
            throw(new MVFatalException("Error while trying to open "+panelClassName()+".java"));
        }

            try {
                FileOutputStream panelFile = new FileOutputStream(new File(path,panelClassName()+"G.java"));
                PrintWriter panelOutput = new PrintWriter(panelFile);

                printPanelClass(panelOutput);

                panelOutput.flush();
                panelFile.close();
            } catch(IOException e2) {
                    throw(new MVFatalException("can't open file "+panelClassName()+"G.java for writing"));
            }

        }

    }
    
    public String getPackage()
    {
        return ((JCBaseLayer) getBaseLayer()).getPackage();
    }

    public void printClassHeader(PrintWriter output) {
        output.println("package "+getPackage()+";");
                                        
        output.println("import JViews.*;");
        output.println("import java.util.*;");

        if(isBBWShape() || isViewClass()) {
            output.println("import java.awt.*;");
            output.println("import bbw.*;");
            output.println("import java.beans.*;");
            if(!getBBWPackageName().equals("")) 
                output.println("import "+getBBWPackageName()+".*;");
        }

        output.println("");
        output.println("public abstract class "+genClassName()+" extends "+parentClassName());

        if(isViewClass())
            output.println(" implements BBWTransactionListener, PropertyChangeListener, "+getBBWPrefix()+"Listener");
        
        output.println(" {");
    }

    public void printClassConstructors(PrintWriter output) {
        // write zero-arg constructor
        output.println("");
        output.println("  public "+genClassName()+"() {");
        output.println("    super();");
        output.println("  }");

        if(isViewClass()) {
            output.println("");
            output.println("  public "+genClassName()+"(MVBaseLayer base, String name) {");
            output.println("    super(base,name);");
            output.println("  }");
        }

        // write multi-arg constructor(s)
        Enumeration e = getcClassMethods().elements();

        while(e.hasMoreElements()) {
            JCBaseMethod m = (JCBaseMethod) e.nextElement();
            if(m.getName() == getName()) {
                output.println("");
                output.println("  public "+genClassName()+"("+m.fullArgs()+") {");
                output.println("    super("+m.argNames()+");");
                printInitAttributes(output);
                printInitRelationships(output);
                output.println("  }");
            }
        }
    }

    public void printClassEnd(PrintWriter output) {
        output.println("}");
        output.println("");
    }

    public void printClassNames(PrintWriter output) {
        output.println("");
        output.println("  public String kindName() {");
        output.println("    return "+'"'+getKindName()+'"'+";");
        output.println("  }");
        output.println("");
        output.println("  public abstract String userName();");
        output.println("");
    }

    public void printUserClass(PrintWriter output) {
        // need to check if user class already exists...

        output.println("package "+getPackage()+";");
        output.println("");
        output.println("import JViews.*;");
        output.println("");
        output.println("public class "+userClassName()+" extends "+genClassName()+" {");
        output.println("");
        output.println("  public "+userClassName()+"() {");
        output.println("    super();");
        output.println("  }");
        output.println("");

        if(isViewClass()) {
            output.println("  public "+userClassName()+"(MVBaseLayer base, String name) {");
            output.println("    super(base,name);");
            output.println("  }");
        }

        output.println("");
        output.println("  public String userName() {");
        output.println("    return "+'"'+"*unknown*"+'"'+";");
        output.println("  }");
        output.println("");
        output.println("}");
        output.println("");

    }

    public void printClassAttributes(PrintWriter output) {
        Enumeration e = getcClassAttributes().elements();

        while(e.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr)e.nextElement();

            output.println("");
            output.println("  public "+a.getType()+" "+a.getGetterName()+"() {");
            output.println("    return get"+a.getJViewsType()+"Value("+'"'+a.getName()+'"'+");");
            output.println("  }");
            output.println("");
            output.println("  public void "+a.getSetterName()+"("+a.getType()+" value) {");
            output.println("    setValue("+'"'+a.getName()+'"'+",value);");
            output.println("  }");
            output.println("");
        }
    }

    public void printInitAttributes(PrintWriter output) {
        Enumeration e = getcClassAttributes().elements();

        output.println("");

        while(e.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr)e.nextElement();
            output.println("    set"+a.getName()+"(MV"+a.getJViewsType()+"Blank);");
        }
    }

    public void printClassLinkRels(PrintWriter output) {
        Enumeration e1 = getcLinkParent().elements();
    
        output.println("");

        while(e1.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink)e1.nextElement();
            if(!l.isGenerateCode())
                continue;
                
            if(l.getName().equals("parents") && l.getpLinkChild() instanceof JCBaseRel)
                continue; // is a relationship's parent link
            
            if(l.getName().equals("children") && this instanceof JCBaseRel)
                continue;
            
            if(l.getParentArity().equals("1:1") || l.getParentArity().equals("0:1")) {

                if(l.getParentArity().equals("0:1")) {
                    output.println("  public "+l.getpLinkChild().userClassName()+" "+l.getChildrenMethodName()+"() {");
                    output.println("    return ("+l.getpLinkChild().userClassName()+") getOneRelatedOrNull("+'"'+l.getName()+'"'+",MVChildren);");
                output.println("  }");
                } else {
                    output.println("  public "+l.getpLinkChild().userClassName()+" "+l.getChildrenMethodName()+"() {");
                    output.println("    return ("+l.getpLinkChild().userClassName()+") getOneRelated("+'"'+l.getName()+'"'+",MVChildren);");
                output.println("  }");
                }
              output.println("");
                // may want to generate code to ENSURE 1:1 rel...
                output.println("  public void "+l.getEstablishChildrenMethodName()+"("+l.getpLinkChild().userClassName()+" comp) {");
                output.println("    establishOneToMany("+'"'+l.getName()+'"'+",comp);");
                printParentLinkListenerCode(output,l);
                output.println("  }");
                output.println("");
                output.println("  public void "+l.getDissolveChildrenMethodName()+"("+l.getpLinkChild().userClassName()+" comp) {");
                output.println("    dissolveOneToMany("+'"'+l.getName()+'"'+",comp);");
                output.println("  }");
                output.println("");
            } else {
                output.println("  public Vector "+l.getChildrenMethodName()+"() {");
                output.println("    return getRelationship("+'"'+l.getName()+'"'+",MVChildren);");
              output.println("  }");
              output.println("");
                output.println("  public void "+l.getEstablishChildrenMethodName()+"("+l.getpLinkChild().userClassName()+" comp) {");
                output.println("    establishOneToMany("+'"'+l.getName()+'"'+",comp);");
                printParentLinkListenerCode(output,l);
                output.println("  }");
                output.println("");
                output.println("  public void "+l.getDissolveChildrenMethodName()+"("+l.getpLinkChild().userClassName()+" comp) {");
                output.println("    dissolveOneToMany("+'"'+l.getName()+'"'+",comp);");
                output.println("  }");
                output.println("");
            }
        }   

        Enumeration e2 = getcLinkChild().elements();

        while(e2.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink)e2.nextElement();
            if(!l.isGenerateCode())
                continue;

            if(l.getName().equals("children") && l.getpLinkParent() instanceof JCBaseRel)
                continue; // is a relationship's parent link
                
            if(l.getName().equals("parents") && this instanceof JCBaseRel)
                continue;
            
               // what if m:n - should these be allowed???

            if(l.getChildArity().equals("0:1") || l.getChildArity().equals("1:1")) {
                if(l.getChildArity().equals("0:1")) {
                    output.println("  public "+l.getpLinkParent().userClassName()+" "+l.getParentsMethodName()+"() {");
                    output.println("    return ("+l.getpLinkParent().userClassName()+") getOneRelatedOrNull("+'"'+l.getName()+'"'+",MVParents);");
                output.println("  }");
                } else {
                    output.println("  public "+l.getpLinkParent().userClassName()+" "+l.getParentsMethodName()+"() {");
                    output.println("    return ("+l.getpLinkParent().userClassName()+") getOneRelated("+'"'+l.getName()+'"'+",MVParents);");
                output.println("  }");
                }
                if(l.getpLinkParent() != this) {
                    // make sure not linked to self so don't
                    // get duplicate est/dissolve!
                    output.println("");
                    output.println("  public void "+l.getEstablishChildrenMethodName()+"("+l.getpLinkParent().userClassName()+" comp) {");
                    output.println("    comp."+l.getEstablishChildrenMethodName()+"(("+userClassName()+") this);");
                    output.println("  }");
                    output.println("");
                    output.println("  public void "+l.getDissolveChildrenMethodName()+"("+l.getpLinkParent().userClassName()+" comp) {");
                    output.println("    comp."+l.getDissolveChildrenMethodName()+"(("+userClassName()+") this);");
                    output.println("  }");
                    output.println("");
                }
            } else {
                output.println("  public Vector "+l.getParentsMethodName()+"() {");
                output.println("    return getRelationship("+'"'+l.getName()+'"'+",MVParents);");
                output.println("  }");
                output.println("");
                if(l.getpLinkParent() != this) {
                    output.println("  public void "+l.getEstablishChildrenMethodName()+"("+l.getpLinkParent().userClassName()+" comp) {");
                    output.println("    comp."+l.getEstablishChildrenMethodName()+"(("+userClassName()+") this);");
                    output.println("  }");
                    output.println("");
                    output.println("  public void "+l.getDissolveChildrenMethodName()+"("+l.getpLinkParent().userClassName()+" comp) {");
                    output.println("    comp."+l.getDissolveChildrenMethodName()+"(("+userClassName()+") this);");
                    output.println("  }");
                    output.println("");
                }
            }
        }
    }
    
    public void printParentLinkListenerCode(PrintWriter output, JCBaseLink l)
    {
        if(l.isAggregate())
            output.println("    setAggregateRel("+'"'+l.getName()+'"'+");");    
    
        if(l.isParentListenBefore())
            output.println("    comp.setListenBeforeRel("+'"'+l.getName()+'"'+");");
        if(l.isParentListenAfter())
            output.println("    comp.setListenAfterRel("+'"'+l.getName()+'"'+");");
        if(l.isParentHandleBefore())
            output.println("    comp.setHandleBeforeRel("+'"'+l.getName()+'"'+");");
        if(l.isParentHandleAfter())
            output.println("    comp.setHandleAfterRel("+'"'+l.getName()+'"'+");");
    
        if(l.isChildListenBefore())
            output.println("    setListenBeforeRel("+'"'+l.getName()+'"'+");");
        if(l.isChildListenAfter())
            output.println("    setListenAfterRel("+'"'+l.getName()+'"'+");");
        if(l.isChildHandleBefore())
            output.println("    setHandleBeforeRel("+'"'+l.getName()+'"'+");");
        if(l.isChildHandleAfter())
            output.println("    setHandleAfterRel("+'"'+l.getName()+'"'+");");
            
    }   
   
    public Vector getpRelParent() {
        Enumeration e = getcLinkParent().elements();
        Vector rels = new Vector();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("parents") && l.getpLinkChild() instanceof JCBaseRel)
                rels.addElement(l.getpLinkChild());
        }

        return rels;
    }

    public Vector getpRelChild() {
        Enumeration e = getcLinkChild().elements();
        Vector rels = new Vector();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("children") && l.getpLinkParent() instanceof JCBaseRel)
                rels.addElement(l.getpLinkParent());
        }

        return rels;
    }


    public void printClassRelationships(PrintWriter output) {
        Enumeration e1 = getpRelParent().elements();

        while(e1.hasMoreElements()) {
            JCBaseRel r = (JCBaseRel)e1.nextElement();
            if(!r.isGenerateCode())
                continue;

            if(r.getParentArity().equals("0:1") || r.getParentArity().equals("1:1")) {
                output.println("  public "+r.userClassName()+" "+r.getChildRelCompsMethodName()+"() {");
                output.println("    return ("+r.userClassName()+") getOneRelated("+'"'+r.getRelName()+'"'+",MVChildRelComps);");
                output.println("  }");
                output.println("");
                output.println("  public void "+r.getEstablishChildrenMethodName()+"("+r.getcRelChild().userClassName()+" comp) {");
                output.println("    getcr"+r.getName()+"().establish(this,comp);");
                output.println("  }");
                output.println("");
                output.println("  public void "+r.getDissolveChildrenMethodName()+"("+r.getcRelChild().userClassName()+" comp) {");
                output.println("    getcr"+r.getName()+"().dissolve(this,comp);");
                output.println("  }");
                output.println("");
            } else {
                output.println("  public Vector "+r.getChildRelCompsMethodName()+"() {");
                output.println("    return getRelationship("+'"'+r.getRelName()+'"'+",MVChildRelComps);");
                output.println("  }");
                output.println("");
            }

            if((r.getParentArity().equals("0:1") || r.getParentArity().equals("1:1")) && 
                (r.getRelChildArity().equals("0:1") || r.getRelChildArity().equals("1:1"))) {
                output.println("  public "+r.getcRelChild().userClassName()+" "+r.getChildrenMethodName()+"() {");
                output.println("    return ("+r.getcRelChild().userClassName()+") getOneRelated("+'"'+r.getRelName()+'"'+",MVChildren);");
                output.println("  }");
                output.println("");
            } else {
                output.println("  public Vector "+r.getChildrenMethodName()+"() {");
                output.println("    return getRelationship("+'"'+r.getRelName()+'"'+",MVChildren);");
                output.println("  }");
                output.println("");
            }
        }

        Enumeration e2 = getpRelChild().elements();

        while(e2.hasMoreElements()) {
            JCBaseRel r = (JCBaseRel)e2.nextElement();
            if(!r.isGenerateCode())
                continue;

            if(r.getChildArity().equals("0:1") || r.getChildArity().equals("1:1")) {
                output.println("  public "+r.userClassName()+" "+r.getParentRelCompsMethodName()+"() {");
                output.println("    return ("+r.userClassName()+") getOneRelated("+'"'+r.getRelName()+'"'+",MVParentRelComps);");
                output.println("  }");
                output.println("");
                output.println("  public void "+r.getEstablishChildrenMethodName()+"("+r.getcRelParent().userClassName()+" comp) {");
                output.println("    comp."+r.getEstablishChildrenMethodName()+"(("+userClassName()+") this);");
                output.println("  }");
                output.println("");
                output.println("  public void "+r.getDissolveChildrenMethodName()+"("+r.getcRelParent().userClassName()+" comp) {");
                output.println("    comp."+r.getDissolveChildrenMethodName()+"(("+userClassName()+") this);");
                output.println("  }");
                output.println("");
            } else {
                output.println("  public Vector "+r.getParentRelCompsMethodName()+"() {");
                output.println("    return getRelationship("+'"'+r.getRelName()+'"'+",MVParentRelComps);");
                output.println("  }");
                output.println("");
            }
            if((r.getChildArity().equals("0:1") || r.getChildArity().equals("1:1")) &&
                (r.getRelParentArity().equals("0:1") || r.getRelParentArity().equals("1:1"))) {
                output.println("  public "+r.getcRelParent().userClassName()+" "+r.getParentsMethodName()+"() {");
                output.println("    return ("+r.getcRelParent().userClassName()+") getOneRelated("+'"'+r.getRelName()+'"'+",MVParents);");
                output.println("  }");
                output.println("");
            } else {
                output.println("  public Vector "+r.getParentsMethodName()+"() {");
                output.println("    return getRelationship("+'"'+r.getRelName()+'"'+",MVParents);");
                output.println("  }");
                output.println("");
            }
        }

    }
    
    public void printInitRelationships(PrintWriter output) {
        // generate code to initialise relationship components
        // and possibly to create linked components (for e.g. listeners)


    }

    public void copyParentConstructors() {
        // copy all constructor methods from parent class and rename 
        // so method name = this class name...


    }

    public void printBeforeChange(PrintWriter output) {
        output.println("  public MVChangeDescr beforeChange(MVChangeDescr c,");
        output.println("      MVComponent from, String rel_name) {");
        printBeforeChangeCode(output);
        output.println("    return super.beforeChange(c,from,rel_name);");
        output.println("  }");
        output.println("");
    }

    public void printAfterChange(PrintWriter output) {
        output.println("  public MVChangeDescr afterChange(MVChangeDescr c,");
        output.println("      MVComponent from, String rel_name) {");
        printAfterChangeCode(output);
        output.println("    return super.afterChange(c,from,rel_name);");
        output.println("  }");
        output.println("");
    }

    public void printOtherCode(PrintWriter output) {

        Enumeration e = getpRelChild().elements();
        while(e.hasMoreElements()) {
            JCBaseRel r = (JCBaseRel) e.nextElement();
            if(r.getParentName().equals("MVViewRel")) {
                output.println("  public String viewRelKind() {");
                output.println("    return "+'"'+r.userClassName()+'"'+";");
                output.println("  }");
                output.println("");
                output.println("  public MVViewRel newViewRel() {");
                output.println("    return new "+r.userClassName()+"();");
                output.println("  }");
                output.println("");
            }
        }


        // if BBW Shape interface, print shape getter

        if(isBBWShape()) {
            printBBWCode(output);
        }

        if(isViewClass())
            printViewCode(output);
    }

    public boolean isBBWShape() {
        if(getShapeName().equals(""))
            return false;
        else
            return true;
    }
    
    public String getClassPrefix()
    {
          return getpBaseComps().getPrefix();
    }

    public String getBBWPrefix() {
        String prefix = getPrefix();
        
        if(prefix.equals("")) {
            if(getViewLayer() != null)  {
                prefix = getViewLayer().getPrefix();
                if(!prefix .equals(""))
                    return prefix;
            }
            return getpBaseComps().getPrefix();
        }
            
        return prefix;
    }

    public String getBBWShapeClassName() {
        char chars[] = getShapeName().toCharArray();
        
        int i = 0;

        for(i = chars.length - 1; i>0; i--)
            if(chars[i] == '.')
                return new String(chars,i+1,chars.length - i - 1);

        return getShapeName();
    }

    public String getBBWPackageName() {
        char chars[] = getShapeName().toCharArray();

        int i = 0;

        for(i= chars.length - 1; i>0; i--)
            if(chars[i] == '.')
                return new String(chars,0,i);

        return "";
    }

    public JCBaseLink findParentLink(String name, JCBaseComp child) {
        Enumeration e1 = getcLinkParent().elements();

        while(e1.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink)e1.nextElement();

            if(l.getName().equals(name) && l.getpLinkChild() == child)
                return l;
        }

        return null;
    }

    public JCBaseLink findChildLink(String name, JCBaseComp parent) {
        Enumeration e2 = getcLinkChild().elements();

        while(e2.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink)e2.nextElement();
            if(l.getName().equals(name) && l.getpLinkParent() == parent)
                return l;
        }

        return null;
    }

    public JCBaseEvent findParentEvent(String name) {
        Enumeration e1 = getcEventParent().elements();

        while(e1.hasMoreElements()) {
            JCBaseEvent l = (JCBaseEvent)e1.nextElement();
            if(l.getName().equals(name))
                return l;
        }

        return null;
    }

    public JCBaseEvent findChildEvent(String name) {
        Enumeration e2 = getcEventChild().elements();

        while(e2.hasMoreElements()) {
            JCBaseEvent l = (JCBaseEvent)e2.nextElement();
            if(l.getName().equals(name))
                return l;
        }

        return null;
    }

    public void addBBWAttribute(String name, String type) {
        String jtype = type;

        if(!type.equals("int") && !type.equals("boolean"))
            jtype = "String";

        JCBaseAttr attr = new JCBaseAttr(getBaseLayer());
        attr.setName(name);
        attr.setType(jtype);
        attr.setMapToName("");
        attr.setBBWType(type);
        establishClassAttributes(attr);
    }

    public void printAfterChangeCode(PrintWriter output) {
        // print mappings to BBW shapes
        if(isBBWShape() && !isViewClass()) {
            output.println("");
            output.println("    if(c instanceof MVSetValue && getBBWShape() != null) {");
    
            Enumeration e1 = getcClassAttributes().elements();
    
            while(e1.hasMoreElements()) {
                JCBaseAttr a = (JCBaseAttr) e1.nextElement();
                output.println("      if(((MVSetValue) c).getPropertyName().equals("+'"'+
                    a.getName()+'"'+"))");
                output.println("        get"+getBBWShapeClassName()+"()."+a.getSetterName()+"("+a.getToBBWType()+"("+ a.getGetterName()+"()));");
            }
    
            output.println("    }");
            output.println("");
        }
        
        // print view event handling code
        if(isViewClass())
            printViewAfterChangeCode(output);
   
        // should add code to handle relationship init using EstablishRel
        // and EstablishOneToMany events...
    
    }

    public void printBeforeChangeCode(PrintWriter output) {

    }

    public void printBBWCode(PrintWriter output) {

        if(isViewClass())
            return;

        //print BBW shape interfacing code...

        output.println("");
        output.println("  public "+getBBWShapeClassName()+" get"+getBBWShapeClassName()+"() {");
        output.println("    return ("+getBBWShapeClassName()+") getBBWShape();");
        output.println("  }");
        output.println("");

        output.println("");

        output.println("");
        output.println("  public void propertyChange(PropertyChangeEvent evt) {");

        output.println("    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {");
      output.println("      super.propertyChange(evt);");
        output.println("      return;");
        output.println("    }");
        output.println("");

        Enumeration e2 = getcClassAttributes().elements();

        while(e2.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e2.nextElement();
            output.println("      if(evt.getPropertyName().equals("+'"'+
                a.getName()+'"'+"))");
            output.println("        "+a.getSetterName()+"("+a.getFromBBWType()+"(get"+getBBWShapeClassName()+"()."+ a.getGetterName()+"()));");
        }

        output.println("    super.propertyChange(evt);");
        output.println("  }");
        output.println("");
        output.println("  public void addedBBWShape(BBWComponent  shape) {");
        output.println("    super.addedBBWShape(shape);");

        Enumeration e3 = getcClassAttributes().elements();

        while(e3.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e3.nextElement();
            output.println("        "+a.getSetterName()+"("+a.getFromBBWType()+"(get"+getBBWShapeClassName()+"()."+ a.getGetterName()+"()));");
        }

        output.println("  }");
        output.println("");

        output.println("  public void addedViewComp(BBWComponent  shape) {");
        output.println("    super.addedViewComp(shape);");

        Enumeration e4 = getcClassAttributes().elements();

        while(e4.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e4.nextElement();
            output.println("        if(getAttribute("+'"'+a.getName()+'"'+") == null)");
            output.println("          "+a.getSetterName()+"("+a.getFromBBWType()+"(get"+getBBWShapeClassName()+"()."+ a.getGetterName()+"()));");
            output.println("        else");
            output.println("          get"+getBBWShapeClassName()+"()."+a.getSetterName()+"("+a.getToBBWType()+"("+ a.getGetterName()+"()));");
        }

        output.println("  }");
        output.println("");

    }
    
    MVChangeDescr store = null;
    
    public MVChangeDescr beforeChange(MVChangeDescr c, MVComponent from, String rel) {
    
        if(store == null)
            store = c;
    
        return super.beforeChange(c,from,rel);
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel) {

        //if(c instanceof MVSetStringValue) {
            //if(((MVSetStringValue) c).getPropertyName().equals("ShapeName"))
            //    if(!getShapeName().equals(""))
            //        getShapeProperties();               
        //}

        if(c == store) {
            store = null;
            storeChange(c);            
        }

        return super.afterChange(c,from,rel);
    }

    public JCBaseAttr addAttribute(String name, String type, String map_to) {
        JCBaseAttr a = new JCBaseAttr(getBaseLayer());
        a.setName(name);
        a.setType(type);
        a.setMapToName(map_to);
        establishClassAttributes(a);
        return a;
    }

    public void printViewCode(PrintWriter output) {
        output.println("");
        output.println("  public void createFrame() {");
        output.println("    frame = new "+panelClassName()+"(this);");

output.println("    MVViewCollabMenu collab = (MVViewCollabMenu) getOneRelatedOrNull("+'"'+"collabMenu"+'"'+",MVParents);");
output.println("    if(collab == null) {");
output.println("      collab = new MVViewCollabMenu();");
output.println("      collab.establishOneToMany("+'"'+"collabMenu"+'"'+",this);");
output.println("    }");
output.println("    collab.addedView(this);");

        output.println("  }");
        output.println("");
  
    output.println("  public void "+changeMethodName()+"("+changeEventName()+" evt) {");
    output.println("    if(!processingJViewsChange)");
        output.println("      processBBWEvent(evt);");
        output.println("  }");
        output.println("");

        output.println("  public void processBBWEvent(EventObject evt) {");
        output.println("    if(inBBWTransaction() && !processingBBWEvents) {");
        output.println("      super.processBBWEvent(evt);");
        output.println("      return;");
        output.println("    }");
        output.println("");
        output.println("    boolean oldChange = startBBWChange();");
        output.println("");
        output.println("    if(evt instanceof "+changeEventName()+") {");
        output.println("");

        Enumeration e = getViewComponents().elements();
        while(e.hasMoreElements()) {
            JCBaseComp c = (JCBaseComp) e.nextElement();

            if(c.getParentName().equals("MVViewComp")) {
                output.println("      if(evt instanceof "+c.getNewShapeEventName()+") {");
                output.println("        startMacroChange(new MVMacroChangeDescr(this,"+'"'+"Add "+c.getKindName()+'"'+"));");
                output.println("        "+c.userClassName()+" new_comp = new "+c.userClassName()+"();");
                output.println("        new_comp.init(this);");
                output.println("        new_comp.addedBBWShape((("+c.getNewShapeEventName()+") evt).get"+c.getUnprefixedShapeName()+"());");
                output.println("        new_comp.showPropertySheet();");
                output.println("        endMacroChange();");
                output.println("     }");
            } else if(c.getParentName().equals("MVOneToOneGlue")) {
                output.println("      if(evt instanceof "+c.getNewShapeEventName()+") {");
                output.println("        startMacroChange(new MVMacroChangeDescr(this,"+'"'+"Add "+c.getKindName()+'"'+"));");
                output.println("        "+c.userClassName()+" new_comp = new "+c.userClassName()+"();");
                
                output.println("        MVViewComp p = findBBWViewComp((("+c.getNewShapeEventName()+") evt).get"+c.getUnprefixedShapeName()+"().getFrom().getOwner());");
                output.println("        MVViewComp c = findBBWViewComp((("+c.getNewShapeEventName()+") evt).get"+c.getUnprefixedShapeName()+"().getTo().getOwner());");
                output.println("        new_comp.init(this,p,c);");
                output.println("        new_comp.addedBBWShape((("+c.getNewShapeEventName()+") evt).get"+c.getUnprefixedShapeName()+"());");
                output.println("        new_comp.showPropertySheet();");
                output.println("        endMacroChange();");
                output.println("     }");
            } else if(c.getParentName().equals("MVSubIcon")) {

            }

        }

/*

          if(jcevt instanceof JCNewElementEvent) {
System.out.println("Adding new element to component...");
              startMacroChange(new MVMacroChangeDescr(this,"Add Element"));
              JCAttrIcon new_comp = new JCAttrIcon();
                ((TextFieldShape) ((JCNewElementEvent) jcevt).getElement()).setFont(new Font("Helvetica",0,8));
              new_comp.addedBBWShape(((JCNewElementEvent) jcevt).getElement());
              new_comp.init(this);
                MVViewComp comp_icon = findBBWViewComp((BBWComponent) ((JCNewElementEvent) jcevt).getSource());
System.out.println("adding new element to "+comp_icon.userName());
                new_comp.setOwner(comp_icon);
              endMacroChange();
          }

*/

        output.println("    }");
        output.println("    if(!oldChange)");
        output.println("      endBBWChange();");
        output.println("");
        output.println("  }");
    
    }

    public void printViewAfterChangeCode(PrintWriter output) {
/*
    output.println("    if(!processingBBWChange && c instanceof MVAddComponent) {");
    output.println("      startJViewsChange();");
    output.println("      (("+panelClassName()+") frame).addedViewComp((MVViewComp) c.getComponent());");
    output.println("      endJViewsChange();");
        output.println("    }");
        output.println("");
*/
    }

    public boolean isViewClass() {
        if(getParentName().equals("MVViewLayer"))
            return true;
        return false;
    }

    public String changeMethodName() {
        return smallletters(getBBWPrefix())+"Change";
    }

    public String changeEventName() {
        return getBBWPrefix()+"ChangeEvent";
    }

    public String panelClassName() {
        return getClassPrefix()+getName()+"Panel";
    }

    private String smallletters(String s) {
        char chars[] = s.toCharArray();

        for(int i=0;i<chars.length;i++) {
            if(chars[i] >= 'A' && chars[i] <= 'Z')
                chars[i] = (char) (chars[i] + ('a' - 'A'));
        }

        return new String(chars);
    }

    public void printPanelClass(PrintWriter output) {
        output.println("package "+getPackage()+";");
        output.println("");
        output.println("import bbw.*;");
        output.println("import java.awt.*;");
        output.println("import "+getBBWPackageName()+".*;");
        output.println("import JViews.*;");
        output.println("");
        output.println("public class "+panelClassName()+"G extends MVViewFrame {");
        output.println("");
        output.println("  public "+panelClassName()+"G(MVViewLayer view) {");
        output.println("    super(view);");
        output.println("    setLayout(new BorderLayout());");
        output.println("      add("+'"'+"North"+'"'+",messagePanel);");
        output.println("    add("+'"'+"Center"+'"'+", panel);");
        output.println("    panel.addTransactionListener(view);");
        output.println("    panel.add"+getBBWPrefix()+"ChangeListener(("+userClassName()+") view);");
        output.println("  }");
        output.println("");

        output.println("  public void addedViewComp(MVViewComp c) {");

        Enumeration e = getViewComponents().elements();
        while(e.hasMoreElements()) {
            JCBaseComp c = (JCBaseComp) e.nextElement();

            if(c.getParentName().equals("MVViewComp")) {
                output.println("    if(c instanceof "+c.userClassName()+") {");
                output.println("      "+c.getBBWShapeClassName()+" new_comp = panel.new"+c.getUnprefixedName()+"(100,100,60,40);");
                output.println("      (("+c.userClassName()+") c).addedViewComp(new_comp);");
                output.println("    }");
            } else if(c.getParentName().equals("MVOneToOneGlue")) {
                output.println("    if(c instanceof "+c.userClassName()+") {");
                output.println("      "+c.getBBWShapeClassName()+" new_comp = panel.new"+c.getUnprefixedName()+"((("+c.userClassName()+") c).getBBWParent(),(("+c.userClassName()+") c).getBBWChild());");
                output.println("      (("+c.userClassName()+") c).addedViewComp(new_comp);");
                output.println("    }");
            } else if(c.getParentName().equals("MVSubIcon")) {
                
            }

        }

        output.println("");
        output.println("    super.addedViewComp(c);");
        output.println("  }");
/*
     // create BBW shapes when JViews icon/glue added...
     
        if(c.comp instanceof JCAttrIcon) {
            JCComponent comp = (JCComponent) ((JCAttrIcon) c.comp).getBBWParent();
            comp.addElement();
            Vector fields = comp.getFields();
            TextFieldShape field = (TextFieldShape) fields.lastElement();
            ((JCAttrIcon) c.comp).addedViewComp(field);
        }

*/

        output.println("  private "+getBBWShapeClassName()+" panel = new "+
            getBBWShapeClassName()+"();");
        output.println("");
        output.println("}");
    }

    public Vector getViewComponents() {
        Vector comps = new Vector();
        Enumeration e = getcLinkParent().elements();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("viewComponents"))
                comps.addElement(l.getpLinkChild());
        }

        return comps;
    }
    
    public JCBaseComp getViewLayer()
    {
        Enumeration e = getcLinkChild().elements();

        while(e.hasMoreElements()) {
            JCBaseLink l = (JCBaseLink) e.nextElement();
            if(l.getName().equals("viewComponents"))
                return (JCBaseComp) l.getpLinkParent();
        }

        return null;        
    }

    public String getNewShapeEventName() {
        return getBBWPrefix()+"New"+getUnprefixedName()+"Event";
    }

    public String getUnprefixedShapeName() {
        char chars[] = getBBWShapeClassName().toCharArray();

        return new String(chars,getClassPrefix().length(),chars.length - getBBWPrefix().length());
    }
    
    public String getUnprefixedName() {
        char chars[] = getBBWShapeClassName().toCharArray();
        String shape = new String(chars,chars.length-5,5);

        if(shape.equals("Shape"))
            return new String(chars,getClassPrefix().length(),chars.length - getBBWPrefix().length()-5);

        return new String(chars,getClassPrefix().length(),chars.length - getBBWPrefix().length());
    }

    public void printUserPanelClass(PrintWriter output) {
        output.println("package "+getPackage()+";");
        output.println("import JViews.*;");
        output.println("");
        output.println("public class "+panelClassName()+" extends "+panelClassName()+"G {");

        output.println("  public "+panelClassName()+"(MVViewLayer view) {");
        output.println("    super(view);");
        output.println("  }");
        output.println("");
        output.println("}");
    }
    
    public JCBaseAspectInfo findAspectInfo(String name)
    {
        Enumeration e = getcAspectInfo().elements();
        while(e.hasMoreElements()) {
            JCBaseAspectInfo ba = (JCBaseAspectInfo) e.nextElement();
            if(ba.getAspectName().equals(name))
                return ba;
        }
        
        return null;
    }

}

