package JComp;

import JViews.*;
import bbw.*;

public class JCActionIconToBase extends JCActionIconToBaseG {

  public JCActionIconToBase() {
    super();
  }

    public String userName() {
        return "";
    }

}

