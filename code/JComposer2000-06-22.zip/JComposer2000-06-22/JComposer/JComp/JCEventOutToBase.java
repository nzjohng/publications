package Serendipity;

import JViews.*;

public class SEEndIconToBase extends SEEndIconToBaseG {

  public SEEndIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

