package JComp;

import JViews.*;

public class JCEventInIcon extends JCEventInIconG {

  public JCEventInIcon() {
    super();
  }


  public String userName() {
    return getText();
  }
  
  public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from, String rel)
  {
    if(from == this && c instanceof MVSetStringValue &&
        ((MVSetStringValue) c).getPropertyName().equals("text") &&
        getBaseComp() == null)
        mapComponent(true);
    
    return super.afterChange(c,from,rel);
  }
  
  public MVBaseComp mapComponent(boolean do_map)
  {

System.out.println("in SEStartIcon::mapComponent()");

        if(getText().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getNameText() = '"+getText()+"'");
/*
        SEBaseStage base_stage = ((SEDiagram) view()).getpSubviews();
        
        if(base_stage == null)
            return null;

        SEBaseStartStage base_comp = base_stage.findStartStage(getText());

if(base_comp != null)
    System.out.println("Base stage found = "+ base_comp);
else
    System.out.println("No base stage found"); 

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = new SEBaseStartStage();
                mapToCreatedBase(base_comp);
                base_comp.init(view().getBaseLayer());
                base_stage.establishSubstages(base_comp);
                return base_comp;
            }
        }
            else return base_comp;
    */
    
        return null;
    }


}

