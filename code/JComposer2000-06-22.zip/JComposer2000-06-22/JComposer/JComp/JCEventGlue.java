package JComp;

import JViews.*;
import bbw.*;


/* hand-written stuff */

public class JCEventGlue extends JCEventGlueG {

    public JCEventGlue() {
        super();
    }

    public String userName() {
        if(hasParent())
            return getParent().userName()+"=>"+getNameText();
        else
            return "=>"+getNameText();
    }

    public MVBaseComp mapComponent(boolean do_map) {
    
        if(getNameText().equals(""))
            return null;

    System.out.println("in JCEventGlue.mapComponent:");

        JCBaseComp p = (JCBaseComp) getParent().baseComp();
        JCBaseComp c = (JCBaseComp) getChild().baseComp();

        if(p == null || c == null)
            return null;

        // just find parent -> child ??? (don't use name?)
        JCBaseEvent l1 = p.findParentEvent(getNameText());
        JCBaseEvent l2 = c.findChildEvent(getNameText());

        // if l1 != l2 then semantic error!!!

        if(do_map) {
            if(l1 != null) {
                mapToBase(l1);
                return l1;
            } else {
                l1 = new JCBaseEvent(view().getBaseLayer());
                p.establishEventParent(l1);
                c.establishEventChild(l1);
                mapToCreatedBase(l1);
                return l1;
            }
        } else
            return l1;
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
System.out.println("JCEventGlue got "+c);
            if(c instanceof MVSetValue)
                if(((MVSetValue) c).getPropertyName().equals("nameText") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for EventGlue calling mapComponent...");
                        mapComponent(true);
                }

        return super.afterChange(c,from,rel_name);
    }

}

