package JComp;

import JViews.*;
import bbw.*;


/* Generated */

public class JCBaseClassesG extends MVHashtableRel {

    public JCBaseClassesG() {
        super();
    }

    public JCBaseClassesG(String rel_name, MVComponent parent_comp) {
        super(rel_name,parent_comp);
    }

    public String kindName() {
        return "Base Classes";
    }

}

