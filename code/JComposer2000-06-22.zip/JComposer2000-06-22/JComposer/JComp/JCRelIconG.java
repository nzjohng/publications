package JComp;

import JViews.*;
import bbw.*;
import java.beans.*;
import java.util.*;
import jComposer.*;

public abstract class JCRelIconG extends MVIcon {

  public JCRelIconG() {
    super();
    establishListeners();
  }

  public JCRelIconG(MVViewLayer v) {
    super(v);
    establishListeners();
  }

  public String kindName() {
    return "Relationship Icon";
  }

  public abstract String userName();

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }

    public String getParentText() {
        return getStringValue("parentText");
    }

    public void setParentText(String value) {
        setValue("parentText",value);
    }

    public String getKindText() {
        return getStringValue("kindText");
    }

    public void setKindText(String value) {
        setValue("kindText",value);
    }

  public String getForeground() {
    return getStringValue("foreground");
  }

  public void setForeground(String value) {
    setValue("foreground",value);
  }

  public String getBackground() {
    return getStringValue("background");
  }

  public void setBackground(String value) {
    setValue("background",value);
  }

  public boolean isGenerateCode() {
    return getBooleanValue("generateCode");
  }

  public void setGenerateCode(boolean value) {
    setValue("generateCode",value);
  }

  public boolean isCreateLinked() {
    return getBooleanValue("createLinked");
  }

  public void setCreateLinked(boolean value) {
    setValue("createLinked",value);
  }

  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }

  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }

  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
        setValue("width",value);
  }

  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
        setValue("height",value);
  }
  
  public void setAggregate(boolean value)
  {
      setValue("aggregate",value);
  }
  
  public boolean isAggregate()
  {
    return getBooleanValue("aggregate");
  
  }


    public JCRelnShape getJCRelnShape() {
        return (JCRelnShape) getBBWShape();
    }

  public JCRelIconToBase getprRelIconToBase() {
    return (JCRelIconToBase) getOneRelated("MVViewRel",MVParents);
  }

  public JCBaseRel getpRelIconToBase() {
    return (JCBaseRel) getOneRelated("MVViewRel",MVParentRelComps);
  }

  public void establishListeners() {
  }

    public String viewRelKind() {
        return "JCRelIconToBase";
    }

    public MVViewRel newViewRel() {
        return new JCRelIconToBase();
    }

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {
        
        if(c instanceof MVSetValue) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCRelnShape().setNameText(getNameText());
            } else if(name.equals("parentText")) {
                getJCRelnShape().setParentText(getParentText());
            } else if(name.equals("kindText")) {
                getJCRelnShape().setKindText(getKindText());
            } else if(name.equals("foreground")) {
                getJCRelnShape().setForeground(java_awt_Color_fromString(getForeground()));
            } else if(name.equals("background")) {
                getJCRelnShape().setBackground(java_awt_Color_fromString(getBackground()));
            } else if(name.equals("x")) {
                getJCRelnShape().setX(getX());
            } else if(name.equals("y")) {
                getJCRelnShape().setY(getY());
            } else if(name.equals("width")) {
                getJCRelnShape().setWidth(getWidth());
            } else if(name.equals("height")) {
                getJCRelnShape().setHeight(getHeight());
            } else if(name.equals("generateCode")) {
                getJCRelnShape().setGenerateCode(isGenerateCode());
            } else if(name.equals("createLinked")) {
                getJCRelnShape().setCreateLinked(isCreateLinked());
            } else if(name.equals("aggregate")) {
                getJCRelnShape().setAggregate(isAggregate());
            }// etc.
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {
        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }

        if(evt.getPropertyName().equals("nameText")) {
            setNameText(getJCRelnShape().getNameText());
        }
        if(evt.getPropertyName().equals("parentText")) {
            setParentText(getJCRelnShape().getParentText());
        }
        if(evt.getPropertyName().equals("kindText")) {
            setKindText(getJCRelnShape().getKindText());
        }
        if(evt.getPropertyName().equals("foreground")) {
            setForeground(java_awt_Color_toString(getJCRelnShape().getForeground()));
        }
        if(evt.getPropertyName().equals("background")) {
            setBackground(java_awt_Color_toString(getJCRelnShape().getBackground()));
        }
        if(evt.getPropertyName().equals("x")) {
            setX(getJCRelnShape().getX());
        }
        if(evt.getPropertyName().equals("y")) {
            setY(getJCRelnShape().getY());
        }
        if(evt.getPropertyName().equals("width")) {
            setWidth(getJCRelnShape().getWidth());
        }
        if(evt.getPropertyName().equals("height")) {
            setHeight(getJCRelnShape().getHeight());
        }
        if(evt.getPropertyName().equals("generateCode")) {
            setGenerateCode(getJCRelnShape().isGenerateCode());
        }
        if(evt.getPropertyName().equals("createLinked")) {
            setCreateLinked(getJCRelnShape().isCreateLinked());
        }
        if(evt.getPropertyName().equals("aggregate")) {
            setAggregate(getJCRelnShape().isAggregate());
        }
        
        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCRelnShape().getNameText());
        setParentText(getJCRelnShape().getParentText());
        setKindText(getJCRelnShape().getKindText());
        setForeground(java_awt_Color_toString(getJCRelnShape().getForeground()));
        setBackground(java_awt_Color_toString(getJCRelnShape().getBackground()));
        setX(getJCRelnShape().getX());
        setY(getJCRelnShape().getY());
        setWidth(getJCRelnShape().getWidth());
        setHeight(getJCRelnShape().getHeight());
        setGenerateCode(getJCRelnShape().isGenerateCode());
        setCreateLinked(getJCRelnShape().isCreateLinked());
        setAggregate(getJCRelnShape().isAggregate());
        // etc.
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
        if(getAttribute("nameText") != null)
            getJCRelnShape().setNameText(getNameText());
        else
            setNameText(getJCRelnShape().getNameText());
        if(getAttribute("parentText") != null)
            getJCRelnShape().setParentText(getParentText());
        else
            setParentText(getJCRelnShape().getParentText());
        if(getAttribute("kindText") != null)
            getJCRelnShape().setKindText(getKindText());
        else
            setKindText(getJCRelnShape().getKindText());
        if(getAttribute("foreground") != null)
            getJCRelnShape().setForeground(java_awt_Color_fromString(getForeground()));
        else
            setForeground(java_awt_Color_toString(getJCRelnShape().getForeground()));
        if(getAttribute("background") != null)
            getJCRelnShape().setBackground(java_awt_Color_fromString(getBackground()));
        else
            setBackground(java_awt_Color_toString(getJCRelnShape().getBackground()));
        if(getAttribute("x") != null)
            getJCRelnShape().setX(getX());
        else
            setX(getJCRelnShape().getX());
        if(getAttribute("y") != null)
            getJCRelnShape().setY(getY());
        else
            setY(getJCRelnShape().getY());
        if(getAttribute("width") != null)
            getJCRelnShape().setWidth(getWidth());
        else
            setWidth(getJCRelnShape().getWidth());
        if(getAttribute("height") != null)
            getJCRelnShape().setHeight(getHeight());
        else
            setHeight(getJCRelnShape().getHeight());
        if(getAttribute("generateCode") != null)
            getJCRelnShape().setGenerateCode(isGenerateCode());
        else
            setGenerateCode(getJCRelnShape().isGenerateCode());
        if(getAttribute("createLinked") != null)
            getJCRelnShape().setCreateLinked(isCreateLinked());
        else
            setCreateLinked(getJCRelnShape().isCreateLinked());
        if(getAttribute("aggregate") != null)
            getJCRelnShape().setAggregate(isAggregate());
        else
            setAggregate(getJCRelnShape().isAggregate());
    }
}

