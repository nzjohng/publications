package JComp;

import JViews.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCLinkGlueG extends MVOneToOneGlue {

    /* Constructors */

    public JCLinkGlueG() {
        super();
    }

    /* Attributes */

    public String getNameText() {
        return getStringValue("nameText");
    }

    public void setNameText(String value) {
        setValue("nameText",value);
    }

    public String getChoiceFrom() {
        return getStringValue("choiceFrom");
    }

    public void setChoiceFrom(String value) {
        setValue("choiceFrom",value);
    }

    public String getChoiceTo() {
        return getStringValue("choiceTo");
    }

    public void setChoiceTo(String value) {
        setValue("choiceTo",value);
    }

    public boolean isGenerateCode() {
        return getBooleanValue("generateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("generateCode",value);
    }

    public boolean isCreateLinked() {
        return getBooleanValue("createLinked");
    }

    public void setCreateLinked(boolean value) {
        setValue("createLinked",value);
    }

    public boolean isChildListenBefore() {
        return getBooleanValue("childListenBefore");
    }

    public void setChildListenBefore(boolean value) {
        setValue("childListenBefore",value);
    }

    public boolean isChildListenAfter() {
        return getBooleanValue("childListenAfter");
    }

    public void setChildListenAfter(boolean value) {
        setValue("childListenAfter",value);
    }
    
    public boolean isChildHandleBefore() {
        return getBooleanValue("childHandleBefore");
    }

    public void setChildHandleBefore(boolean value) {
        setValue("childHandleBefore",value);
    }

    public boolean isChildHandleAfter() {
        return getBooleanValue("childHandleAfter");
    }

    public void setChildHandleAfter(boolean value) {
        setValue("childHandleAfter",value);
    }
    
    public boolean isParentListenBefore() {
        return getBooleanValue("parentListenBefore");
    }

    public void setParentListenBefore(boolean value) {
        setValue("parentListenBefore",value);
    }

    public boolean isParentListenAfter() {
        return getBooleanValue("parentListenAfter");
    }

    public void setParentListenAfter(boolean value) {
        setValue("parentListenAfter",value);
    }
    
    public boolean isParentHandleBefore() {
        return getBooleanValue("parentHandleBefore");
    }

    public void setParentHandleBefore(boolean value) {
        setValue("parentHandleBefore",value);
    }

    public boolean isParentHandleAfter() {
        return getBooleanValue("parentHandleAfter");
    }

    public void setParentHandleAfter(boolean value) {
        setValue("parentHandleAfter",value);
    }
    
    public boolean isAggregate() {
        return getBooleanValue("aggregate");
    }
    
    public  void setAggregate(boolean value)
    {
        setValue("aggregate",value);
    }
    
    public JCArrowArity getJCArrowArity() {
        return (JCArrowArity) getBBWShape();
    }

    /* Relationships */

    /* Methods */

    public abstract String userName();

    /* Read/write methods */

    public MVViewRel newViewRel() {
        return new JCLinkGlueToBase();
    }

    public String viewRelKind() {
        return "JCLinkGlueToBase";
    }

    // keep BBW shape & JViews component attributes consistent...

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

        if(c instanceof MVSetValue && getJCArrowArity() != null) {
            String name = ((MVSetValue) c).getPropertyName();
            if(name.equals("nameText")) {
                getJCArrowArity().setNameText(getNameText());
            } else if(name.equals("choiceFrom")) {
                getJCArrowArity().setChoiceFrom(getChoiceFrom());
            } else if(name.equals("choiceTo")) {
                getJCArrowArity().setChoiceTo(getChoiceTo());
            } else if(name.equals("generateCode")) {
                getJCArrowArity().setGenerateCode(isGenerateCode());
            } else if(name.equals("createLinked")) {
                getJCArrowArity().setCreateLinked(isCreateLinked());
            } else if(name.equals("childListenBefore")) {
                getJCArrowArity().setChildListenBefore(isChildListenBefore());
            } else if(name.equals("childListenAfter")) {
                getJCArrowArity().setChildListenAfter(isChildListenAfter());
            } else if(name.equals("childHandleBefore")) {
                getJCArrowArity().setChildHandleBefore(isChildHandleBefore());
            } else if(name.equals("childListenAfter")) {
                getJCArrowArity().setChildHandleAfter(isChildHandleAfter());
            } else if(name.equals("parentListenBefore")) {
                getJCArrowArity().setParentListenBefore(isParentListenBefore());
            } else if(name.equals("parentListenAfter")) {
                getJCArrowArity().setParentListenAfter(isParentListenAfter());
            } else if(name.equals("parentHandleBefore")) {
                getJCArrowArity().setParentHandleBefore(isParentHandleBefore());
            } else if(name.equals("parentListenAfter")) {
                getJCArrowArity().setParentHandleAfter(isParentHandleAfter());
            } else if(name.equals("aggregate")) {
                getJCArrowArity().setAggregate(isAggregate());            
            } 
        }

        return super.afterChange(c,from,rel_name);  
    }

    public void propertyChange(PropertyChangeEvent evt) {

        if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
            super.propertyChange(evt);
            return;
        }
        
        if(evt.getPropertyName().equals("name")) {
            setNameText(getJCArrowArity().getNameText());
        } else if(evt.getPropertyName().equals("choiceFrom")) {
            setChoiceFrom(getJCArrowArity().getChoiceFrom());
        } else if(evt.getPropertyName().equals("choiceTo")) {
            setChoiceTo(getJCArrowArity().getChoiceTo());
        } else if(evt.getPropertyName().equals("generateCode")) {
            setGenerateCode(getJCArrowArity().isGenerateCode());
        } else if(evt.getPropertyName().equals("createLinked")) {
            setCreateLinked(getJCArrowArity().isCreateLinked());
        } else if(evt.getPropertyName().equals("aggregate")) {
            setAggregate(getJCArrowArity().isAggregate());
        } else if(evt.getPropertyName().equals("childListenBefore")) {
            setChildListenBefore(getJCArrowArity().isChildListenBefore());
        } else if(evt.getPropertyName().equals("childListenAfter")) {
            setChildListenAfter(getJCArrowArity().isChildListenAfter());
        } else if(evt.getPropertyName().equals("childHandleBefore")) {
            setChildHandleBefore(getJCArrowArity().isChildHandleBefore());
        } else if(evt.getPropertyName().equals("childHandleAfter")) {
            setChildHandleAfter(getJCArrowArity().isChildHandleAfter());
        } else if(evt.getPropertyName().equals("parentListenBefore")) {
            setParentListenBefore(getJCArrowArity().isParentListenBefore());
        } else if(evt.getPropertyName().equals("parentListenAfter")) {
            setParentListenAfter(getJCArrowArity().isParentListenAfter());
        } else if(evt.getPropertyName().equals("parentHandleBefore")) {
            setParentHandleBefore(getJCArrowArity().isParentHandleBefore());
        } else if(evt.getPropertyName().equals("parentHandleAfter")) {
            setParentHandleAfter(getJCArrowArity().isParentHandleAfter());
        } 

        super.propertyChange(evt);
    }

    public void addedBBWShape(BBWComponent shape) {
        super.addedBBWShape(shape);
        setNameText(getJCArrowArity().getNameText());
        setChoiceFrom(getJCArrowArity().getChoiceFrom());
        setChoiceTo(getJCArrowArity().getChoiceTo());
        setGenerateCode(getJCArrowArity().isGenerateCode());
        setCreateLinked(getJCArrowArity().isCreateLinked());
        setAggregate(getJCArrowArity().isAggregate());
        setChildListenBefore(getJCArrowArity().isChildListenBefore());
        setChildListenAfter(getJCArrowArity().isChildListenAfter());
        setChildHandleBefore(getJCArrowArity().isChildHandleBefore());
        setChildHandleAfter(getJCArrowArity().isChildHandleAfter());
        setParentListenBefore(getJCArrowArity().isParentListenBefore());
        setParentListenAfter(getJCArrowArity().isParentListenAfter());
        setParentHandleBefore(getJCArrowArity().isParentHandleBefore());
        setParentHandleAfter(getJCArrowArity().isParentHandleAfter());
    }

    public void addedViewComp(BBWComponent shape) {
        super.addedViewComp(shape);
     
        if(getAttribute("nameText") != null)
            getJCArrowArity().setNameText(getNameText());
        else
            setNameText(getJCArrowArity().getNameText());
        if(getAttribute("choiceFrom") != null)
            getJCArrowArity().setChoiceFrom(getChoiceFrom());
        else
            setChoiceFrom(getJCArrowArity().getChoiceFrom());
        if(getAttribute("choiceTo") != null)
            getJCArrowArity().setChoiceTo(getChoiceTo());
        else
            setChoiceTo(getJCArrowArity().getChoiceTo());
        if(getAttribute("generateCode") != null)
            getJCArrowArity().setGenerateCode(isGenerateCode());
        else
            setGenerateCode(getJCArrowArity().isGenerateCode());
        if(getAttribute("createLinked") != null)
            getJCArrowArity().setCreateLinked(isCreateLinked());
        else
            setCreateLinked(getJCArrowArity().isCreateLinked());
        if(getAttribute("aggregate") != null)
            getJCArrowArity().setAggregate(isAggregate());
        else
            setAggregate(getJCArrowArity().isAggregate());
        if(getAttribute("childListenBefore") != null)
            getJCArrowArity().setChildListenBefore(isChildListenBefore());
        else
            setChildListenBefore(getJCArrowArity().isChildListenBefore());
        if(getAttribute("childListenAfter") != null)
            getJCArrowArity().setChildListenAfter(isChildListenAfter());
        else
            setChildListenAfter(getJCArrowArity().isChildListenAfter());
        if(getAttribute("childHandleBefore") != null)
            getJCArrowArity().setChildHandleBefore(isChildHandleBefore());
        else
            setChildHandleBefore(getJCArrowArity().isChildHandleBefore());
        if(getAttribute("childHandleAfter") != null)
            getJCArrowArity().setChildHandleAfter(isChildHandleAfter());
        else
            setChildHandleAfter(getJCArrowArity().isChildHandleAfter());
        if(getAttribute("parentListenBefore") != null)
            getJCArrowArity().setParentListenBefore(isParentListenBefore());
        else
            setParentListenBefore(getJCArrowArity().isParentListenBefore());
        if(getAttribute("parentListenAfter") != null)
            getJCArrowArity().setParentListenAfter(isParentListenAfter());
        else
            setParentListenAfter(getJCArrowArity().isParentListenAfter());
        if(getAttribute("parentHandleBefore") != null)
            getJCArrowArity().setParentHandleBefore(isParentHandleBefore());
        else
            setParentHandleBefore(getJCArrowArity().isParentHandleBefore());
        if(getAttribute("parentHandleAfter") != null)
            getJCArrowArity().setParentHandleAfter(isParentHandleAfter());
        else
            setParentHandleAfter(getJCArrowArity().isParentHandleAfter());

    }

}

