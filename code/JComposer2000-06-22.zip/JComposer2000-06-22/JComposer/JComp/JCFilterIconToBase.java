package JComp;

import JViews.*;
import bbw.*;

public class JCFilterIconToBase extends JCFilterIconToBaseG {

  public JCFilterIconToBase() {
    super();
  }

    public String userName() {
        return "";
    }

}

