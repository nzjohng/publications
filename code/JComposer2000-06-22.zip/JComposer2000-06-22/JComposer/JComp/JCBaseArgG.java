package JComp;

import JViews.*;
import bbw.*;



/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseArgG extends MVBaseComp {

    /* Constructors */

    public JCBaseArgG() {
        super();
    }

    public JCBaseArgG(MVBaseLayer base_layer) {
        super(base_layer);

        setName(MVStringBlank);
        setType(MVStringBlank);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    public String getType() {
    return getStringValue("Type");
    }

    public void setType(String value) {
        setValue("Type",value);
    }

    /* Relationships */

    public JCBaseMethod getpMethodArgs() {
        return (JCBaseMethod) getOneRelated("MethodArgs",MVParents);
    }

    /* Methods */

    public abstract String userName();

    public String kindName() {
        return "Base Argument";
    }

    /* Read/write methods */

}

