package JComp;

import JViews.*;
import bbw.*;
import java.util.*;
import bbw.shape.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.lang.reflect.*;

public class JCCompIcon extends JCCompIconG {

  public JCCompIcon() {
    super();
  }

    public MVBaseComp mapComponent(boolean do_map) {

System.out.println("in mapComponent()");

        if(getNameText().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getNameText() = '"+getNameText()+"'");

        JCBaseLayer base_layer = (JCBaseLayer) view().getBaseLayer();
        JCBaseComp base_comp = base_layer.findBaseComp(getNameText());

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = new JCBaseComp(base_layer);
                mapToCreatedBase(base_comp);
                base_comp.init(base_layer);
                base_layer.establishBaseComps(base_comp);
                return base_comp;
            }
        }
            else return base_comp;

    }

    public String userName() {
        return getNameText();
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue) {
                if(((MVSetValue) c).getPropertyName().equals("nameText") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for CompIcon calling mapComponent...");
                        mapComponent(true);
                }
                
            }

            return super.afterChange(c,from,rel_name);
        }
              

    public void updateBBWAttributes(Vector checks, Vector names, Vector types)
    {
        JCBaseComp bc = (JCBaseComp) getBaseComp();

        for(int i=0;i<checks.size();i++) {
            Checkbox cb = (Checkbox)  checks.elementAt(i);
            String name = (String) names.elementAt(i);
            String type = (String) types.elementAt(i);
            
System.out.println(cb.getState()+" "+name+" "+type);

            if(!cb.getState())
                continue;
        
            String jtype = type;
             if(!type.equals("int") && !type.equals("boolean"))
                    jtype = "String"; 
 
            JCBaseAttr battr = bc.findAttributeName(name);
            if(battr != null) {
                battr.setType(jtype);
                battr.setBBWType(type);
            } else {
                bc.addBBWAttribute(name,type);
            }


            // Let user determine which to show???
            
            JCAttrIcon aicon = findAttributeIcon(name);    
            if(aicon != null) {
                aicon.setText(name+":"+jtype);
            } else {
                aicon = new JCAttrIcon();
                aicon.setOwner(this);
                aicon.init(view());
                aicon.setText(name+":"+jtype);
                aicon.mapComponent(false);
            }

       
        }
        
        // remove old BBW icon/base attributes ...
        
        Vector attrs = ((JCBaseComp) baseComp()).getcClassAttributes();

        Enumeration e1 = attrs.elements();
        while(e1.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e1.nextElement();
System.out.println(" base attr = "+a.getName());
            if(!a.getBBWType().equals("")) { 
                Enumeration e2 = names.elements();
                boolean checked = false;
                while(e2.hasMoreElements()) {
                    String aname = (String) e2.nextElement();
                    if(aname.equals(a.getName()))
                        if(((Checkbox) checks.elementAt(names.indexOf(aname))).getState())
                        checked = true;
                }
                if(!checked) {
                    JCAttrIcon ai = findAttributeIcon(a.getName());
                    if(ai != null)
                        ai.delete();               
                    a.delete();
                }
            }
         }
 
         bbwAttributes  = null;
    }
    
    public JCAttrIcon findAttributeIcon(String name)
    {
        Enumeration e3 = getRelationship("IconOwner",MVParentRelComps).elements();
        while(e3.hasMoreElements()) {
            JCAttrIcon attr = (JCAttrIcon) e3.nextElement();
            if(attr.getName().equals(name))
                return attr;       
        }    
        
        return null;
    }
    
    public void showHideAttributes(Vector checks, Vector names, Vector types)
    {
        JCBaseComp bc = (JCBaseComp) getBaseComp();

        for(int i=0;i<checks.size();i++) {
            Checkbox cb = (Checkbox)  checks.elementAt(i);
            String name = (String) names.elementAt(i);
            String type = (String) types.elementAt(i);
            
System.out.println(cb.getState()+" "+name+" "+type);
            
            JCAttrIcon aicon = findAttributeIcon(name);
            if(cb.getState()) {
                if(aicon == null) {
                    aicon = new JCAttrIcon();
                    aicon.setOwner(this);
                    aicon.init(view());
                    aicon.setText(name+":"+type);
                    aicon.mapComponent(false);
                }
            } else {
                if(aicon != null)
                    aicon.delete();
            }
        }

         showHideAttrs = null;
    }
    
    public void deleteAttributes(Vector checks, Vector names, Vector types)
    {
        JCBaseComp bc = (JCBaseComp) getBaseComp();

        for(int i=0;i<checks.size();i++) {
            Checkbox cb = (Checkbox)  checks.elementAt(i);
            String name = (String) names.elementAt(i);
            String type = (String) types.elementAt(i);
            
System.out.println(cb.getState()+" "+name+" "+type);
            
            
            if(cb.getState()) {
                JCAttrIcon aicon = findAttributeIcon(name);
                if(aicon != null)
                    aicon.delete();
                 
                JCBaseAttr battr = bc.findAttributeName(name);
                battr.delete();
            }
        }
        
        deleteAttrs = null;    
    }
    
    public void getBBWAttributes()
    {

    if(getBbwShapeText().equals("") || getBaseComp() == null || isViewClass())
        return;
            
    JCBaseComp bc = (JCBaseComp) getBaseComp();

    PropertyDescriptor properties[] = null;
    Object targ = null;
    
    Vector checks = new Vector();
    Vector names = new Vector();
    Vector types = new Vector();

    try {
            Class c = Class.forName(getBbwShapeText());
            targ = c.newInstance();
        BeanInfo bi = Introspector.getBeanInfo(c);
        properties = bi.getPropertyDescriptors();
    } catch (ClassNotFoundException e) {
            System.out.println("BBW shape class "+getBbwShapeText()+" does not exist!!");
            throw(new MVFatalException("Class does not exist"));
    } catch (IntrospectionException ex) {
        throw(new MVFatalException("PropertySheet: Couldn't introspect"+getBbwShapeText()));
    } catch(Exception e) {
            System.out.println("Can't create instance of class "+getBbwShapeText());
            throw(new MVFatalException("Can't create instance of class"));
    }

    try {
/*
    if (targ instanceof bbw.BBWComponent) {

// Copy only BBW Shape editable properties (???)

       String[] editableProperties = ((bbw.BBWComponent)targ).getEditableProperties();
       if (editableProperties.length > 0) {
        PropertyDescriptor[] newProperties = new PropertyDescriptor[editableProperties.length];
        for (int i = 0; i < editableProperties.length; i++) {
            String ep = editableProperties[i];
            for (int j = 0; j < properties.length; j++)
                if (ep.equals(properties[j].getName())) {
                    newProperties[i] = properties[j];
                    break;
                    }
            if (newProperties[i] == null) {
                System.out.println("Actual property names:");
                for (int k = 0; k < properties.length; k++)
                    System.out.println(properties[k].getName());
                throw new RuntimeException("Unknown property name included in getEditableProperties(): "+ep);
                }
            }
        properties = newProperties;
        }
    // end addition
    }
*/
        for (int i = 0; i < properties.length; i++) {

            // Don't copy hidden or expert properties.
            if (properties[i].isHidden() || properties[i].isExpert()) {
                continue;
            }

            String name = properties[i].getName();
            Class type = properties[i].getPropertyType();
            Method getter = properties[i].getReadMethod();
            Method setter = properties[i].getWriteMethod();


            // Only copy read/write properties.
            if (getter == null || setter == null) {
                continue;
            }
            
            Checkbox cb = new JCAttrCheckbox();
            JCBaseAttr ba = bc.findAttributeName(name);
            if(ba != null && !ba.getBBWType().equals(""))
                cb.setState(true);
                
            checks.addElement(cb);
            names.addElement(name);
            types.addElement(className(type));
            
        }

        }
        catch(Exception e) {
            throw(new MVFatalException("Error in copying BBW shape properties"));
        }
        
        bbwAttributes = new JCAttributesDisplay("BBW Attributes for: "+userName(),checks,names,types);
        bbwAttributes.okButton.addActionListener(this);
        bbwAttributes.setVisible(true);        

    }
    
    public void selectShowHideAttrs()
    {
        Vector checks = new Vector();
        Vector names = new Vector();
        Vector types = new Vector();
 System.out.println("show/hide attrs");
        Vector attrs = ((JCBaseComp) baseComp()).getcClassAttributes();

        Enumeration e1 = attrs.elements();
        while(e1.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e1.nextElement();
            Checkbox cb = new JCAttrCheckbox(); 
            if(findAttributeIcon(a.getName()) != null)
                cb.setState(true);
            checks.addElement(cb);
            names.addElement(a.getName());
            types.addElement(a.getType());
        }
        
        showHideAttrs = new JCAttributesDisplay("Show/hide attributes for: "+userName(),checks,names,types);
        showHideAttrs.okButton.addActionListener(this);
        showHideAttrs.setVisible(true); 
    }
    
    public void selectDeleteAttrs()
    {
        Vector checks = new Vector();
        Vector names = new Vector();
        Vector types = new Vector();
 System.out.println("delete attrs");
        Vector attrs = ((JCBaseComp) baseComp()).getcClassAttributes();

        Enumeration e1 = attrs.elements();
        while(e1.hasMoreElements()) {
            JCBaseAttr a = (JCBaseAttr) e1.nextElement();
            Checkbox cb = new JCAttrCheckbox();
            checks.addElement(cb);
            names.addElement(a.getName());
            types.addElement(a.getType());
        }
        
        deleteAttrs = new JCAttributesDisplay("Delete attributes for: "+userName(),checks,names,types);
        deleteAttrs.okButton.addActionListener(this);
        deleteAttrs.setVisible(true);     
    }
    
    JCAttributesDisplay bbwAttributes;
    JCAttributesDisplay showHideAttrs;
    JCAttributesDisplay deleteAttrs;

    public boolean isViewClass() {
        if(getParentText().equals("MVViewLayer"))
            return true;
        return false;
    }  
    
    private String capitalize(String s) {
        char chars[] = s.toCharArray();
        chars[0] = Character.toUpperCase(chars[0]);
        return new String(chars);
    }

    private String className(Class c) {
        String name = c.getName();

        if(name.equals("java.lang.Boolean"))
            return "boolean";
        else if(name.equals("java.lang.Integer"))
            return "int";
        else if(name.equals("java.lang.String"))
            return "String";
        return name;
    }
    
    MenuItem getAttrsItem = new MenuItem("Get BBW Attributes");
    MenuItem showHideItem = new MenuItem("Show/Hide Attributes");
    MenuItem deleteItem = new MenuItem("Delete Attributes");
    
    public void addJViewsPopups(BBWComponent shape)
    {
        super.addJViewsPopups(shape);
        shape.addPopupMenuItem(new MenuItem("-"));
        shape.addPopupMenuItem(showHideItem);
        showHideItem.addActionListener(this);
        shape.addPopupMenuItem(deleteItem);
        deleteItem.addActionListener(this);
        shape.addPopupMenuItem(getAttrsItem);
        getAttrsItem.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        super.actionPerformed(e);
 System.out.println("Comp Icon Got "+e);     
        if(e.getSource() == getAttrsItem)
             getBBWAttributes(); 
        else if(e.getSource() == showHideItem)
            selectShowHideAttrs();
        else if(e.getSource() == deleteItem)
            selectDeleteAttrs();
        else if(bbwAttributes != null) {
            if(e.getSource() == bbwAttributes.okButton)
                updateBBWAttributes(bbwAttributes.checks,bbwAttributes.names,bbwAttributes.types);   
        } else if(showHideAttrs != null) {
            if(e.getSource() == showHideAttrs.okButton)
                showHideAttributes(showHideAttrs.checks,showHideAttrs.names,showHideAttrs.types);   
        } else if(deleteAttrs != null) {
            if(e.getSource() == deleteAttrs.okButton)
                deleteAttributes(deleteAttrs.checks,deleteAttrs.names,deleteAttrs.types);   
        }
    }
}

class JCAttributesDisplay extends Frame implements ActionListener
{
    public Vector checks;
    public Vector names;
    public Vector types;
    
    public Button okButton = new Button("Ok");
    Button cancelButton = new Button("Cancel");
    
    Panel data = new Panel();
    Panel buttons = new JCAttrButtonPanel();
    
    public JCAttributesDisplay(String title, Vector cs, Vector ns, Vector ts)
    {
        super();
        setTitle(title);
        
        checks = cs;
        names = ns;
        types = ts;
        
        data.setLayout(new GridLayout(0,3));

        for(int i=0;i<checks.size();i++) {
            data.add((Checkbox) checks.elementAt(i));
            data.add(new JCAttrTextField((String) names.elementAt(i)));
            data.add(new JCAttrTextField((String) types.elementAt(i)));
        }        
                 
        buttons.add(okButton);
        okButton.addActionListener(this);
        buttons.add(cancelButton);   
        cancelButton.addActionListener(this);
        JCAttrScrollPane p = new JCAttrScrollPane();
        p.add(data);
        add("Center",p);
        add("South",buttons);
        
        setSize(400,300);
        pack();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        setVisible(false);
    }

}

class JCAttrButtonPanel extends Panel
{
    public JCAttrButtonPanel()
    {
        super();
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(400,30);
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(400,30);
    }
}

class JCAttrScrollPane extends ScrollPane
{
    public JCAttrScrollPane()
    {
        super();
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(400,270);
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(400,270);
    }
}

class JCAttrCheckbox extends Checkbox {

    public JCAttrCheckbox()
    {
        super();
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(30,25);
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(30,25);
    }

}

class JCAttrTextField extends TextField {

    public JCAttrTextField(String value)
    {
        super(value);
    }
    
    public Dimension getMinimumSize()
    {
        return new Dimension(160,25);
    }
    
    public Dimension getPreferredSize()
    {
        return new Dimension(160,25);
    }

}
