package JComp;

import JViews.*;
import bbw.*;


public class JCAttrIcon extends JCAttrIconG {

  public JCAttrIcon() {
    super();
  }

    public MVBaseComp mapComponent(boolean do_map) {

System.out.println("in AttrIcon.mapComponent()");
System.out.println(this);
System.out.println("getName() = '"+getName()+"'");

        if(getName().equals(""))
            return null;

System.out.println("trying to map to base...");
System.out.println("getName() = '"+getName()+"'");

        JCBaseComp owner = (JCBaseComp) getOwner().baseComp();
        if(owner == null)
            return null;
System.out.println("adding attribute to "+owner.userName());

        JCBaseAttr base_comp = owner.findAttributeName(getName());

        if(do_map) {
            if(base_comp != null) {
                mapToBase(base_comp);
                return base_comp;
            } else {
                base_comp = owner.addAttribute(getName(),getType(),getMapToName());
                mapToCreatedBase(base_comp);
                return base_comp;
            }
        }
            else return base_comp;

    }

    public String userName() {
        if(hasOwner())
            return getOwner().userName()+":"+getName();
        else
            return ":"+getName();
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue)
                if(((MVSetValue) c).getPropertyName().equals("text") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for AttrIcon calling mapComponent...");
                        mapComponent(true);
                }

            return super.afterChange(c,from,rel_name);
        }

    
    public String getName() {
        char chars[] = getText().toCharArray();

        int i = 0;
        while(i < chars.length) {
            if(chars[i] == ':' || chars[i] == '=') 
                return new String(chars,0,i);
            i++;
        }
        return getText();
    }

    public String getType() {
        char chars[] = getText().toCharArray();

        int i = 0;
        while(i < chars.length) {
            if(chars[i] == ':') {
                int j = i + 1;
                while(j < chars.length) {
                    if(chars[j] == '=')
                        return new String(chars,i+1,j-i-1);
                    j++;
                }
                return new String(chars,i+1,chars.length - i - 1);
            }
            i++;
        }
        return "";
        
    }

    public String getMapToName() {
        char chars[] = getText().toCharArray();

        int i = chars.length - 1;
        while(i >= 0) {
            if(chars[i] == '=') 
                return new String(chars,i+1,chars.length-i-1);
            i--;
        }

        return "";
    }
}

