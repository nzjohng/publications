package JComp;

import JViews.*;
import bbw.*;

public class JCCompIconToBase extends JCCompIconToBaseG {

  public JCCompIconToBase() {
    super();
  }

    public String userName() {
        return "*unknown*";
    }

}

