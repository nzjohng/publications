package JComp;

import JViews.*;
import bbw.*;


import java.util.*;

/*
 * generated JViews component classes
 *
 */

public abstract class JCBaseLinkG extends MVBaseComp {

    /* Constructors */

    public JCBaseLinkG() {
        super();
    }

    public JCBaseLinkG(MVBaseLayer base_layer) {
        super(base_layer);
    }

    /* Attributes */

    public String getName() {
    return getStringValue("Name");
    }

    public void setName(String value) {
        setValue("Name",value);
    }

    public String getParentArity() {
    return getStringValue("ParentArity");
    }

    public void setParentArity(String value) {
        setValue("ParentArity",value);
    }

    public String getChildArity() {
    return getStringValue("ChildArity");
    }

    public void setChildArity(String value) {
        setValue("ChildArity",value);
    }

    public boolean isParentListenBefore() {
    return getBooleanValue("ParentListenBefore");
    }

    public void setParentListenBefore(boolean value) {
        setValue("ParentListenBefore",value);
    }

    public boolean isParentListenAfter() {
    return getBooleanValue("ParentListenAfter");
    }

    public void setParentListenAfter(boolean value) {
        setValue("ParentListenAfter",value);
    }

    public boolean isParentHandleBefore() {
    return getBooleanValue("ParentHandleBefore");
    }

    public void setParentHandleBefore(boolean value) {
        setValue("ParentHandleBefore",value);
    }

    public boolean isParentHandleAfter() {
    return getBooleanValue("ParentHandleAfter");
    }

    public void setParentHandleAfter(boolean value) {
        setValue("ParentHandleAfter",value);
    }

    public boolean isChildListenBefore() {
    return getBooleanValue("ChildListenBefore");
    }

    public void setChildListenBefore(boolean value) {
        setValue("ChildListenBefore",value);
    }

    public boolean isChildListenAfter() {
    return getBooleanValue("ChildListenAfter");
    }

    public void setChildListenAfter(boolean value) {
        setValue("ChildListenAfter",value);
    }

    public boolean isChildHandleBefore() {
    return getBooleanValue("ChildHandleBefore");
    }

    public void setChildHandleBefore(boolean value) {
        setValue("ChildHandleBefore",value);
    }

    public boolean isChildHandleAfter() {
    return getBooleanValue("ChildHandleAfter");
    }

    public void setChildHandleAfter(boolean value) {
        setValue("ChildHandleAfter",value);
    }

    public boolean isAggregate() {
    return getBooleanValue("Aggregate");
    }

    public void setAggregate(boolean value) {
        setValue("Aggregate",value);
    }

    public boolean isGenerateCode() {
    return getBooleanValue("GenerateCode");
    }

    public void setGenerateCode(boolean value) {
        setValue("GenerateCode",value);
    }

    public boolean isCreateLinked() {
    return getBooleanValue("CreateLinked");
    }

    public void setCreateLinked(boolean value) {
        setValue("CreateLinked",value);
    }

    /* Relationships */

    public JCBaseComp getpLinkParent() {
        return (JCBaseComp)getOneRelated("LinkParent",MVParents);
    }

    public JCBaseComp getpLinkChild() {
        return (JCBaseComp)getOneRelated("LinkChild",MVParents);
    }

    /* Methods */

    public abstract String userName();

    public String kindName() {
        return "Base Link";
    }

    /* Read/write methods */

}

