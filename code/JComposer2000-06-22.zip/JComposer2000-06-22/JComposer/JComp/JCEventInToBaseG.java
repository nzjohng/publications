package Serendipity;
import JViews.*;
import java.util.*;

public abstract class SEStartIconToBaseG extends MVViewRel
 {

  public SEStartIconToBaseG() {
    super();
  }

  public String kindName() {
    return "Kind";
  }

  public abstract String userName();


  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue) {
      String name = ((MVSetValue)c).getPropertyName();
      if(isParent(c.target) && name.equals("name")) {
                Enumeration e = children();
        while(e.hasMoreElements()) {
                    ((SEStartIcon)e.nextElement()).setText(((SEBaseStartStage)c.target).getName());
        }
      }
            else if(isChild(c.target) && name.equals("text")) {
                Enumeration e = parents();
        while(e.hasMoreElements()) {
                    ((SEBaseStartStage)e.nextElement()).setName(((SEStartIcon)c.target).getText());
        }
      }
    }
    return super.afterChange(c,from,rel_name);
  }


  public String viewRelKind() {
    return "SEStartIconToBase";
  }

  public void upliftAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEStartIcon)vc).setText(((SEBaseStartStage)bc).getName());
  }

  public void downloadAttributes(MVBaseComp bc, MVViewComp vc) {
  ((SEBaseStartStage)bc).setName(((SEStartIcon)vc).getText());
  }

  public MVViewRel newViewRel() {
    return new SEStartIconToBase();
  }

  public String getViewRelKind() {
    return "SEStartIconToBase";
  }


  public void establish(MVComponent parent, MVComponent child) {
    super.establish(parent,child);
  }

}

