package JComp;

import JViews.*;
import bbw.*;


/* hand-written stuff */

public class JCLinkGlue extends JCLinkGlueG {

    public JCLinkGlue() {
        super();
    }

    public String userName() {
        if(hasParent())
            return getParent().userName()+"->"+getNameText();
        else
            return getNameText();
    }

    public MVBaseComp mapComponent(boolean do_map) {
    
        if(getNameText().equals(""))
            return null;

    System.out.println("in JCLinkGlue.mapComponent:");

        JCBaseComp p = (JCBaseComp) getParent().baseComp();
        JCBaseComp c = (JCBaseComp) getChild().baseComp();

        if(p == null || c == null)
            return null;

        JCBaseLink l1 = p.findParentLink(getNameText(),c);

        if(do_map) {
            if(l1 != null) {
                mapToBase(l1);
                return l1;
            } else {
                l1 = new JCBaseLink(view().getBaseLayer());
                p.establishLinkParent(l1);
                c.establishLinkChild(l1);
                mapToCreatedBase(l1);
                return l1;
            }
        } else
            return l1;
    }

    public MVChangeDescr afterChange(MVChangeDescr c, MVComponent from,
        String rel_name) {

            if(c instanceof MVSetValue)
                if(((MVSetValue) c).getPropertyName().equals("nameText") &&
                    baseComp() == null && hasView()) {
System.out.println("afterUpdate for LinkGlue calling mapComponent...");
                        mapComponent(true);
                }

            return super.afterChange(c,from,rel_name);
        }

}

