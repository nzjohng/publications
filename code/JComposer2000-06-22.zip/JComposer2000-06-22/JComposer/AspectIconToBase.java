package ;

import JViews.*;

public class AspectIconToBase extends AspectIconToBaseG {

  public AspectIconToBase() {
    super();
  }


  public String userName() {
    return "*unknown*";
  }

}

