package ;
import JViews.*;
import java.util.*;
import java.awt.*;
import bbw.*;
import java.beans.*;
import jComposer.*;

public abstract class AspectInfoIconG extends MVViewComp
 {

  public AspectInfoIconG() {
    super();
  }

  public String kindName() {
    return "Aspect Info Icon";
  }

  public abstract String userName();


  public int getWidth() {
    return getIntValue("width");
  }

  public void setWidth(int value) {
    setValue("width",value);
  }


  public int getHeight() {
    return getIntValue("height");
  }

  public void setHeight(int value) {
    setValue("height",value);
  }


  public String getAspectName() {
    return getStringValue("aspectName");
  }

  public void setAspectName(String value) {
    setValue("aspectName",value);
  }


  public boolean isDesignLevel() {
    return getBooleanValue("designLevel");
  }

  public void setDesignLevel(boolean value) {
    setValue("designLevel",value);
  }


  public String getJviewsClass() {
    return getStringValue("jviewsClass");
  }

  public void setJviewsClass(String value) {
    setValue("jviewsClass",value);
  }


  public String getAspectType() {
    return getStringValue("aspectType");
  }

  public void setAspectType(String value) {
    setValue("aspectType",value);
  }


  public int getY() {
    return getIntValue("y");
  }

  public void setY(int value) {
    setValue("y",value);
  }


  public int getX() {
    return getIntValue("x");
  }

  public void setX(int value) {
    setValue("x",value);
  }


  public AspectIconToBase getprAspectIconToBase() {
    return (AspectIconToBase) getOneRelated("MVViewRel",MVParents);
  }

  public void establishAspectIconToBase(BaseAspectInfo comp) {
    comp.establishAspectIconToBase((AspectInfoIcon) this);
  }

  public void dissolveAspectIconToBase(BaseAspectInfo comp) {
    comp.dissolveAspectIconToBase((AspectInfoIcon) this);
  }

  public BaseAspectInfo getpAspectIconToBase() {
    return (BaseAspectInfo) getOneRelated("MVViewRel",MVParentRelComps);
  }

  public MVChangeDescr beforeChange(MVChangeDescr c,
      MVComponent from, String rel_name) {
    return super.beforeChange(c,from,rel_name);
  }

  public MVChangeDescr afterChange(MVChangeDescr c,
      MVComponent from, String rel_name) {

    if(c instanceof MVSetValue && getBBWShape() != null) {
      if(((MVSetValue) c).getPropertyName().equals("width"))
        getJCAspectInfo().setWidth((getWidth()));
      if(((MVSetValue) c).getPropertyName().equals("height"))
        getJCAspectInfo().setHeight((getHeight()));
      if(((MVSetValue) c).getPropertyName().equals("aspectName"))
        getJCAspectInfo().setAspectName((getAspectName()));
      if(((MVSetValue) c).getPropertyName().equals("designLevel"))
        getJCAspectInfo().setDesignLevel((isDesignLevel()));
      if(((MVSetValue) c).getPropertyName().equals("jviewsClass"))
        getJCAspectInfo().setJviewsClass((getJviewsClass()));
      if(((MVSetValue) c).getPropertyName().equals("aspectType"))
        getJCAspectInfo().setAspectType((getAspectType()));
      if(((MVSetValue) c).getPropertyName().equals("y"))
        getJCAspectInfo().setY((getY()));
      if(((MVSetValue) c).getPropertyName().equals("x"))
        getJCAspectInfo().setX((getX()));
    }

    return super.afterChange(c,from,rel_name);
  }

  public String viewRelKind() {
    return "AspectIconToBase";
  }

  public MVViewRel newViewRel() {
    return new AspectIconToBase();
  }


  public JCAspectInfo getJCAspectInfo() {
    return (JCAspectInfo) getBBWShape();
  }



  public void propertyChange(PropertyChangeEvent evt) {
    if(hasView() && !view().processingBBWEvents && view().processingBBWChange) {
      super.propertyChange(evt);
      return;
    }

      if(evt.getPropertyName().equals("width"))
        setWidth((getJCAspectInfo().getWidth()));
      if(evt.getPropertyName().equals("height"))
        setHeight((getJCAspectInfo().getHeight()));
      if(evt.getPropertyName().equals("aspectName"))
        setAspectName((getJCAspectInfo().getAspectName()));
      if(evt.getPropertyName().equals("designLevel"))
        setDesignLevel((getJCAspectInfo().isDesignLevel()));
      if(evt.getPropertyName().equals("jviewsClass"))
        setJviewsClass((getJCAspectInfo().getJviewsClass()));
      if(evt.getPropertyName().equals("aspectType"))
        setAspectType((getJCAspectInfo().getAspectType()));
      if(evt.getPropertyName().equals("y"))
        setY((getJCAspectInfo().getY()));
      if(evt.getPropertyName().equals("x"))
        setX((getJCAspectInfo().getX()));
    super.propertyChange(evt);
  }

  public void addedBBWShape(BBWComponent  shape) {
    super.addedBBWShape(shape);
        setWidth((getJCAspectInfo().getWidth()));
        setHeight((getJCAspectInfo().getHeight()));
        setAspectName((getJCAspectInfo().getAspectName()));
        setDesignLevel((getJCAspectInfo().isDesignLevel()));
        setJviewsClass((getJCAspectInfo().getJviewsClass()));
        setAspectType((getJCAspectInfo().getAspectType()));
        setY((getJCAspectInfo().getY()));
        setX((getJCAspectInfo().getX()));
  }

  public void addedViewComp(BBWComponent  shape) {
    super.addedViewComp(shape);
        if(getAttribute("width") == null)
          setWidth((getJCAspectInfo().getWidth()));
        else
          getJCAspectInfo().setWidth((getWidth()));
        if(getAttribute("height") == null)
          setHeight((getJCAspectInfo().getHeight()));
        else
          getJCAspectInfo().setHeight((getHeight()));
        if(getAttribute("aspectName") == null)
          setAspectName((getJCAspectInfo().getAspectName()));
        else
          getJCAspectInfo().setAspectName((getAspectName()));
        if(getAttribute("designLevel") == null)
          setDesignLevel((getJCAspectInfo().isDesignLevel()));
        else
          getJCAspectInfo().setDesignLevel((isDesignLevel()));
        if(getAttribute("jviewsClass") == null)
          setJviewsClass((getJCAspectInfo().getJviewsClass()));
        else
          getJCAspectInfo().setJviewsClass((getJviewsClass()));
        if(getAttribute("aspectType") == null)
          setAspectType((getJCAspectInfo().getAspectType()));
        else
          getJCAspectInfo().setAspectType((getAspectType()));
        if(getAttribute("y") == null)
          setY((getJCAspectInfo().getY()));
        else
          getJCAspectInfo().setY((getY()));
        if(getAttribute("x") == null)
          setX((getJCAspectInfo().getX()));
        else
          getJCAspectInfo().setX((getX()));
  }

}

