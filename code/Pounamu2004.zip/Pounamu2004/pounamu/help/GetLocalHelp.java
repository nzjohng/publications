/*
 * @(#)GetLocalHelp.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.help;

import java.io.*;
import javax.swing.*;
import pounamu.core.*;
import java.awt.*;
/**
 * Title: GetLocalHelp
 * Description:  A class to display the tutorial files of this tool
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class GetLocalHelp implements Runnable {

   Pounamu pounamu = null;
   String fileSeparator = null;
  /**
    * construct this class which will open a browser window and display the tutorial file of this tool
    * @param univModeller the UnivModeller instance which this class works for
    */
   public GetLocalHelp(Pounamu pounamu) {
     this.pounamu = pounamu;
     fileSeparator = System.getProperty("file.separator");
   }

   /**
    * open a browser window and display the tutorial files of this tool
    */
   public void run() {
     try{
       String filePath = (String)pounamu.getProperties().get("pounamu")+""+fileSeparator+"documents"+fileSeparator+"tutorial"+fileSeparator+"title.html";
       Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + filePath);
     }
     catch(Exception eeee){
       pounamu.displayMessage("Exception from Class GetLocalHelp: " + eeee.getMessage());
       Toolkit.getDefaultToolkit().beep();
     }  
   }
}