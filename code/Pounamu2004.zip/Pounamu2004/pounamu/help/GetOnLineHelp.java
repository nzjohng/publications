/*
 * @(#)GetOnLineHelp.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.help;

import java.io.*;
import javax.swing.*;
import pounamu.core.*;
import java.awt.*;
/**
 * Title: GetOnLineHelp
 * Description:  A class to display any online information of this tool
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class GetOnLineHelp implements Runnable {

   Pounamu pounamu = null;

  /**
    * construct this class which will open a browser window and connect to Pounamu home
    * @param univModeller the UnivModeller instance which this class works for
    */
   public GetOnLineHelp(Pounamu pounamu) {
     this.pounamu = pounamu;
   }

  /**
   * open a browser window and connect to the pounamu home
   */
   public void run() {
     try{
       String filePath = "http://www.cs.auckland.ac.nz/compsci732s1c";
       Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + filePath);
     }
     catch(Exception eeee){
       pounamu.displayMessage("Exception from Class GetOnLineHelp: " + eeee.getMessage());
       Toolkit.getDefaultToolkit().beep();
     }  
   }
}