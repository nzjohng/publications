/*
 * @(#)PounamuVersionDialog.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.help;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import pounamu.core.*;

/**
 * Title: PounamuVersionDialog
 * Description:  A dialog to display any information related to the version of this tool
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class PounamuVersionDialog extends JDialog implements ActionListener {

  JPanel panel1 = new JPanel();
  JPanel panel2 = new JPanel();
  JPanel insetsPanel1 = new JPanel();
  JPanel insetsPanel2 = new JPanel();
  JPanel insetsPanel3 = new JPanel();
  JButton button1 = new JButton();
  JLabel imageControl1 = new JLabel();
  ImageIcon imageIcon;
  JLabel label1 = new JLabel();
  JLabel label2 = new JLabel();
  JLabel label3 = new JLabel();
  JLabel label4 = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  BorderLayout borderLayout2 = new BorderLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  FlowLayout flowLayout2 = new FlowLayout();
  GridLayout gridLayout1 = new GridLayout();
  String product = "Pounamu";
  String version = "version 1.0";
  String copyright = "Copyright (c) 2003";
  String comments = "A MetaCASE / CASE Tool";
  String fileSeparator = null;
   /**
    * construct this dialog which will display information related to the version of this tool
    * @param univModeller the UnivModeller instance which this class works for
    */
  public PounamuVersionDialog(Pounamu pounamu) {
    super(pounamu, "About Pounamu", true);
    fileSeparator = System.getProperty("file.separator");
    try  {
      //System.out.println("path is +++ " + pounamu.getProperties().get("pounamu")+""+fileSeparator+"image"+fileSeparator+"folder.gif");
      imageIcon = new ImageIcon(PounamuVersionDialog.class.getResource(".."+fileSeparator+"image"+fileSeparator+"pounamu.gif"));
      imageControl1.setIcon(imageIcon);
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    //imageControl1.setIcon(pounamu.imags[15]);
    pack();
  }

  /**
   * initial visual components
   */
  private void jbInit() throws Exception  {

    //this.setTitle("About");
    setResizable(false);
    panel1.setLayout(borderLayout1);
    panel2.setLayout(borderLayout2);
    insetsPanel1.setLayout(flowLayout1);
    insetsPanel2.setLayout(flowLayout1);
    insetsPanel2.setBorder(new EmptyBorder(10, 10, 10, 10));
    gridLayout1.setRows(4);
    gridLayout1.setColumns(1);
    label1.setText(product);
    label2.setText(version);
    label3.setText(copyright);
    label4.setText(comments);
    insetsPanel3.setLayout(gridLayout1);
    insetsPanel3.setBorder(new EmptyBorder(10, 10, 10, 10));
    button1.setText("OK");
    button1.addActionListener(this);
    insetsPanel2.add(imageControl1, null);
    panel2.add(insetsPanel2, BorderLayout.WEST);
    this.getContentPane().add(panel1, null);
    insetsPanel3.add(label1, null);
    insetsPanel3.add(label2, null);
    insetsPanel3.add(label3, null);
    insetsPanel3.add(label4, null);
    panel2.add(insetsPanel3, BorderLayout.CENTER);
    insetsPanel1.add(button1, null);
    panel1.add(insetsPanel1, BorderLayout.SOUTH);
    panel1.add(panel2, BorderLayout.NORTH);
  }

  /**
   * close this dialog
   */
  public void actionPerformed(ActionEvent e) {
    if(e.getSource() == button1) {
       dispose();
    }
  }
}