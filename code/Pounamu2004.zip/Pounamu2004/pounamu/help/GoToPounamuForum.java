/*
 * @(#)GoToPounamuForum.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.help;

import java.io.*;
import javax.swing.*;
import pounamu.core.*;
import java.awt.*;
/**
 * Title: GoToPounamuForum
 * Description:  A class to guide users of this tool to the forum of this tool
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class GoToPounamuForum implements Runnable {

   Pounamu pounamu = null;

   /**
    * construct this class which will open a browser window and connect to Pounamu forum
    * @param univModeller the UnivModeller instance which this class works for
    */
   public GoToPounamuForum(Pounamu pounamu) {
     this.pounamu = pounamu;
   }

   /**
    * open a browser window and connect to the pounamu forum
    */
   public void run() {
     try{
       String filePath = "http://forums.cs.auckland.ac.nz:8181/";
       Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + filePath);
     }
     catch(Exception eeee){
       pounamu.displayMessage("Exception from Class GoToPounamuForum: " + eeee.getMessage());
       Toolkit.getDefaultToolkit().beep();
     }  
   }
}