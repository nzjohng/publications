/*
 * ModelEventHandler.java
 *
 * Created on 5 August 2003, 10:11
 */

package pounamu.core;

import pounamu.event.*;
import pounamu.data.*;
import java.util.*;

/**
 *
 * @author  nzhu002
 */
public class PounamuModelHandler extends PounamuHandler {
    
    /** Creates a new instance of ModelEventHandler */
    public PounamuModelHandler() {
      super();
    }
    
  /**
   * when a model project is set, the "tool", "manager", "pounamu" objects are also set, so that users can access them in their own code,
   * @param model the model the event hander belongs to
   */
  public void setModel(PounamuModelProject model){
    this.model = model;
    this.tool = model.getTool();
    this.manager = model.getManager();
    this.pounamu = manager.getPounamu();
  }
  
}
