/*
 * @(#)Configuration.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import java.util.*;
import pounamu.data.*;

/**
 * Title: PounamuTabbedPane
 * Description:  extend JTabbedPane to hold all views in Pounamu
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuTabbedPane extends JTabbedPane implements ChangeListener{

  Hashtable compAndScrollPaneMapping = new Hashtable();
  Hashtable scrollPaneAndCompMapping = new Hashtable();
  PounamuProject project = null;

  /**
   * the constructor
   * i) super
   * ii) add a change listener
   */
  public PounamuTabbedPane(){
    super();
    this.addChangeListener(this);
  }

  /**
   * the constructor
   * i) super
   * ii) add a change listener
   * @param manager the PounamuProjectManagerPanel object
   */
  public PounamuTabbedPane(PounamuProject project){
    super();
    this.project = project;
    this.addChangeListener(this);
  }

  /**
   * set the value of project
   * @param manager the PounamuProjectManagerPanel object
   */
  public void setProject(PounamuProject project){
    this.project = project;
  }
  
  /**
   * add a new tab to this PounamuTabbedPane
   * @param name the tab name
   * @param tab the component to be added
   */
  public void addTab(String name, Component tab){
    if(tab == null)
      return;
    if(tab instanceof JPanel){
      JScrollPane jsp = new JScrollPane(tab);
      compAndScrollPaneMapping.put(tab, jsp);
      scrollPaneAndCompMapping.put(jsp, tab);
      super.addTab(name, jsp);
    }
    else
      super.addTab(name, tab);
  }

  /**
   * return the compAndScrollPaneMappingtable which map the tab component and its surrounded JScrollPane
   * @return the hashtable
   */
  public Hashtable getCompAndScrollPaneMapping(){
    return compAndScrollPaneMapping;
  }

  /**
   * get the mappings from the scroll pane to component
   * @return the mappings from the scroll pane to component in a hashtable
   */
  public Hashtable getScrollPaneAndCompMapping(){
    return scrollPaneAndCompMapping;
  }

  /**
   * remove a tab
   * @param tab the component to be removed
   */
  public void remove(Component tab){
    if(tab instanceof JPanel){
      if(compAndScrollPaneMapping.get(tab)==null)
        return;
      JScrollPane jsp = (JScrollPane)compAndScrollPaneMapping.get(tab);
      super.remove(jsp);
      compAndScrollPaneMapping.remove(tab);
    }
    else super.remove(tab);
  }

  /**
   * set the selected component
   * @param tab the component to be selected
   */
  public void setSelectedComponent(Component tab){
    if(tab instanceof JPanel){
      if(compAndScrollPaneMapping.get(tab)==null)
        return;
      JScrollPane jsp = (JScrollPane)compAndScrollPaneMapping.get(tab);
      super.setSelectedComponent(jsp);
    }
    else super.setSelectedComponent(tab);
  }

  /**
   * get the index of the specifuied tab component
   * @param tab the specified component
   * @return the index of the tab
   */
  public int indexOfComponent(Component tab){
    if(tab instanceof JPanel){
      if(compAndScrollPaneMapping.get(tab)==null)
        return -1;
      JScrollPane jsp = (JScrollPane)compAndScrollPaneMapping.get(tab);
      return super.indexOfComponent(jsp);
    }
    return super.indexOfComponent(tab);
  }

  /**
   * implement the change listenner
   * when the selected tab change, the selection of the manager tree will change corresponsively
   * @param ce the Change event object
   */
  public void stateChanged(ChangeEvent ce){
    if(project == null)
      return;
    if(this.getSelectedIndex()<0)
      return;
    Component tab = this.getSelectedComponent();
    String s = this.getTitleAt(this.getSelectedIndex());
    if(project.getViewsTabNode(tab) != null){
      DefaultMutableTreeNode node = project.getViewsTabNode(tab);
      TreePath tp = new TreePath(node.getPath());
      project.getManagerTree().setSelectionPath(tp);
    }
    /*System.out.println("in class  PounamuTabbedPane, visited");
    if((Component)scrollPaneAndCompMapping.get(tab) != null){
      System.out.println("in class  PounamuTabbedPane (Component)scrollPaneAndCompMapping.get(tab) != null");
    if(project.getViewTabNode((Component)scrollPaneAndCompMapping.get(tab)) != null)
      System.out.println("in class  PounamuTabbedPane project.getViewTabNode((Component)scrollPaneAndCompMapping.get(tab)) != null)");
    }*/
    if(((Component)scrollPaneAndCompMapping.get(tab) != null)&& (project.getViewTabNode((Component)scrollPaneAndCompMapping.get(tab)) != null)){
      DefaultMutableTreeNode node = project.getViewTabNode((Component)scrollPaneAndCompMapping.get(tab));
      TreePath tp = new TreePath(node.getPath());
      project.getManagerTree().setSelectionPath(tp);
    }
  }

}


