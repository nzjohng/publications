/*
 * @(#)PounamuTreeCellRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;
import java.util.*;

/**
 * Title: PounamuTreeCellRenderer
 * Description:  A extended DefaultTreeCellRenderer which defines how to render the object as a tree selectedNode
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuTreeModelListener implements TreeModelListener {
         
        PounamuManagerPanel manager = null;
        Pounamu pounamu = null;
        DefaultMutableTreeNode parentNode = null; 
        DefaultMutableTreeNode selectedNode = null; 
        String fileSeparator = null;
        public PounamuTreeModelListener(PounamuManagerPanel manager) {
          this.manager = manager;
          this.pounamu = manager.getPounamu();
          fileSeparator = System.getProperty("file.separator");
        }

        public void treeNodesChanged(TreeModelEvent treeModelEvent) {
          parentNode = (DefaultMutableTreeNode)(treeModelEvent.getTreePath().getLastPathComponent());
          try {
            int index = treeModelEvent.getChildIndices()[0];
            selectedNode = (DefaultMutableTreeNode)parentNode.getChildAt(index);
          } 
          catch (NullPointerException exc) {
            parentNode.setUserObject("pounamu");
            pounamu.displayMessage("This node value is not editable!");
            return;
          }
          String oldName = (String)manager.getNodeAndItsValueMapping().get(selectedNode);
          String newName = (String)selectedNode.getUserObject(); 
          if (oldName.equals("pounamu")
              ||oldName.equals("tool projects")
              ||oldName.equals("model projects")
              ||oldName.equals("entity")
              ||oldName.equals("association")
              ||oldName.equals("entity type")
              ||oldName.equals("association type")
              ||oldName.equals("icon_creator")
              ||oldName.equals("shape_creator")
              ||oldName.equals("connector_creator")
              ||oldName.equals("handler_definer")
              ||oldName.equals("model_handler_definer")
              ||oldName.equals("model_event_handler_definer")
              ||oldName.equals("model_user_handler_definer")
              ||oldName.equals("visual_handler_definer")
              ||oldName.equals("visual_event_handler_definer")
              ||oldName.equals("visual_user_handler_definer")
              ||oldName.equals("meta_model_definer")
              ||oldName.equals("view_type_definer")
              ||oldName.startsWith("Using_")) {
              selectedNode.setUserObject(oldName);
              pounamu.displayMessage("This node value is not editable!");
              return;
           }
          String temp = newName.trim(); 
           if(temp.equals("pounamu")
              ||temp.equals("tool projects")
              ||temp.equals("model projects")
              ||temp.equals("entity")
              ||temp.equals("association")
              ||temp.equals("entity type")
              ||temp.equals("association type")
              ||temp.equals("icon_creator")
              ||temp.equals("shape_creator")
              ||temp.equals("connector_creator")
              ||temp.equals("handler_definer")
              ||temp.equals("model_handler_definer")
              ||temp.equals("model_event_handler_definer")
              ||temp.equals("model_user_handler_definer")
              ||temp.equals("visual_handler_definer")
              ||temp.equals("visual_event_handler_definer")
              ||temp.equals("visual_user_handler_definer")               
              ||temp.equals("meta_model_definer")
              ||temp.equals("view_type_definer")
              ||temp.startsWith("Using_")) {
              selectedNode.setUserObject(manager.getNodeAndItsValueMapping().get(selectedNode));
              pounamu.displayMessage("The name you input is not valid for this node! Operation ignored!");
              return;
            }
            String parentName = (String)parentNode.getUserObject(); 
            if(manager.getNodeAndProjectMapping().get(selectedNode) instanceof PounamuToolProject){
              //System.out.println("tool in class TrremodelListener, selected node is now " + manager.getSelectedNode().getUserObject());
              PounamuToolProject tool = (PounamuToolProject)manager.getNodeAndProjectMapping().get(selectedNode);
              tool.save();
              //THE SELECTED node is a tool project node
              if(parentName.equals("tool projects")){
                if(newName.indexOf(" ")>0){
                  selectedNode.setUserObject(oldName);
                  pounamu.displayMessage("As tool name will be used as part of package name in java class, space in it is not allowed!");
                  return;
                }
                if(manager.getRegisteredTools().containsKey(newName)){
                  selectedNode.setUserObject(oldName);
                  pounamu.displayMessage("A tool with the name you input already existed! operation ignored!");
                  return;
                }
                //tool.deleteFolders();
                tool.setName(newName);
                tool.setLocation(pounamu.getPounamuHome()+fileSeparator+"tools"+fileSeparator+newName);
                tool.createFolders();
                tool.doRegisterToolProject(selectedNode);
                String fullPath = "\""+pounamu.getPounamuHome()+fileSeparator+"tools"+fileSeparator+oldName+"\"";
                //System.out.println("fullPath in class toolProject is " + fullPath);
                MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefolder");
                mfs.run();
                manager.getRegisteredTools().remove(manager.getNodeAndItsValueMapping().get(selectedNode));
                if(manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(selectedNode) != null){
                  DefaultMutableTreeNode ddd = (DefaultMutableTreeNode)manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(selectedNode);
                  ddd.setUserObject("Using_"+newName);
                }
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a connector node
              else if(tool.getNodeAndConnectorMapping().get(selectedNode) != null){ 
                if(tool.getRegisteredConnectors().contains(newName)){
                  selectedNode.setUserObject(oldName);
                  pounamu.displayMessage("A connector with the name you input already existed! operation ignored!");
                  return;
                }
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                view.setName(newName);
                IconDisplayPanel panel = (IconDisplayPanel)view.getDisplayPanel();
                PounamuConnector con = (PounamuConnector)tool.getNodeAndConnectorMapping().get(selectedNode);
                con.setDisplayName(newName);
                PounamuTabbedPane tabs = (PounamuTabbedPane)tool.getNodeAndViewsTabMapping().get(selectedNode);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);//for a shape selectedNode
                tool.getRegisteredConnectors().remove(oldName);
                tool.getIconNameToTextAreaPropertiesMapping().remove(oldName);
                tool.getIconNameToTextFieldPropertiesMapping().remove(oldName);
                tool.doSaveIcon(selectedNode);
                tool.doRegisterConnector(selectedNode);
                String fullPath = "\""+tool.getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+oldName+".xml\"";
                MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                mfs.run();                
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a shape node
              else if(tool.getNodeAndShapeMapping().get(selectedNode) != null){
                if(tool.getRegisteredShapes().contains(newName)){
                  selectedNode.setUserObject(oldName);
                  pounamu.displayMessage("A shape with the name you input already existed! operation ignored!");
                  return;
                }
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                view.setName(newName);                
                PounamuShape shape = (PounamuShape)tool.getNodeAndShapeMapping().get(selectedNode);
                shape.setDisplayName(newName);
                PounamuTabbedPane tabs = (PounamuTabbedPane)tool.getNodeAndViewsTabMapping().get(selectedNode);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);//for a shape selectedNode
                tool.getRegisteredShapes().remove(oldName);
                tool.getIconNameToTextAreaPropertiesMapping().remove(oldName);
                tool.getIconNameToTextFieldPropertiesMapping().remove(oldName);
                tool.doSaveIcon(selectedNode);
                tool.doRegisterShape(selectedNode);
                String fullPath = "\""+tool.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+oldName+".xml\"";
                MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                mfs.run();                
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a visual component node under a shape node
              else if(tool.getNodeAndComponentMapping().get(selectedNode) != null){
                Configurable con = (Configurable)tool.getNodeAndComponentMapping().get(selectedNode);
                con.setDisplayName(newName);
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a model handler node or visual handler node
              else if(parentName.equals("model_event_handler_definer")
                    ||parentName.equals("model_user_handler_definer")
                    ||parentName.equals("visual_event_handler_definer")
                    ||parentName.equals("visual_user_handler_definer")){
                if(newName.indexOf(" ") > 0){
                  pounamu.displayMessage("the name you input is not a valid handler name. no space in the name please!");
                  selectedNode.setUserObject(oldName);
                  return;
                }
                else if(parentName.equals("model_event_handler_definer")&&tool.getRegisteredModelEventHandlers().containsKey(newName)){
                  pounamu.displayMessage("the name you input has been used by an existed handler. Operation cancelled.");
                  selectedNode.setUserObject(oldName);
                  return;
                } 
                else if(parentName.equals("model_user_handler_definer")&&tool.getRegisteredModelUserHandlers().containsKey(newName)){
                  pounamu.displayMessage("the name you input has been used by an existed handler. Operation cancelled.");
                  selectedNode.setUserObject(oldName);
                  return;
                } 
                else if(parentName.equals("visual_event_handler_definer")&&tool.getRegisteredVisualEventHandlers().containsKey(newName)){
                  pounamu.displayMessage("the name you input has been used by an existed handler. Operation cancelled.");
                  selectedNode.setUserObject(oldName);
                  return;
                } 
                else if(parentName.equals("visual_user_handler_definer")&&tool.getRegisteredVisualUserHandlers().containsKey(newName)){
                  pounamu.displayMessage("the name you input has been used by an existed handler. Operation cancelled.");
                  selectedNode.setUserObject(oldName);
                  return;
                } 
                else{}
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
                PounamuTabbedPane tabs = (PounamuTabbedPane)tool.getNodeAndViewsTabMapping().get(selectedNode);
                view.setName(newName);
                panel.setName(newName);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);
                if(parentName.equals("model_event_handler_definer")){
                  tool.getRegisteredModelEventHandlers().remove(oldName);
                  tool.doRegisterModelEventHandler(selectedNode);
                  String fullPath = "\""+tool.getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+oldName+".xml\"";
                  MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                  mfs.run();                 
                }
                else if(parentName.equals("model_user_handler_definer")){
                  tool.getRegisteredModelUserHandlers().remove(oldName);
                  tool.doRegisterModelUserHandler(selectedNode);
                  String fullPath = "\""+tool.getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+oldName+".xml\"";
                  MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                  mfs.run();                
                }
                else if(parentName.equals("visual_event_handler_definer")){
                  tool.getRegisteredVisualEventHandlers().remove(oldName);
                  tool.doRegisterVisualEventHandler(selectedNode);
                  String fullPath = "\""+tool.getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+oldName+".xml\"";
                  MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                  mfs.run();                
                }
                else if(parentName.equals("visual_user_handler_definer")){
                  tool.getRegisteredVisualUserHandlers().remove(oldName);
                  tool.doRegisterVisualUserHandler(selectedNode);
                  String fullPath = "\""+tool.getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+oldName+".xml\"";
                  MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                  mfs.run();                
                }
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a view type node
              else if(parentName.equals("view_type_definer")){
                if(newName.indexOf(":") > 0){
                  pounamu.displayMessage("the name you input is not a valid view type name. no \":\" in the name please!");
                  selectedNode.setUserObject(oldName);
                  return;
                }
                if(tool.getRegisteredViewTypes().contains(newName)){
                   pounamu.displayMessage("a view type with the name you input existed already! operation ignored!");
                   selectedNode.setUserObject(oldName);
                   return;
                }
                tool.doDeregisterViewType(selectedNode, "rename", oldName);
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                view.setName(newName);
                ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel();
                //String oldName = (String)(manager.getNodeAndItsValueMapping().get(selectedNode));
                PounamuTabbedPane tabs = (PounamuTabbedPane)tool.getNodeAndViewsTabMapping().get(selectedNode);
                view.setName(newName);
                panel.setName(newName);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
                tool.doRegisterViewType(selectedNode);
              }
              //the selected node is a meta model view node
              else if(parentName.equals("meta_model_definer")){
                if(tool.getRegisteredMetaModelViews().contains(newName)){
                  selectedNode.setUserObject(oldName);
                  pounamu.displayMessage("A meta model view with the name you input already existed! operation ignored!");
                  return;
                }
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                PounamuTabbedPane tabs = (PounamuTabbedPane)tool.getNodeAndViewsTabMapping().get(selectedNode);
                view.setName(newName);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);
                tool.getRegisteredMetaModelViews().remove(oldName);
                tool.doRegisterMetaModelView(selectedNode);
                String fullPath = "\""+tool.getLocation()+fileSeparator+"metamodel"+fileSeparator+"metamodelviews"+fileSeparator+oldName+".xml\"";
                MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
                mfs.run();                
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the node is an entity type node
              else if(tool.getEntityTypeObject(selectedNode) != null){
                //get the current meta model view
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                //the current entity type object
                PounamuMetaModelElement oldEntityTypeObject = (PounamuMetaModelElement)tool.getEntityTypeObject(selectedNode);
                //set name for the entity type object
                oldEntityTypeObject.setName(newName);                
              }
              //the node is an association type node
              else if(tool.getAssociationTypeObject(selectedNode) != null){
                //get the current meta model view
                PounamuView view = (PounamuView)(tool.getNodeAndViewMapping().get(selectedNode));
                //the current association type object
                PounamuMetaModelElement oldAssociationTypeObject = (PounamuMetaModelElement)tool.getAssociationTypeObject(selectedNode);
                //set name for the association type object
                oldAssociationTypeObject.setName(newName);                
              }                           
            }
            else if(manager.getNodeAndProjectMapping().get(selectedNode) instanceof PounamuModelProject){
              //System.out.println("model in class TrremodelListener, selected node is now " + manager.getSelectedNode().getUserObject());
              PounamuModelProject model = (PounamuModelProject)manager.getNodeAndProjectMapping().get(selectedNode);
              //the selected node is a model project node
              if(parentName.startsWith("Using_")){
                model.setName(newName);
                model.setLocation(pounamu.getPounamuHome()+""+fileSeparator+"models"+fileSeparator+parentName+fileSeparator+newName);
                model.initFolders();
                model.doSaveModelProject(selectedNode);
                manager.getOpenedModels().remove(oldName);
                manager.getOpenedModels().put(newName, model);
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a model view node
              else if(model.getNodeAndIconMapping().get(selectedNode) instanceof ModellerPanel){
                PounamuView view = (PounamuView)(model.getNodeAndViewMapping().get(selectedNode));
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                //String oldName = (String)(manager.getNodeAndItsValueMapping().get(selectedNode));
                PounamuTabbedPane tabs = (PounamuTabbedPane)model.getNodeAndViewsTabMapping().get(selectedNode);
                view.setName(newName);
                tabs.setTitleAt(tabs.getSelectedIndex(), newName);
                Hashtable hash = (Hashtable)model.getOpenedModelViews().get(view.getType());
                hash.remove(oldName);
                hash.put(newName, view);
                manager.getNodeAndItsValueMapping().put(selectedNode, newName);
              }
              //the selected node is a entity node
              else /*if(model.getNodeAndEntityMapping().get(selectedNode)!= null || model.getNodeAndAssociationMapping().get(selectedNode) != null)*/{
                pounamu.displayMessage("this node is not editable!");
                //String oldName = (String)(manager.getNodeAndItsValueMapping().get(selectedNode));
                selectedNode.setUserObject(oldName);
                return;
              } 
              
            }
            if(selectedNode != null){
              manager.removeTreeNode(selectedNode);
              manager.addTreeNode(parentNode, selectedNode);
              manager.setSelectedNode(selectedNode);
            }
        }
        
        public void treeNodesInserted(TreeModelEvent treeModelEvent) {
        }
        
        public void treeNodesRemoved(TreeModelEvent treeModelEvent) {
        }
        
        public void treeStructureChanged(TreeModelEvent treeModelEvent) {
        }
        
    }

