/*
 * @(#)SavePounamuIconToXML.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import javax.swing.border.*;
import pounamu.visualcomp.*;
import java.lang.reflect.*;
import java.util.*;


/**
 * Title: SavePounamuIconToXML
 * Description:  to save a pounamu icon into xml file
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class SavePounamuIconToXML{

  Object target = null;
  final static String space = "     ";
  Vector exportedPropertyNames = new Vector();
  Vector exportedPropertyTypes = new Vector();
  Vector exportedComponentPath = new Vector();
  Vector exportedPropertyOldNames = new Vector();
  Vector exportedPropertyFlags = new Vector();
  String fileSeparator = null;

  /**
   * constructor
   * @param target the icon to be saved
   */
  public SavePounamuIconToXML(Object target){
    this.target = target;
    fileSeparator = System.getProperty("file.separator");
  }

  /**
   * generate xml representation of this icon
   * @param name the name of the xml file
   */
  public String generate(String name){
    StringBuffer buf = new StringBuffer (400000);
    if(!(target instanceof PounamuConnector)){
      buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE pounamushape SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"icon.dtd\">\n");
      buf.append ("<pounamushape>\n");
      buf.append(space+"<name>"+name+"</name>\n");
      buf.append (space+"<source>");
      buf.append (name);
      buf.append ("</source>\n");
      //PounamuShape shape = ((PounamuPanel)target).getPounamuShape();
      buf.append (space+"<thumbnailshapetype>");
      buf.append (((PounamuPanel)target).getThumbnailShapeType());
      buf.append ("</thumbnailshapetype>\n");
      buf.append (space+"<thumbnailsizetype>");
      buf.append (((PounamuPanel)target).getThumbnailSizeType());
      buf.append ("</thumbnailsizetype>\n");
      buf.append (space+"<thumbnailwidth>");
      buf.append (((PounamuPanel)target).getThumbnailWidth());
      buf.append ("</thumbnailwidth>\n");
      buf.append (space+"<thumbnailheight>");
      buf.append (((PounamuPanel)target).getThumbnailHeight());
      buf.append ("</thumbnailheight>\n");
      generateXMLForComponent(target, "this", space, buf);
      saveExportedProperties(name, buf);
      buf.append ("</pounamushape>\n");
    }
    else if(target instanceof PounamuConnector){
      buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE pounamuconnector SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"icon.dtd\">\n");
      buf.append ("<pounamuconnector>\n");
      buf.append (space+"<source>");
      buf.append (name);
      buf.append ("</source>\n");
      generateXMLForComponent(target, "this", space, buf);
      saveExportedProperties(name, buf);
      buf.append ("</pounamuconnector>\n");
    }
    else
      buf.append ("No such icon type");
    return buf.toString();
  }

  /**
   * generate xml representation for a component in this icon
   * @param target the icon to be saved
   * @param path the path that specify the component to be saved
   * @param newspace empty string to keep alignment
   * @param buf the String Buffer object
   */
  private void generateXMLForComponent(Object target, String path, String newSpace, StringBuffer buf){
    if(target instanceof Configurable){
      buf.append (newSpace+"<displayname>");
      buf.append (((Configurable)target).getDisplayName());
      buf.append ("</displayname>\n");
    }
    buf.append (newSpace+"<type>");
    buf.append (target.getClass().getName());
    buf.append ("</type>\n");
    buf.append (newSpace+"<path>");
    buf.append (path);
    buf.append ("</path>\n");
    saveProperties(target, path, newSpace, buf);
    if( target instanceof PounamuPanel ){
      Component[] comps = ((PounamuPanel)target).getPanel().getComponents();
      for(int i = 0; i < comps.length; i++){
      	if( comps[i] instanceof PounamuHandle ) continue;
        buf.append(newSpace+"<subshape>\n");
        generateXMLForComponent(comps[i], path+"_comp"+i, newSpace+space, buf);
        buf.append(newSpace+"</subshape>\n");
      }
    }
  }

  /**
   * save one property of the component of a icon
   * @param target the icon to be saved
   * @param path specify the component in this icon which is to be saved
   * @param newspace empty string to keep alignment
   * @param buf the String Buffer object
   */
  private void saveProperties(Object target, String path, String newSpace, StringBuffer buf){
    String[] properties = ((Configurable)target).propertyNameList();
    String[] types = ((Configurable)target).propertyTypeList();
    String[] flags = ((Configurable)target).propertyFlagList();
    String[] exportedProperties = ((Configurable)target).getExportedPropertyNames();
    //System.out.println("length of the property array is "+exportedProperties.length);
    String[] exportedPropertyTypes = ((Configurable)target).getExportedPropertyTypes();
    String[] exportedPropertiesWithOldNames = ((Configurable)target).getExportedPropertyOldNames();
    String[] exportedPropertyFlags = ((Configurable)target).getExportedPropertyFlags();

    for (int j = 0; j < properties.length; j++){
      String property = properties[j];
      if(property.equals("index")) continue;
      String type = types[j];
      String flag = flags[j];
      String methodName = "";
      Class c = target.getClass();
      if(type.equals("boolean"))
        methodName = "is"+capitalizeFirstLetter(property);
      else
        methodName = "get"+capitalizeFirstLetter(property);
      try{
          buf.append(newSpace+"<property>\n");
          buf.append(newSpace+space+"<propertyname>");
          buf.append(property);
          buf.append("</propertyname>\n");
          buf.append(newSpace+space+"<propertytype>");
          buf.append(type);
          buf.append("</propertytype>\n");
          buf.append(newSpace+space+"<propertyflag>");
          buf.append(flag);
          buf.append("</propertyflag>\n");
          buf.append(newSpace+space+"<propertypath>");
          buf.append(path);
          buf.append("</propertypath>\n");
          buf.append(newSpace+space+"<propertyvalue>\n");
          Method m = c.getMethod(methodName, new Class[]{});
          Object value = m.invoke(target, new Object[]{});
          if(type.equals("int"))
            saveIntValue(((Integer)value).intValue(), newSpace+space+space, buf);
          else if(type.equals("boolean"))
            saveBooleanValue(((Boolean)value).booleanValue(), newSpace+space+space, buf);
          else if(type.equals("Font"))
            saveFontValue((Font)value, newSpace+space+space, buf);
          else if(type.equals("Border"))
            saveBorderValue((Border)value, newSpace+space+space, buf);
          else if(type.equals("Color"))
            saveColorValue((Color)value, newSpace+space+space, buf);
          else if(type.equals("HorizontalAlignment"))
            saveIntValue(((Integer)value).intValue(), newSpace+space+space, buf);
          else if(type.equals("VerticalAlignment"))
            saveIntValue(((Integer)value).intValue(), newSpace+space+space, buf);
          else if(type.equals("LayoutParameters"))
            saveLayoutValue((LayoutManager)value, newSpace+space+space, buf);
          else if(type.equals("MultiLinesText"))
            saveMultiLinesTextValue((Vector)value, newSpace+space+space, buf);
          else if(type.equals("GridBagConstraints"))
            saveGridBagConstraintsValue((GridBagConstraints)value, newSpace+space+space, buf);
          else if(type.equals("BasicStroke"))
            saveBasicStrokeValue((BasicStroke)value, newSpace+space+space, buf);
          else if(type.equals("Insets"))
            saveInsetsValue((Insets)value, newSpace+space+space, buf);
          else if(type.equals("Location"))
            saveLocationValue((Point)value, newSpace+space+space, buf);
          else if(type.equals("Size"))
            saveSizeValue((Dimension)value, newSpace+space+space, buf);
          else if(type.equals("ImageResource"))
            saveImageResourceValue((String)value, newSpace+space+space, buf);
          else
            saveStringValue((String)value, newSpace+space+space, buf);
          buf.append(newSpace+space+"</propertyvalue>\n");
          if(contains(exportedPropertiesWithOldNames, property)!= -1){
            int index = contains(exportedPropertiesWithOldNames, property);
            this.exportedPropertyNames.add(exportedProperties[index]);
            this.exportedPropertyTypes.add(exportedPropertyTypes[index]);
            this.exportedPropertyFlags.add(exportedPropertyFlags[index]);
            this.exportedComponentPath.add(path);
            this.exportedPropertyOldNames.add(exportedPropertiesWithOldNames[index]);
            buf.append(newSpace+space+"<exportedname>"+exportedProperties[index]+"</exportedname>\n");
          }
          buf.append(newSpace+"</property>\n");
      }
      catch(Exception e){
        //pounamu.displayMessage("Exception in class SavePounamuIconToXML "+e.toString());
        System.out.println(e.toString());
      }
    }
  }

  /**
   * save those properties of this icon, which are exported to user
   * @param name the name of the property
   * @param buf the String Buff object
   */
  private void saveExportedProperties(String name, StringBuffer buf){
    for(int i = 0; i < exportedPropertyNames.size(); i++){
      buf.append(space+"<exportedproperty>\n");
      buf.append(space+space+"<exportedpropertyname>"+exportedPropertyNames.elementAt(i)+"</exportedpropertyname>\n");
      buf.append(space+space+"<exportedpropertytype>"+exportedPropertyTypes.elementAt(i)+"</exportedpropertytype>\n");
      buf.append(space+space+"<exportedpropertyflag>"+exportedPropertyFlags.elementAt(i)+"</exportedpropertyflag>\n");
      if(name.endsWith("Conector"))
        buf.append(space+space+"<exportedcomponentpath>this</exportedcomponentpath>\n");
      else
        buf.append(space+space+"<exportedcomponentpath>"+exportedComponentPath.elementAt(i)+"</exportedcomponentpath>\n");
      buf.append(space+space+"<exportedpropertyoldname>"+exportedPropertyOldNames.elementAt(i)+"</exportedpropertyoldname>\n");
      buf.append(space+"</exportedproperty>\n");
    }
  }

  /**
   * save a value which is a int
   * @param i the value to be saved
   * @param newspace empty string to keep alignment
   * @param buf the String Buffer object
   */
  private void saveIntValue(int i, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<simplevalue>"+i+"</simplevalue>\n");
  }

  /**
   * save a value which is a boolean
   * @param b the value to be saved
   * @param newspace empty string to keep alignment
   * @param buf the String Buffer object
   */
  private void saveBooleanValue(boolean b, String newSpace, StringBuffer buf){
    if(b==true)
      buf.append(newSpace+"<simplevalue>true</simplevalue>\n");
    else
      buf.append(newSpace+"<simplevalue>false</simplevalue>\n");
  }

  /**
   * save a value which is a Font
   * @param f the value to be saved
   * @param newspace empty string to keep alignment
   * @param buf the String Buffer object
   */
  private void saveFontValue(Font f, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<family>Helvetica</family>\n");
    //buf.append(newSpace+"<family>"+f.getFamily()+"</family>\n");
    buf.append(newSpace+"<style>"+f.getStyle()+"</style>\n");
    buf.append(newSpace+"<size>"+f.getSize()+"</size>\n");
  }

  private void saveBorderValue(Border b, String newSpace, StringBuffer buf){
    //System.out.println("in class SavePounamuIconToXML, Border b is " + b.toString());
    if(b instanceof EmptyBorder)
      buf.append(newSpace+"<simplevalue>EmptyBorder</simplevalue>\n");
    else if(b instanceof LineBorder)
      buf.append(newSpace+"<simplevalue>LineBorder</simplevalue>\n");
    else if(b instanceof EtchedBorder)
      buf.append(newSpace+"<simplevalue>EtchedBorder</simplevalue>\n");
    else if(b instanceof BevelBorder){
      if(((BevelBorder)b).getBevelType()==BevelBorder.RAISED)
        buf.append(newSpace+"<simplevalue>SharedRaisedBevel</simplevalue>\n");
      else
        buf.append(newSpace+"<simplevalue>SharedLoweredBevel</simplevalue>\n");
    }
    else {}
  }

  private void saveColorValue(Color c, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<red>"+c.getRed()+"</red>\n");
    buf.append(newSpace+"<green>"+c.getGreen()+"</green>\n");
    buf.append(newSpace+"<blue>"+c.getBlue()+"</blue>\n");
  }

  private void saveLayoutValue(LayoutManager l, String newSpace, StringBuffer buf){
    if(l == null)
      buf.append(newSpace+"<layouttype>null</layouttype>\n");
    else if(l instanceof FlowLayout){
      buf.append(newSpace+"<layouttype>FlowLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((FlowLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((FlowLayout)l).getHgap()+"</hgap>\n");
      buf.append(newSpace+"<alignment>"+((FlowLayout)l).getAlignment()+"</alignment>\n");
    }
    else if(l instanceof VerticalFlowLayout){
      buf.append(newSpace+"<layouttype>VerticalFlowLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((VerticalFlowLayout)l).getVGap()+"</vgap>\n");
    }
    else if(l instanceof BorderLayout){
      buf.append(newSpace+"<layouttype>BorderLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((BorderLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((BorderLayout)l).getHgap()+"</hgap>\n");
    }
    else if(l instanceof GridLayout){
      buf.append(newSpace+"<layouttype>GridLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((GridLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((GridLayout)l).getHgap()+"</hgap>\n");
      buf.append(newSpace+"<cols>"+((GridLayout)l).getColumns()+"</cols>\n");
      buf.append(newSpace+"<rows>"+((GridLayout)l).getRows()+"</rows>\n");
    }
    else
      buf.append(newSpace+"<layouttype>GridBagLayout</layouttype>\n");
  }

  private void saveMultiLinesTextValue(Vector v, String newSpace, StringBuffer buf){
    for(int i = 0; i < v.size(); i++){
      buf.append(newSpace+"<item>");
      buf.append((String)v.get(i));
      buf.append("</item>\n");
    }
  }

  private void saveGridBagConstraintsValue(GridBagConstraints gc, String newSpace, StringBuffer buf){
      buf.append(newSpace+"<gridx>"+gc.gridx+"</gridx>\n");
      buf.append(newSpace+"<gridy>"+gc.gridy+"</gridy>\n");
      buf.append(newSpace+"<gridwidth>"+gc.gridwidth+"</gridwidth>\n");
      buf.append(newSpace+"<gridheight>"+gc.gridheight+"</gridheight>\n");
      buf.append(newSpace+"<ipadx>"+gc.ipadx+"</ipadx>\n");
      buf.append(newSpace+"<ipady>"+gc.ipady+"</ipady>\n");
      buf.append(newSpace+"<weightx>"+gc.weightx+"</weightx>\n");
      buf.append(newSpace+"<weighty>"+gc.weighty+"</weighty>\n");
      buf.append(newSpace+"<insets_top>"+gc.insets.top+"</insets_top>\n");
      buf.append(newSpace+"<insets_bottom>"+gc.insets.bottom+"</insets_bottom>\n");
      buf.append(newSpace+"<insets_left>"+gc.insets.left+"</insets_left>\n");
      buf.append(newSpace+"<insets_right>"+gc.insets.right+"</insets_right>\n");
      buf.append(newSpace+"<fill>"+gc.fill+"</fill>\n");
      buf.append(newSpace+"<anchor>"+gc.anchor+"</anchor>\n");
  }

  private void saveBasicStrokeValue(BasicStroke basicStroke, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<linewidth>");
    buf.append(basicStroke.getLineWidth()+"");
    buf.append("</linewidth>\n");
    buf.append(newSpace+"<endcaps>");
    buf.append(basicStroke.getEndCap()+"");
    buf.append("</endcaps>\n");
    buf.append(newSpace+"<linejoints>");
    buf.append(basicStroke.getLineJoin()+"");
    buf.append("</linejoints>\n");
    float[] f = basicStroke.getDashArray();
    for(int i = 0; i < f.length; i++){
      buf.append(newSpace+"<dasharray"+i+">");
      buf.append(f[i]+"");
      buf.append("</dasharray"+i+">\n");
    }
    buf.append(newSpace+"<miterlimit>");
    buf.append(basicStroke.getMiterLimit()+"");
    buf.append("</miterlimit>\n");
    buf.append(newSpace+"<dashphase>");
    buf.append(basicStroke.getDashPhase()+"");
    buf.append("</dashphase>\n");
  }

  private void saveInsetsValue(Insets insets, String newSpace, StringBuffer buf){
      buf.append(newSpace+"<insets_top>"+insets.top+"</insets_top>\n");
      buf.append(newSpace+"<insets_bottom>"+insets.bottom+"</insets_bottom>\n");
      buf.append(newSpace+"<insets_left>"+insets.left+"</insets_left>\n");
      buf.append(newSpace+"<insets_right>"+insets.right+"</insets_right>\n");
  }

  private void saveLocationValue(Point point, String newSpace, StringBuffer buf){
      buf.append(newSpace+"<x>"+point.x+"</x>\n");
      buf.append(newSpace+"<y>"+point.y+"</y>\n");
  }

  private void saveSizeValue(Dimension dim, String newSpace, StringBuffer buf){
      buf.append(newSpace+"<width>"+dim.width+"</width>\n");
      buf.append(newSpace+"<height>"+dim.height+"</height>\n");
  }

  private void saveStringValue(String s, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<simplevalue>"+s+"</simplevalue>\n");
  }
  
  private void saveImageResourceValue(String s, String newSpace, StringBuffer buf){
    buf.append(newSpace+"<imageresource>"+s+"</imageresource>\n");
  }
  /**
   * a help method to check if a string s is contained in the string array sa
   * @return the index of the string s in the array sa
   * @param sa the string array
   * @param s the string
   */
  public int contains(String[] sa, String s){
    if(sa == null)
      return -1;
    for(int i = 0; i < sa.length; i++)
      if (sa[i].equals(s))
        return i;
    return -1;
  }

  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }
}