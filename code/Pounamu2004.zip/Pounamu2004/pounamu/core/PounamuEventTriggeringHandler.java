 /*
 * UserPlugIn.java
 *
 * Created on 5 August 2003, 10:05
 */

package pounamu.core;

import pounamu.event.*;
/**
 *
 * @author  nzhu002
 */
public interface PounamuEventTriggeringHandler {
    
   public void eventReceived(PounamuEvent pe);
    
}