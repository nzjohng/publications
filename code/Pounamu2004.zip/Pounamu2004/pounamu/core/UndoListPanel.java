/*
 * @(#)UndoListPanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import pounamu.command.*;

/**
 * Title: UndoListPanel
 * Description:  A panel to show undoable actions history list
 * Copyright:    Copyright (c) 2002
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class UndoListPanel extends JPanel{
  PounamuStack undoModel = new PounamuStack();
  JList undoList = new JList(undoModel);
  PounamuStack redoModel = new PounamuStack();
  JScrollPane jsp = new JScrollPane(undoList);
  JButton undoLatest = new JButton("undo latest");
  JButton undoSelected = new JButton("undo selected");
  JButton deleteSelected = new JButton("delete selected");
  JButton deleteAll = new JButton("delete all");

  /**
   * constructor
   * i) init a button panel which contains four buttons used to controll this list
   * ii) init the undo list
   */
  public UndoListPanel(){
    super();
    JPanel buttonPanel = new JPanel();
    undoLatest.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doUndoLatest();
      }
    });
    undoSelected.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doUndoSelected();
      }
    });
    deleteSelected.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doDeleteSelected();
      }
    });
    deleteAll.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doDeleteAll();
      }
    });
    buttonPanel.add(undoLatest);
    buttonPanel.add(undoSelected);
    buttonPanel.add(deleteSelected);
    buttonPanel.add(deleteAll);
    this.setLayout(new BorderLayout());
    undoList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    this.add(buttonPanel, BorderLayout.NORTH);
    this.add(jsp, BorderLayout.CENTER);
  }

  /**
   * set the undo list model
   * @param model the undo list list model
   */
  public void setUndoListModelForUndoListPanel(PounamuStack model){
    undoList.setModel(model);
    undoModel = model;
    this.validate();
  }

  /**
   * set the redo list model for this undo list
   * @param model the redo list list model
   */
  public void setRedoListModelForUndoListPanel(PounamuStack model){
    redoModel = model;
  }

  /**
   * undo the last command in the command history which is shown on the top of this list
   */
  public void doUndoLatest(){
    if(undoModel.isEmpty())
      return;
    PounamuCommand pc = undoModel.pop();
    pc.undo();
    redoModel.push(pc);
    this.validate();
  }

  /**
   * undo the selected command(s)
   */
  public void doUndoSelected(){
    if(undoModel.isEmpty())
      return;
    Object[] temp = undoList.getSelectedValues();
    for(int i = 0; i < temp.length; i++){
      String s = (String)temp[i];
      PounamuCommand pc = undoModel.getCommandObject(s);
      if(undoModel.removeElement(s))
        undoModel.removeEntry(s);
      pc.undo();
      redoModel.push(pc);
    }
    this.validate();
  }

  /**
   * delete the selected command from the command history list
   */
  public void doDeleteSelected(){
    if(undoModel.isEmpty())
      return;
    Object[] temp = undoList.getSelectedValues();
    for(int i = 0; i < temp.length; i++){
      String s = (String)temp[i];
      if(undoModel.removeElement(s))
        undoModel.removeEntry(s);
    }
    this.validate();
  }

  /**
   * delete all entries in this command history list
   */
  public void doDeleteAll(){
    if(undoModel.isEmpty())
      return;
    undoModel.removeAllElements();
    undoModel.removeAllEntries();
    this.validate();
  }
}

