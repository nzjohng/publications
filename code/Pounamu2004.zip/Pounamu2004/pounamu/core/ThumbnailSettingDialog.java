/*
 * ThumbnailSettingDialog.java
 *
 * Created on 12 September 2003, 14:37
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import com.sun.image.codec.jpeg.*;
import java.awt.image.*;
import java.io.*;
/**
 *
 * @author  nzhu002
 */
public class ThumbnailSettingDialog extends JDialog {

    JRadioButton jrb1 = new JRadioButton("square");
    JRadioButton jrb2 = new JRadioButton("as original");
    JRadioButton jrb3 = new JRadioButton("arbitrary");
    JTextField thumbWidth = new JTextField(8);
    JTextField thumbHeight = new JTextField(8);
    int width = 0;
    int height = 0;
    int thumbW = 0;
    int thumbH = 0;
    String thumbShapeType = "as original";
    String thumbSizeType = "";
    JPanel previewPanel = new JPanel();
    JButton okButton = new JButton("ok");
    PounamuToolProject tool = null;
    DefaultMutableTreeNode currentNode = null;
    JPanel icon = null;
    Image fileImage = null;
    IconDisplayPanel iconView = null;
    String name = null;
    String fileSeparator = null;
    /** Creates a new instance of ThumbnailSettingDialog */
    public ThumbnailSettingDialog(PounamuToolProject tool, DefaultMutableTreeNode dmtn) {
      super(tool.getPounamu(), "Thumbnail setting dialog", true);
      this.tool = tool;
      this.currentNode = dmtn;
      this.name = (String)dmtn.getUserObject();
      fileSeparator = System.getProperty("file.separator");
      try {
         getImage();
         jbInit();
         preview();
        this.pack();
      }
      catch(Exception e) {
        //e.printStackTrace();
        tool.getPounamu().displayMessage("Exception in class ThumbnailSettingDialog: "+e.toString());
      }
    }

    public void  getImage(){
      PounamuView view = tool.getView(currentNode);
      iconView = (IconDisplayPanel)view.getDisplayPanel();
      Rectangle recta = iconView.getBounds();
      fileImage = iconView.createImage(recta.width,recta.height);
      Graphics g = fileImage.getGraphics();
      iconView.paint(g);
      g.dispose();
      icon = iconView.getTarget();
      Rectangle rect = icon.getBounds();
      width = rect.width;
      height = rect.height;
      if(icon instanceof PounamuPanel){
         thumbShapeType = ((PounamuPanel)icon).getThumbnailShapeType();
         //thumbSizeType = ((PounamuPanel)icon).getThumbnailSizeType();
         thumbW = ((PounamuPanel)icon).getThumbnailWidth();
         thumbH = ((PounamuPanel)icon).getThumbnailHeight();
         if(thumbW==0 &&thumbShapeType.equals("square")){
           thumbW = 100;
           thumbH = 100;
         }
         if(thumbW==0 &&thumbShapeType.equals("arbitrary")){
           thumbW = 100;
           thumbH = 100;
         }
         if(thumbW==0 &&thumbShapeType.equals("as original")){
           thumbW = width;
           thumbH = height;
         }
      }
      else if(icon instanceof PounamuConnector){
         thumbShapeType = ((PounamuConnector)icon).getThumbnailShapeType();
         //thumbSizeType = ((PounamuPanel)icon).getThumbnailSizeType();
         thumbW = /*((PounamuConnector)icon).getThumbnailWidth()*/width-80;
         thumbH = /*((PounamuConnector)icon).getThumbnailHeight()*/height-60;
         if(thumbW==0 &&thumbShapeType.equals("square")){
           thumbW = 100;
           thumbH = 100;
         }
         if(thumbW==0 &&thumbShapeType.equals("arbitrary")){
           thumbW = 100;
           thumbH = 100;
         }
         if(thumbW==0 &&thumbShapeType.equals("as original")){
           thumbW = width;
           thumbH = height;
         }
      }

    }

    public void preview(){
      try{
       ImageFilter filter = null;
       Rectangle rect = icon.getBounds();
      if(icon instanceof PounamuConnector){
        if(!thumbShapeType.equals("square")){
          filter = new CropImageFilter((int)(rect.getX()+40), (int)(rect.getY()+30), (int)(rect.getWidth()-80), (int)(rect.getHeight()-60));
        }
        else
          filter = new CropImageFilter((int)rect.getX(), (int)(rect.getY()-(rect.getWidth()-rect.getHeight())/2), (int)rect.getWidth(), (int)rect.getWidth());
      }
      else {
        if(thumbShapeType.equals("square")){
          if(rect.getWidth()>=rect.getHeight())
             filter = new CropImageFilter((int)rect.getX(), (int)(rect.getY()-(rect.getWidth()-rect.getHeight())/2), (int)rect.getWidth(), (int)rect.getWidth());
          else
             filter = new CropImageFilter((int)(rect.getX()-(rect.getHeight()-rect.getWidth())/2), (int)rect.getY(), (int)rect.getHeight(), (int)rect.getHeight());
        }
        else{
          filter = new CropImageFilter((int)rect.getX(), (int)rect.getY(), (int)rect.getWidth(), (int)rect.getHeight());
        }
      }
      FilteredImageSource fis = new FilteredImageSource(fileImage.getSource(), filter);
      Image subImage = iconView.createImage(fis);
      int imageWidth = subImage.getWidth(null);
      int imageHeight = subImage.getHeight(null);
      //int thumbWidth = 150;
      //int thumbHeight = 150;
      BufferedImage thumbImage = null;
      //if(icon instanceof PounamuConnector)
        //thumbImage = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
      //else
        thumbImage = new BufferedImage(Integer.parseInt(thumbWidth.getText()), Integer.parseInt(thumbHeight.getText()), BufferedImage.TYPE_INT_RGB);
      Graphics2D graphics2D = thumbImage.createGraphics();
      graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      //if(icon instanceof PounamuConnector)
        //graphics2D.drawImage(subImage, 0, 0, imageWidth, imageHeight, null);
      //else
        graphics2D.drawImage(subImage, 0, 0, Integer.parseInt(thumbWidth.getText()), Integer.parseInt(thumbHeight.getText()), null);
      BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tool.getLocation()+""+fileSeparator+"images"+fileSeparator+""+name+".JPEG"));
      JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
      JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(thumbImage);
      //int quality = Integer.parseInt(args[4]);
      //quality = Math.max(0, Math.min(quality, 100));
      //param.setQuality((float)quality / 100.0f, false);
      param.setQuality(1000, false);
      encoder.setJPEGEncodeParam(param);
      encoder.encode(thumbImage);
      Icon ic = new ImageIcon(thumbImage);
      JLabel label = new JLabel(ic);
      previewPanel.removeAll();
      previewPanel.add(label);
      previewPanel.setPreferredSize(new Dimension(Integer.parseInt(thumbWidth.getText())+10, Integer.parseInt(thumbHeight.getText())+10));
      this.getContentPane().setSize(Math.max(290,Integer.parseInt(thumbWidth.getText())), 285+Integer.parseInt(thumbHeight.getText())) ;
      this.setSize(Math.max(290,Integer.parseInt(thumbWidth.getText())), 285+Integer.parseInt(thumbHeight.getText())) ;
      this.getContentPane().validate();
      this.getContentPane().repaint();
      this.validate();
      this.repaint();
      }
      catch(Exception e){
        tool.getPounamu().displayMessage("Exception in class ThumbnailSettingDialog: " + e.toString());
      }
      //this.repaint();
    }


    public void jbInit() throws Exception {
      thumbWidth = new JTextField(thumbW+"", 8);
      thumbHeight = new JTextField(thumbH+"", 8);
      ButtonGroup bg = new ButtonGroup();
      bg.add(jrb1);
      bg.add(jrb2);
      bg.add(jrb3);
      jrb1.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JRadioButton jrb = (JRadioButton)e.getSource();
          if(jrb.isSelected()){
            thumbWidth.setText(""+100);
            thumbHeight.setText(""+100);
            thumbShapeType = "square";
            preview();
          }
        }
      });
      jrb2.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JRadioButton jrb = (JRadioButton)e.getSource();
          if(jrb.isSelected()){
            if(icon instanceof PounamuConnector){
              thumbWidth.setText(""+(width-80));
              thumbHeight.setText(""+(height-60));
            }
            else{
              thumbWidth.setText(""+width);
              thumbHeight.setText(""+height);
            }
            thumbShapeType = "as original";
            preview();
          }
        }
      });
      jrb3.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JRadioButton jrb = (JRadioButton)e.getSource();
          if(jrb.isSelected()){
            thumbShapeType = "arbitrary";
            preview();
          }
        }
      });
      thumbWidth.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(jrb1.isSelected()){
             thumbHeight.setText(thumbWidth.getText());
           }
          else if(jrb2.isSelected()){
            int  temp = Integer.parseInt(thumbWidth.getText());
            if(icon instanceof PounamuConnector){
              thumbHeight.setText(""+(height*(80+temp)/width-60));
            }
            else
              thumbHeight.setText(""+height*temp/width);  
          }
          else if(jrb3.isSelected()){}
          else{}
          preview();
        }
      });
      thumbHeight.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          if(jrb1.isSelected()){
            thumbWidth.setText(thumbHeight.getText());
          }
          else if(jrb2.isSelected()){
             int  temp = Integer.parseInt(thumbHeight.getText());
             thumbWidth.setText(""+width*temp/height);
          }
          else if(jrb3.isSelected()){}
          else{}
          preview();
        }
      });
      okButton.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
         if(icon instanceof PounamuPanel){
            if(jrb1.isSelected())
               ((PounamuPanel)icon).setThumbnailShapeType(jrb1.getText());
            else if(jrb2.isSelected())
               ((PounamuPanel)icon).setThumbnailShapeType(jrb2.getText());
            else if(jrb3.isSelected())
               ((PounamuPanel)icon).setThumbnailShapeType(jrb3.getText());
            else{}
             ((PounamuPanel)icon).setThumbnailWidth(Integer.parseInt(thumbWidth.getText()));
             ((PounamuPanel)icon).setThumbnailHeight(Integer.parseInt(thumbHeight.getText()));
           }
          else if(icon instanceof PounamuConnector){
            if(jrb1.isSelected())
               ((PounamuConnector)icon).setThumbnailShapeType(jrb1.getText());
            else if(jrb2.isSelected())
               ((PounamuConnector)icon).setThumbnailShapeType(jrb2.getText());
            else if(jrb3.isSelected())
               ((PounamuConnector)icon).setThumbnailShapeType(jrb3.getText());
            else{}
             ((PounamuConnector)icon).setThumbnailWidth(Integer.parseInt(thumbWidth.getText()));
           }
           ThumbnailSettingDialog.this.dispose();
        }
      });
      JPanel jPanel00 = new JPanel();
      jPanel00.setBorder(BorderFactory.createTitledBorder("Information of the original icon"));
      jPanel00.setLayout(new GridLayout(2,2));
      jPanel00.add(new JLabel("original  width:"));
      JTextField temp1 = new JTextField(width+"", 8);
      temp1.setEditable(false);
      jPanel00.add(temp1);
      jPanel00.add(new JLabel("original height:"));
      JTextField temp2 = new JTextField(height+"", 8);
      temp2.setEditable(false);
      jPanel00.add(temp2);
      //jPanel00.add(thumbHeight);
      JPanel jPanel0 = new JPanel();
      jPanel0.setBorder(BorderFactory.createTitledBorder("Please specify the thumbnail shape"));
      //jPanel0.setLayout(new VerticalFlowLayout(3));
      jPanel0.add(jrb1);
      jPanel0.add(jrb2);
      jPanel0.add(jrb3);
      JPanel jPanel1 = new JPanel();
      jPanel1.setBorder(BorderFactory.createTitledBorder("Please specify the thumbnail size"));
      //jPanel1.setLayout(new VerticalFlowLayout(3));
      jPanel1.setLayout(new GridLayout(2,2));
      jPanel1.add(new JLabel("thumbnail  width:"));
      jPanel1.add(thumbWidth);
      jPanel1.add(new JLabel("thumbnail height:"));
      jPanel1.add(thumbHeight);
      this.getContentPane().setLayout(new VerticalFlowLayout(3));
      this.getContentPane().add(jPanel00);
      this.getContentPane().add(jPanel0);
      this.getContentPane().add(jPanel1);
      this.getContentPane().add(previewPanel);
      this.getContentPane().add(okButton);
      if(thumbShapeType.equals("square"))
        jrb1.setSelected(true);
      if(thumbShapeType.equals("as original"))
        jrb2.setSelected(true);
      if(thumbShapeType.equals("arbitrary"))
        jrb3.setSelected(true);
    }

}
