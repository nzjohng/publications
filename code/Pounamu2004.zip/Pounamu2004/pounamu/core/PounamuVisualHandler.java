/*
 * PounamuVisualHandler.java
 *
 * Created on 5 August 2003, 10:16
 */

package pounamu.core;

import pounamu.event.*;
import pounamu.data.*;
import java.util.*;
/**
 *
 * @author  nzhu002
 */
public class PounamuVisualHandler extends PounamuHandler {
    
    /** Creates a new instance of ViewEventHandler */
  public PounamuVisualHandler() {
    super();
  }
    
    
  /**
   * specify the view this handler will be working for
   * when a view is set, the "tool", "manager", "pounamu", "model" and "panel" objects are also set, so that users can access them in their own code,
   * @param model the model the event hander belongs to
   */
  public void setView(PounamuView view){
    this.view = view;
    this.model = (PounamuModelProject)view.getPounamuProject();
    this.tool = model.getTool();
    this.manager = model.getManager();
    this.pounamu = manager.getPounamu();
    this.panel = (ModellerPanel)view.getDisplayPanel();
  }

}
