/*
 * @(#)Pounamu.java	1.1 02/09/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */


package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import pounamu.data.*;
import pounamu.help.*;

/**
 * Title: Pounamu
 * Description:  An dynamic universal modelling tool
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class Pounamu extends JFrame {
  /**
   * menubar, menus and menu items
   */
  JMenuBar menuBar = new JMenuBar();
  JMenu jMenuPounamu = new JMenu("Pounamu");
  JMenu jMenuHelp = new JMenu("Help");
  JMenuItem jMenuHelpPounamuBP = new JMenuItem("Pounamu Blue Prints");
  JMenuItem jMenuHelpPounamuAPI = new JMenuItem("Pounamu API");
  JMenuItem jMenuHelpPounamuHT = new JMenuItem("Pounamu Tutorial");
  JMenuItem jMenuHelpPounamuCA = new JMenuItem("Contact Authors");
  JMenuItem jMenuHelpPounamuOL = new JMenuItem("Pounamu Online");
  JMenuItem jMenuHelpPounamuUF = new JMenuItem("Pounamu User Forum");
  JMenuItem jMenuHelpAboutPounamu = new JMenuItem("About Pounamu");
  /**
   * three main showing areas arranged into horrizontal split panes
   */
  JSplitPane jSplitPane11 = new JSplitPane();
  JSplitPane jSplitPane12 = new JSplitPane();
  JSplitPane jSplitPane13 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
  /**
   * general information panel, lay between the main showing area and the status bar
   */
  ConsolePanel console = new ConsolePanel(this);
  /**
   * statusBar
   */
  JLabel statusBar = new JLabel();
  /**
   * the manager panel nested in the left split pane
   */
  PounamuManagerPanel manager = null;
  ToolIconPanel toolIconPanel = null;
  PounamuTabbedPane leftTab = new PounamuTabbedPane(/*new PounamuToolProject()*/);
  /**
   * the main displaying canvas nested in the middle split pane
   */
  PounamuTabbedPane defaultProjectTab = new PounamuTabbedPane(/*new PounamuToolProject()*/);
  PounamuTabbedPane projectTab = defaultProjectTab;

  /**
   * the property panel nested in the right split pane
   */
  JPanel defaultPropertyPanel = new JPanel();
  JPanel propertyPanel = defaultPropertyPanel;
  /**
   * index all displaying messages
   */
  static int messageCount = 0;
  /**
   * The file chooser for general use
   */
  JFileChooser fileChooser = new JFileChooser();
  /**
   * to hold properties of this tool
   */
  Properties  properties = new Properties();
  JScrollPane toolIconScroll = null;
  String fileSeparator = null;
  /**
   * Constructor:
   * 1) set icon image for the frame
   * 2) load in properties of this tool
   * 3) choose the available shapes, connectrs and handlers
   * 4) initial visual interface
   */

  public Pounamu() {
    super();
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    fileSeparator = System.getProperty("file.separator");
    try {       
      Image titleImage = Toolkit.getDefaultToolkit().getImage("pounamu"+fileSeparator+"image"+fileSeparator+"pounamu.gif");
      this.setIconImage(titleImage);
      FileInputStream fileInputStream = new FileInputStream("pounamu"+fileSeparator+"nonjavafiles"+fileSeparator+"Configuration.txt");
      properties.load(fileInputStream);
      String temp = System.getProperty("user.dir");
      if(!temp.endsWith(fileSeparator))
        temp = temp + fileSeparator;
      properties.put("pounamu", temp+"pounamu");
      properties.put("jdk", System.getProperty("java.home"));
      manager = new PounamuManagerPanel(this);
      jbInit();
      getContentPane().validate();
      Configuration configuration = new Configuration(this);
      if(((String)properties.get("nexttime")).equals("false"))
        configuration.setVisible(true);
    }
    catch(Exception e) {
      //pounamu.displayMessage("Exception in class Pounamu "+e.toString());
      e.printStackTrace();
      //System.out.println("Exception in the constructor of class Pounamu: " + e.printStackTrace());
      //this.displayMessage("Exception in the constructor of class Pounamu: " + e.printStackTrace());
    }
  }

  /**
   * Component initialization
   * 1) initial buttons in the  tool bar
   * 2) initial menu bar
   * 3) initial toolbox of each ub tool
   * 4) initial manager panel and view panel
   * 5) add and configure all listeners
   * 6) initial popup menu for modeller tool
   */
  private void jbInit() throws Exception  {

    JPanel contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(new BorderLayout());
    this.setSize(new Dimension(1024, 740));
    this.setTitle("Pounamu: Model things with your own tool ");
    statusBar.setText("Welcome to use Pounamu");
    menuBar.add(jMenuPounamu);
    menuBar.add(jMenuHelp);
    this.setJMenuBar(menuBar);
    contentPane.add(statusBar, BorderLayout.SOUTH);
    contentPane.add(jSplitPane13, BorderLayout.CENTER);
    JScrollPane jsp = new JScrollPane(manager);
    //toolIconScroll = new JScrollPane(toolIconPanel);
    leftTab.addTab("Manager Tree", jsp);
    setToolIconPanel(toolIconPanel);
    //leftTab.addTab("Tool Icons", toolIconScroll);
    //jSplitPane11.add(jsp, JSplitPane.LEFT);
    jSplitPane11.add(leftTab, JSplitPane.LEFT);
    jSplitPane11.add(defaultProjectTab, JSplitPane.RIGHT);
    jSplitPane11.setDividerLocation(230);
    jSplitPane12.add(jSplitPane11, JSplitPane.LEFT);
    JScrollPane jsp1 = new JScrollPane(defaultPropertyPanel);
    jSplitPane12.add(jsp1, JSplitPane.RIGHT);
    jSplitPane12.setDividerLocation(774);
    jSplitPane13.add(jSplitPane12, JSplitPane.TOP);
    jSplitPane13.add(console, JSplitPane.BOTTOM);
    jSplitPane13.setDividerLocation(580);
    /*jMenuPounamu.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuPounamu_actionPerformed(e);
      }
    });*/
    jMenuHelpPounamuBP.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpPounamuBP_actionPerformed(e);
      }
    });

    jMenuHelpPounamuAPI.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpPounamuAPI_actionPerformed(e);
      }
    });

    jMenuHelpPounamuHT.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpPounamuHT_actionPerformed(e);
      }
    });

    jMenuHelpPounamuCA.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpPounamuCA_actionPerformed(e);
      }
    });

    jMenuHelpPounamuOL.addActionListener(new ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpPounamuOL_actionPerformed(e);
      }
    });

    jMenuHelpPounamuUF.addActionListener(new ActionListener()  {
	      public void actionPerformed(ActionEvent e) {
	        jMenuHelpPounamuUF_actionPerformed(e);
	      }
    });

    jMenuHelpAboutPounamu.addActionListener(new ActionListener()  {
	      public void actionPerformed(ActionEvent e) {
	        jMenuHelpAboutPounamu_actionPerformed(e);
	      }
    });
    //jMenuPounamu.add(jMenuHelpPounamuBP);
    jMenuHelp.add(jMenuHelpPounamuBP);
    jMenuHelp.add(jMenuHelpPounamuAPI);
    jMenuHelp.add(jMenuHelpPounamuHT);
    jMenuHelp.addSeparator();
    jMenuHelp.add(jMenuHelpPounamuCA);
    jMenuHelp.addSeparator();
    jMenuHelp.add(jMenuHelpPounamuOL);
    jMenuHelp.add(jMenuHelpPounamuUF);
    jMenuHelp.addSeparator();
    jMenuHelp.add(jMenuHelpAboutPounamu);
  }

  /**
   * set the project tab bed pane with the specified new one
   * @param projectTab the new tabbed pane
   */
  public void setProjectTab(PounamuTabbedPane projectTab){
    int temp = jSplitPane11.getDividerLocation();
    if(projectTab == null)
      jSplitPane11.setRightComponent(defaultProjectTab);
    else
      jSplitPane11.setRightComponent(projectTab);
    jSplitPane11.setDividerLocation(temp);
    this.projectTab = projectTab;
    this.validate();
  }

  /**
   * get the tabbed Pane for projects
   * @return the tabbed Pane for projects
   */
 // public Properties getProperties(){
    //return properties;
 // }
  
  /**
   * get the tabbed Pane for projects
   * @return the tabbed Pane for projects
   */
  public PounamuTabbedPane getProjectTab(){
    return projectTab;
  }

  /**
   * get the manager panel of this tool
   */

  public PounamuManagerPanel getManager(){
    return manager;
  }
  /**
   * get the dynamic menu
   * @return the dynamic menu
   */
  public JMenu getDynamicMenu(){
    return jMenuPounamu;
  }

  /**
   * show the property panel of the selected icon
   * @param propertyPanel the property panel to be shown
   */
  public void setPropertyPanel(JPanel propertyPanel){
    if(propertyPanel == null)
      propertyPanel = defaultPropertyPanel;
    int temp = jSplitPane12.getDividerLocation();
    JScrollPane jsp = new JScrollPane(propertyPanel);
    jSplitPane12.setRightComponent(jsp);
    jSplitPane12.setDividerLocation(temp);
    this.propertyPanel = propertyPanel;
    this.validate();
  }

  public ToolIconPanel getToolIconPanel(){
    return toolIconPanel;
  }
  
  public void setToolIconPanel(ToolIconPanel panel){
    toolIconPanel = panel;
    leftTab.remove(toolIconScroll);
    toolIconScroll = new JScrollPane(toolIconPanel);
    leftTab.add("Tool Icons", toolIconScroll);
  }
    
  /**
   * get property panel
   * @return property panel
   */
  public JPanel getPropertyPanel(){
    return propertyPanel;
  }

  /**
   * get file chooser
   * @return file chooser
   */
  public JFileChooser getFileChooser(){
    return fileChooser;
  }

  /**
   * display the message in the status bar
   * @param message the information to be displayed in the status bar
   */
  public void setMessage(String message){
    statusBar.setText(message);
    this.validate();
  }

  /**
   * set up models for both undo list panel and redo list panel
   * @param undoModel the undo model
   * @param redoModel the redo model
   */
  public void setListModel(PounamuStack undoModel, PounamuStack redoModel){
    console.setListModel(undoModel, redoModel);
    this.validate();
  }

  /**
   * display any runtime messages or exceptions
   * @param info the information to be shown
   */
  public void displayMessage(String info){
    console.displayMessage(messageCount+": "+info);
    messageCount++;
  }


  /**
   * get the properties of pounamu
   * @return the properties of pounamu
   */
  public Properties getProperties(){
    return properties;
  }
  
  /**
   * get the location of pounamu folder
   * @return the path to the location of pounamu folder
   */
  public String getPounamuHome(){
    return (String)getProperties().get("pounamu");
  }

  //public void eventReceived(pounamu.event.PounamuEvent pe){}

  /**
   * define what to happen when the menu item "Help_pounamuBlueprints" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuBP_actionPerformed(ActionEvent e) {
    GetBluePrints getBluePrints = new GetBluePrints(this);
      new Thread(getBluePrints).start();
  }

  /**
   * define what to happen when the menu item "Help_pounamuAPI" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuAPI_actionPerformed(ActionEvent e) {
    OpenPounamuAPI openPounamuAPI = new OpenPounamuAPI(this);
      new Thread(openPounamuAPI).start();
  }

  /**
   * define what to happen when the menu item "Help_tutorial" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuHT_actionPerformed(ActionEvent e) {
    GetLocalHelp getLocalHelp = new GetLocalHelp(this);
      new Thread(getLocalHelp).start();
  }

  /**
   * define what to happen when the menu item "Help_contactAuthors" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuCA_actionPerformed(ActionEvent e) {
    ContactAuthor contactAuthor = new ContactAuthor(this);
      new Thread(contactAuthor).start();
  }

  /**
   * define what to happen when the menu item "Help_onlinehelp" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuOL_actionPerformed(ActionEvent e) {
    GetOnLineHelp getOnLineHelp = new GetOnLineHelp(this);
      new Thread(getOnLineHelp).start();
  }

  /**
   * define what to happen when the menu item "Help_pounamuUserForum" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpPounamuUF_actionPerformed(ActionEvent e) {
    GoToPounamuForum goToPounamuForum = new GoToPounamuForum(this);
      new Thread(goToPounamuForum).start();
  }

 /* public void jMenuPounamu_actionPerformed(ActionEvent e) {
    //JMenu menu = pounamu.getDynamicMenu();
    menu.minimumSize()
    jMenuPounamu.removeAll();
    Vector menuItems = null;
    Vector toolButtons = null;
    DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode)manager.getSelectedNode();
    PounamuProject project = manager.getProject(selectedNode);
    if(project == null){
      menuItems = (Vector)(manager.getNodeAndMenuItemsMapping().get(selectedNode));
      toolButtons = (Vector)(manager.getNodeAndToolButtonsMapping().get(selectedNode));
    }
    else{
      menuItems = project.getMenuItems(selectedNode);
      //toolButtons = project.getToolButtons(selectedNode);
    }
    for(int i = 0; i < menuItems.size(); i++){
      if(menuItems.elementAt(i)!=null){
        JMenuItem item = (JMenuItem)menuItems.elementAt(i);
        item.setVisible(true);
        jMenuPounamu.add(item);
      }
      else
        jMenuPounamu.addSeparator();
    }
    //pounamu.setToolIconPanel(new ToolIconPanel(this, toolButtons));
    
  }*/
  //}
  /**
   * define what to happen when the menu item "Help_aboutpounamu" is clicked.
   * @param e the action event on the menuitem
   */
  public void jMenuHelpAboutPounamu_actionPerformed(ActionEvent e) {
    PounamuVersionDialog dlg = new PounamuVersionDialog(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.setVisible(true);
  }

  /**
   * open a HTML browsing window showing all available help files
   */
  public void  doHelp() {
    StartingHelp startingHelp = new StartingHelp(this);
    new Thread(startingHelp).start();
  }

  /**
   * Overridden so we can exit when window is closed
   * @param e the window event
   */
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if(e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.dispose();
      System.exit(0);
    }
  }

  /**
   * Initial a <i>Pounamu</i> instance, and set its look&feel to that of Windows
   */
  public static void main(String[] args){
    try{
      UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
    }
    catch(Exception e){}
    Pounamu pounamu = new Pounamu();
    pounamu.setVisible(true);
  }
}