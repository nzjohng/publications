/*
 * @(#)ExistedMetaModelElementChooser.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;


/**
 * Title: ExistedMetaModelElementChooser
 * Description:  A dialog for user to create an object by three ways
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ExistedMetaModelElementChooser extends JDialog {


  JComboBox box = new JComboBox();
  JButton ok = new JButton("   OK   ");
  JButton cancel = new JButton("Cancel");
  Pounamu pounamu = null;
  //PounamuModelProject project = null;
  PounamuToolProject tool = null;
  PounamuView view = null;
  ModellerPanel panel = null;
  DefaultMutableTreeNode node = null;
  PounamuMetaModelElement target = null;
  String type = null;
  String targetName = null;
  Hashtable keyAndMetaModelElementMapping = new Hashtable();
  /**
   * construct a dialog which allow user to add a object to meta model view by thre ways
   * @param tool the tool project this dialog works for
   * @param view the view where the new object will be added to
   * @param type the type of the new object
   */
  public ExistedMetaModelElementChooser(PounamuToolProject tool, DefaultMutableTreeNode node, String type){
    super(tool.getPounamu(), "meta model object chooser", true);
    this.tool = tool;
    this.node = node;
    this.type = type; 
    if(type.equals("entity type")) 
      this.target = (PounamuMetaModelElement)tool.getEntityTypeObject(node);
    else
      this.target = (PounamuMetaModelElement)tool.getAssociationTypeObject(node);
    this.targetName = ((PounamuMetaModelElement)target).getName();
    this.view = (PounamuView)tool.getNodeAndViewMapping().get(node);
    this.panel = (ModellerPanel)view.getDisplayPanel();
    this.pounamu = tool.getPounamu();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {

    JPanel jPanel5 = new JPanel();
    initJComboBox();
    //jPanel5.setLayout(new GridLayout(1,1, 3,3));
    jPanel5.add(box);
    jPanel5.setBorder(BorderFactory.createTitledBorder("Please choose an existed " + type +  " here " ));

    JPanel jPanel7 = new JPanel();
    jPanel7.add(ok);
    jPanel7.add(cancel);

    this.getContentPane().setLayout(new VerticalFlowLayout(4));
    this.getContentPane().add(jPanel5);
    this.getContentPane().add(jPanel7);
    this.setResizable(false);
    this.pack();
    ok.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        mapObject();
        doCancel();
      }
    });

    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doCancel();
      }
    });
  }

  /**
   * init the combo box and put all added objects with the same type into it
   */
  public void initJComboBox(){
    Enumeration en = null;
    Vector h = null;
    if(type.equals("entity type"))
      h = tool.getEntityTypeObjects();
    else
      h = tool.getAssociationTypeObjects();
    Vector v = new Vector();
    for(int i = 0; i < h.size(); i++){
      PounamuMetaModelElement temp  = (PounamuMetaModelElement)h.get(i);
      if(temp != target){
        v.add(temp.getName());
        keyAndMetaModelElementMapping.put(temp.getName(), temp);
      }
    }
    Object[] array = v.toArray();
    Arrays.sort(array);
    for(int i = 0; i < array.length; i++){
      String s = (String)array[i];      
      box.addItem(s);
    }
    box.addItem("                                                                  ");
  }

  /**
   * create a object by one of the three ways
   */
  private void mapObject(){
    if(((String)box.getSelectedItem()).equals("                                                                  ")){
      pounamu.displayMessage("You have not chosen a target");
      return;
    } 
    PounamuMetaModelElement pme = (PounamuMetaModelElement)keyAndMetaModelElementMapping.get(box.getSelectedItem());
    if(type.equals("entity type")){
      tool.removeEntityTypeObject(target);
      tool.addEntityTypeObject(pme);
    }
    else{
      tool.removeAssociationTypeObject(target);
      tool.addAssociationTypeObject(pme);
    }
    PounamuPanel pp = (PounamuPanel)tool.getNodeAndIconMapping().get(node);
    PounamuShape p = pp.getPounamuShape();
    p.setRelatedObject(pme);
    target.removeIcon(view, pp);
    pme.addIcon(view, pp);
    node.setUserObject(pme.getName());
    PounamuMetaModelElementSpecifier pmes = new PounamuMetaModelElementSpecifier(pp, view);
    pounamu.setPropertyPanel(pmes);
    pmes.ok_pressed();     
    doCancel();   
  }


   /*
   * this dialog disappear when cancel button is clicked
   */
  private void doCancel(){
    this.dispose();
  }

}