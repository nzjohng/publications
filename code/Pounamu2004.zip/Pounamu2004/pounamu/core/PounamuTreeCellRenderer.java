/*
 * @(#)PounamuTreeCellRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import pounamu.data.*;

/**
 * Title: PounamuTreeCellRenderer
 * Description:  A extended DefaultTreeCellRenderer which defines how to render the object as a tree node
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuTreeCellRenderer extends DefaultTreeCellRenderer {
        ImageIcon[] treeIcons;
        PounamuManagerPanel manager = null;
        String fileSeparator = null;
        /**
         * the constructor
         * i) init all image icons that will be used to render diffirent tree node types
         */
        public PounamuTreeCellRenderer(PounamuManagerPanel manager) {
            treeIcons = new ImageIcon[11];
            this.manager = manager;
            fileSeparator = System.getProperty("file.separator");
            treeIcons[0] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"projectnode.gif"));
            treeIcons[1] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"folder.gif"));
            treeIcons[2] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"unregistered.gif"));
            treeIcons[3] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"registered.gif"));
            treeIcons[4] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"wasregistered.gif"));
            treeIcons[5] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"metamodelnode.gif"));
            treeIcons[6] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"modelnode.gif"));
            treeIcons[7] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"entitynode.gif"));
            treeIcons[8] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"associationnode.gif"));
            treeIcons[9] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"componentnode.gif"));
            treeIcons[10] = new ImageIcon(PounamuTreeCellRenderer.class.getResource(".."+fileSeparator+"image"+fileSeparator+"defaultnode.gif"));
        }

        /**
         * get the component that will be used to render the object as a tree node
         * @param tree the tree this component will be used to
         * @param value the object to be rendered
         * @param sel specified if this node is selected
         * @param expanded specified if this node is expanded
         * @param leaf specified if this node is a leaf
         * @param row specified if the index of the row of this node in the tree
         * @param hasFocus specified if this node has a focus
         * @return the component used to render the value
         */
        public Component getTreeCellRendererComponent(
                            JTree tree,
                            Object value,
                            boolean sel,
                            boolean expanded,
                            boolean leaf,
                            int row,
                            boolean hasFocus) {

            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;    
            DefaultMutableTreeNode parent = (DefaultMutableTreeNode)node.getParent();
            String ss = "";
            if(parent != null)
              ss = (String)parent.getUserObject(); 
            PounamuToolProject tool = null;
            PounamuModelProject model = null;
            if(manager.getNodeAndProjectMapping().get(node) != null){      
               if(manager.getNodeAndProjectMapping().get(node) instanceof PounamuToolProject){
                 tool = (PounamuToolProject)manager.getNodeAndProjectMapping().get(node);
               }//locate previously selected tool
               else if(manager.getNodeAndProjectMapping().get(node) instanceof PounamuModelProject){
                 model = (PounamuModelProject)manager.getNodeAndProjectMapping().get(node);
               }//locate previously selected model 
               else{}
            }
            String s = (String)node.getUserObject();
            //for node "pounamu"
            if (s.equals("pounamu")) {
                setIcon(treeIcons[0]);
                setToolTipText("right click to configure or exit pounamu");
            }
            //for node "tool projects")
            else if(s.equals("tool projects")){
                setIcon(treeIcons[1]);
                setToolTipText("create or re_open tool projects");
            }
            //for node "model projects")
            else if(s.equals("model projects")){
                setIcon(treeIcons[1]);
                setToolTipText("create or re_open model projects");
            }
            //for node "entity type" under a meta model view node
            else if(s.equals("entity type")){
                setIcon(treeIcons[10]);
                setToolTipText("create or re_open entity type objects");
            }
            //for node "association type" under a meta model view node
            else if(s.equals("association type")){
                setIcon(treeIcons[10]);
                setToolTipText("create or re_open association type objects");
            }
            //for node "icon_creator" under a tool node
            else if(s.equals("icon_creator")){
                setIcon(treeIcons[10]);
                setToolTipText("please right click either shape_creator or connector_creator node under this node to create, open, save, save as, close or remove an icon");
            }
            //for node "shape_creator" under an icon creator node
            else if(s.equals("shape_creator")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove a shape");
            }
            //for node "connector_creator" under an icon creator node
            else if(s.equals("connector_creator")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove a connector.");
            }
            //for node "handler_definer" under a tool node
            else if(s.equals("handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("please right click the child nodes of this node to get tools you want");
            }
            //for node "model_handler_definer" under "handler_definer" node
            else if(s.equals("model_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("please right click the child nodes of this node to get tools you want");
            }
            //for node "model_event_handler_definer" under "model_handler_definer" node
            else if(s.equals("model_event_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove an event triggering model handler");
            }
            //for node "model_user_handler_definer" under "model_handler_definer" node
            else if(s.equals("model_user_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove an user triggering model handler");
            }
            //for node "visual_handler_definer" under "handler_definer" node
            else if(s.equals("visual_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("please right click the child nodes of this node to get tools you want");
            }
            //for node "visual_event_handler_definer" under "visual_handler_definer" node
            else if(s.equals("visual_event_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove an event triggering visual handler");
            }
            //for node "visual_user_handler_definer" under "visual_handler_definer" node
            else if(s.equals("visual_user_handler_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove an user triggering visual handler");
            }
            //for node "meta_model_definer" under a tool node
            else if(s.equals("meta_model_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("right click to create, open, save, save as, close or remove a metamodel definer view");
            }
            //for node "view_type_definer" under a tool node
            else if(s.equals("view_type_definer")){
                setIcon(treeIcons[10]);
                setToolTipText("all created model element instances");
            }
            //for node "entity" under a model view node
            else if(s.equals("entity")){
                setIcon(treeIcons[10]);
                setToolTipText("all entities in this model view");
            }
            //for node "association" under a model view node
            else if(s.equals("association")){
                setIcon(treeIcons[10]);
                setToolTipText("all associations in this model view");
            }
            //using parent node value 
            //for a tool node
            else if (ss.equals("tool projects")) {
                    if(((PounamuProject)manager.getNodeAndProjectMapping().get((DefaultMutableTreeNode)value)).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(((PounamuProject)manager.getNodeAndProjectMapping().get((DefaultMutableTreeNode)value)).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("manager a tool project");
             }
             //for a model type node under node "model projects" which starts wity "using_xxxx"
             else if(ss.equals("model projects")){
                    setIcon(treeIcons[1]);
                    setToolTipText("create or re_open a model project using the specified tool");
             }
             //for a connector node
             else if(ss.equals("connector_creator")){             
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]);  
                    setToolTipText("define a connector");
              }
              //for a shape node
              else if(ss.equals("shape_creator")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define a shape");
               }
                //for a model event handler node
               else if(ss.equals("model_event_handler_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an event triggering model handler");
                }
                 //for a model user handler node
               else if(ss.equals("model_user_handler_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an user triggering model handler");
                }
                
                //for a visual event handler node
                else if(ss.equals("visual_event_handler_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an event triggering visual handler");
                }
                 //for a visual user handler node
                else if(ss.equals("visual_user_handler_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an user triggering visual handler");
                }
                //for a meta model view node
                else if(ss.equals("meta_model_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define a meta model view");
                }
                //for a view type node
                else if(ss.equals("view_type_definer")){
                    if(tool.getView(node).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(tool.getView(node).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define a view type");
                }
                //for a entity type object node under node "entity type"
                else if(ss.equals("entity type")){
                    if(((PounamuMetaModelElement)tool.getEntityTypeObject(node)).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(((PounamuMetaModelElement)tool.getEntityTypeObject(node)).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an entity type");
                }
                //for a association type object node under node "entity type"
                else if(ss.equals("association type")){
                    if(((PounamuMetaModelElement)tool.getAssociationTypeObject(node)).isRegistered())
                      setIcon(treeIcons[3]);
                    else if(((PounamuMetaModelElement)tool.getAssociationTypeObject(node)).isWasRegistered())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("define an association type");
                }
                //for a entity type node under node "entity" under a model view node
                 else if(ss.equals("entity")){
                    setIcon(treeIcons[10]);
                    setToolTipText("all entities of this entity type in this model view");
                 }
                //for a association type node under node "association" under a model view node
                 else if(ss.equals("association")){
                    setIcon(treeIcons[10]);
                    setToolTipText("all associations of this association type in this model view");
                 }
                //for a model node
                 else if(ss.startsWith("Using_")){
                    if(((PounamuProject)manager.getNodeAndProjectMapping().get(node)).isSaved())
                      setIcon(treeIcons[3]);
                    else if(((PounamuProject)manager.getNodeAndProjectMapping().get(node)).isWasSaved())
                      setIcon(treeIcons[4]);
                    else
                      setIcon(treeIcons[2]); 
                    setToolTipText("manager a model project");
                 }
                
                 else if(parent.getParent() != null){
                     DefaultMutableTreeNode d = (DefaultMutableTreeNode)parent.getParent();
                     String sss = (String)d.getUserObject();
                     //for a view type node unde a model node
                     if(sss.startsWith("Using_")){
                       setIcon(treeIcons[10]);
                       setToolTipText("all model views of the specified view type in this model");
                     }
                     //for a entity object
                     else if(sss.equals("entity")){
                       if(((PounamuModelElement)model.getEntity(node)).isSaved())
                         setIcon(treeIcons[3]);
                       else if(((PounamuModelElement)model.getEntity(node)).isWasSaved())
                         setIcon(treeIcons[4]);
                       else
                         setIcon(treeIcons[2]); 
                       setToolTipText("define an entity");
                     } 
                     //for a entity object
                     else if(sss.equals("association")){
                       if(((PounamuModelElement)model.getAssociation(node)).isSaved())
                         setIcon(treeIcons[3]);
                       else if(((PounamuModelElement)model.getAssociation(node)).isWasSaved())
                         setIcon(treeIcons[4]);
                       else
                         setIcon(treeIcons[2]); 
                       setToolTipText("define an association");
                     } 
                     else if(d.getParent() != null){
                       DefaultMutableTreeNode dt = (DefaultMutableTreeNode)d.getParent();
                       String sssss = (String)dt.getUserObject(); 
                       //for a view node under a view type node under a model node
                       if(sssss.startsWith("Using_")){
                         if(model.getView(node).isSaved())
                           setIcon(treeIcons[3]);
                         else if(model.getView(node).isWasSaved())
                           setIcon(treeIcons[4]);
                         else
                           setIcon(treeIcons[2]); 
                         setToolTipText("define a model view");
                       }
                       else{
                         //for visual component node
                         setIcon(treeIcons[9]);
                         setToolTipText("a visual component");
                       }
                     }
                 }
                
                 else{};
            //System.out.println(s);
            return this;
        }
    }

