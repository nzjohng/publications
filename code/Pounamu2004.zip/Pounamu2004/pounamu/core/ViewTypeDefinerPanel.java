/*
 * @(#)ViewTypeDefiner.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;


/**
 * Title: ViewTypeDefiner
 * Description:  A panel to define a type of view, including defining allowed meta model elements, handlers,
 * choosing icons for metamodel elements and mapping properties between them
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ViewTypeDefinerPanel extends JPanel {

  DefaultListModel availableVisualEventHandlersModel=new DefaultListModel();
  JList availableVisualEventHandlersList = new JList(availableVisualEventHandlersModel);
  DefaultListModel allowedVisualEventHandlersModel=new DefaultListModel();
  JList allowedVisualEventHandlersList = new JList(allowedVisualEventHandlersModel);
  DefaultListModel availableVisualUserHandlersModel=new DefaultListModel();
  JList availableVisualUserHandlersList = new JList(availableVisualUserHandlersModel);
  DefaultListModel allowedVisualUserHandlersModel=new DefaultListModel();
  JList allowedVisualUserHandlersList = new JList(allowedVisualUserHandlersModel);
  DefaultListModel availableEntityTypesModel=new DefaultListModel();
  JList availableEntityTypesList = new JList(availableEntityTypesModel);
  DefaultListModel availableAssociationTypesModel=new DefaultListModel();
  JList availableAssociationTypesList = new JList(availableAssociationTypesModel);
  DefaultListModel allowedAssociationTypesModel=new DefaultListModel();
  JList allowedAssociationTypesList1 = new JList(allowedAssociationTypesModel);
  JList allowedAssociationTypesList2 = new JList(allowedAssociationTypesModel);
  DefaultListModel allowedEntityTypesModel=new DefaultListModel();
  JList allowedEntityTypesList1 = new JList(allowedEntityTypesModel);
  JList allowedEntityTypesList2 = new JList(allowedEntityTypesModel);
  DefaultListModel availableShapesModel=new DefaultListModel();
  JList availableShapesList = new JList(availableShapesModel);
  DefaultListModel availableConnectorsModel=new DefaultListModel();
  JList availableConnectorsList = new JList(availableConnectorsModel);
  DefaultListModel entityTypeAndShapeMappingModel=new DefaultListModel();
  JList entityTypeAndShapeMappingList1 = new JList(entityTypeAndShapeMappingModel);
  JList entityTypeAndShapeMappingList2 = new JList(entityTypeAndShapeMappingModel);
  DefaultListModel associationTypeAndConnectorMappingModel=new DefaultListModel();
  JList associationTypeAndConnectorMappingList1 = new JList(associationTypeAndConnectorMappingModel);
  JList associationTypeAndConnectorMappingList2 = new JList(associationTypeAndConnectorMappingModel);
  DefaultListModel elementPropertiesModel=new DefaultListModel();
  JList elementPropertiesList = new JList(elementPropertiesModel);
  DefaultListModel iconFieldPropertiesModel=new DefaultListModel();
  JList iconFieldPropertiesList = new JList(iconFieldPropertiesModel);
  DefaultListModel iconAreaPropertiesModel=new DefaultListModel();
  JList iconAreaPropertiesList = new JList(iconAreaPropertiesModel);
  PounamuManagerPanel manager = null;
  PounamuToolProject project = null;
  String name = null;
  Hashtable nameAndPanelMapping = new Hashtable();
  JPanel dynamicPanelInEntityTypePanel = new JPanel();
  JPanel panelInEntityTypePanel = new JPanel();
  JPanel dynamicPanelInAssociationTypePanel = new JPanel();
  JPanel panelInAssociationTypePanel = new JPanel();
  JPanel entityTypePanel = new JPanel();
  JPanel associationTypePanel = new JPanel();
  JPanel visualEventHandlerPanel = new JPanel();
  JPanel visualUserHandlerPanel = new JPanel();
  String fileSeparator = null;
  
  /**
   * construct a dialog which allow user to choose an icon for a metamodel element
   * @param name the name of the view type being defined
   * @param project the tool project which uses this view type
   */
  public ViewTypeDefinerPanel(String name, PounamuProject project){
    //super(project.getPounamu(), "Model View Type Definer", true);
    this.name = name;
    this.project = (PounamuToolProject)project;
    fileSeparator = System.getProperty("file.separator");
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void setName(String name){
    this.name = name;
  }
  
  public String getName(){
    return this.name;
  }
  /**
   * get the list model of the allowed elements list
   * @return the list model
   */
  /*public DefaultListModel getAllowedElementsModel(){
    return allowedElementsModel;
  }*/
  
  public DefaultListModel getAllowedEntityTypesModel(){
    return allowedEntityTypesModel;
  }
  
  public DefaultListModel getAllowedAssociationTypesModel(){
    return allowedAssociationTypesModel;
  }

  public void setAllowedEntityTypesModel(DefaultListModel allowedEntityTypesModel){
    this.allowedEntityTypesModel = allowedEntityTypesModel;
  }

  public void setAllowedAssociationTypesModel(DefaultListModel allowedAssociationTypesModel){
    this.allowedAssociationTypesModel = allowedAssociationTypesModel;
  }

  /**
   * get the list model of the allowed visual event handler list
   * @return the visual event handler list model
   */
  public DefaultListModel getAllowedVisualEventHandlersModel(){
    return allowedVisualEventHandlersModel;
  }
  
  /**
   * get the list model of the allowed visual user handler list
   * @return the visual user handler list model
   */
  public DefaultListModel getAllowedVisualUserHandlersModel(){
    return allowedVisualUserHandlersModel;
  }


  /**
   * set the list model for the allowed visual event handler list
   * @param allowedVisualEventHandlersModel a DefaultListModel object
   */
  public void setAllowedVisualEventHandlersModel(DefaultListModel allowedVisualEventHandlersModel){
    this.allowedVisualEventHandlersModel = allowedVisualEventHandlersModel;
  }
  
  /**
   * set the list model for the allowed visual user handler list
   * @param allowedVisualUserHandlersModel a DefaultListModel object
   */
  public void setAllowedVisualUserHandlersModel(DefaultListModel allowedVisualUserHandlersModel){
    this.allowedVisualUserHandlersModel = allowedVisualUserHandlersModel;
  }

  /**
   * get the list model of the available element list
   * @return the list model
   */
 /* public DefaultListModel getAvailableElementsModel(){
    return availableElementsModel;
  }*/
  public DefaultListModel getAvailableEntityTypesModel(){
    return availableEntityTypesModel;
  }
  
  public DefaultListModel getAvailableAssociationTypesModel(){
    return availableAssociationTypesModel;
  }

  public void setAvailableEntityTypesModel(DefaultListModel availableEntityTypesModel){
    this.availableEntityTypesModel = availableEntityTypesModel;
  }

  public void setAvailableAssociationTypesModel(DefaultListModel availableAssociationTypesModel){
    this.availableAssociationTypesModel = availableAssociationTypesModel;
  }


  /**
   * get the list model of the available visual event handler list
   * @return the visual event list model
   */
  public DefaultListModel getAvailableVisualEventHandlersModel(){
    return availableVisualEventHandlersModel;
  }
  
  /**
   * get the list model of the available visual user handler list
   * @return the visual user list model
   */
  public DefaultListModel getAvailableVisualUserHandlersModel(){
    return availableVisualUserHandlersModel;
  }

  /**
   * set the list model for the available visual event handler list
   * @param availableVisualEventHandlersModel a DefaultListModel object
   */
  public void setAvailableVisualEventHandlersModel(DefaultListModel availableVisualEventHandlersModel){
    this.availableVisualEventHandlersModel = availableVisualEventHandlersModel;
  }
  
  /**
   * set the list model for the available visual user  handler list
   * @param availableVisualUserHandlersModel a DefaultListModel object
   */
  public void setAvailableVisualUserHandlersModel(DefaultListModel availableVisualUserHandlersModel){
    this.availableVisualUserHandlersModel = availableVisualUserHandlersModel;
  }

  public DefaultListModel getAvailableShapesModel(){
    return availableShapesModel;
  }
  
  public DefaultListModel getAvailableConnectorsModel(){
    return availableConnectorsModel;
  }

  public void setAvailableShapesModel(DefaultListModel availableShapesModel){
    this.availableShapesModel = availableShapesModel;
  }
  
  public void setAvailableConnectorsModel(DefaultListModel availableConnectorsModel){
    this.availableConnectorsModel = availableConnectorsModel;
  }

  public DefaultListModel getEntityTypeAndShapeMappingModel(){
    return entityTypeAndShapeMappingModel;
  }
  public DefaultListModel getAssociationTypeAndConnectorMappingModel(){
    return associationTypeAndConnectorMappingModel;
  }

  public void setEntityTypeAndShapeMappingModel(DefaultListModel entityTypeAndShapeMappingModel){
    this.entityTypeAndShapeMappingModel = entityTypeAndShapeMappingModel;
  }

  public void setAssociationTypeAndConnectorMappingModel(DefaultListModel associationTypeAndConnectorMappingModel){
    this.associationTypeAndConnectorMappingModel = associationTypeAndConnectorMappingModel;
  }


  /**
   * register this view type to the tool project
   * @param project the tool which will use this view type
   */
  public void registerViewType(PounamuToolProject project){
    if(!(project.getRegisteredViewTypes().contains(name)))
      project.getRegisteredViewTypes().add(name);
    Vector v  = new Vector();
    for(int i = 0; i < allowedVisualEventHandlersModel.getSize(); i++){
      v.add(allowedVisualEventHandlersModel.get(i));
    }
    project.getViewTypeAndAllowedVisualEventHandlersMapping().put(name, v);
    v  = new Vector();
    for(int i = 0; i < allowedVisualUserHandlersModel.getSize(); i++){
      v.add(allowedVisualUserHandlersModel.get(i));
    }
    project.getViewTypeAndAllowedVisualUserHandlersMapping().put(name, v);
    v = new Vector();
    for(int i = 0; i < allowedEntityTypesModel.getSize(); i++){
      v.add(allowedEntityTypesModel.get(i));
    }
    //project.getViewTypeAndAllowedMetaModelTypesMapping().put(name, v);
    project.getViewTypeAndAllowedEntityTypesMapping().put(name, v);
    v = new Vector();
    for(int i = 0; i < allowedAssociationTypesModel.getSize(); i++){
      v.add(allowedAssociationTypesModel.get(i));
    }
    //project.getViewTypeAndAllowedMetaModelTypesMapping().put(name, v);
    project.getViewTypeAndAllowedAssociationTypesMapping().put(name, v);
    
    
    /*v = new Vector();
    for(int j = 0; j < elementAndIconMappingModel.getSize(); j++){
      v.add(elementAndIconMappingModel.get(j));
      PropertyMappingPanel pmp = (PropertyMappingPanel)nameAndPanelMapping.get((String)elementAndIconMappingModel.get(j));
      String key = name+":"+(String)elementAndIconMappingModel.get(j);
      pmp.registerViewType(key, project);
    }
    project.getViewTypeAndMetaModelTypesAndIconMapping().put(name, v);*/
    v = new Vector();
    for(int j = 0; j < entityTypeAndShapeMappingModel.getSize(); j++){
      v.add(entityTypeAndShapeMappingModel.get(j));
      PropertyMappingPanel pmp = (PropertyMappingPanel)nameAndPanelMapping.get((String)entityTypeAndShapeMappingModel.get(j));
      String key = name+":"+(String)entityTypeAndShapeMappingModel.get(j);
      if(pmp != null)
        pmp.registerViewType(key, project);
    }
    project.getViewTypeAndEntityTypeAndShapeMapping().put(name, v);
    v = new Vector();
    for(int j = 0; j < associationTypeAndConnectorMappingModel.getSize(); j++){
      v.add(associationTypeAndConnectorMappingModel.get(j));
      PropertyMappingPanel pmp = (PropertyMappingPanel)nameAndPanelMapping.get((String)associationTypeAndConnectorMappingModel.get(j));
      String key = name+":"+(String)associationTypeAndConnectorMappingModel.get(j);
      if(pmp != null)
        pmp.registerViewType(key, project);
    }
    project.getViewTypeAndAssociationTypeAndConnectorMapping().put(name, v);
  }

  /**
   * dynamicly update the available elements, handlers and icons
   */
  public void updateAvailableTypesAndIcons(){
    availableVisualEventHandlersModel.removeAllElements();
    availableVisualUserHandlersModel.removeAllElements();
    availableEntityTypesModel.removeAllElements();
    availableAssociationTypesModel.removeAllElements();
    availableShapesModel.removeAllElements();
    availableConnectorsModel.removeAllElements();
    initAvailableVisualEventHandlersModel();
    initAvailableVisualUserHandlersModel();
    initAvailableEntityTypesModel();
    initAvailableAssociationTypesModel();
    initAvailableShapesModel();
    initAvailableConnectorsModel();
  }


  private void initAvailableVisualEventHandlersModel(){
    Enumeration e = project.getRegisteredVisualEventHandlers().keys();
    String[] array = new String[project.getRegisteredVisualEventHandlers().size()];
    int i = 0;
    while(e.hasMoreElements()){
      array[i] = (String)e.nextElement();
      i++;
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableVisualEventHandlersModel.addElement(ss);
    }
  }
  
  private void initAvailableVisualUserHandlersModel(){

    Enumeration e = project.getRegisteredVisualUserHandlers().keys();
    String[] array = new String[project.getRegisteredVisualUserHandlers().size()];
    int i = 0; 
    while(e.hasMoreElements()){
      array[i] = (String)e.nextElement();
      i++;
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableVisualUserHandlersModel.addElement(ss);
    }
  }

  private void initAvailableEntityTypesModel(){
    Vector entityTypes = project.getEntityTypeObjects();
    String[] array = new String[entityTypes.size()];
    for(int i = 0; i < entityTypes.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)entityTypes.get(i);
      array[i] = element.getName();
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableEntityTypesModel.addElement(ss);
    }
  }
  
  private void initAvailableAssociationTypesModel(){
    Vector associationTypes = project.getAssociationTypeObjects();
    String[] array = new String[associationTypes.size()];
    for(int i = 0; i < associationTypes.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)associationTypes.get(i);
      array[i] = element.getName();
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableAssociationTypesModel.addElement(ss);
    }
  }

  private void initAvailableShapesModel(){
    Vector v = project.getRegisteredShapes();
    String[] array = new String[v.size()];
    for(int i = 0; i<v.size(); i++){
      array[i] = (String)v.get(i);
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableShapesModel.addElement(ss);
    }     
  }
  
  private void initAvailableConnectorsModel(){
    Vector v = project.getRegisteredConnectors();
    String[] array = new String[v.size()];
    for(int i = 0; i<v.size(); i++){
      array[i] = (String)v.get(i);
    }
    Arrays.sort(array);
    //Vector v = project.getRegisteredAssociationTypes();
    for(int j = 0; j<array.length; j++){
      String ss = array[j];
      availableConnectorsModel.addElement(ss);
    }     
  }
  /**
   * Component initialization
   */
  private void jbInit() throws Exception {
    initAvailableVisualEventHandlersModel();
    initAvailableVisualUserHandlersModel();
    initAvailableEntityTypesModel();
    initAvailableAssociationTypesModel();
    //initAvailableElementsModel();
    initAvailableShapesModel();
    initAvailableConnectorsModel();
    //initAvailableIconsModel();
    availableVisualEventHandlersList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    availableVisualUserHandlersList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    //availableElementsList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    availableEntityTypesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    availableAssociationTypesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    //allowedElementsList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    allowedEntityTypesList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    allowedAssociationTypesList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    //allowedElementsList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    allowedEntityTypesList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    allowedAssociationTypesList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    //availableIconsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    availableShapesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    availableConnectorsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    //elementAndIconMappingList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    entityTypeAndShapeMappingList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    associationTypeAndConnectorMappingList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    entityTypeAndShapeMappingList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    associationTypeAndConnectorMappingList2.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    initialVisualEventHandlerPanel();
    initialVisualUserHandlerPanel();
    initialEntityTypePanel();
    initialAssociationTypePanel();
    JTabbedPane tab = new JTabbedPane();
    tab.add(entityTypePanel, "Entity Type");
    tab.add(associationTypePanel, "Association Type");
    tab.add(visualEventHandlerPanel, "Visual Event Handler");
    tab.add(visualUserHandlerPanel, "Visual User Handler");
    tab.setSelectedComponent(entityTypePanel);
    this.setLayout(new BorderLayout());
    this.add(tab, BorderLayout.CENTER);
  }
  
  public void initialVisualEventHandlerPanel(){
         
    visualEventHandlerPanel.setLayout(new GridLayout(1, 3, 5, 5));
    JScrollPane listScrollPane10 = new JScrollPane(availableVisualEventHandlersList);
    listScrollPane10.setPreferredSize(new Dimension(110, 50));
    visualEventHandlerPanel.add(listScrollPane10);
    JPanel jPanel00 = new JPanel();
    JButton addButton0 = new JButton("add to >>");
    JButton removeButton0 = new JButton("<< remove");
    jPanel00.setLayout(new VerticalFlowLayout(5));
    jPanel00.add(addButton0);
    addButton0.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(availableVisualEventHandlersList.getSelectedIndex() == -1)){
           Object[] items = availableVisualEventHandlersList.getSelectedValues();
           for(int i = 0; i < items.length; i++){
              if(!(allowedVisualEventHandlersModel.contains(items[i])))
                allowedVisualEventHandlersModel.addElement(items[i]);
           }
         }
      }
    });
    jPanel00.add(removeButton0);
    removeButton0.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedVisualEventHandlersList.getSelectedIndex() != -1){
           int[] index = allowedVisualEventHandlersList.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             allowedVisualEventHandlersModel.remove(index[i]);
           }
         }
      }
    });
    visualEventHandlerPanel.add(jPanel00);
    JScrollPane listScrollPane100 = new JScrollPane(allowedVisualEventHandlersList);
    listScrollPane100.setPreferredSize(new Dimension(110, 90));
    visualEventHandlerPanel.add(listScrollPane100);
    visualEventHandlerPanel.setBorder(BorderFactory.createTitledBorder("Please select allowed visual event handlers"));
  }
  
  public void initialVisualUserHandlerPanel(){
         
    visualUserHandlerPanel.setLayout(new GridLayout(1, 3, 5, 5));
    JScrollPane listScrollPane10 = new JScrollPane(availableVisualUserHandlersList);
    listScrollPane10.setPreferredSize(new Dimension(110, 50));
    visualUserHandlerPanel.add(listScrollPane10);
    JPanel jPanel00 = new JPanel();
    JButton addButton0 = new JButton("add to >>");
    JButton removeButton0 = new JButton("<< remove");
    jPanel00.setLayout(new VerticalFlowLayout(5));
    jPanel00.add(addButton0);
    addButton0.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(availableVisualUserHandlersList.getSelectedIndex() == -1)){
           Object[] items = availableVisualUserHandlersList.getSelectedValues();
           for(int i = 0; i < items.length; i++){
              if(!(allowedVisualUserHandlersModel.contains(items[i])))
                allowedVisualUserHandlersModel.addElement(items[i]);
           }
         }
      }
    });
    jPanel00.add(removeButton0);
    removeButton0.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedVisualUserHandlersList.getSelectedIndex() != -1){
           int[] index = allowedVisualUserHandlersList.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             allowedVisualUserHandlersModel.remove(index[i]);
           }
         }
      }
    });
    visualUserHandlerPanel.add(jPanel00);
    JScrollPane listScrollPane100 = new JScrollPane(allowedVisualUserHandlersList);
    listScrollPane100.setPreferredSize(new Dimension(110, 90));
    visualUserHandlerPanel.add(listScrollPane100);
    visualUserHandlerPanel.setBorder(BorderFactory.createTitledBorder("Please select allowed visual user handlers"));
  }
  
  public void initialAssociationTypePanel(){
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new GridLayout(1, 3, 5, 5));
    JScrollPane listScrollPane11 = new JScrollPane(availableAssociationTypesList);
    listScrollPane11.setPreferredSize(new Dimension(110, 90));
    jPanel1.add(listScrollPane11);
    JPanel jPanel2 = new JPanel();
    JButton addButton = new JButton("add to >>");
    JButton removeButton = new JButton("<< remove");
    jPanel2.setLayout(new VerticalFlowLayout(5));
    jPanel2.add(addButton);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(availableAssociationTypesList.getSelectedIndex() == -1)){
           Object[] items = availableAssociationTypesList.getSelectedValues();
           for(int i = 0; i < items.length; i++){
              if(!(allowedAssociationTypesModel.contains(items[i])))
                allowedAssociationTypesModel.addElement(items[i]);
           }
         }
      }
    });
    jPanel2.add(removeButton);
    removeButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedAssociationTypesList1.getSelectedIndex() != -1){
           int[] index = allowedAssociationTypesList1.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             allowedAssociationTypesModel.remove(index[i]);
           }
         }
      }
    });
    jPanel1.add(jPanel2);
    JScrollPane listScrollPane12 = new JScrollPane(allowedAssociationTypesList1);
    listScrollPane12.setPreferredSize(new Dimension(110, 90));
    jPanel1.add(listScrollPane12);
    jPanel1.setBorder(BorderFactory.createTitledBorder("Please select allowed meta model types"));
    //+============= end of element selection panelInEntityTypePanel==========================
    //+========== initial model and icon mapping panelInEntityTypePanel =========================
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new GridLayout(1, 4, 5, 5));
    JScrollPane listScrollPane13 = new JScrollPane(allowedAssociationTypesList2);
    listScrollPane13.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane13);
    JScrollPane listScrollPane14 = new JScrollPane(availableConnectorsList);
    listScrollPane14.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane14);
    JPanel jPanel4 = new JPanel();
    JButton mappingButton = new JButton("mapping >>");
    JButton removeButton1 = new JButton("<< remove");
    jPanel4.setLayout(new VerticalFlowLayout(5));
    jPanel4.add(mappingButton);
    mappingButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedAssociationTypesList2.getSelectedIndex() == -1||
            availableConnectorsList.getSelectedIndex() == -1){
              project.getPounamu().displayMessage("You have not select one connector for an association type");
              return;
            }
         else{
           String elementName = (String)allowedAssociationTypesList2.getSelectedValue();
           String iconName = (String)availableConnectorsList.getSelectedValue();
           associationTypeAndConnectorMappingModel.addElement(elementName+":"+iconName);
           PropertyMappingPanel pmp = new PropertyMappingPanel(project, elementName, iconName);
           //System.out.println("elementName is" + elementName + "iconName is" + iconName);
           nameAndPanelMapping.put(elementName+":"+iconName, pmp);
         }
      }
    });
    jPanel4.add(removeButton1);
    removeButton1.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(associationTypeAndConnectorMappingList1.getSelectedIndex() == -1)){
           int[] index = associationTypeAndConnectorMappingList1.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             associationTypeAndConnectorMappingModel.remove(index[i]);
           }
         }
      }
    });
    jPanel3.add(jPanel4);
    JScrollPane listScrollPane15 = new JScrollPane(associationTypeAndConnectorMappingList1);
    listScrollPane15.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane15);
    jPanel3.setBorder(BorderFactory.createTitledBorder("Please map association types and connectors"));
    //+========== end of model and icon mapping panelInEntityTypePanel =========================
    //+========== initial property mapping panelInEntityTypePanel ==============================
    panelInAssociationTypePanel.setLayout(new FlowLayout());
    associationTypeAndConnectorMappingList2.addListSelectionListener(new ListSelectionListener(){
      public void valueChanged(ListSelectionEvent e){
        //if(e.getValueIsAdjusting() == false){
          if(associationTypeAndConnectorMappingList2.getSelectedIndex() == -1){
            //No selection, disable delete button.
            return;
          }
          else{
            String s = associationTypeAndConnectorMappingList2.getSelectedValue().toString();
            //System.out.println("ssssssss "+ s);
            if(dynamicPanelInAssociationTypePanel != null){
              panelInAssociationTypePanel.remove(dynamicPanelInAssociationTypePanel);
            }
            dynamicPanelInAssociationTypePanel = (PropertyMappingPanel)nameAndPanelMapping.get(s);
            if(dynamicPanelInAssociationTypePanel != null){
              panelInAssociationTypePanel.add(dynamicPanelInAssociationTypePanel);
            }
            panelInAssociationTypePanel.validate();
            panelInAssociationTypePanel.getParent().validate();
            panelInAssociationTypePanel.repaint();
          }
      }
    });
    JScrollPane listScrollPane16 = new JScrollPane(associationTypeAndConnectorMappingList2);
    listScrollPane16.setPreferredSize(new Dimension(100, 120));
    panelInAssociationTypePanel.add(listScrollPane16);
    panelInAssociationTypePanel.add(dynamicPanelInAssociationTypePanel);
    panelInAssociationTypePanel.setBorder(BorderFactory.createTitledBorder("Please map properties here"));
    associationTypePanel.setLayout(new VerticalFlowLayout(2));
    associationTypePanel.add(jPanel1);
    associationTypePanel.add(jPanel3);
    associationTypePanel.add(panelInAssociationTypePanel);
  }
  
  public void initialEntityTypePanel(){
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new GridLayout(1, 3, 5, 5));
    JScrollPane listScrollPane11 = new JScrollPane(availableEntityTypesList);
    listScrollPane11.setPreferredSize(new Dimension(110, 90));
    jPanel1.add(listScrollPane11);
    JPanel jPanel2 = new JPanel();
    JButton addButton = new JButton("add to >>");
    JButton removeButton = new JButton("<< remove");
    jPanel2.setLayout(new VerticalFlowLayout(5));
    jPanel2.add(addButton);
    addButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(availableEntityTypesList.getSelectedIndex() == -1)){
           Object[] items = availableEntityTypesList.getSelectedValues();
           for(int i = 0; i < items.length; i++){
              if(!(allowedEntityTypesModel.contains(items[i])))
                allowedEntityTypesModel.addElement(items[i]);
           }
         }
      }
    });
    jPanel2.add(removeButton);
    removeButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedEntityTypesList1.getSelectedIndex() != -1){
           int[] index = allowedEntityTypesList1.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             allowedEntityTypesModel.remove(index[i]);
           }
         }
      }
    });
    jPanel1.add(jPanel2);
    JScrollPane listScrollPane12 = new JScrollPane(allowedEntityTypesList1);
    listScrollPane12.setPreferredSize(new Dimension(110, 90));
    jPanel1.add(listScrollPane12);
    jPanel1.setBorder(BorderFactory.createTitledBorder("Please select allowed meta model types"));
    //+============= end of element selection panelInEntityTypePanel==========================
    //+========== initial model and icon mapping panelInEntityTypePanel =========================
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new GridLayout(1, 4, 5, 5));
    JScrollPane listScrollPane13 = new JScrollPane(allowedEntityTypesList2);
    listScrollPane13.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane13);
    JScrollPane listScrollPane14 = new JScrollPane(availableShapesList);
    listScrollPane14.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane14);
    JPanel jPanel4 = new JPanel();
    JButton mappingButton = new JButton("mapping >>");
    JButton removeButton1 = new JButton("<< remove");
    jPanel4.setLayout(new VerticalFlowLayout(5));
    jPanel4.add(mappingButton);
    mappingButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(allowedEntityTypesList2.getSelectedIndex() == -1||
            availableShapesList.getSelectedIndex() == -1){
              project.getPounamu().displayMessage("You have not select one shape for an entity type");
              return;
            }
         else{
           String elementName = (String)allowedEntityTypesList2.getSelectedValue();
           String iconName = (String)availableShapesList.getSelectedValue();
           entityTypeAndShapeMappingModel.addElement(elementName+":"+iconName);
           PropertyMappingPanel pmp = new PropertyMappingPanel(project, elementName, iconName);
           //System.out.println("elementName is" + elementName + "iconName is" + iconName);
           nameAndPanelMapping.put(elementName+":"+iconName, pmp);
         }
      }
    });
    jPanel4.add(removeButton1);
    removeButton1.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
         if(!(entityTypeAndShapeMappingList1.getSelectedIndex() == -1)){
           int[] index = entityTypeAndShapeMappingList1.getSelectedIndices();
           for(int i = 0; i < index.length; i++){
             entityTypeAndShapeMappingModel.remove(index[i]);
           }
         }
      }
    });
    jPanel3.add(jPanel4);
    JScrollPane listScrollPane15 = new JScrollPane(entityTypeAndShapeMappingList1);
    listScrollPane15.setPreferredSize(new Dimension(110, 90));
    jPanel3.add(listScrollPane15);
    jPanel3.setBorder(BorderFactory.createTitledBorder("Please map meta model types and icons"));
    //+========== end of model and icon mapping panelInEntityTypePanel =========================
    //+========== initial property mapping panelInEntityTypePanel ==============================
    panelInEntityTypePanel.setLayout(new FlowLayout());
    entityTypeAndShapeMappingList2.addListSelectionListener(new ListSelectionListener(){
      public void valueChanged(ListSelectionEvent e){
        //if(e.getValueIsAdjusting() == false){
          if(entityTypeAndShapeMappingList2.getSelectedIndex() == -1){
            //No selection, disable delete button.
            return;
          }
          else{
            String s = entityTypeAndShapeMappingList2.getSelectedValue().toString();
            //System.out.println("ssssssss "+ s);
            panelInEntityTypePanel.remove(dynamicPanelInEntityTypePanel);
            dynamicPanelInEntityTypePanel = (PropertyMappingPanel)nameAndPanelMapping.get(s);
            if(dynamicPanelInEntityTypePanel!=null)
              panelInEntityTypePanel.add(dynamicPanelInEntityTypePanel);
            panelInEntityTypePanel.validate();
            panelInEntityTypePanel.getParent().validate();
            panelInEntityTypePanel.repaint();
          }
      }
    });
    JScrollPane listScrollPane16 = new JScrollPane(entityTypeAndShapeMappingList2);
    listScrollPane16.setPreferredSize(new Dimension(100, 120));
    panelInEntityTypePanel.add(listScrollPane16);
    panelInEntityTypePanel.add(dynamicPanelInEntityTypePanel);
    panelInEntityTypePanel.setBorder(BorderFactory.createTitledBorder("Please map properties here"));
    entityTypePanel.setLayout(new VerticalFlowLayout(2));
    entityTypePanel.add(jPanel1);
    entityTypePanel.add(jPanel3);
    entityTypePanel.add(panelInEntityTypePanel);
  }

  /**
   * save this view as a xml file which has the same name of this view type into the default location
   */
  public void save(){
    Pounamu pounamu = project.getPounamu();
    String outputPath = project.getLocation()+""+fileSeparator+"viewtypes"+fileSeparator+""+name+".xml";
    try{
      FileWriter fw = new FileWriter(outputPath);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(getXML());
      bw.flush();
      fw.close();
    }
    catch(Exception ee){
      project.getPounamu().displayMessage("Exception from Class ViewTypeDefinerPanel "+ee.toString());
      //System.out.println(ee.toString());
    }
  }

  /**
   * get th exml representationfor this view type
   * @return the xml String
   */
  public String getXML(){
    StringBuffer buf = new StringBuffer (400000);
    String space = "            ";
    buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE viewtype SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"viewtype.dtd\">\n");
    buf.append ("<viewtype>\n");
    buf.append (space+"<name>"+name+"</name>\n");
    for(int i = 0; i < allowedEntityTypesModel.getSize(); i++){
      String s = (String)allowedEntityTypesModel.elementAt(i);
      buf.append (space+"<allowedentitytypesmodel>"+s+"</allowedentitytypesmodel>\n");
    }
    for(int i = 0; i < allowedAssociationTypesModel.getSize(); i++){
      String s = (String)allowedAssociationTypesModel.elementAt(i);
      buf.append (space+"<allowedassociationtypesmodel>"+s+"</allowedassociationtypesmodel>\n");
    }
    for(int i = 0; i < availableEntityTypesModel.getSize(); i++){
      String s = (String)availableEntityTypesModel.elementAt(i);
      buf.append (space+"<availableentitytypesmodel>"+s+"</availableentitytypesmodel>\n");
    }
    for(int i = 0; i < availableAssociationTypesModel.getSize(); i++){
      String s = (String)availableAssociationTypesModel.elementAt(i);
      buf.append (space+"<availableassociationtypesmodel>"+s+"</availableassociationtypesmodel>\n");
    }
    for(int i = 0; i < allowedVisualEventHandlersModel.getSize(); i++){
      String s = (String)allowedVisualEventHandlersModel.elementAt(i);
      buf.append (space+"<allowedVisualEventHandlersModel>"+s+"</allowedVisualEventHandlersModel>\n");
    }
    for(int i = 0; i < allowedVisualUserHandlersModel.getSize(); i++){
      String s = (String)allowedVisualUserHandlersModel.elementAt(i);
      buf.append (space+"<allowedVisualUserHandlersModel>"+s+"</allowedVisualUserHandlersModel>\n");
    }
    for(int i = 0; i < availableVisualEventHandlersModel.getSize(); i++){
      String s = (String)availableVisualEventHandlersModel.elementAt(i);
      buf.append (space+"<availableVisualEventHandlersModel>"+s+"</availableVisualEventHandlersModel>\n");
    }
    for(int i = 0; i < availableVisualUserHandlersModel.getSize(); i++){
      String s = (String)availableVisualUserHandlersModel.elementAt(i);
      buf.append (space+"<availableVisualUserHandlersModel>"+s+"</availableVisualUserHandlersModel>\n");
    }
    for(int i = 0; i < availableShapesModel.getSize(); i++){
      String s = (String)availableShapesModel.elementAt(i);
      buf.append (space+"<availableshapesmodel>"+s+"</availableshapesmodel>\n");
    }
    for(int i = 0; i < availableConnectorsModel.getSize(); i++){
      String s = (String)availableConnectorsModel.elementAt(i);
      buf.append (space+"<availableconnectorsmodel>"+s+"</availableconnectorsmodel>\n");
    }
    for(int i = 0; i < entityTypeAndShapeMappingModel.getSize(); i++){
      String s = (String)entityTypeAndShapeMappingModel.elementAt(i);
      buf.append (space+"<entitytypeandshapemappingmodel>"+s+"</entitytypeandshapemappingmodel>\n");
    }
    for(int i = 0; i < associationTypeAndConnectorMappingModel.getSize(); i++){
      String s = (String)associationTypeAndConnectorMappingModel.elementAt(i);
      buf.append (space+"<associationtypeandconnectormappingmodel>"+s+"</associationtypeandconnectormappingmodel>\n");
    }
    for(int j = 0; j < entityTypeAndShapeMappingModel.getSize(); j++){
      PropertyMappingPanel pmp = (PropertyMappingPanel)nameAndPanelMapping.get((String)entityTypeAndShapeMappingModel.get(j));
      if(pmp != null){
        buf.append(space+"<propertymappingforentitytypeandshape>\n");
        buf.append(space+space+"<key>"+(String)entityTypeAndShapeMappingModel.get(j)+"</key>\n");
        pmp.save(buf, space+space);
        buf.append (space+"</propertymappingforentitytypeandshape>\n");
      }
    }
    for(int j = 0; j < associationTypeAndConnectorMappingModel.getSize(); j++){
      PropertyMappingPanel pmp = (PropertyMappingPanel)nameAndPanelMapping.get((String)associationTypeAndConnectorMappingModel.get(j));
      if(pmp != null){
        buf.append(space+"<propertymappingforassociationtypeandconnector>\n");
        buf.append(space+space+"<key>"+(String)associationTypeAndConnectorMappingModel.get(j)+"</key>\n");
        pmp.save(buf, space+space);
        buf.append (space+"</propertymappingforassociationtypeandconnector>\n");
      }
    }
    if(entityTypeAndShapeMappingList2.getSelectedValue()!=null)
      buf.append (space+"<selectedindexforentitytypeandshape>"+entityTypeAndShapeMappingList2.getSelectedIndex()+"</selectedindexforentitytypeandshape>\n");
    if(associationTypeAndConnectorMappingList2.getSelectedValue()!=null)
      buf.append (space+"<selectedindexforassociationtypeandconnector>"+associationTypeAndConnectorMappingList2.getSelectedIndex()+"</selectedindexforassociationtypeandconnector>\n");
    
    buf.append ("</viewtype>\n");
    return buf.toString();
  }

  /**
   * restore a view type from a predefined xml file
   * @param xmlDocument the Document from the xml file
   */
  public void restore(Document xmlDocument){
    Node m = xmlDocument.getDocumentElement();
    NodeList nll = ((Element)m).getElementsByTagName("allowedentitytypesmodel");
    //DefaultListModel model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      //System.out.println(n.getFirstChild().getNodeValue());
      //model.addElement(n.getFirstChild().getNodeValue());
      allowedEntityTypesModel.addElement(n.getFirstChild().getNodeValue());
    }
    
    nll = ((Element)m).getElementsByTagName("allowedassociationtypesmodel");
    //DefaultListModel model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      //System.out.println(n.getFirstChild().getNodeValue());
      //model.addElement(n.getFirstChild().getNodeValue());
      allowedAssociationTypesModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setAllowedElementsModel(model);

    nll = ((Element)m).getElementsByTagName("allowedVisualEventHandlersModel");
    //model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      allowedVisualEventHandlersModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setallowedVisualHandlersModel(model);
    
    nll = ((Element)m).getElementsByTagName("allowedVisualUserHandlersModel");
    //model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      allowedVisualUserHandlersModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setallowedVisualHandlersModel(model);

    nll = ((Element)m).getElementsByTagName("availableVisualEventHandlersModel");
    availableVisualEventHandlersModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableVisualEventHandlersModel.addElement(n.getFirstChild().getNodeValue());
    }
    
    nll = ((Element)m).getElementsByTagName("availableVisualUserHandlersModel");
    availableVisualUserHandlersModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableVisualUserHandlersModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setavailableVisualHandlersModel(model);

    nll = ((Element)m).getElementsByTagName("availableentitytypesmodel");
    availableEntityTypesModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableEntityTypesModel.addElement(n.getFirstChild().getNodeValue());
    }
    
    nll = ((Element)m).getElementsByTagName("availableassociationtypesmodel");
    availableAssociationTypesModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableAssociationTypesModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setAvailableElementsModel(model);

    nll = ((Element)m).getElementsByTagName("availableshapesmodel");
    availableShapesModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableShapesModel.addElement(n.getFirstChild().getNodeValue());
    }
    
    nll = ((Element)m).getElementsByTagName("availableconnectorsmodel");
    availableConnectorsModel.removeAllElements();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      availableConnectorsModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setAvailableIconsModel(model);

    nll = ((Element)m).getElementsByTagName("entitytypeandshapemappingmodel");
    //model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      entityTypeAndShapeMappingModel.addElement(n.getFirstChild().getNodeValue());
    }
    
    nll = ((Element)m).getElementsByTagName("associationtypeandconnectormappingmodel");
    //model = new DefaultListModel();
    for(int i = 0; i < nll.getLength(); i++){
      Node n = nll.item(i);
      associationTypeAndConnectorMappingModel.addElement(n.getFirstChild().getNodeValue());
    }
    //setElementAndIconMappingModel(model);
    ////////////////////////////////////////////////////////////////////////////////////////
    nll = ((Element)m).getElementsByTagName("propertymappingforentitytypeandshape");
    for(int j = 0; j < nll.getLength(); j++){
      Node k = nll.item(j);
      NodeList nlnl = ((Element)k).getElementsByTagName("key");
      Node b = nlnl.item(0);
      String s = b.getFirstChild().getNodeValue();
      //System.out.println("888888888888888888888888888 s is " + s);
      String modelName = s.substring(0, s.indexOf(":"));
      String iconName = s.substring(s.indexOf(":")+1);
      nlnl = ((Element)k).getElementsByTagName("value");
      if((project.getRegisteredShapes().contains(iconName)&&project.getRegisteredEntityTypeObjects().containsKey(modelName))){
        PropertyMappingPanel pmp = new PropertyMappingPanel(project, modelName, iconName);
        nameAndPanelMapping.put(s, pmp);
        //System.out.println("dddddddddddd "+s);
        for(int i = 0; i < nlnl.getLength(); i++){
          Node n = nlnl.item(i);
          String temp = n.getFirstChild().getNodeValue();
          String temp1 = temp.substring(0, temp.indexOf(":"));
          String temp2 = temp.substring(temp.indexOf(":")+1);
          pmp.restore(Integer.parseInt(temp1), Integer.parseInt(temp2));
        }
      }
      else{
        project.getPounamu().displayMessage(modelName+" or "+iconName+" not registered!");
        break;
      }
    }
    nll = ((Element)m).getElementsByTagName("propertymappingforassociationtypeandconnector");
    for(int j = 0; j < nll.getLength(); j++){
      Node k = nll.item(j);
      NodeList nlnl = ((Element)k).getElementsByTagName("key");
      Node b = nlnl.item(0);
      String s = b.getFirstChild().getNodeValue();
      //System.out.println("888888888888888888888888888 s is " + s);
      String modelName = s.substring(0, s.indexOf(":"));
      String iconName = s.substring(s.indexOf(":")+1);
      nlnl = ((Element)k).getElementsByTagName("value");
      if((project.getRegisteredConnectors().contains(iconName)&&project.getRegisteredAssociationTypeObjects().containsKey(modelName))){
        PropertyMappingPanel pmp = new PropertyMappingPanel(project, modelName, iconName);
        nameAndPanelMapping.put(s, pmp);
        //System.out.println("dddddddddddd "+s);
        for(int i = 0; i < nlnl.getLength(); i++){
          Node n = nlnl.item(i);
          String temp = n.getFirstChild().getNodeValue();
          String temp1 = temp.substring(0, temp.indexOf(":"));
          String temp2 = temp.substring(temp.indexOf(":")+1);
          pmp.restore(Integer.parseInt(temp1), Integer.parseInt(temp2));
        }
      }
      else{
        project.getPounamu().displayMessage(modelName+" or "+iconName+" not registered!");
        break;
      }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////
    nll = ((Element)m).getElementsByTagName("selectedindexforassociationtypeandconnector");
    if(nll != null){
      if(nll.item(0) != null){
        Node e = nll.item(0);
        if(e.getFirstChild()!=null){
          int in = Integer.parseInt(e.getFirstChild().getNodeValue());
          associationTypeAndConnectorMappingList2.setSelectedIndex(in);
        }
      }
    }
    nll = ((Element)m).getElementsByTagName("selectedindexforentitytypeandshape");
    if(nll != null){
      if(nll.item(0) != null){
        Node e = nll.item(0);
        if(e.getFirstChild()!=null){
          int in = Integer.parseInt(e.getFirstChild().getNodeValue());
          entityTypeAndShapeMappingList2.setSelectedIndex(in);
        }
      }
    }

  }
}