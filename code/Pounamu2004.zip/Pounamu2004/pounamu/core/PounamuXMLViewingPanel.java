/*
 * @(#)PounamuXMLViewingPanel.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.IOException;
//import pounamu.gui.icon.*;
import java.awt.print.*;

/**
 * Title: PounamuXMLViewingPanel
 * Description:  The panel which will be used to display xml files in a elegent way
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class PounamuXMLViewingPanel extends JTextPane implements Printable{

  String xml = ""; //xml file as a string
  String temp = ""; //hold spaces or "\n"s before "<"
  Document doc = this.getDocument();

  /**
   * constructor, styles will initial
   */
  public PounamuXMLViewingPanel(){
    super();
    initStyles();
  }

  /**
   * print the contents in this panel
   * @param g the Griphics instance
   * @param pf the PageFormat instace
   * @param pi a int
   * @return Printable.PAGE_EXISTS if print successful
   * @throws PrinterException
   */
  public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
        if (pi >= 1) {
            return Printable.NO_SUCH_PAGE;
	}
	print(g);
        //printChildren(g);
        return Printable.PAGE_EXISTS;
    }

  /**
   * initial two basi styles, one for keywords another for normal text
   */
  public void initStyles(){ //initial two styles: one for <tags>, another one for text
    Style def = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
    Style tag = this.addStyle("tag", def);
    StyleConstants.setForeground(tag, Color.magenta);//tags will be red
    Style text = this.addStyle("text", def);
    StyleConstants.setForeground(text, new Color(0, 0, 255));//values will be blue
  }

  /**
   * display the xml file in this panel
   * @param xml the string to be displayed
   */
  public void setXML(String xml){
    if(xml == null|| xml.equals("")) //if empty, do nothing
      return;
    setText(""); //clear up the panel before set xml
    this.xml = xml;
    temp = ""; //xml will start with "<"
    printOutXML();
  }

  /**
   * display the xml contents into this panel
   */

  public void printOutXML(){
    while((!xml.equals("")&&xml!=null)){//if empty, do nothing
      if(xml.startsWith("<")){//start with "<"
        String cell = temp+xml.substring(0, xml.indexOf(">")+1);//get "<....>" and the spaces or "\n"s hold in temp
        temp = ""; //no space or "\n" between ">" and value string
        try{
          doc.insertString(doc.getLength(), cell, this.getStyle("tag"));//print out this <tag> in red
        }
        catch (BadLocationException ble) {
          System.err.println("Couldn't insert initial text.");
          //pounamu.displayMessage("Exception in class PounamuXMLViewingPanel "+ble.toString());
        }
        xml = xml.substring(xml.indexOf(">")+1, xml.length());//"<....> removed from the xml string
      }
      else if(xml.startsWith(" ")){//start with a space
        xml = xml.substring(1, xml.length());//"the first space removed from the xml string, temp add a space
        temp = temp + " ";
      }
      else if(xml.startsWith("\n")){//start with a space
        xml = xml.substring(1, xml.length());//"the first "\n" removed from the xml string, temp add a space
        temp = temp + "\n";
      }
      else{
        String cell = xml.substring(0, xml.indexOf("<"));
        temp = "";
        try{
          doc.insertString(doc.getLength(), cell, this.getStyle("text"));
        }
        catch (BadLocationException ble) {
          //pounamu.displayMessage("Exception in class PounamuXMLViewingPanel "+ble.toString());
          System.err.println("Couldn't insert initial text.");
        }
        xml = xml.substring(xml.indexOf("<"), xml.length());
      }
    }
  }
  /*public void printOutXML(){
    if(xml.equals("")||xml==null)//if empty, do nothing
      return;
    if(xml.startsWith("<")){//start with "<"
      String cell = temp+xml.substring(0, xml.indexOf(">")+1);//get "<....>" and the spaces or "\n"s hold in temp
      temp = ""; //no space or "\n" between ">" and value string
      try{
        doc.insertString(doc.getLength(), cell, this.getStyle("tag"));//print out this <tag> in red
      }
      catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
      }
      xml = xml.substring(xml.indexOf(">")+1, xml.length());//"<....> removed from the xml string
      printOutXML();
    }
    else if(xml.startsWith(" ")){//start with a space
      xml = xml.substring(1, xml.length());//"the first space removed from the xml string, temp add a space
      temp = temp + " ";
      printOutXML();
    }
    else if(xml.startsWith("\n")){//start with a space
      xml = xml.substring(1, xml.length());//"the first "\n" removed from the xml string, temp add a space
      temp = temp + "\n";
      printOutXML();
    }
    else{
      String cell = xml.substring(0, xml.indexOf("<"));
      temp = "";
      try{
        doc.insertString(doc.getLength(), cell, this.getStyle("text"));
      }
      catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
      }
      xml = xml.substring(xml.indexOf("<"), xml.length());
      printOutXML();
    }*/
  }
 /* public void changeToStringArray(String xml, String temp, Vector v){

    if(xml == null|| xml.equals("")) //if empty, return
      return;
    if(xml.startsWith("<")){//look for "<"
      String cell = temp+xml.substring(0, xml.indexOf(">")+1);
      v.add(cell);
      changeToStringArray(xml.substring(xml.indexOf(">")+1, xml.length()), "", v);
    }
    else if(xml.startsWith(" ")){
      if(xml.length()<1)
        return;
      changeToStringArray(xml.substring(1, xml.length()), temp+" ", v);
    }
    else if(xml.startsWith("\n")){
      if(xml.length()==1)
        return;
      changeToStringArray(xml.substring(1, xml.length()), temp+"\n", v);
    }
    else{
      if(xml.indexOf("<")<0)
        return;
      String cell = xml.substring(0, xml.indexOf("<"));
      v.add(cell);
      changeToStringArray(xml.substring(xml.indexOf("<"), xml.length()), "", v);
    }
  }

  public void setXML(String xml){
    this.setText("");
    Vector v = new Vector();
    changeToStringArray(xml, "", v);
    String[] initString = new String[v.size()];
    String[] initStyles = new String[v.size()];
    for(int i = 0; i < v.size(); i++){
      initString[i] = (String)v.elementAt(i);
      if(initString[i].endsWith(">"))
        initStyles[i] = "flags";
      else
        initStyles[i] = "text";
    }
    Document doc = this.getDocument();
    try {
      for (int i=0; i < initString.length; i++){
        doc.insertString(doc.getLength(), initString[i], this.getStyle(initStyles[i]));
      }
    }
    catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
    }
  }*/



