/*
 * @(#)ConsolePanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.awt.*;


/**
 * Title: ConsolePanel
 * Description:  A tabbed panel to hold all information panels like todo, undo list etc
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ConsolePanel extends JTabbedPane{
  Pounamu pounamu = null;
  MessagePanel mp = new MessagePanel();
  UndoListPanel ulp = new UndoListPanel();
  RedoListPanel rlp = new RedoListPanel();
  /**
   * constructor
   * @param pounamu the tool which use this tabbed panel
   */
  public ConsolePanel(Pounamu pounamu){
    this.pounamu = pounamu;
    this.add(mp, "general", 0);
    this.add(ulp, "undo list", 1);
    this.add(rlp, "redo list", 2);
  }

  /**
   * set up models for both undo list panel and redo list panel
   * @param undoModel the undo model
   * @param redoModel the redo model
   */
  public void setListModel(PounamuStack undoModel, PounamuStack redoModel){
    setUndoListModelForUndoListPanel(undoModel);
    setRedoListModelForUndoListPanel(redoModel);
    setUndoListModelForRedoListPanel(undoModel);
    setRedoListModelForRedoListPanel(redoModel);
  }

  /**
   * to set the undo list model for undo list
   * @param model the PounamuStack to be set to the undo list
   */
  public void setUndoListModelForUndoListPanel(PounamuStack model){
    ulp.setUndoListModelForUndoListPanel(model);
  }

  /**
   * to set the redo list model for undo list
   * @param model the PounamuStack to be set to the redo list
   */
  public void setRedoListModelForUndoListPanel(PounamuStack model){
    ulp.setRedoListModelForUndoListPanel(model);
  }

   /**
   * to set the undo list model for redo list
   * @param model the PounamuStack to be set to the undo list
   */
  public void setUndoListModelForRedoListPanel(PounamuStack model){
    rlp.setUndoListModelForRedoListPanel(model);
  }

  /**
   * to set the redo list model for redo list
   * @param model the PounamuStack to be set to the redo list
   */
  public void setRedoListModelForRedoListPanel(PounamuStack model){
    rlp.setRedoListModelForRedoListPanel(model);
  }

  /**
   * display any runtime messages or exceptions
   * @param info the information to be shown
   */
  public void displayMessage(String info){
    mp.displayMessage(info);
  }
}

