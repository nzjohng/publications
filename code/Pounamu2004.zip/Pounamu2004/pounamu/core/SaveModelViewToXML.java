/*
 * @(#)SaveModelViewToXML.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.io.*;
import java.awt.*;
import javax.swing.border.*;
import pounamu.visualcomp.*;
import pounamu.data.*;
import java.lang.reflect.*;
import java.util.*;

/**
 * Title: SaveModelViewToXML
 * Description:  save the modelling view into a XML file
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class SaveModelViewToXML{

  ModellerPanel panel = null;
  Object target = null;
  final static String space = "         ";
  //Vector shapes = new Vector();
  //Vector connectors = new Vector();
  StringBuffer buf = null;
  PounamuView view = null;
  String viewType = null;
  String outputPath = null;
  String fileSeparator = null;
 /**
  * constructor
  * @param panel the panel contains the modelling view
  */
  public SaveModelViewToXML(ModellerPanel panel){
    this.panel = panel;
    fileSeparator = System.getProperty("file.separator");
    //this.shapes = panel.getShapes();
    //this.connectors = panel.getConnectors();
    this.view = panel.getView();
    this.viewType = view.getType();
    this.outputPath = panel.getProject().getLocation();
  }

  /**
   * generate XML file
   * @return the generated XML file
   */
  public String getXML(){
    buf = new StringBuffer (400000);
    if(viewType.equals("metamodelview"))
      buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE view SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"view.dtd\">\n");
    else
      buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE view SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"view.dtd\">\n");
    buf.append ("<view>\n");
    buf.append (space+"<viewname>"+view.getName()+"</viewname>\n");
    buf.append (space+"<viewtype>"+view.getType()+"</viewtype>\n");
    //get all icons in this model panel
    Component[] com = panel.getComponents();
    //go through this array
    for(int i = 0; i < com.length; i++){
        //when the icon is a pounamu panel (shape)
        if(com[i] instanceof PounamuPanel){
          getXMLForAShape((PounamuPanel)com[i], buf, i);
        }
        //when the icon is a pounamu connector 
        else if(com[i] instanceof PounamuConnector){
          getXMLForAConnector((PounamuConnector)com[i], buf, i);
        }
     }
    buf.append ("</view>");
    return buf.toString();
  }
  
  private void getXMLForAShape(PounamuPanel basePanel, StringBuffer buf, int i){
      PounamuShape shape = basePanel.getPounamuShape();
      buf.append(space+"<shape>\n");
      if(viewType.equals("metamodelview")){
        PounamuMetaModelElement pmme = (PounamuMetaModelElement)shape.getRelatedObject();
        if(pmme.getType().equals("entitytype")){
          pmme.save(outputPath+fileSeparator+"metamodel"+fileSeparator+"entitytypes"+fileSeparator+""+pmme.getName()+".xml");
        }
        else if (pmme.getType().equals("associationtype")){
          pmme.save(outputPath+fileSeparator+"metamodel"+fileSeparator+"associationtypes"+fileSeparator+""+pmme.getName()+".xml");
        }
        else{}
        //System.out.println("pmme type is "+pmme.getType()+" in class SaveModelViewToXML");
        buf.append(space+space+"<name>");
        buf.append(pmme.getName());
        buf.append("</name>\n");
        if(pmme.getType().equals("entitytype")){
          buf.append(space+space+"<type>");
          buf.append("entitytype");
          buf.append("</type>\n");
        }
        else if (pmme.getType().equals("associationtype")){
          buf.append(space+space+"<type>");
          buf.append("associationtype");
          buf.append("</type>\n");
        }
        else{}
      }
      else{
        PounamuModelElement pme = (PounamuModelElement)shape.getRelatedObject();
        //pme.save(outputPath+""+fileSeparator+"entity_objects"+fileSeparator+""+pme.getType()+""+fileSeparator+""+pme.getName()+".xml");
        buf.append(space+space+"<name>");
        buf.append(pme.getName());
        buf.append("</name>\n");
        buf.append(space+space+"<type>");
        buf.append(pme.getType());
        buf.append("</type>\n");
      }
      buf.append(space+space+"<id>");
      buf.append("shape"+i);
      buf.append("</id>\n");
      buf.append(space+space+"<rootid>");
      buf.append(shape.getRootID());
      buf.append("</rootid>\n");
      buf.append(space+space+"<objectid>");
      buf.append(shape.getObjectID());
      buf.append("</objectid>\n");
      
      buf.append(space+space+"<iconname>");
      buf.append(shape.getName());
      buf.append("</iconname>\n");
      buf.append(space+space+"<icontype>");
      buf.append(shape.getType());
      buf.append("</icontype>\n");
      buf.append(space+space+"<basex>");
      buf.append(basePanel.getX());
      buf.append("</basex>\n");
      buf.append(space+space+"<basey>");
      buf.append(basePanel.getY());
      buf.append("</basey>\n");
      buf.append(space+space+"<width>");
      buf.append(basePanel.getWidth());
      buf.append("</width>\n");
      buf.append(space+space+"<height>");
      buf.append(basePanel.getHeight());
      buf.append("</height>\n");
      String[] propertyNames = shape.getExportedPropertyNames();
      String[] propertyTypes = shape.getExportedPropertyTypes();
      String[] componentPaths = shape.getExportedComponentPath();
      String[] propertyOldNames = shape.getExportedPropertyOldNames();
      for (int j = 0; j < propertyNames.length; j++){
        try{
          buf.append(space+space+"<property>\n");
          buf.append(space+space+space+"<propertyname>");
          buf.append(propertyNames[j]);
          buf.append("</propertyname>\n");
          buf.append(space+space+space+"<propertytype>");
          buf.append(propertyTypes[j]);
          buf.append("</propertytype>\n");
          buf.append(space+space+space+"<propertypath>");
          buf.append(componentPaths[j]);
          buf.append("</propertypath>\n");
          buf.append(space+space+space+"<propertyoldname>");
          buf.append(propertyOldNames[j]);
          buf.append("</propertyoldname>\n");
          Object comp = shape.pathComponentMapping.get(componentPaths[j]);
          savePropertyValues(propertyNames[j], propertyTypes[j], propertyOldNames[j], comp);
          buf.append(space+space+"</property>\n");
        }
        catch(Exception e){
          //pounamu.displayMessage("Exception in class SaveModelViewToXML "+e.toString());
          System.out.println(e.toString());
        }
      }
      buf.append(space+"</shape>\n");
    }
  
  private void getXMLForAConnector(PounamuConnector connector, StringBuffer buf, int i){
    
      buf.append(space+"<connector>\n");
      if(viewType.equals("metamodelview")){
        PounamuMetaModelElement pmme = (PounamuMetaModelElement)connector.getRelatedObject();
        pmme.save(outputPath+fileSeparator+"metamodel"+fileSeparator+"associationtypes"+fileSeparator+""+pmme.getName()+".xml");
        buf.append(space+space+"<name>");
        buf.append(pmme.getName());
        buf.append("</name>\n");
      }
      else{
        PounamuModelElement pme = (PounamuModelElement)connector.getRelatedObject();
        //pme.save(outputPath+fileSeparator+"association_objects"+fileSeparator+""+pme.getType()+""+fileSeparator+""+pme.getName()+".xml");
        buf.append(space+space+"<name>");
        buf.append(pme.getName());
        buf.append("</name>\n");
        buf.append(space+space+"<type>");
        buf.append(pme.getType());
        buf.append("</type>\n");
      }
      //buf.append(space+"<connector>\n");
      buf.append(space+space+"<id>");
      buf.append("connector"+i);
      buf.append("</id>\n");
      buf.append(space+space+"<rootid>");
      buf.append(connector.getRootID());
      buf.append("</rootid>\n");
      buf.append(space+space+"<objectid>");
      buf.append(connector.getObjectID());
      buf.append("</objectid>\n");      
      buf.append(space+space+"<iconname>");
      buf.append(connector.getName());
      buf.append("</iconname>\n");
      buf.append(space+space+"<icontype>");
      buf.append(connector.getType());
      buf.append("</icontype>\n");
      PounamuHandle handler = connector.getStartHandler();
      Component[] com = panel.getComponents();
      //go through this array
      for(int j = 0; j < com.length; j++){
        //when the icon is a pounamu panel (shape)
        if(com[j] instanceof PounamuPanel){
          PounamuHandle[] handlers = ((PounamuPanel)com[j]).getHandlers();
          for(int in = 0; in < handlers.length; in++){
            if(handlers[in] == handler){
              buf.append(space+space+"<startshape>shape"+j+"</startshape>\n");
              buf.append(space+space+"<starthandler>"+in+"</starthandler>\n");
              break;
            }
          }
        }
      }
      handler = connector.getEndHandler();
      //com = panel.getComponents();
      //go through this array
      for(int k = 0; k < com.length; k++){
        //when the icon is a pounamu panel (shape)
        if(com[k] instanceof PounamuPanel){
          PounamuHandle[] handlers = ((PounamuPanel)com[k]).getHandlers();
          for(int in = 0; in < handlers.length; in++){
            if(handlers[in] == handler){
              buf.append(space+space+"<endshape>shape"+k+"</endshape>\n");
              buf.append(space+space+"<endhandler>"+in+"</endhandler>\n");
              break;
            }
          }
        }
      }
      String[] propertyNames = connector.getExportedPropertyNames();
      String[] propertyTypes = connector.getExportedPropertyTypes();
      String[] componentPaths = connector.getExportedComponentPath();
      String[] propertyOldNames = connector.getExportedPropertyOldNames();
      for (int j = 0; j < propertyNames.length; j++){
        try{
          buf.append(space+space+"<property>\n");
          buf.append(space+space+space+"<propertyname>");
          buf.append(propertyNames[j]);
          buf.append("</propertyname>\n");
          buf.append(space+space+space+"<propertytype>");
          buf.append(propertyTypes[j]);
          buf.append("</propertytype>\n");
          buf.append(space+space+space+"<propertypath>");
          buf.append(componentPaths[j]);
          buf.append("</propertypath>\n");
          buf.append(space+space+space+"<propertyoldname>");
          buf.append(propertyOldNames[j]);
          buf.append("</propertyoldname>\n");
          savePropertyValues(propertyNames[j], propertyTypes[j], propertyOldNames[j], connector);
          buf.append(space+space+"</property>\n");
        }
        catch(Exception e){
          //pounamu.displayMessage("Exception in class SaveModelViewToXML "+e.toString());
          System.out.println(e.toString());
        }
      }
      buf.append(space+"</connector>\n");
    }
  /*  buf.append ("</view>");
    return buf.toString();
  }*/

  /**
   * save a property into XML file
   * @param propertyName the name of this property
   * @param type the type of this property
   * @param propertyOldName te old name of this property
   * @param comp the object which has this property
   */
  private void savePropertyValues(String propertyName, String type, String propertyOldName, Object comp){
    String methodName = "";
    Class c = comp.getClass();
    if(type.equals("boolean"))
      methodName = "is"+capitalizeFirstLetter(propertyOldName);
    else
      methodName = "get"+capitalizeFirstLetter(propertyOldName);
    try{
      buf.append(space+space+space+"<propertyvalue>\n");
      Method m = c.getMethod(methodName, new Class[]{});
      Object value = m.invoke(comp, new Object[]{});
      if(type.equals("int"))
        saveIntValue(((Integer)value).intValue(), space+space+space+space);
      else if(type.equals("boolean"))
        saveBooleanValue(((Boolean)value).booleanValue(), space+space+space+space);
      else if(type.equals("Font"))
        saveFontValue((Font)value, space+space+space+space);
      else if(type.equals("Border"))
        saveBorderValue((Border)value, space+space+space+space);
      else if(type.equals("Color"))
        saveColorValue((Color)value, space+space+space+space);
      else if(type.equals("HorizontalAlignment"))
        saveIntValue(((Integer)value).intValue(), space+space+space+space);
      else if(type.equals("VerticalAlignment"))
        saveIntValue(((Integer)value).intValue(), space+space+space+space);
      else if(type.equals("LayoutParameters"))
        saveLayoutValue((LayoutManager)value, space+space+space+space);
      else if(type.equals("MultiLinesText"))
        saveMultiLinesTextValue((Vector)value, space+space+space+space);
      else if(type.equals("GridBagConstraints"))
	    saveGridBagConstraintsValue((GridBagConstraints)value, space+space+space+space);
	  else if(type.equals("BasicStroke"))
	    saveBasicStrokeValue((BasicStroke)value, space+space+space+space);
	  else if(type.equals("Insets"))
	  	saveInsetsValue((Insets)value, space+space+space+space);
	  else if(type.equals("Location"))
	  	saveLocationValue((Point)value, space+space+space+space);
	  else if(type.equals("Size"))
        saveSizeValue((Dimension)value, space+space+space+space);
      else
        saveStringValue((String)value, space+space+space+space);
      buf.append(space+space+space+"</propertyvalue>\n");
    }
    catch(Exception e){
      panel.getPounamu().displayMessage(e.toString());
      Toolkit.getDefaultToolkit().beep();
    }
  }

  /**
   * save a value which is a int
   * @param i the int
   * @param newSpace the space reserved for this line
   */
  private void saveIntValue(int i, String newSpace){
    buf.append(newSpace+"<simplevalue>"+i+"</simplevalue>\n");
  }

  /**
   * save a value which is a boolean
   * @param b the boolean
   * @param newSpace the space reserved for this line
   */
  private void saveBooleanValue(boolean b, String newSpace){
    if(b==true)
      buf.append(newSpace+"<simplevalue>true</simplevalue>\n");
    else
      buf.append(newSpace+"<simplevalue>false</simplevalue>\n");
  }

  /**
   * save a value which is a Font
   * @param f the Font
   * @param newSpace the space reserved for this line
   */
  private void saveFontValue(Font f, String newSpace){
    buf.append(newSpace+"<family>"+f.getFamily()+"</family>\n");
    buf.append(newSpace+"<style>"+f.getStyle()+"</style>\n");
    buf.append(newSpace+"<size>"+f.getSize()+"</size>\n");
  }

  /**
   * save a value which is a Border
   * @param b the Border
   * @param newSpace the space reserved for this line
   */
  private void saveBorderValue(Border b, String newSpace){
    if(b instanceof EmptyBorder)
      buf.append(newSpace+"<simplevalue>EmptyBorder</simplevalue>\n");
    else if(b instanceof LineBorder)
      buf.append(newSpace+"<simplevalue>LineBorder</simplevalue>\n");
    else if(b instanceof EtchedBorder)
      buf.append(newSpace+"<simplevalue>EtchedBorder</simplevalue>\n");
    else if(b instanceof BevelBorder){
      if(((BevelBorder)b).getBevelType()==BevelBorder.RAISED)
        buf.append(newSpace+"<simplevalue>SharedRaisedBevel</simplevalue>\n");
      else
        buf.append(newSpace+"<simplevalue>SharedLoweredBevel</simplevalue>\n");
    }
    else {}
  }

  /**
   * save a value which is a Color
   * @param c the Color
   * @param newSpace the space reserved for this line
   */
  private void saveColorValue(Color c, String newSpace){
    buf.append(newSpace+"<red>"+c.getRed()+"</red>\n");
    buf.append(newSpace+"<green>"+c.getGreen()+"</green>\n");
    buf.append(newSpace+"<blue>"+c.getBlue()+"</blue>\n");
  }

  /**
   * save a value which is a LayoutManager
   * @param l the LayoutManager
   * @param newSpace the space reserved for this line
   */
  private void saveLayoutValue(LayoutManager l, String newSpace){
    if(l == null)
      buf.append(newSpace+"<layouttype>null</layouttype>\n");
    else if(l instanceof FlowLayout){
      buf.append(newSpace+"<layouttype>FlowLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((FlowLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((FlowLayout)l).getHgap()+"</hgap>\n");
      buf.append(newSpace+"<alignment>"+((FlowLayout)l).getAlignment()+"</alignment>\n");
    }
    else if(l instanceof VerticalFlowLayout){
      buf.append(newSpace+"<layouttype>VerticalFlowLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((VerticalFlowLayout)l).getVGap()+"</vgap>\n");
    }
    else if(l instanceof BorderLayout){
      buf.append(newSpace+"<layouttype>BorderLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((BorderLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((BorderLayout)l).getHgap()+"</hgap>\n");
    }
    else if(l instanceof GridLayout){
      buf.append(newSpace+"<layouttype>GridLayout</layouttype>\n");
      buf.append(newSpace+"<vgap>"+((GridLayout)l).getVgap()+"</vgap>\n");
      buf.append(newSpace+"<hgap>"+((GridLayout)l).getHgap()+"</hgap>\n");
      buf.append(newSpace+"<cols>"+((GridLayout)l).getColumns()+"</cols>\n");
      buf.append(newSpace+"<rows>"+((GridLayout)l).getRows()+"</rows>\n");
    }
    else
      buf.append(newSpace+"<layouttype>GridBagLayout</layouttype>\n");
  }

  /**
   * save a value which is a DefaultListModel
   * @param d the DefaultListModel
   * @param newSpace the space reserved for this line
   */
  private void saveMultiLinesTextValue(Vector v, String newSpace){
    for(int i = 0; i < v.size(); i++){
      buf.append(newSpace+"<item>");
      buf.append((String)v.elementAt(i));
      buf.append("</item>\n");
    }
  }

  /**
   * save a value which is a BasicStroke
   * @param basicStroke the BasicStroke
   * @param newSpace the space reserved for this line
   */
  private void saveBasicStrokeValue(BasicStroke basicStroke, String newSpace){
    buf.append(newSpace+"<linewidth>");
    buf.append(basicStroke.getLineWidth()+"");
    buf.append("</linewidth>\n");
    buf.append(newSpace+"<endcaps>");
    buf.append(basicStroke.getEndCap()+"");
    buf.append("</endcaps>\n");
    buf.append(newSpace+"<linejoints>");
    buf.append(basicStroke.getLineJoin()+"");
    buf.append("</linejoints>\n");
    float[] f = basicStroke.getDashArray();
    for(int i = 0; i < f.length; i++){
      buf.append(newSpace+"<dasharray"+i+">");
      buf.append(f[i]+"");
      buf.append("</dasharray"+i+">\n");
    }
    buf.append(newSpace+"<miterlimit>");
    buf.append(basicStroke.getMiterLimit()+"");
    buf.append("</miterlimit>\n");
    buf.append(newSpace+"<dashphase>");
    buf.append(basicStroke.getDashPhase()+"");
    buf.append("</dashphase>\n");
  }

  private void saveGridBagConstraintsValue(GridBagConstraints gc, String newSpace){
          buf.append(newSpace+"<gridx>"+gc.gridx+"</gridx>\n");
          buf.append(newSpace+"<gridy>"+gc.gridy+"</gridy>\n");
          buf.append(newSpace+"<gridwidth>"+gc.gridwidth+"</gridwidth>\n");
          buf.append(newSpace+"<gridheight>"+gc.gridheight+"</gridheight>\n");
          buf.append(newSpace+"<ipadx>"+gc.ipadx+"</ipadx>\n");
          buf.append(newSpace+"<ipady>"+gc.ipady+"</ipady>\n");
          buf.append(newSpace+"<weightx>"+gc.weightx+"</weightx>\n");
          buf.append(newSpace+"<weighty>"+gc.weighty+"</weighty>\n");
          buf.append(newSpace+"<insets_top>"+gc.insets.top+"</insets_top>\n");
          buf.append(newSpace+"<insets_bottom>"+gc.insets.bottom+"</insets_bottom>\n");
          buf.append(newSpace+"<insets_left>"+gc.insets.left+"</insets_left>\n");
          buf.append(newSpace+"<insets_right>"+gc.insets.right+"</insets_right>\n");
          buf.append(newSpace+"<fill>"+gc.fill+"</fill>\n");
          buf.append(newSpace+"<anchor>"+gc.anchor+"</anchor>\n");
    }

    private void saveInsetsValue(Insets insets, String newSpace){
          buf.append(newSpace+"<insets_top>"+insets.top+"</insets_top>\n");
          buf.append(newSpace+"<insets_bottom>"+insets.bottom+"</insets_bottom>\n");
          buf.append(newSpace+"<insets_left>"+insets.left+"</insets_left>\n");
          buf.append(newSpace+"<insets_right>"+insets.right+"</insets_right>\n");
    }

    private void saveLocationValue(Point point, String newSpace){
          buf.append(newSpace+"<x>"+point.x+"</x>\n");
          buf.append(newSpace+"<y>"+point.y+"</y>\n");
    }

    private void saveSizeValue(Dimension dim, String newSpace){
          buf.append(newSpace+"<width>"+dim.width+"</width>\n");
          buf.append(newSpace+"<height>"+dim.height+"</height>\n");
    }


  /**
   * save a value which is a String
   * @param s the String
   * @param newSpace the space reserved for this line
   */
  private void saveStringValue(String s, String newSpace){
    buf.append(newSpace+"<simplevalue>"+s+"</simplevalue>\n");
  }

  /**
   * a help method to check if string array sa contains String s
   * @param sa the string array
   * @param s the string
   * @return the index of the string in the string array
   */
  private int contains(String[] sa, String s){
    for(int i = 0; i < sa.length; i++)
      if (sa[i].equals(s))
        return i;
    return -1;
  }

  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */

  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }
}