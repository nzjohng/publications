/*
 * PounamuUserTriggeringHandler.java
 *
 * Created on 5 August 2003, 10:05
 */

package pounamu.core;

/**
 *
 * @author  nzhu002
 */
public interface PounamuUserTriggeringHandler {
   
   public void execute();
    
}