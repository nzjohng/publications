/*
 * @(#)PounamuEventHandler.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import pounamu.event.*;
import pounamu.data.*;
import java.util.*;

/**
 * Title: PounamuEventHandler
 * Description:  the super class of all pounamu handler classes
 * Copyright:    Copyright (c) 2002
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuHandler implements PounamuUserPlugIn{
  
  /** 
   * type is a string varible which has only two values: 
   * "model handler": the handler will work for a model
   * "visual handler": the handler will work for a view
   */
  String type = null;
  String className = null;
  String   menuItemText = null;
  String description = null; 
  /**
   * enabled is a boolean which specify whether if the handler is in working state
   */
  boolean enabled = true;
  /**
   * respondingEvents is a vector holding all event names (String) this handler will respond to
   */
  Vector respondingEvents = new Vector();
  /**
   * pounamu is the instance of Pouanmu running this project
   */
  Pounamu pounamu = null;
  /**
   * manager is the instance of PounamuManagerPanel managing this project
   */
  PounamuManagerPanel manager = null;
  /**
   * project is the instance of the PounamuModelProject to which this handler will be registered
   */
  PounamuModelProject model = null;
  /**
   * tool is the pounamtToolProject instance which is used by thi project
   */
  PounamuToolProject tool = null;
  /**
   * view is a PounamuView instance to which a visual handler will be registered
   */
  PounamuView view = null;
  /**
   * panel is a PounamuModellerPanel instance which holds all user created objects
   */
  ModellerPanel panel = null;
  
  
  

  /**
   * an empty constructor
   */
  public PounamuHandler() {}

 
  /**
   * get the Pounamu working object
   * @return the Pounamu working object
   */
  public Pounamu getPounamu(){
    return pounamu;
  }

  public void setPounamu(Pounamu pounamu){
    this.pounamu = pounamu;
  }


  /**
   * get the tool used by this model model which uses this handler
   * @return the tool used by this model project which uses this handler
   */
  public PounamuToolProject getTool(){
    return tool;
  }
  
  public void setTool(PounamuToolProject tool){
    this.tool = tool;
  }

  /**
   * get the model project which uses this handler
   * @return the model model which uses this handler
   */
  public PounamuModelProject getModel(){
    return model;
  }
  
  public void setModel(PounamuModelProject model){
    this.model = model;
  }

  /**
   * get the manager panel of the Pounamu working object
   * @return the manager panel of the Pounamu working object
   */
  public PounamuManagerPanel getManager(){
    return manager;
  }
  
  public void setManager(PounamuManagerPanel manager){
    this.manager = manager;
  }
  
  public PounamuView getView(){
    return view;
  }
  
  public  void setView(PounamuView view){
    this.view = view;
  }
  
  public ModellerPanel getPanel(){
    return panel;
  }
  
  public void setPanel(ModellerPanel panel){
    this.panel = panel;
  }

  /**
   * a method all the pounamu classes should extend
   * @param pe the pounamu event this handler will received
   */
  ///public void eventReceived(PounamuEvent pe){
    //if(enabled == false)
     // return;
  //}
  /**
   * get the type of this handler
   * @return the type of this handler
   */
  public String getType(){
    return type;
  }
  
  public void setType(String type){
    this.type = type;
  }
  
  public String getClassName(){
    return className;
  }
  
  public void setClassName(String className){
    this.className = className;
  }
  
  public String getDescription(){
    return description;
  }
  
  public void setDescription(String description){
    this.description = description;
  }
  
  public boolean isEnabled(){
    return enabled;
  }
  
  public void setEnabled(boolean enabled){
    this.enabled = enabled;
  }
  
  public Vector getRespondingEvents(){
    return respondingEvents;
  }
  
  public void setRespondingEvents(Vector respondingEvents){
    this.respondingEvents = respondingEvents;
  }
  
  public void setMenuItemText(String menuItemText){
        this.menuItemText = menuItemText;
    }

  public String getMenuItemText(){
        return menuItemText;
    }
    
    
    
}