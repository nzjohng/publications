/*
 * @(#)MaintainFileSystem.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.io.*;
import javax.swing.*;
import pounamu.core.*;
import pounamu.data.*;

/**
 * Title: MaintainFileSystem
 * Description:  Compile a java file with the specified full name
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class MaintainFileSystem /*implements Runnable*/ {

   String fullPath = null;
   Pounamu pounamu = null;
   String type = null;
   String fileSeparator = null;

   /**
    * conatructor
    * @param fullName the full name opf he jave file
    * @param name the nale of the jave file
    */
   public MaintainFileSystem(String fullPath, Pounamu pounamu, String type) {
     this.fullPath = fullPath;
     this.pounamu = pounamu;
     this.type = type;
     fileSeparator = System.getProperty("file.separator");
   }

   /**
    * compile the java file into corresponding class file in the same folder
    */
   public void run() {
     try{
      String home = pounamu.getPounamuHome();
      Runtime runtime=Runtime.getRuntime();
      Process p = runtime.exec(home+fileSeparator+"nonjavafiles"+fileSeparator+type+".bat "+fullPath);;
      InputStream in = p.getErrorStream();
      int k;
      String information = "";
      while((k = in.read()) != -1){
         information = information + (char)k;
      }
      p.waitFor();
    }
    catch(IOException eeee){
      pounamu.displayMessage("IOException when "+ type + " in class MaintainFileSystem:" + eeee.getMessage());
    }
    catch(InterruptedException eee){
      pounamu.displayMessage("InterruptedException when "+ type + " in class MaintainFileSystem" + eee.getMessage());
    }
   }
}