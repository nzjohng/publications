/*
 * @(#)PounamuJavaCodeViewingPanel.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.IOException;
import pounamu.visualcomp.*;
import java.awt.print.*;

/**
 * Title: PounamuJavaCodeViewingPanel
 * Description:  A panel designed to display java files in a elegant way
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class PounamuJavaCodeViewingPanel extends JTextPane implements Printable{

  String javaCode = ""; //java Code as a string
  Document doc = this.getDocument();
  Vector keyWords = new Vector();

  /**
   * Constructor
   * 1) initial two basic styles
   * 2) define keywords which will be showed in a special style
   */
  public PounamuJavaCodeViewingPanel(){
    super();
    initStyles();
    keyWords.add("package");
    keyWords.add("interface");
    keyWords.add("class");
    keyWords.add("public");
    keyWords.add("static");
    keyWords.add("void");
    keyWords.add("super");
    keyWords.add("new");
    keyWords.add("extends");
    keyWords.add("implements");
    keyWords.add("import");
    keyWords.add("if");
    keyWords.add("else");
    keyWords.add("instanceof");
    keyWords.add("while");
    keyWords.add("try");
    keyWords.add("catch");
    keyWords.add("throws");
    keyWords.add("return");
    keyWords.add("true");
    keyWords.add("false");
    keyWords.add("int");
    keyWords.add("float");
    keyWords.add("double");
    keyWords.add("this");
    keyWords.add("null");
    keyWords.add("boolean");
    keyWords.add("char");
  }

  /**
   * print out the file displayed in this panel
   * @param g the graphics
   * @param pf the PageFormat
   * @param pi an int
   * @return Printable.PAGE_EXISTS if print successful
   */
  public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
        if (pi >= 1) {
            return Printable.NO_SUCH_PAGE;
	}
	print(g);
        return Printable.PAGE_EXISTS;
    }

  /**
   * initial two baisc styles
   */
  public void initStyles(){ //initial two styles: one for <tags>, another one for text
    Style def = StyleContext.getDefaultStyleContext().getStyle(StyleContext.DEFAULT_STYLE);
    Style keyWord = this.addStyle("keyWord", def);
    StyleConstants.setBold(keyWord, true);
    StyleConstants.setForeground(keyWord, Color.blue);//key words will be red
    Style text = this.addStyle("text", def);
  }

  /**
   * displaying the java code in this panel
   * @param javacode the code to be displayed
   */
  public void setJavaCode(String javaCode){
    if(javaCode == null|| javaCode.equals("")) //if empty, do nothing
      return;
    setText(""); //clear up the panel before set xml
    this.javaCode = javaCode;
    printOutJavaCode();
  }

  /**
   * displaying the java code
   */
  public void printOutJavaCode(){
    StringTokenizer st = new StringTokenizer(javaCode, " \"\n{.;()", true);
    while(st.hasMoreTokens()){//if empty, do nothing
      String cell = st.nextToken();
      try{
        if(isAKeyWord(cell))
          doc.insertString(doc.getLength(), cell, this.getStyle("keyWord"));
        else
          doc.insertString(doc.getLength(), cell, this.getStyle("text"));
      }
      catch (BadLocationException ble) {
          System.err.println("Couldn't insert initial text.");
      }
    }
  }

  /**
   * to check if the string s is a key word or not
   * @return true if  s is a keyword
   * @param s the string to be displayed
   */
  public boolean isAKeyWord(String s){
    return keyWords.contains(s);
  }

  /*public void printOutXML(){
    if(xml.equals("")||xml==null)//if empty, do nothing
      return;
    if(xml.startsWith("<")){//start with "<"
      String cell = temp+xml.substring(0, xml.indexOf(">")+1);//get "<....>" and the spaces or "\n"s hold in temp
      temp = ""; //no space or "\n" between ">" and value string
      try{
        doc.insertString(doc.getLength(), cell, this.getStyle("tag"));//print out this <tag> in red
      }
      catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
      }
      xml = xml.substring(xml.indexOf(">")+1, xml.length());//"<....> removed from the xml string
      printOutXML();
    }
    else if(xml.startsWith(" ")){//start with a space
      xml = xml.substring(1, xml.length());//"the first space removed from the xml string, temp add a space
      temp = temp + " ";
      printOutXML();
    }
    else if(xml.startsWith("\n")){//start with a space
      xml = xml.substring(1, xml.length());//"the first "\n" removed from the xml string, temp add a space
      temp = temp + "\n";
      printOutXML();
    }
    else{
      String cell = xml.substring(0, xml.indexOf("<"));
      temp = "";
      try{
        doc.insertString(doc.getLength(), cell, this.getStyle("text"));
      }
      catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
      }
      xml = xml.substring(xml.indexOf("<"), xml.length());
      printOutXML();
    }*/
  }
 /* public void changeToStringArray(String xml, String temp, Vector v){

    if(xml == null|| xml.equals("")) //if empty, return
      return;
    if(xml.startsWith("<")){//look for "<"
      String cell = temp+xml.substring(0, xml.indexOf(">")+1);
      v.add(cell);
      changeToStringArray(xml.substring(xml.indexOf(">")+1, xml.length()), "", v);
    }
    else if(xml.startsWith(" ")){
      if(xml.length()<1)
        return;
      changeToStringArray(xml.substring(1, xml.length()), temp+" ", v);
    }
    else if(xml.startsWith("\n")){
      if(xml.length()==1)
        return;
      changeToStringArray(xml.substring(1, xml.length()), temp+"\n", v);
    }
    else{
      if(xml.indexOf("<")<0)
        return;
      String cell = xml.substring(0, xml.indexOf("<"));
      v.add(cell);
      changeToStringArray(xml.substring(xml.indexOf("<"), xml.length()), "", v);
    }
  }

  public void setXML(String xml){
    this.setText("");
    Vector v = new Vector();
    changeToStringArray(xml, "", v);
    String[] initString = new String[v.size()];
    String[] initStyles = new String[v.size()];
    for(int i = 0; i < v.size(); i++){
      initString[i] = (String)v.elementAt(i);
      if(initString[i].endsWith(">"))
        initStyles[i] = "flags";
      else
        initStyles[i] = "text";
    }
    Document doc = this.getDocument();
    try {
      for (int i=0; i < initString.length; i++){
        doc.insertString(doc.getLength(), initString[i], this.getStyle(initStyles[i]));
      }
    }
    catch (BadLocationException ble) {
        System.err.println("Couldn't insert initial text.");
    }
  }*/



