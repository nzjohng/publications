/*
 * ToolIconPanel.java
 *
 * Created on 3 September 2003, 12:48
 */

package pounamu.core;

import javax.swing.*;
import javax.swing.tree.*; 
import java.awt.*;
import java.util.*;
import pounamu.visualcomp.*;
/**
 *
 * @author  nzhu002
 */
public class ToolIconPanel extends PounamuTabbedPane {
    
   
  Pounamu pounamu = null;
  PounamuManagerPanel manager = null;
  DefaultMutableTreeNode selectedNode = null;
  Vector toolButtons = null;
  //PounamuTabbedPane tab = new PounamuTabbedPane();
   /** Creates a new instance of ToolIconPanel */
  public ToolIconPanel (PounamuManagerPanel manager, Vector toolButtons){
    this.manager = manager;
    this.pounamu = manager.getPounamu();
    this.selectedNode = manager.getSelectedNode();
    this.toolButtons = toolButtons;
    
    this.setTabPlacement(JTabbedPane.BOTTOM);
    try{
      init();      
    }
    catch(Exception e){
      pounamu.displayMessage("Exception in class ToolIconPanel: " + e.toString());
    }
  }
  
  public void init(){
    if(toolButtons == null){
      //System.out.println("toolButton is null ");
      return;
    }
    //System.out.println("toolButton size is " + toolButtons.size());
    JPanel functionPanel = new JPanel();  
    functionPanel.setLayout(new VerticalFlowLayout(3));
    functionPanel.setSize(new Dimension(400, 740));    
    functionPanel.setBackground(Color.white);     
    JScrollPane jsp = new JScrollPane(functionPanel);
    JPanel entityPanel = new JPanel();     
    entityPanel.setSize(new Dimension(400, 740));    
    entityPanel.setLayout(new VerticalFlowLayout(3));
    entityPanel.setBackground(Color.white);     
    JScrollPane jsp0 = new JScrollPane(entityPanel);
    JPanel associationPanel = new JPanel();     
    associationPanel.setLayout(new VerticalFlowLayout(3));
    associationPanel.setSize(new Dimension(400, 740));    
    associationPanel.setBackground(Color.white);     
    JScrollPane jsp1 = new JScrollPane(associationPanel);
    
    for(int i = 0; i < toolButtons.size(); i++){
      //System.out.println("inside for loop " + i);
      if(toolButtons.get(i) != null){
        //System.out.println("inside if clause " );
        JButton button = (JButton)toolButtons.get(i);
        if(button.getToolTipText().startsWith("function:")){
          functionPanel.add(button);
        }
        else if(button.getToolTipText().startsWith("entity:")){
          entityPanel.add(button);
        }
        else{
          associationPanel.add(button);
        }
      }
    }
    if(functionPanel.getComponentCount() > 0)
    //System.out.println("what is wrong here");
       this.addTab("function", jsp);
    if(entityPanel.getComponentCount() > 0)
    //System.out.println("what is wrong here");
       this.addTab("entities", jsp0);
    if(associationPanel.getComponentCount() > 0)
    //System.out.println("what is wrong here");
       this.addTab("associations", jsp1);
    
  }
  
}
