/*
 * @(#)Configuration.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.*;
import pounamu.visualcomp.*;

/**
 * Title: Configuration
 * Description:  A dialog to be used to configure this tool Pounamu
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class Configuration extends JDialog {

  JPanel jPanel0 = new JPanel();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JPanel jPanel4 = new JPanel();
  JPanel jPanel5 = new JPanel();   
  JButton saveButton = new JButton("Ok");
  JLabel jLabel0 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JCheckBox nextTime = new JCheckBox();
  Pounamu pounamu = null;

  /**
   * construct a dialog which allow user to configure this tool
   * @param pounamu the Pounamu instance this dialog works for
   */
  public Configuration(Pounamu pounamu){
    super(pounamu, "Welcome", false);
    this.pounamu = pounamu;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {
    String welcome = "<html>Hi, <strong>" + System.getProperty("user.name")+"</strong>. Welcome to use Pounamu!";
    welcome = welcome + "<p><p>";
    welcome = welcome + "You are using <strong>jdk" + System.getProperty("java.version")+ "</strong> installed in <strong>" +System.getProperty("java.home")+"</strong> running on <strong>"+ System.getProperty("os.name")+" " +System.getProperty("os.version")+"</strong>. And<p> ";
    welcome = welcome + "your current working directory is <strong>" + System.getProperty("user.dir") + "</strong>, which is also the parent directory of pounamu home.<p>";
    welcome = welcome + "<p>";
    welcome = welcome + "Please set the path to your web browser if the path showed below is not true: " ;
    jLabel0.setText(welcome);
    
    welcome =           "<html>If you do not know how to use this tool, please click the help menu on the menu bar, you may<p>";
    welcome = welcome + "find a carefully designed tutorial and some useful information there.<p><p>";
    welcome = welcome + "Please make sure that, whenever you want to do something with pouanmu, you should firstly <p>";
    welcome = welcome + "select the object, which you're going to operate with, by clicking on the corresponding node<p>";
    welcome = welcome + "from the pounamu manager tree, and then choose one of the available function items from the <p>";
    welcome = welcome + "\"pounamu\" menu on the menu bar or the popup manu (by right clicking the manage tree panel)<p>";
    welcome = welcome + "to do what you like to do.</html>";
    jLabel2.setText(welcome);
    this.getContentPane().setLayout(new VerticalFlowLayout(2));
    jPanel0.add(jLabel0);
    jPanel2.add(jLabel2);
    jPanel4.add(nextTime);
    if(((String)pounamu.getProperties().get("nexttime")).equals("false"))
      nextTime.setSelected(false);
    else
      nextTime.setSelected(true);
    //System.out.println((String)pounamu.properties.get("nexttime"));
    jPanel4.add(new JLabel("<html><u><i>Do not show this dialog next time when start this tool.</u></i>"));
    jPanel5.add(saveButton);
    this.getContentPane().add(jPanel0);
    this.getContentPane().add(jPanel2);
    this.getContentPane().add(jPanel4);
    this.getContentPane().add(jPanel5);
    this.validate();
    this.pack();     
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        addProperties();
        try{
          String path = System.getProperty("user.dir")+System.getProperty("file.separator")+"pounamu"+System.getProperty("file.separator")+"nonjavafiles"+System.getProperty("file.separator")+"Configuration.txt";
          FileOutputStream fos = new FileOutputStream(path);
          pounamu.getProperties().store(fos, null);
        }
        catch(Exception ee) {
          ee.printStackTrace();
        }
        doCancel();
      }
    });
  }

  /**
   * add the selected property values to the properties
   */
  private void addProperties(){     
    if( nextTime.isSelected())
      pounamu.getProperties().put("nexttime", "true");
    else
      pounamu.getProperties().put("nexttime", "false");
  }

  /**
   * this dialog disappear when cancel button is clicked
   */
  private void doCancel(){
    this.dispose();
  }
}