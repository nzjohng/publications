/*
 * @(#)MessagePanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.awt.*;


/**
 * Title: MessagePanel
 * Description:  A panel to show any runtime message
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class MessagePanel extends JPanel{
  JEditorPane jp = new JEditorPane();
  JScrollPane jsp = new JScrollPane(jp);

  /**
   * constructor
   */
  public MessagePanel(){
    super();
    jp.setPreferredSize(new Dimension(1024, 1000));
    this.setLayout(new BorderLayout());
    this.add(jsp, BorderLayout.CENTER);
  }

  /**
   * display any runtime messages or exceptions
   * @param info the information to be shown
   */
  public void displayMessage(String info){
    String temp = jp.getText();
    jp.setText(temp+"\n"+info);
    jp.validate();
  }
}

