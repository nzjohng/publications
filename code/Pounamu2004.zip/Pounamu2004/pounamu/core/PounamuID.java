/*
 * @(#)PounamuID.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */
package pounamu.core;

/**
 * Title: PounamuID
 * Description:  A mechanizm to give each Pounamu Object an ID
 * Copyright:    Copyright (c) 2003
 * Company:      Auckland UniServices Limited
 * @author       Akhil Mehra
 * @version 1.0
 */

public class PounamuID {
    
    /* The root ID for this object */
    private String rootID = "";
    
    /* The current ID for this object */
    private String objectID = "";
    
    /* Initialize the class */
    public PounamuID() {
        String tempID = PounamuGenID.genID();
        rootID = tempID;
        objectID = tempID;
    }
    
    public PounamuID(String rootID1) {

        if( rootID1 != null && !rootID1.equals("") )
            this.rootID = rootID;
        else
            rootID1 = PounamuGenID.genID();
        
        this.objectID = PounamuGenID.genID();
    
    }
    
    /* Gets the rootID for this object */
    public String getRootID() {
        return rootID;
    }
    
    /* Sets the objectID for this object */
    public void setRootID(String ID) {
        
        if( rootID != null && !rootID.equals("") )
            rootID = ID;
        else
            rootID = PounamuGenID.genID();
        
    }
    
    /* Gets the objectID for this object */
    public String getObjectID() {
        return objectID;
    }
    
    /* Sets the objectID for this object */
    public void setObjectID(String ID) {
        objectID = ID;
    }
    
    
    
}