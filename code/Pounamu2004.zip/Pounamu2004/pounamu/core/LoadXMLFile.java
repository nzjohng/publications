/*
 * @(#)LoadXMLFile.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import java.io.File;
import java.io.IOException;
import org.w3c.dom.Document;
import org.w3c.dom.DOMException;

/**
 * Title: LoadXMLFile
 * Description:  used to parse a xml file into xml document
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class LoadXMLFile{

  File file = null;
  Document document;
  DocumentBuilderFactory factory;

  /**
   * constructor
   * @param file the xml file to be parsed
   */
  public LoadXMLFile(File file){
    this.file = file;
    factory = DocumentBuilderFactory.newInstance();
  }

  /**
   * parsing the xml file into xml document
   * @return the result xml document
   */
  public Document getDocument(){
    try {
      DocumentBuilder builder = factory.newDocumentBuilder();
      document = builder.parse(file);
      return document;
    }
    catch (SAXException sxe) {
      // Error generated during parsing)
      Exception  x = sxe;
      if (sxe.getException() != null)
        x = sxe.getException();
      x.printStackTrace();
    }
    catch (ParserConfigurationException pce) {
        // Parser with specified options can't be built
        pce.printStackTrace();
    }
    catch (IOException ioe) {
        // I/O error
        ioe.printStackTrace();
    }
    return null;
  }
}