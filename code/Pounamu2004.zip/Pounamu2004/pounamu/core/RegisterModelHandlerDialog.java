/*
 * @(#)NewToolProjectDialog.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import javax.swing.*;


/**
 * Title: NewToolProjectDialog
 * Description:  A dialog to be used to configure this tool Pounamu
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class RegisterModelHandlerDialog extends JDialog {

   
  JButton ok = new JButton("   OK   ");
  JButton cancel = new JButton("Cancel");
  Pounamu pounamu = null;
  PounamuToolProject tool = null;
  JCheckBox[] availableModelHandlers = null;
  Hashtable availableHash = null;
  Hashtable registeredHash = null;
  /**
   * construct a dialog which allow user to put in some imformation related to the project
   * @param pounamu the Pounamu instance this dialog works for
   */
  public RegisterModelHandlerDialog(PounamuToolProject tool){
    super(tool.getPounamu(), "Register model handlers dialog", true);
    this.tool = tool;
    this.pounamu = tool.getPounamu();
    //availableHash = tool.getRegisteredModelHandlers();
    //registeredHash = tool.getCurrentRegisteredModelHandlers();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {
      
    /*JPanel checkBoxPanel = new JPanel();
    checkBoxPanel.setLayout(new VerticalFlowLayout(4));
    checkBoxPanel.setBorder(BorderFactory.createTitledBorder("Please select handlers to be registered"));
    availableModelHandlers = new JCheckBox[availableHash.size()+2];
    availableModelHandlers[0] = new JCheckBox("ALL                                                                                      ");
    availableModelHandlers[1] = new JCheckBox("NONE                                                                                     ");
    checkBoxPanel.add(availableModelHandlers[0]);
    checkBoxPanel.add(availableModelHandlers[1]);
    Enumeration e = availableHash.keys();
    int k = 2;
    while(e.hasMoreElements()){
      availableModelHandlers[k] = new JCheckBox((String)e.nextElement());
      checkBoxPanel.add(availableModelHandlers[k]);
      k++;
    }
    if(registeredHash.size() == 0){
      availableModelHandlers[0].setSelected(false);
      availableModelHandlers[0].setEnabled(false);
      availableModelHandlers[1].setSelected(true);
      availableModelHandlers[1].setEnabled(true);
      for(int i = 2; i < availableModelHandlers.length; i++){
        availableModelHandlers[i].setEnabled(false);
      }
    }
    else if(availableHash.size() == registeredHash.size()){
      availableModelHandlers[0].setSelected(true);
      availableModelHandlers[0].setEnabled(true);
      availableModelHandlers[1].setSelected(false);
      availableModelHandlers[1].setEnabled(false);
      for(int i = 2; i < availableModelHandlers.length; i++){
        availableModelHandlers[i].setEnabled(false);
      }
    }
    else{
      for(int i = 2; i < availableModelHandlers.length; i++){
        if(registeredHash.containsKey(availableModelHandlers[i].getText()))
          availableModelHandlers[i].setSelected(true);
      }
    } 
    JPanel functionPanel = new JPanel();
    functionPanel.add(ok);
    functionPanel.add(cancel);
    //this.setBounds(290, 200, 480, 290);
    this.getContentPane().setLayout(new BorderLayout());
    this.getContentPane().add(checkBoxPanel, BorderLayout.CENTER);
    this.getContentPane().add(functionPanel, BorderLayout.SOUTH);
    this.setResizable(false);
    availableModelHandlers[0].addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        JCheckBox box = (JCheckBox)e.getSource();
        for(int i = 1; i < availableModelHandlers.length; i++){
          if(box.isSelected())
            availableModelHandlers[i].setEnabled(false);
          else
            availableModelHandlers[i].setEnabled(true);
        }
      }
    });
    availableModelHandlers[1].addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        JCheckBox box = (JCheckBox)e.getSource();
        if(box.isSelected())
          availableModelHandlers[0].setEnabled(false);
        else
          availableModelHandlers[0].setEnabled(true);        
        for(int i = 2; i < availableModelHandlers.length; i++){
          if(box.isSelected())
            availableModelHandlers[i].setEnabled(false);
          else
            availableModelHandlers[i].setEnabled(true);
        }
      }
    });
    for(int i = 2; i < availableModelHandlers.length; i++){
      availableModelHandlers[i].addActionListener(new java.awt.event.ActionListener(){
        public void actionPerformed(ActionEvent e){
          JCheckBox box = (JCheckBox)e.getSource();
          boolean allSelected = true; 
          boolean allNotSelected = false;
          boolean someSelected = false;
          if(availableModelHandlers[2].isSelected()){
            for(int j = 3; j < availableModelHandlers.length; j++){
              if(!availableModelHandlers[j].isSelected()){
                allSelected = false; 
                someSelected = true;
                break;
              }
            }
          }
          else  if(!availableModelHandlers[2].isSelected()){
            allSelected = false;
            allNotSelected = true;
            for(int j = 3; j < availableModelHandlers.length; j++){
              if(availableModelHandlers[j].isSelected()){
                allNotSelected = false; 
                someSelected = true;
                break;
              }
            }
          }
         
          
          if(someSelected){}  
          if(allSelected){
            for(int j = 1; j < availableModelHandlers.length; j++){
              availableModelHandlers[j].setEnabled(false);
            }
            availableModelHandlers[0].setSelected(true);
            box.setSelected(false);
          }
          
          if(allNotSelected){
            for(int j = 2; j < availableModelHandlers.length; j++){
              availableModelHandlers[j].setEnabled(false);
            }
            availableModelHandlers[0].setSelected(false);
            availableModelHandlers[0].setEnabled(false);
            availableModelHandlers[1].setSelected(true);
            availableModelHandlers[1].setEnabled(true);
            box.setSelected(false);
          }
        }
      });
    }
    
    ok.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        if(availableModelHandlers[0].isSelected()){}
          //tool.setCurrentRegisteredModelHandlers(tool.getRegisteredModelHandlers());
        //else if(availableModelHandlers[1].isSelected())
          //tool.setCurrentRegisteredModelHandlers(new Hashtable());
        else{
          Hashtable hash = new Hashtable();
          for(int i = 2; i < availableModelHandlers.length; i++){
            if(availableModelHandlers[i].isSelected()){
              hash.put(availableModelHandlers[i].getText(), availableHash.get(availableModelHandlers[i].getText()));
            }
          }
          //tool.setCurrentRegisteredModelHandlers(hash);
        }
        doCancel();
      }
    });

    cancel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doCancel();
      }
    });
    this.pack();*/
  }

 
  /**
   * this dialog disappear when cancel button is clicked
   */
  public void doCancel(){
    this.setVisible(false);
  }
}