/*
 * @(#)ModellerPanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;
import java.lang.reflect.*;
import java.io.*;
import pounamu.editor.*;
import pounamu.core.*;
import pounamu.command.*;
import pounamu.visualcomp.*;
import pounamu.data.*;
import pounamu.event.*;
import java.awt.print.*;
import javax.swing.tree.*;

/**
 * Title: ModellerPanel
 * Description:  A panel to draw shapes and connectors used to model a project
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ModellerPanel extends JPanel implements Printable{

    String state = "select";
    String subState = "";
    StringBuffer buf;
    JPanel drawingPanel = new JPanel();
    JPanel toolPanel = new JPanel();
    //Vector shapes = new Vector();
    //Vector connectors = new Vector();
    PounamuHandle firstHandler = null, secondHandler = null;
    JPanel selectedIcon = null;
    JPanel editingIcon = null;
    String shapeType = "", connectorType = "";
    Pounamu pounamu = null;
    PounamuManagerPanel manager= null;
    static int count=0;
    File inputFile = null;
    String fullNewClassName = "", newClassName = "", name = "";
    Hashtable compEditorMapping = new Hashtable();
    //TablePropertySheet tps = new TablePropertySheet();
    static String temp = ""; //for pass arguments to inner classes
    boolean doMove=false, doBottomRight=false, doTopRight=false, doBottomLeft=false, doTopLeft=false,
    doTop=false, doBottom=false, doLeft=false, doRight=false;
    PounamuStack undoStack = new PounamuStack();
    PounamuStack redoStack = new PounamuStack();
    int oldX = 0, oldY = 0, newX = 0, newY = 0, startX = 0, startY = 0;
    // holds list of listeners to PounamuCommands
    Vector commandListeners = new Vector();
    Vector visualEventHandlers = new Vector();
    Vector visualUserHandlers = new Vector();
    String type = null;
    JPopupMenu popup = null;
    Object object = null;
    PounamuProject project = null;
    PounamuToolProject tool = null;
    PounamuView view = null;
    String fileSeparator = null;

    /**
     * Constructor
     * @param pounamu the tool which uses this panel
     * @param manager the corresponding PounamuProjectManagerPanel
     * @param projectPanel the tabbed panel which holds this panel
     */
    public ModellerPanel(PounamuProject project, String type, PounamuView view) {
        this.project = project;
        fileSeparator = System.getProperty("file.separator");
        if(project instanceof PounamuModelProject){
            tool = ((PounamuModelProject)project).getTool();
        }
        this.pounamu = project.getPounamu();
        this.manager = project.getManager();
        this.type = type;
        this.view = view;
        //view.setDisplayPane((JPanel)this);
        this.setLayout(null);
        this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        this.setPreferredSize(new Dimension(1000, 1000));
        this.setBackground(Color.white);
        //JScrollPane jsp = new JScrollPane(this, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        //this.add(jsp, BorderLayout.CENTER);
        this.addMouseListener(new java.awt.event.MouseListener() {
            public void mouseClicked(MouseEvent e) {
                whenMouseClicked(e);
            }
            public void mousePressed(MouseEvent e) {
                whenMousePressed(e);
            }
            public void mouseReleased(MouseEvent e) {
                whenMouseReleased(e);
            }
            public void mouseEntered(MouseEvent e) {
                whenMouseEntered(e);
            }
            public void mouseExited(MouseEvent e) {
                whenMouseExited(e);
            }
        });
        this.addMouseMotionListener(new java.awt.event.MouseMotionListener() {
            public void mouseDragged(MouseEvent e) {
                whenMouseDragged(e);
            }
            public void mouseMoved(MouseEvent e) {
                whenMouseMoved(e);
            }
        });
        //initShapes();
        //initConnectors();
        pounamu.setListModel(undoStack, redoStack);
        //initPopupMenus();
        //this.add(popup);
    }

    /**
     * get the view this panel belongs to
     * @return the PounamuView object view
     */
    public PounamuView getView(){
        return view;
    }

    /**
     * set a view for this panel
     * @param view the PounamuView object view
     */
    public void setView(PounamuView view){
        this.view = view;
    }

    /**
     * get the manager used to manage this panel
     * @return the PounamuManagerPanel object manager
     */
    public PounamuManagerPanel getManager(){
        return manager;
    }

    /**
     * set a manager for this panel
     * @param manager the PounamuManagerPanel object manager
     */
    public void setManager(PounamuManagerPanel manager){
        this.manager = manager;
    }

    /**
     * get the pounamu running instance
     * @return the pounamu running instance
     */
    public Pounamu getPounamu(){
        return pounamu;
    }

    /**
     * set a pounamu instance
     * @param pounamu a running instance of Pounamu
     */
    public void setPounamu(Pounamu pounamu){
        this.pounamu = pounamu;
    }

    /**
     * get the project this panel belongs to, if this panel is used for a meta model definer,
     * the project would be a PounamuToolProject, if for a modeller, the project would be a PounamuModelProject
     * @return the project
     */
    public PounamuProject getProject(){
        return project;
    }


    /**
     * set the project this panel belongs to
     * @param project a project,  if this panel is used for a meta model definer, the project would be a PounamuToolProject, if for a modeller, the project would be a PounamuModelProject
     */
    public void setProject(PounamuProject project){
        this.project = project;
    }

    /**
     * get type of this panel, if this panel is used in meta model definer, type is "metamodelview", if for a modeller, type is "modelview"
     * @return the type of this panel
     */
    public String getType(){
        return type;
    }

    /**
     * set type for this panel
     * @param type a string, if this panel is used in meta model definer, type is "metamodelview", if for a modeller, type is "modelview"
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * set the current object of this panel, once mouse relesed, this object will be added to the panel
     * @param object the current object to be added to the panel after mouse release
     */
    public void setObject(Object object){
        this.object = object;
    }

    /**
     * get the current object of this panel, once mouse relesed, this object will be added to the panel
     * @return the current object to be added to the panel after mouse release
     */
    public Object getObject(){
        return object;
    }

    /**
     * set the current object of this panel, once mouse relesed, this object will be added to the panel
     * @param object the current object to be added to the panel after mouse release
     */
    public void setCurrentObject(Object object){
        this.object = object;
    }

    /**
     * get the current object of this panel, once mouse relesed, this object will be added to the panel
     * @return the current object to be added to the panel after mouse release
     */
    public Object getCurrentObject(){
        return object;
    }

 /* public void initShapes(){
    if(type.equals("metamodel")){
    }
    else{}
  }*/

    // public void initConnectors(){}

  /*public void initPopupMenus(){
    popup = new JPopupMenu();
    JMenu addShape = new JMenu("enter adding shape state and add a");
    JMenu addConnector = new JMenu("enter adding connector state and add a");
    JMenuItem menuItem = null;
    menuItem = new JMenuItem("enter select state");
    menuItem.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent ev){
         doSelect();
       }
    });
    popup.add(menuItem);
    menuItem.setVisible(true);
    popup.addSeparator();
    if(type.equals("metamodel")){
      menuItem = new JMenuItem("enter adding shape state and adding an entity type");
      menuItem.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
          setState("entitytype");
          //NewObjectDialog dialog = new NewObjectDialog(pounamu, manager, ModellerPanel.this, "entitytype");
          //dialog.setVisible(true);
        }
      });
      popup.add(menuItem);
      menuItem.setVisible(true);
      menuItem = new JMenuItem("enter adding shape state and adding an association");
      menuItem.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
          setState("addAssociation");
          //NewObjectDialog dialog = new NewObjectDialog(pounamu, manager, ModellerPanel.this, "associationtype");
          //dialog.setVisible(true);
        }
      });
      popup.add(menuItem);
      menuItem.setVisible(true);
      menuItem = new JMenuItem("enter adding connector state");
      menuItem.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
          setState("connectentityandassociation");
        }
      });
      popup.add(menuItem);
      menuItem.setVisible(true);
    }
    else{
      popup.add(addShape);
      addShape.setVisible(true);
      for (int i = 0; i < availableConnectors.size(); i++){
      String item = (String)(availableConnectors.elementAt(i));
      File inputFile = new File((String)properties.get("pounamu")+fileSeparator+"gui"+fileSeparator+"dynamic"+fileSeparator+"pounamuconnectors"+fileSeparator+""+item+".xml");
      pounamuConnectorNameMapping.put(item, inputFile);
      menuItem = new JMenuItem(item);
      menuItem.setToolTipText(item);
      menuItem.addActionListener(new ActionListener(){
         public void actionPerformed(ActionEvent ev){
           JMenuItem jmi = (JMenuItem)ev.getSource();
           connectorsBox.setSelectedItem(jmi.getToolTipText());
           setMessage("you are going to add a"+jmi.getToolTipText()+" ...");
        }
      });
      addConnector.add(menuItem);
      menuItem.setVisible(true);
      }
      popup.add(addConnector);
      addConnector.setVisible(true);
    }
    popup.addSeparator();
    //--------add Remove Element menu----------
    menuItem = new JMenuItem("delete");
    menuItem.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDelete();
      }
    });
    popup.add(menuItem);
    menuItem.setVisible(true);

    //--------add Remove Element menu----------
     menuItem = new JMenuItem("clear all");
     menuItem.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ev){
          doClear();
        }
     });
     popup.add(menuItem);
     menuItem.setVisible(true);
     //popup.setVisible(true);
  }*/



    /**
     * print out all information in this panel
     */
    public void print(){
        PrinterJob printJob = PrinterJob.getPrinterJob();
        PageFormat pf = printJob.pageDialog(printJob.defaultPage());
        printJob.setPrintable(this);
        if (printJob.printDialog()) {
            try {
                //view.paintComponent(Graphics g);
                printJob.print();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

  /*public void doSelect(){
    this.setState("select");
  }*/

    /**
     * get the state of this panel, under different state, different behaviour to the mouse event
     * @return the state of this panel
     */
    public String getState(){
        return state;
    }



    /**
     * print
     * @return Printable.PAGE_EXISTS if successful
     * @param g the Graphics
     * @param pf the PageFormat
     * @param pi the int
     */
    public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
        if (pi >= 1) {
            return Printable.NO_SUCH_PAGE;
        }
        //printComponent(g);//drawShapes((Graphics2D) g);
        printChildren(g);
        return Printable.PAGE_EXISTS;
    }

    /**
     * set state of this panel which will determine what happen when there is a mouse event
     * @param message the vlue which will be set to state
     */
    public void setState(String message){
        state = message;
        if(state.equals("select")){
            setSelectCursors();
            //addMouseListeners();
        }
    /*else if(state.equals("edit"))
      setEditCursors();
    else
      setIdleCursors();*/
    }

 /* public void addMouseListeners(){
    for (int i = 0; i < shapes.size(); i++){
      //((PounamuPanel)shapes.elementAt(i)).setSelectCursors();
      ((PounamuPanel)shapes.elementAt(i)).addMouseListeners(this);
    }
  }*/

    /**
     * assign a default cursor to all shapes and connectors
     */
    public void setSelectCursors(){
        Component[] com = this.getComponents();
        for (int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuPanel)
                ((PounamuPanel)com[i]).setSelectCursors();
        }
    /*for (int i = 0; i < shapes.size(); i++){
      ((PounamuPanel)shapes.elementAt(i)).setSelectCursors();
    }*/
    }

    /**
     * assign a default cursor to all shapes and connectors
     */
    public void setIdleCursors(){
        Component[] com = this.getComponents();
        for (int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuPanel)
                ((PounamuPanel)com[i]).setIdleCursors();
        }
    /*for (int i = 0; i < shapes.size(); i++){
      ((PounamuPanel)shapes.elementAt(i)).setIdleCursors();
    }*/
    }

    /**
     * assign a default cursor to all shapes and connectors
     */
    public void setEditCursors(){
        Component[] com = this.getComponents();
        for (int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuPanel)
                ((PounamuPanel)com[i]).setEditCursors();
        }
    /*for (int i = 0; i < shapes.size(); i++){
      ((PounamuPanel)shapes.elementAt(i)).setEditCursors();
    }*/
    }

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMousePressed(MouseEvent e) {
        if(e.getClickCount()>=2){
            if(selectedIcon != editingIcon){
                editingIcon = selectedIcon;
                if(editingIcon instanceof PounamuPanel)
                    ((PounamuPanel)editingIcon).setEditCursors();
            }
        }
        Point p = e.getPoint();
        subState = "";
        firstHandler = null;
        secondHandler = null;
        selectedIcon = null;
        if(state.equals("select"))
            getSelectedItem(p);
        if(selectedIcon != editingIcon){
            if(editingIcon != null && editingIcon instanceof PounamuPanel){
                ((PounamuPanel)editingIcon).setSelectCursors();
                editingIcon = null;
            }
        }
        if(e.getButton() == MouseEvent.BUTTON3){
            JPopupMenu pop = (JPopupMenu)manager.getPopupMenu(manager.getSelectedNode());
            pop.addPopupMenuListener(new PopupMenuListener(){
                public void popupMenuWillBecomeVisible(PopupMenuEvent e){}
                public void popupMenuWillBecomeInvisible(PopupMenuEvent e){
                    rearrangeMenuItem(e);
                }
                public void popupMenuCanceled(PopupMenuEvent e){
                    rearrangeMenuItem(e);
                }
                public void rearrangeMenuItem(PopupMenuEvent e){
                    JPopupMenu p = (JPopupMenu)e.getSource();
                    p.removeAll();
                    manager.prepareDynamicMenu();
                }
            });
            pop.show(this, e.getX(), e.getY());
        }
    /*if(e.isPopupTrigger()||(e.getModifiers()&InputEvent.BUTTON3_MASK)!=0){
       manager.getPopupMenu(manager.getSelectedNode()).show(this, e.getX(), e.getY());
     }*/
        startX = e.getX();
        startY = e.getY();
        oldX = e.getX();
        oldY = e.getY();
        if(state.equals("select")){
            //set selected icon if it is a shape
      /*for (int i = 0; i < shapes.size(); i++){
        if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
          if(((PounamuPanel)shapes.elementAt(i)) != selectedIcon){
            selectedIcon = (PounamuPanel)shapes.elementAt(i);
            setSelected(false);
            //oneShapeSelected = true;
            ((PounamuPanel)selectedIcon).setSelected(true);
            DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)project.getIconAndNodeMapping().get((PounamuPanel)selectedIcon);
            TreePath path = new TreePath(dmtn.getPath());
            manager.getManagerTree().setSelectionPath(path);
            break;
          }
        }
      }
      //set the selected icon if it is a connector
      for (int i = 0; i < connectors.size(); i++){
        if(((PounamuConnector)connectors.elementAt(i)).contains(p)){
          if(((PounamuPanel)shapes.elementAt(i)) != selectedIcon){
            selectedIcon = (PounamuConnector)connectors.elementAt(i);
            setSelected(false);
            ((PounamuConnector)selectedIcon).setSelected(true);
            DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)project.getIconAndNodeMapping().get((PounamuConnector)selectedIcon);
            TreePath path = new TreePath(dmtn.getPath());
            manager.getManagerTree().setSelectionPath(path);
            break;
          }
        }
      }*/
            //if selectedIcon is a connector, then check which handler of the shape is selected
            if(selectedIcon != null && selectedIcon instanceof PounamuConnector){
                PounamuPanel shape = (PounamuPanel)((PounamuConnector)selectedIcon).getStartHandler().getParent();
                PounamuHandle[] handlers = shape.getHandlers();
                for(int i = 0; i < handlers.length; i++){
                    if(handlers[i].contains(p)){
                        firstHandler = handlers[i];
                        ((PounamuConnector)selectedIcon).setHandlerToBeReplaced("start");
                        shape.setSelected(true);
                        subState = "doMoveHandler";
                        return;
                    }
                }
                shape = (PounamuPanel)((PounamuConnector)selectedIcon).getEndHandler().getParent();
                handlers = shape.getHandlers();
                for(int j = 0; j < handlers.length; j++){
                    if(handlers[j].contains(p)){
                        firstHandler = handlers[j];
                        ((PounamuConnector)selectedIcon).setHandlerToBeReplaced("end");
                        shape.setSelected(true);
                        subState = "doMoveHandler";
                        return;
                    }
                }
            }
            //if selected icon is a Pounamu shape
            if(selectedIcon != null && selectedIcon instanceof PounamuPanel){
                PounamuHandle[] handlers = ((PounamuPanel)selectedIcon).getHandlers();
                subState = "doMoveShape";
                for(int j = 0; j < handlers.length; j++){
                    if(handlers[j].contains(p)){
                        if(handlers[j].getRole().equals("EResize"))
                            subState = "doEResize";
                        else if(handlers[j].getRole().equals("SResize"))
                            subState = "doSResize";
                        else if(handlers[j].getRole().equals("SEResize"))
                            subState = "doSEResize";
                        else if(handlers[j].getRole().equals("SWResize"))
                            subState = "doSWResize";
                        else if(handlers[j].getRole().equals("NEResize"))
                            subState = "doNEResize";
                        else if(handlers[j].getRole().equals("NWResize"))
                            subState = "doNWResize";
                        else if(handlers[j].getRole().equals("WResize"))
                            subState = "doWResize";
                        else if(handlers[j].getRole().equals("NResize"))
                            subState = "doNResize";
                        return;
                    }
                }
            }
        }
        if(state.equals("Inheritance")||state.equals("Connectible")||state.equals("addassociation")){
            Component[] com = this.getComponents();
            for (int i = 0; i < com.length; i++){
                if(com[i] instanceof PounamuPanel){
                    PounamuPanel shape = (PounamuPanel)com[i];
                    PounamuHandle[] handlers = shape.getHandlers();
                    for(int j = 0; j < handlers.length; j++){
                        if(handlers[j].contains(p)){
                            firstHandler = handlers[j];
                            break;
                        }
                    }
                }
            }
        }
       /*for (int i = 0; i < shapes.size(); i++){
        PounamuPanel shape = (PounamuPanel)shapes.elementAt(i);
        PounamuHandler[] handlers = shape.getHandlers();
        for(int j = 0; j < handlers.length; j++){
          if(handlers[j].contains(p)){
            firstHandler = handlers[j];
            break;
          }
        }
      }*/

        this.validate();
        this.repaint();
        //System.out.println("in ModellerPanel, state is now select!!!!!!!!");
    }

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseReleased(MouseEvent e) {
        //System.out.println("In class ModellerPanel: 00");
        Point p = e.getPoint();
        newX = e.getX();
        newY = e.getY();
        //do move shape
        if(state.equals("select")&&subState.equals("doMoveShape")){
            MoveShape ms = new MoveShape(this, (PounamuPanel)selectedIcon, (int)oldX, (int)oldY, (int)newX, (int)newY, startX, startY);
            ms.excute();
            undoStack.push(ms);
            subState="";
        }
        //do resize shape
        if(state.equals("select")&&(subState.equals("doEResize")||
        subState.equals("doSResize")||subState.equals("doSEResize"))){
            ResizeShape rs = new ResizeShape(this, (PounamuPanel)selectedIcon, (int)oldX, (int)oldY, (int)newX, (int)newY, startX, startY);
            rs.excute();
            undoStack.push(rs);
            subState="";
        }
        //do move handler
        if(state.equals("select")&&subState.equals("doMoveHandler")){
            PounamuHandle[] handlers = ((PounamuPanel)firstHandler.getParent()).getHandlers();
            for(int j = 0; j < handlers.length; j++){
                if(handlers[j].contains(p)){
                    secondHandler = handlers[j];
                    break;
                }
            }
            if(secondHandler!=null){
                if(((PounamuConnector)selectedIcon).getHandlerToBeReplaced().equals("start"))
                    ((PounamuConnector)selectedIcon).setStartHandler(secondHandler);
                else if(((PounamuConnector)selectedIcon).getHandlerToBeReplaced().equals("end"))
                    ((PounamuConnector)selectedIcon).setEndHandler(secondHandler);
                else{}
                ((PounamuConnector)selectedIcon).repaint();
                setSelected(false);
                ((PounamuConnector)selectedIcon).setSelected(true);
            }
        }//end of do move handler
        //start for addassociation state
        if(state.equals("Inheritance")||state.equals("Connectible")||state.equals("addassociation")){
            Component[] com = this.getComponents();
            for (int i = 0; i < com.length; i++){
                if(com[i] instanceof PounamuPanel){
                    PounamuPanel shape = (PounamuPanel)com[i];
                    PounamuHandle[] handlers = shape.getHandlers();
                    for(int j = 0; j < handlers.length; j++){
                        if(handlers[j].contains(p)){
                            secondHandler = handlers[j];
                            break;
                        }
                    }
                }
            }
    /*if(state.equals("Inheritance")||state.equals("Connectible")||state.equals("addassociation")){
      for (int i = 0; i < shapes.size(); i++){
        PounamuPanel shape = (PounamuPanel)shapes.elementAt(i);
        PounamuHandler[] handlers = shape.getHandlers();
        for(int j = 0; j < handlers.length; j++){
          if(handlers[j].contains(p)){
            secondHandler = handlers[j];
            break;
          }
        }
      }*/
            if(secondHandler == null){
                firstHandler = null;
                return;
            }
            if(secondHandler == firstHandler || secondHandler.getParent() == firstHandler.getParent()){
                pounamu.displayMessage("You have select two handlers from the same shape");
                firstHandler = null;
                secondHandler = null;
                return;
            }
            else{
                if(state.equals("Inheritance")||state.equals("Connectible")){
                    try{
                        File inputFile = new File(project.getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+"C_"+state+".xml");
                        LoadXMLFile lxf = new LoadXMLFile(inputFile);
                        PounamuConnector pc = new  PounamuConnector(state);
                        pc.setHandlers(firstHandler, secondHandler);
                        pc.setXMLDocument(lxf.getDocument());
                        pc.setType(""+fileSeparator+"C_"+state);
                        AddNewConnector anc = new AddNewConnector(this, pc);
                        anc.excute();
                        undoStack.push(anc);
                    }
                    catch(Exception ex){
                        //System.out.println(ex.toString());
                        pounamu.displayMessage("Exception in class ModellerPanel "+ex.toString());

                    }
                }
                else{
                    //System.out.println("In modellerpanel here visited 0  ");
                    String name = ((PounamuModelElement)object).getName();
                    //System.out.println("In modellerpanel name is " + name);
                    String modelType = ((PounamuModelElement)object).getType();
                    //System.out.println("In modellerpanel modelType is " + modelType);
                    String viewType = view.getType();
                    //System.out.println("In modellerpanel viewType is " + viewType);
                    String iconType = tool.getConnectorType(modelType, viewType);
                    //System.out.println("In modellerpanel iconType is " + iconType);
                    File inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+""+iconType+".xml");
                    LoadXMLFile lxf = new LoadXMLFile(inputFile);
                    PounamuConnector pc = new PounamuConnector(name);
                    pc.setRelatedObject(object);
                    pc.setType(iconType);
                    pc.setHandlers(firstHandler, secondHandler);
                    pc.setXMLDocument(lxf.getDocument());
                    ((PounamuModelElement)object).addIcon(view, pc);
                    //System.out.println("In modellerpanel AddNewConnector visited 1 ");
                    AddNewConnector ana = new AddNewConnector(this, pc);
                    //System.out.println("In modellerpanel AddNewConnector visited 2 ");
                    ana.excute();
                    //System.out.println("In modellerpanel AddNewConnector visited 3 ");
                    undoStack.push(ana);
                    //this.setState("idle");
                    this.setState("select");
                    this.validate();
                    this.repaint();
                }
            }
        }

        if(state.startsWith("addentity")){
            addEntity(p);
            //System.out.println("In class ModellerPanel: 0");
      /*String name = ((PounamuModelElement)object).getName();
      String modelType = ((PounamuModelElement)object).getType();
      String viewType = view.getType();
      String iconType = tool.getShapeType(modelType, viewType);
      File inputFile = new File(tool.getLocation()+""+fileSeparator+"shapes"+fileSeparator+""+iconType+".xml");
      //System.out.println("In class ModellerPanel: 1");
      LoadXMLFile lxf = new LoadXMLFile(inputFile);
      //System.out.println("In class ModellerPanel: 2");
      PounamuShape pp = new PounamuShape(name, lxf.getDocument(), project, view);
      //System.out.println("In class ModellerPanel: 3");
      pp.setType(iconType);
      pp.setRelatedObject(object);
      ((PounamuModelElement)object).addIcon(view, pp);
      pp.getBasePanel().setLocation(p);
      //System.out.println("In class ModellerPanel: 4");
      AddEntity ans = new AddEntity(this);
      //System.out.println("In class ModellerPanel: 5");
      ans.excute();
      undoStack.push(ans);
      this.setState("idle");
      this.validate();
      this.repaint();*/
        }
        //when state is a kind of "entitytype"
        if(state.equals("entitytype")){
            String name=((PounamuMetaModelElement)object).getName();
            try{
                File inputFile = null;
                String iconName = ((PounamuToolProject)project).getEntityTypeIcon();
                if(iconName.equals("S_DefaultShapeForEntityType"))
                    inputFile = new File(pounamu.getPounamuHome()+fileSeparator+"nonjavafiles"+fileSeparator+iconName+".xml");
                else
                    inputFile = new File(project.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconName+".xml");
                LoadXMLFile lxf = new LoadXMLFile(inputFile);
                PounamuShape pp = new PounamuShape(name, lxf.getDocument(), project, view);
                pp.setRelatedObject(object);
                pp.setType(((PounamuToolProject)project).getEntityTypeIcon());
                ((PounamuMetaModelElement)object).addIcon(view, pp.getBasePanel());
                String iconPropertyName = (String)((PounamuToolProject)project).getPropertyMappingFromEntityTypeToIcon().get("name");
                pp.setProperty(iconPropertyName, name);
                pp.getBasePanel().setLocation(p);
                pp.getBasePanel().addMouseListeners(this);
                AddNewPounamuMetaModelElement ans = new AddNewPounamuMetaModelElement(this, pp.getBasePanel());
                ans.excute();
                undoStack.push(ans);
                this.setState("select");
            }
            catch(Exception eeee){
                pounamu.displayMessage("Exception in class ModellerPanel "+eeee.toString());
            }
        }
        if(state.equals("associationtype")){
            String name=((PounamuMetaModelElement)object).getName();
            try{
                File inputFile = null;
                String iconName = ((PounamuToolProject)project).getAssociationTypeIcon();
                if(iconName.equals("S_DefaultShapeForAssociationType"))
                    inputFile = new File(pounamu.getPounamuHome()+fileSeparator+"nonjavafiles"+fileSeparator+iconName+".xml");
                else
                    inputFile = new File(project.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconName+".xml");
                LoadXMLFile lxf = new LoadXMLFile(inputFile);
                PounamuShape pp = new PounamuShape(name, lxf.getDocument(), project, view);
                pp.setType(((PounamuToolProject)project).getAssociationTypeIcon());
                pp.setRelatedObject(object);
                ((PounamuMetaModelElement)object).addIcon(view, pp.getBasePanel());
                String iconPropertyName = (String)((PounamuToolProject)project).getPropertyMappingFromAssociationTypeToIcon().get("name");
                pp.setProperty(iconPropertyName, name);
                pp.getBasePanel().setLocation(p);
                pp.getBasePanel().addMouseListeners(this);
                AddNewPounamuMetaModelElement ans = new AddNewPounamuMetaModelElement(this, pp.getBasePanel());
                ans.excute();
                undoStack.push(ans);
                this.setState("select");
            }
            catch(Exception eeee){
                pounamu.displayMessage("Exception in class ModellerPanel "+eeee.toString());
            }
        }

        //when state is a kind of "Connector"...
        if(state.startsWith("association_")){
            //System.out.println("======================= visited 0");
      /*for (int i = 0; i < shapes.size(); i++){
        if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
          secondHandler = (PounamuPanel)shapes.elementAt(i);
          break;
        }
      }*/
            //System.out.println("======================= visited 1");
            //if first shape and the second one are the same, do nothing
            if(firstHandler == secondHandler){
                firstHandler = null;
                secondHandler = null;
                return;
            }
            //System.out.println("======================= visited 2");
            //check if there is connector between these two shapes already..
      /*for (int i = 0; i < connectors.size(); i++){
        if(((((PounamuConnector)connectors.elementAt(i)).s1==firstHandler)
           &&(((PounamuConnector)connectors.elementAt(i)).s2==secondHandler))
          ||((((PounamuConnector)connectors.elementAt(i)).s1==secondHandler)
           &&(((PounamuConnector)connectors.elementAt(i)).s2==firstHandler))){
          JOptionPane.showMessageDialog(this, "There is a connector between these two shape already!");
          firstHandler = null;
          secondHandler = null;
          return;
        }
      }*/
            //System.out.println("======================= visited 3");
            //if both shape are not null, add new connector
            if (firstHandler!=null&&secondHandler!=null){
                //System.out.println(state);
                //System.out.println("======================= visited 4");
       /* String name = ((PounamuModelElement)object).getName();
        //System.out.println("nameType is " + name);
        String modelType = ((PounamuModelElement)object).getType();
        //System.out.println("modelType is " + name);
        String viewType = view.getType();
        //System.out.println("viewType is " + name);
        String iconType = project.getIconType(modelType, viewType);
        //System.out.println("iconType 0 is " + iconType);
        if(iconType == null||iconType.equals("")){
          //System.out.println("======================= visited 5");
          ModelIconChooser mic = new ModelIconChooser(view, modelType);
          mic.setVisible(true);
          //System.out.println("======================= visited 6");
          iconType = project.getIconType(modelType, viewType);
          //System.out.println("iconType 1 is " + iconType);
        }
        File inputFile = (File)project.getXMLFile(iconType);
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuConnector pp = new PounamuConnector(lxf.getDocument());
        //PounamuShape pp = new PounamuShape(name, lxf.getDocument(), pounamu, manager, view);
        pp.setRelatedObject(object);
        if(((PounamuModelElement)object).getIcon(view)!=null){
          pounamu.displayMessage("this " + modelType+" has been defined in this view already!");
          Toolkit.getDefaultToolkit().beep();
          return;
        }
        ((PounamuModelElement)object).addIcon(view, pp);
        String iconPropertyName = project.getIconPropertyName(modelType, iconType, "name");
        pp.setProperty(iconPropertyName, name);
        pp.setPounamuPanels(firstHandler, secondHandler);
        setSelected(false);
        pp.setSelected(true);
        //System.out.println("here visited: ModellerPanel, whenMouseReleased 0");
        //AddNewConnector anc = new AddNewConnector(this, pp);
        AddNewAssociation ana = new AddNewAssociation(this);
        ana.excute();
        undoStack.push(ana);
        //AddNewEntity ans = new AddNewEntity(this);
        //ans.excute();
        //undoStack.push(ans);
      //System.out.println("here visited: ModellerPanel, whenMouseReleased 0");*/
        /*try{
          //File inputFile = (File)pounamu.pounamuConnectorNameMapping.get(state);
          File inputFile = (File)project.getXMLFile(state);
          LoadXMLFile lxf = new LoadXMLFile(inputFile);
          PounamuConnector pc = new  PounamuConnector();
          pc.setPounamuPanels(firstHandler, secondHandler);
          pc.setXMLDocument(lxf.getDocument());
          AddNewConnector anc = new AddNewConnector(this, pc);
          anc.excute();
          undoStack.push(anc);
        }
        catch(Exception ex){
          System.out.println(ex.toString());
        }*/
            }
        }
        //when state is a kind of "bidirection conector" or "single Direction connector"...
        if(state.equals("Connector_BiDirection")||state.equals("Connector_SingleDirection")){
            //locate the second shape
      /*for (int i = 0; i < shapes.size(); i++){
        if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
          secondHandler = (PounamuPanel)shapes.elementAt(i);
          break;
        }
      }*/
            //if first shape and the second one are the same, do nothing
            if(firstHandler == secondHandler){
                firstHandler = null;
                secondHandler = null;
                return;
            }
            //check if there is connector between these two shapes already..
      /*for (int i = 0; i < connectors.size(); i++){
        if(((((PounamuConnector)connectors.elementAt(i)).s1==firstHandler)
           &&(((PounamuConnector)connectors.elementAt(i)).s2==secondHandler))
          ||((((PounamuConnector)connectors.elementAt(i)).s1==secondHandler)
           &&(((PounamuConnector)connectors.elementAt(i)).s2==firstHandler))){
          //JOptionPane.showMessageDialog(this, "There is a connector between these two shape already!");
          pounamu.displayMessage("There is a connector between these two shape already!");
          firstHandler = null;
          secondHandler = null;
          return;
        }
      }*/
            //if both shape are not null, add new connector
            if (firstHandler!=null&&secondHandler!=null){
        /*try{
          //System.out.println("Look here! state now is "+state);
          File inputFile = (File)project.getXMLFile(state);
          //System.out.println("getXMLFile excued! state now is "+state);
          LoadXMLFile lxf = new LoadXMLFile(inputFile);
          PounamuConnector pc = new  PounamuConnector(state);
          pc.setPounamuPanels(firstHandler, secondHandler);
          pc.setXMLDocument(lxf.getDocument());
          AddNewConnector anc = new AddNewConnector(this, pc);
          anc.excute();
          undoStack.push(anc);
        }
        catch(Exception ex){
          System.out.println(ex.toString());
        }*/
            }
        }
        subState = "";
        firstHandler = null;
        secondHandler = null;
        this.validate();
        this.repaint();
    }

    public void addEntity(Point p){
        String name = ((PounamuModelElement)object).getName();
        String modelType = ((PounamuModelElement)object).getType();
        String viewType = view.getType();
        String iconType = tool.getShapeType(modelType, viewType);
        File inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconType+".xml");
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuShape pp = new PounamuShape(name, lxf.getDocument(), project, view);
        pp.setType(iconType);
        pp.setRelatedObject(object);
        pp.getBasePanel().setLocation(p);
        AddNewShape ans = new AddNewShape(this, pp);
        ans.excute();
        undoStack.push(ans);
        this.setState("select");
        this.validate();
        this.repaint();
    }
    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseEntered(MouseEvent e) {}

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseExited(MouseEvent e) {}

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseDragged(MouseEvent e) {
        newX = e.getX();
        newY = e.getY();
        if(state.equals("select")&&subState.equals("doMoveShape")){
            ((PounamuPanel)selectedIcon).setLocation(((PounamuPanel)selectedIcon).getBounds().x-oldX+newX, ((PounamuPanel)selectedIcon).getBounds().y-oldY+newY);
            oldX = newX;
            oldY = newY;
        }
        else if(state.equals("select")&&(subState.equals("doSResize")||
        subState.equals("doSEResize")||subState.equals("doEResize"))){
            ((PounamuPanel)selectedIcon).setBounds(((PounamuPanel)selectedIcon).getBounds().x, ((PounamuPanel)selectedIcon).getBounds().y,
            ((PounamuPanel)selectedIcon).getBounds().width-oldX+newX, ((PounamuPanel)selectedIcon).getBounds().height-oldY+newY);
            oldX = newX;
            oldY = newY;
        }
        this.repaint();
    }

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseMoved(MouseEvent e) {

    /*if(!state.equals("select"))
      return;
    if(selectedIcon==null)
      return;
    if(selectedIcon instanceof PounamuConnector)
      return;
    Point p = e.getPoint();
    if(p == null)
      return;
    JPanel underneathIcon = null;
   // setDefaultCursor();
    if(state.equals("select")){
      if(((PounamuPanel)selectedIcon).contains(p)){
        ((PounamuPanel)selectedIcon).setCursors();

      }
    }*/
    }

    /**
     * implements mouse listener
     * @param e the mouse event
     */
    public void whenMouseClicked(MouseEvent e) {
    /*Point p = e.getPoint();
    subState = "";
    firstHandler = null;
    secondHandler = null;
    if(state.equals("idle")||state.equals("select")||state.equals("edit"))
      getSelectedItem(p);
    if(e.isPopupTrigger()||(e.getModifiers()&InputEvent.BUTTON3_MASK)!=0){
       manager.getPopupMenu(manager.getSelectedNode()).show(this, e.getX(), e.getY());
     }*/
    }

    public void getSelectedItem(Point p){
        //check if previously selected icon contains this point, if yes, then do nothing
        if(selectedIcon != null){
            if(selectedIcon instanceof PounamuPanel){
                if(((PounamuPanel)selectedIcon).contains(p))
                    return;
            }
            else if(selectedIcon instanceof PounamuConnector){
                if(((PounamuConnector)selectedIcon).contains(p))
                    return;
            }
        }
        //set selectedIcon null
        selectedIcon = null;
        //get all icons in this model panel
        Component[] com = this.getComponents();
        //go through this array
        for(int i = 0; i < com.length; i++){
            //when the icon is a pounamu panel (shape)
            if(com[i] instanceof PounamuPanel){
                PounamuPanel shape = (PounamuPanel)com[i];
                if(shape.contains(p)){
                    selectedIcon = (PounamuPanel)shape;
                    setSelected(false);
                    shape.setSelected(true);
                    break;
                }
            }
            else if(com[i] instanceof PounamuConnector){
                PounamuConnector connector = (PounamuConnector)com[i];
                if(connector.contains(p)){
                    selectedIcon = (PounamuConnector)connector;
                    setSelected(false);
                    connector.setSelected(true);
                    break;
                }
            }
        }
        //if no shape, and no connector contains this point, then set the selected icon this model panel
        if(selectedIcon == null){
            selectedIcon = this;
            setSelected(false);
        }
        //set the selected node on the tree node
        DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)(project.getIconAndNodeMapping().get(selectedIcon));
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
   /* boolean oneShapeSelected = false;
    boolean oneConnectorSelected = false;

    for (int i = 0; i < shapes.size(); i++){
      if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
        selectedIcon = (PounamuPanel)shapes.elementAt(i);
        setSelected(false);
        oneShapeSelected = true;
        ((PounamuPanel)selectedIcon).setSelected(true);
        DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)project.getIconAndNodeMapping().get((PounamuPanel)selectedIcon);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        break;
      }
    }
    if(oneShapeSelected == true)
        return;
      //System.out.println("here visited as well");
    for (int i = 0; i < connectors.size(); i++){
      if(((PounamuConnector)connectors.elementAt(i)).contains(p)){
        selectedIcon = (PounamuConnector)connectors.elementAt(i);
        setSelected(false);
        oneConnectorSelected = true;
        ((PounamuConnector)selectedIcon).setSelected(true);
        DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)(project.getIconAndNodeMapping().get((PounamuConnector)selectedIcon));
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        break;
      }
    }
    if(oneConnectorSelected == true)
      return;
    setSelected(false);
    DefaultMutableTreeNode dmtn =(DefaultMutableTreeNode)(project.getIconAndNodeMapping().get(this));
    TreePath path = new TreePath(dmtn.getPath());
    manager.getManagerTree().setSelectionPath(path);*/
    }

    /**
     * set the selected value se to every shaape and connector
     * @param se the boolean represents selected or not
     */
    public void setSelected(boolean se){

        //get all icons in this model panel
        Component[] com = this.getComponents();
        //go through this array
        for(int i = 0; i < com.length; i++){
            //when the icon is a pounamu panel (shape)
            if(com[i] instanceof PounamuPanel){
                ((PounamuPanel)com[i]).setSelected(se);
            }
            //when the icon is a pounamu connector
            else if(com[i] instanceof PounamuConnector){
                ((PounamuConnector)com[i]).setSelected(se);
            }
        }
     /*for (int i = 0; i < connectors.size(); i++){
       ((PounamuConnector)connectors.elementAt(i)).setSelected(se);
    }
    for (int i = 0; i < shapes.size(); i++){
       ((PounamuPanel)shapes.elementAt(i)).setSelected(se);
    }*/
        this.validate();
        this.repaint();
    }

    /**
     * remove the selected shape from the modeller panel
     */
    public void doDelete(){
   /* if(selectedShape == null)
      return;
    if(selectedShape instanceof PounamuShape){
      RemoveShape rs = new RemoveShape(this, (PounamuShape)selectedShape);
      rs.excute();
      undoStack.push(rs);
    }
    else{
      RemoveConnector rc = new RemoveConnector(this, (PounamuConnector)selectedShape);
      rc.excute();
      undoStack.push(rc);
    }*/
    }

    /**
     * save the project modelling in this modeller panel
     * @param viewName the name of this view
     */
    public void save(String viewName){

        String outputPath = null;
        if(project instanceof PounamuToolProject)
            outputPath = project.getLocation()+fileSeparator+"metamodel"+fileSeparator+"metamodelviews"+fileSeparator+viewName+".xml";
        else
            outputPath = project.getLocation()+fileSeparator+"views"+fileSeparator+view.getType()+fileSeparator+viewName+".xml";
        SaveModelViewToXML save = new SaveModelViewToXML(this);
        try{
            FileWriter fw = new FileWriter(outputPath);
            BufferedWriter bw = new BufferedWriter(fw, 40000);
            bw.write(save.getXML());
            bw.flush();
            fw.close();
        }
        catch(Exception ee){
            pounamu.displayMessage(ee.toString());
            Toolkit.getDefaultToolkit().beep();
        }
    }

    /**
     * clear all components in this modeller panel
     */
    public void doClear(){
        ClearAll ca = new ClearAll(this);
        ca.excute();
        undoStack.push(ca);
    }

 /*public JPanel getDrawingPanel(){
   return this;
 }*/

    /**
     * get all shapes in this panel
     * @return all shapes in a vector
     */
/* public Vector getShapes(){
   return shapes;
 }*/

    /**
     * get all connectors in this panel
     * @return all connectors in a vector
     */
 /*public Vector getConnectors(){
   return connectors;
 }*/

    /**
     * get the undo stack of this panel
     * @return the undo stack
     */
    public PounamuStack getUndoStack(){
        return undoStack;
    }

    /**
     * get the redo stack of this panel
     * @return the redo stack
     */
    public PounamuStack getRedoStack(){
        return redoStack;
    }

    /**
     * get currently selected icon of this panel
     * @return the selected icon
     */
    public JPanel getSelectedIcon(){
        return selectedIcon;
    }

    /**
     * get currently editing icon of this panel
     * @return the editing icon
     */
    public JPanel getEditingIcon(){
        return editingIcon;
    }

    /**
     * set a icon to be selected icon
     * @param icon the icon to be st as selected icon
     */
    public void setSelectedIcon(JPanel icon){
        selectedIcon = icon;
    }

    /**
     * set a icon to be editing icon
     * @param icon the icon to be st as editing icon
     */
    public void setEditingIcon(JPanel icon){
        editingIcon = icon;
    }

    /**
     * set or not set all shapes in this panel selected (highlight)
     * @param selected a boolean value
     */
    public void setAllShapesSelected(boolean selected){
        Component[] com = this.getComponents();
        //go through this array
        for(int i = 0; i < com.length; i++){
            //when the icon is a pounamu panel (shape)
            if(com[i] instanceof PounamuPanel){
                ((PounamuPanel)com[i]).setSelected(selected);
            }
        }
   /*for(int i = 0; i < shapes.size(); i++){
     ((PounamuPanel)shapes.get(i)).setSelected(selected);
   }*/
    }

/* public Hashtable getCompEditorMapping(){
   return compEditorMapping;
 }*/

/* public void addCommandListener(PounamuCommandListener object){
   commandListeners.addElement(object);
 }

 public void removeCommandListener(PounamuCommandListener object){
   commandListeners.removeElement(object);
 }

 public void notifyCommandPerformed(PounamuCommand command, int type){
   Enumeration e = commandListeners.elements();
   while(e.hasMoreElements()) {
     PounamuCommandListener listener = (PounamuCommandListener)e.nextElement();
     listener.commandPerformed(command, type);
   }
 }*/

    /**
     * add a visual event handler
     * @param object a PounamuHandler which has been registered to this panel
     */
    public void addVisualEventHandler(PounamuHandler object){
        visualEventHandlers.addElement(object);
    }

    /**
     * add a visual user handler
     * @param object a PounamuHandler which has been registered to this panel
     */
    public void addVisualUserHandler(PounamuHandler object){
        visualUserHandlers.addElement(object);
    }

    /**
     * remove a visual event handler
     * @param object a PounamuHandler which has been registered to this panel
     */
    public void removeVisualEventHandler(PounamuHandler object){
        visualEventHandlers.removeElement(object);
    }

    public void removeAllVisualEventHandlers(){
        visualEventHandlers.removeAllElements();
    }

    public Vector getVisualUserHandlers(){
        return visualUserHandlers;
    }

    /**
     * remove a visual event handler
     * @param object a PounamuHandler which has been registered to this panel
     */
    public void removeVisualUserHandler(PounamuHandler object){
        visualUserHandlers.removeElement(object);
    }

    public void removeAllVisualUserHandlers(){
        visualUserHandlers.removeAllElements();
    }


    /**
     * once a event is received by this panel, the event will be passed to all handlers registered to this panel
     * @param event the received event
     */
    public void eventReceived(PounamuEvent event){
        Enumeration e = visualEventHandlers.elements();
        while(e.hasMoreElements()) {
            PounamuHandler handler = (PounamuHandler)e.nextElement();
            //System.out.println("here handler tosating is " + handler.toString());
            ((PounamuEventTriggeringHandler)handler).eventReceived(event);
        }
    }

/* public void highLightSelectedIcon(JPanel ps){
   setSelected(false);
   setSelectedShape(ps);
   if(ps instanceof PounamuShape)
     ((PounamuShape)ps).setSelected(true);
   else
     ((PounamuConnector)ps).setSelected(true);
 }*/

    /**
     * get the xml representation of this panel
     * @return the xml string
     */
    public String getXML(){
        SaveModelViewToXML save = new SaveModelViewToXML(this);
        return save.getXML();
    }


    /**
     * a help method which changes the first letter of the string into capital letter
     * @return the changed string
     * @param s the string to be changed
     */
    protected String capitalizeFirstLetter(String s) {
        char chars[] = s.toCharArray();
        if(chars[0]>='a'&&chars[0]<='z')
            chars[0] = (char)(chars[0]-('a' - 'A'));
        return new String(chars);
    }


    /* Code added by Akhil */
    public PounamuShape getShapeByID(String id) {

        Component[] com = this.getComponents();

        for(int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuPanel){
                PounamuShape tempShape = ((PounamuPanel)com[i]).getPounamuShape();
                if( id.equals(tempShape.getRootID()))
                    return tempShape;
            }

        }

        return null;
    }

    public PounamuConnector getConnectorByID(String id) {

        Component[] com = this.getComponents();
        for(int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuConnector){
                PounamuConnector tempConnector = ((PounamuConnector)com[i]);
                if( id.equals(tempConnector.getRootID()))
                    return tempConnector;
            }
        }
        return null;
    }


    public Vector getShapes() {

        Vector shapeVector = new Vector();
        Component[] com = this.getComponents();
        for(int i = 0; i < com.length; i++){
            if(com[i] instanceof PounamuPanel){
                shapeVector.add(((PounamuPanel)com[i]));
            }
        }
        return shapeVector;

    }


    /**
     * get all connectors in this panel
     * @return all connectors in a vector
     */
    public Vector getConnectors() {

      Vector connectors = new Vector();
      Component[] com = this.getComponents();
      //go through this array and addit to the vector
      for (int i = 0; i < com.length; i++) {
        //when the icon is a pounamu panel (shape)
        if (com[i] instanceof PounamuConnector) {
          connectors.add( ( (PounamuConnector) com[i]));
        }
      }
      return connectors;
    }

    public int getNewX() {

        return newX;
    }

    public int getNewY() {

        return newY;
    }

    //added by penny
    public Object getComponentByID(String id){
      Component[] com = this.getComponents();
      for(int i = 0; i < com.length; i++){
        if(com[i] instanceof PounamuConnector){
          PounamuConnector tempConnector = ((PounamuConnector)com[i]);
          if( id.equals(tempConnector.getRootID()))
            return tempConnector;
        }
        else if(com[i] instanceof PounamuPanel){
          PounamuShape tempShape=((PounamuPanel)com[i]).getPounamuShape();
          if( id.equals(tempShape.getRootID()))
            return tempShape;
        }
        else{}
      }
      return null;
    }

}