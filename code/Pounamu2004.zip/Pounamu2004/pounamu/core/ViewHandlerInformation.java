/*
 * ViewHandlerInformation.java
 *
 * Created on 7 August 2003, 15:25
 */

package pounamu.core;
import java.util.*;
import javax.swing.*;
import pounamu.visualcomp.*;
import java.awt.event.*;
import java.awt.*;
/**
 *
 * @author  nzhu002
 */
public class ViewHandlerInformation extends JDialog {
    Vector handlers = null;
    JButton button = new JButton("ok");
    
    /** Creates a new instance of ViewHandlerInformation */
    public ViewHandlerInformation(Pounamu pounamu, Vector handlers) {
      super(pounamu, "Handler information viewer", true);
      this.handlers = handlers;
      this.getContentPane().setLayout(new VerticalFlowLayout(4));
      JTable table = new JTable(new HandlerImformationTableModel(handlers));
      table.setPreferredScrollableViewportSize(new Dimension(800, 120));
      JScrollPane scrollPane = new JScrollPane(table);
      this.getContentPane().add(scrollPane);
      JPanel panel = new JPanel();
      panel.add(button);
      this.getContentPane().add(panel);
      this.pack(); 
      button.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          ViewHandlerInformation.this.dispose();
        }
      });
    }
    
}
