/*
 * @(#)IconDisplayPanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import pounamu.visualcomp.*;
import pounamu.data.*;
import java.awt.print.PrinterJob;
import java.awt.print.*;

/**
 * Title: IconDisplayPanel
 * Description:  The panel which will be used to show icons in icon creation stage
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class IconDisplayPanel extends JPanel implements Printable{

  //PounamuXMLViewingPanel xmlPane = new PounamuXMLViewingPanel();
  Pounamu pounamu = null;
  PounamuProject project = null;
  JPanel target = null;
  String name = null;
  String xmlRepresentation = "";
  String outputPath = "";
  String fileSeperator = "";
  Vector shapes = new Vector();
  Vector connectors = new Vector();
  JPanel selectedShape = null;
  JPanel activePanel = null;
  boolean doMove=false, doBottomRight=false, doTopRight=false, doBottomLeft=false, doTopLeft=false,
          doTop=false, doBottom=false, doLeft=false, doRight=false;

/**
 * constructor: a panel to display icon in icon creation stage
 * @param pounamu the pounamu tool this panel belongs to
 * @param project the tool project this panel belongs to
 * @param target the icon to be displayed
 * @param name the name of the icon
 */
public IconDisplayPanel(Pounamu pounamu, PounamuProject project, JPanel target, String name){
  this.pounamu = pounamu;
  this.project = project;
  this.target = target;
  this.name = name;
  //Added by Penny
  this.setPreferredSize(new Dimension(600, 600));
  this.setLayout(null);
  this.setBackground(Color.white);
  fileSeperator = System.getProperty("file.separator");
  if(target instanceof PounamuConnector){
    this.outputPath = ((PounamuToolProject)project).getLocation()+fileSeperator+"icons"+fileSeperator+"connectors"+fileSeperator+getName()+".xml";
    PounamuHandle hp1 = new PounamuHandle();
    PounamuHandle hp2 = new PounamuHandle();
    hp1.setLocation(150, 270);
    hp2.setLocation(350, 270);
    this.add(hp1);
    this.add(hp2);
    ((PounamuConnector)target).setHandlers(hp1, hp2);
    this.add((PounamuConnector)target);
    ((PounamuConnector)target).setSelected(false);
    this.connectors.add((PounamuConnector)target);
    }
  else{
    this.outputPath = ((PounamuToolProject)project).getLocation()+fileSeperator+"icons"+fileSeperator+"shapes"+fileSeperator+getName()+".xml";
    this.add((PounamuPanel)target);
    ((PounamuPanel)target).setSelected(true);
    //System.out.println("finish add pounamu panel");
    this.shapes.add((PounamuPanel)target);
  }
  this.addMouseListener(new java.awt.event.MouseListener(){
    public void mouseClicked(MouseEvent e){
      whenMouseClicked(e);
    }
    public void mousePressed(MouseEvent e){
      whenMousePressed(e);
    }
    public void mouseReleased(MouseEvent e){
      whenMouseReleased(e);
    }
    public void mouseEntered(MouseEvent e){
    }
    public void mouseExited(MouseEvent e){
      whenMouseExited(e);
    }
  });
 }

  /**
   * get tool project this panel belongs to
   * @return the tool project this panel belongs to
   */
  public PounamuProject getProject(){
    return project;
  }

  /**
   * set tool project this panel belongs to
   * @param project the tool project this panel belongs to
   */
  public void setProject(PounamuProject  project){
    this.project = project;
  }

  /**
   * get pounamu tool this panel belongs to
   * @return the pounamu tool this panel belongs to
   */
  public Pounamu getPounamu(){
    return pounamu;
  }

  /**
   * set pounamu tool this panel belongs to
   * @param pouanu the pounamu tool this panel belongs to
   */
  public void setPounamu(Pounamu pounamu){
    this.pounamu = pounamu;
  }
  /**
   * get the icon being displayed
   * @return the icon being displayed
   */
  public JPanel getTarget(){
    return target;
  }

  /**
   * set the icon to be displayed
   * @param target the icon to be displayed
   */
  public void setTarget(JPanel target){
    this.target = target;
  }

  /**
   * get xml representation of the target
   * @return xml representation, in a string,  of the target
   */
  public String getXMLRepresentation(){
    SavePounamuIconToXML spst = new SavePounamuIconToXML(target);
    if(target instanceof PounamuConnector)
      return spst.generate(((PounamuConnector)target).getDisplayName());
    return spst.generate(((PounamuShape)(((PounamuPanel)target).getPounamuShape())).getDisplayName());
  }

  /**
   * set the name of the target
   * @param name for the target
   */
  public void setName(String name){
    this.name = name;
    //this.displayName = name;
  }

  /**
   * get the name of the target
   * @return the current name of the target
   */
  public String getName(){
    return name;
  }

   /**
   * get the display name of the target
   * @return the current name of the target
   */
  //public String getDisplayName(){
    //return name;
  //}


  /**
   * set output file path for this target's xml file
   * @param outputPath the full path
   */
  public void setOutputPath(String outputPath){
    this.outputPath = outputPath;
  }

  /**
   * get the file path for this target's xml file
   * @return the full path for this target's xml file
   */
  public String getOutputPath(){
    if(target instanceof PounamuConnector)
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeperator+"icons"+fileSeperator+"connectors"+fileSeperator+((PounamuConnector)target).getDisplayName()+".xml";
    else
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeperator+"icons"+fileSeperator+"shapes"+fileSeperator+((PounamuShape)(((PounamuPanel)target).getPounamuShape())).getDisplayName()+".xml";
    return outputPath;
  }

  /**
   * save the xml representation
   */
  public void save(){
    //System.out.println("in class icondisplaypanel, getOutputPath is " + getOutputPath());
    doSaveFile(getXMLRepresentation(), getOutputPath());
    //System.out.println("save finished in class icondisplaypanel, getOutputPath is " + getOutputPath());
  }

  /**
   * save the string into a file
   * @param s the string to be saved
   * @param outputPath the output file path
   */
  public void doSaveFile(String s, String outputPath){
    try{
      FileWriter fw = new FileWriter(outputPath);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(s);
      bw.flush();
      fw.close();
      //System.out.println("save finished ");
  }
    catch(Exception ee){
      pounamu.displayMessage("Exception in method doSaveFile of class IconDisplayPanel: " +ee.toString());
    }
  }

  /**
   * not applicable yet
   * @param g Graphics
   * @param pf PageFormat
   * @param pi int
   * @return 1 if print successfully
   * @throws PrinterException
   */
  public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
    if (pi >= 1) {
      return Printable.NO_SUCH_PAGE;
    }
    printChildren(g);
    return Printable.PAGE_EXISTS;
  }

  /**
   * implements mouse listener
   * @param e the MouseEvent
   */
  public void whenMousePressed(MouseEvent e) {
    Point p = e.getPoint();
      boolean inOneShape = false;
      for (int i = 0; i < shapes.size(); i++){
        if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
          selectedShape = (PounamuPanel)shapes.elementAt(i);
          setSelected(false);
          inOneShape = true;
         // selectedShape.setSelected(true);
         // tps.setTarget(((PounamuPanel)selectedShape), ((PounamuPanel)selectedShape).shortPropertiesList());
         // manager.setProperties(tps);
          break;
        }
      }
      if(inOneShape == true){
       /* ((PounamuPanel)selectedShape).whenMouseClicked(e);
        if(((PounamuPanel)selectedShape).nearBottomEdge((double)p.getX(), (double)p.getY())&&
             ((PounamuPanel)selectedShape).nearRightEdge((double)p.getX(), (double)p.getY()))
             doBottomRight=true;
        else if(((PounamuPanel)selectedShape).nearTopEdge((double)p.getX(), (double)p.getY())&&
             ((PounamuPanel)selectedShape).nearRightEdge((double)p.getX(), (double)p.getY()))
             doTopRight=true;
        else if(((PounamuPanel)selectedShape).nearBottomEdge((double)p.getX(), (double)p.getY())&&
             ((PounamuPanel)selectedShape).nearLeftEdge((double)p.getX(), (double)p.getY()))
             doBottomLeft=true;
        else if(((PounamuPanel)selectedShape).nearTopEdge((double)p.getX(), (double)p.getY())&&
             ((PounamuPanel)selectedShape).nearLeftEdge((double)p.getX(), (double)p.getY()))
             doTopLeft=true;
        else if(((PounamuPanel)selectedShape).nearLeftEdge((double)p.getX(), (double)p.getY()))
             doLeft=true;
        else if(((PounamuPanel)selectedShape).nearBottomEdge((double)p.getX(), (double)p.getY()))
             doBottom=true;
        else if(((PounamuPanel)selectedShape).nearRightEdge((double)p.getX(), (double)p.getY()))
             doRight=true;
        else if(((PounamuPanel)selectedShape).nearTopEdge((double)p.getX(), (double)p.getY()))
             doTop=true;
        else
             doMove=true;*/
      }
  }

  /**
   * implements mouse listener
   * @param e the MouseEvent
   */
  public void whenMouseReleased(MouseEvent e) {

    Point p = e.getPoint();

    /*if(doMove==true){
          ((PounamuPanel)selectedShape).doMove(e);
          doMove=false;
    }
    if(doBottomRight==true){
          ((PounamuPanel)selectedShape).doResizeFromBottomRight(e);
          doBottomRight=false;
    }
    if(doBottomLeft==true){
          ((PounamuPanel)selectedShape).doResizeFromBottomLeft(e);
          doBottomLeft=false;
    }
    if(doTopRight==true){
          ((PounamuPanel)selectedShape).doResizeFromTopRight(e);
          doTopRight=false;
    }
    if(doTopLeft==true){
          ((PounamuPanel)selectedShape).doResizeFromTopLeft(e);
          doTopLeft=false;
    }
    if(doBottom==true){
          ((PounamuPanel)selectedShape).doResizeFromBottom(e);
          doBottom=false;
    }
    if(doRight==true){
          ((PounamuPanel)selectedShape).doResizeFromRight(e);
          doRight=false;
    }
    if(doLeft==true){
          ((PounamuPanel)selectedShape).doResizeFromLeft(e);
          doLeft=false;
    }
    if(doTop==true){
          ((PounamuPanel)selectedShape).doResizeFromTop(e);
          doTop=false;
    }*/

  }

  /**
   * implements mouse listener
   * @param e the MouseEvent
   */
  public void whenMouseEntered(MouseEvent e) {}
  /**
   * implements mouse listener
   * @param e the MouseEvent
   */
  public void whenMouseExited(MouseEvent e) {}
  /**
   * implements mouse listener
   * @param e the MouseEvent
   */
  public void whenMouseClicked(MouseEvent e) {
    Point p = e.getPoint();
    boolean oneShapeSelected = false;
      for (int i = 0; i < shapes.size(); i++){
        if(((PounamuPanel)shapes.elementAt(i)).contains(p)){
          selectedShape = (PounamuPanel)shapes.elementAt(i);
          setSelected(false);
          oneShapeSelected = true;
          //((PounamuPanel)selectedShape).setSelected(true);
         // tps.setTarget(((PounamuPanel)selectedShape), ((PounamuPanel)selectedShape).shortPropertiesList());
         // manager.setProperties(tps);
          break;
        }
      }
      if(oneShapeSelected == true)
        return;
      for (int i = 0; i < connectors.size(); i++){
        if(((PounamuConnector)connectors.elementAt(i)).contains(p)){
          selectedShape = (PounamuConnector)connectors.elementAt(i);
          setSelected(false);
          //((PounamuConnector)selectedShape).setSelected(true);
          //tps.setTarget(((PounamuConnector)selectedShape), ((PounamuConnector)selectedShape).shortPropertiesList());
          //manager.setProperties(tps);
          break;
        }
      }
    this.validate();
  }

  /**
   * set icon in this panel selected
   * @param se a boolean value
   */
  public void setSelected(boolean se){
    for (int i = 0; i < connectors.size(); i++){
       //((PounamuConnector)connectors.elementAt(i)).setSelected(se);
       //tps.setTarget((PounamuConnector)connectors.elementAt(i), ((PounamuConnector)connectors.elementAt(i)).shortPropertiesList());
    }
    for (int i = 0; i < shapes.size(); i++){
       ((PounamuPanel)shapes.elementAt(i)).setSelected(se);
       //tps.setTarget((PounamuPanel)connectors.elementAt(i), ((PounamuPanel)connectors.elementAt(i)).shortPropertiesList());
    }
    this.validate();
  }

  /**
   * not applicable
   * @param activePanel not applicable
   */
  public void setActivePanel(JPanel activePanel){
    this.activePanel = activePanel;
  }

  /**
   * not applicable
   * @return not applicable
   */
  public JPanel getActivePanel(){
    return activePanel;
  }
}