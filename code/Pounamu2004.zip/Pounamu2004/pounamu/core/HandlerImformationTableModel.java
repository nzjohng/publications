/*
 * HandlerImformationTableModel.java
 *
 * Created on 7 August 2003, 13:08
 */

package pounamu.core;

import javax.swing.table.*;
import javax.swing.*;
import java.util.*;
/**
 *
 * @author  nzhu002
 */
public class HandlerImformationTableModel extends AbstractTableModel {
  final String[] columnNames = {"Handler Name", 
                                      "Responding events",
                                      "Trigger Methods",
                                      "Description",
                                      "Enabled"};
  Vector pounamuEventHandlers = null;  
    /** Creates a new instance of HandlerImformationTableModel */
  public HandlerImformationTableModel(Vector pounamuEventHandlers) {
    this.pounamuEventHandlers = pounamuEventHandlers;
  }
      
  public int getColumnCount() {
    return columnNames.length;
  }
        
  public int getRowCount() {
    return pounamuEventHandlers.size();
  }

  public String getColumnName(int col) {
    return columnNames[col];
  }

  public Object getValueAt(int row, int col) {
   /* if(row == 0){
      if(col == 0){return "Handler Name";}
      else if(col == 1){return "Responding events";}
      else if(col == 2){return "Trigger Methods";}
      else if(col == 3){return "Description";}
      else if(col == 4){return "Enabled";}
    }*/
   // else{
      PounamuHandler handler = (PounamuHandler)pounamuEventHandlers.get(row);
      if(col == 0)
        return handler.getClassName();
      else if (col == 1){
        Vector v  = handler.getRespondingEvents();
        String s = "";
        for(int i = 0; i < v.size(); i ++){
          s = s+(String)v.get(i)+", ";
        }
        if (s.equals(""))
          return "NONE";
        else        
          return s.substring(0, s.length()-2);
      }
      else if (col == 2)
        return "not applicable";
      else if (col == 3)
        return handler.getDescription();
      else if (col == 4)
        return new Boolean (handler.isEnabled());
   // }
    return null;
    
  }
        /*
         * JTable uses this method to determine the default renderer/
         * editor for each cell.  If we didn't implement this method,
         * then the last column would contain text ("true"/"false"),
         * rather than a check box.
         */
        public Class getColumnClass(int c) {
            return getValueAt(0, c).getClass();
        }

        /*
         * Don't need to implement this method unless your table's
         * editable.
         */
        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.
            if (col < 4) { 
                return false;
            } else {
                return true;
            }
        }

        /*
         * Don't need to implement this method unless your table's
         * data can change.
         */
        public void setValueAt(Object value, int row, int col) {
            if(col != 4)
              return;
           /* if(row == 0)
              return;*/
            PounamuHandler handler = (PounamuHandler)pounamuEventHandlers.get(row);
            if(value instanceof String){
              if(((String)value).toUpperCase().equals("YES"))
                handler.setEnabled(true);
              else if(((String)value).toUpperCase().equals("NO"))
                handler.setEnabled(false);
            }
            if(value instanceof Boolean){
              if(((Boolean)value).booleanValue())
                handler.setEnabled(true);
              else if(!((Boolean)value).booleanValue())
                handler.setEnabled(false);
            }               
        }

        
}
