/*
 * @(#)RedoListPanel.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import pounamu.command.*;
/**
 * Title: RedoListPanel
 * Description:  A panel to show undoable actions history list
 * Copyright:    Copyright (c) 2002
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class RedoListPanel extends JPanel{
  PounamuStack redoModel = new PounamuStack();
  JList redoList = new JList(redoModel);
  PounamuStack undoModel = new PounamuStack();
  JScrollPane jsp = new JScrollPane(redoList);

  JButton redoLatest = new JButton("redo latest");
  JButton redoSelected = new JButton("redo selected");
  JButton deleteSelected = new JButton("delete selected");
  JButton deleteAll = new JButton("delete all");

  /**
   * constructor
   * i) init a button panel which contains four buttons used to controll this list
   * ii) init the redo list
   */
  public RedoListPanel(){
    super();
    JPanel buttonPanel = new JPanel();
    redoLatest.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doRedoLatest();
      }
    });
    redoSelected.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doRedoSelected();
      }
    });
    deleteSelected.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doDeleteSelected();
      }
    });
    deleteAll.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        doDeleteAll();
      }
    });
    buttonPanel.add(redoLatest);
    buttonPanel.add(redoSelected);
    buttonPanel.add(deleteSelected);
    buttonPanel.add(deleteAll);
    this.setLayout(new BorderLayout());
    redoList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    this.add(buttonPanel, BorderLayout.NORTH);
    this.add(jsp, BorderLayout.CENTER);
  }

  /**
   * set the redo list model
   * @param model the redo list list model
   */
  public void setRedoListModelForRedoListPanel(PounamuStack model){
    redoList.setModel(model);
    redoModel = model;
    this.validate();
  }

  /**
   * set the undo list model for this redo list
   * @param model the undo list model
   */
  public void setUndoListModelForRedoListPanel(PounamuStack model){
    undoModel = model;
  }

  /**
   * undo the last command in the command history which is shown on the top of this list
   */
  public void doRedoLatest(){
    if(redoModel.isEmpty())
      return;
    PounamuCommand pc = redoModel.pop();
    pc.redo();
    undoModel.push(pc);
    this.validate();
  }

  /**
   * undo the selected command(s)
   */
  public void doRedoSelected(){
    if(redoModel.isEmpty())
      return;
    Object[] temp = redoList.getSelectedValues();
    for(int i = 0; i < temp.length; i++){
      String s = (String)temp[i];
      PounamuCommand pc = redoModel.getCommandObject(s);
      if(redoModel.removeElement(s))
        redoModel.removeEntry(s);
      pc.redo();
      undoModel.push(pc);
    }
    this.validate();
  }

  /**
   * delete the selected command from the command history list
   */
  public void doDeleteSelected(){
    if(redoModel.isEmpty())
      return;
    Object[] temp = redoList.getSelectedValues();
    for(int i = 0; i < temp.length; i++){
      String s = (String)temp[i];
      if(redoModel.removeElement(s))
        redoModel.removeEntry(s);
    }
    this.validate();
  }

  /**
   * delete all entries in this command history list
   */
  public void doDeleteAll(){
    if(redoModel.isEmpty())
      return;
    redoModel.removeAllElements();
    redoModel.removeAllEntries();
    this.validate();
  }
}

