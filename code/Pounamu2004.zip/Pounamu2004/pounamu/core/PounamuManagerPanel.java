/*
 * @(#)PounamuManagerPanel.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;
import java.io.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;
import pounamu.plugins.collaborate.*;
import pounamu.plugins.ThinClientAccess.ThinClientEditing;

/**
 * Title: PounamuManagerPanel
 * Description:  A panel that manager the project the user is working with
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class PounamuManagerPanel extends JPanel implements TreeSelectionListener, MouseListener{

    /**
     * refer to the working instance of the Pouanmu tool
     */
    Pounamu pounamu = null;
    PounamuProject project = null;
    Hashtable registeredTools = new Hashtable();
    //Hashtable openedTools = new Hashtable();
    Hashtable openedModels = new Hashtable();
    /**
     * the model for this manager tree
     */
    DefaultTreeModel treeModel = null;
    /**
     * the manager tree
     */
    JTree managerTree = null;
    /**
     * the selected tree node
     */
    DefaultMutableTreeNode selectedNode = null;
    DefaultMutableTreeNode previousSelectedNode = new DefaultMutableTreeNode("previousNode");
    DefaultMutableTreeNode toolProjectNode = null;
    DefaultMutableTreeNode modelProjectNode = null;
    Hashtable nodeAndProjectMapping = new Hashtable();
    Hashtable nodeAndMenuItemsMapping = new Hashtable();
    Hashtable nodeAndToolButtonsMapping = new Hashtable();
    Hashtable nodeAndItsValueMapping = new Hashtable();
    Hashtable toolProjectNodeAndToolNodeUnderModelProjectMapping = new Hashtable();
    PounamuToolProject currentTool = null;
    int modelProjectCount = 0;
    int toolProjectCount = 0;
    String fileSeparator = null;
    /**
     * the constructor
     * @param pounamu the tool which uses ths panel
     */
    public PounamuManagerPanel(){};

    /**
     * the  constructor
     * @param pounamu the Pouanmu working instance
     */
    public PounamuManagerPanel(Pounamu pounamu){
        this.pounamu = pounamu;
        fileSeparator = System.getProperty("file.separator");
        initRegisteredTools();
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("pounamu");
        nodeAndItsValueMapping.put(root, "pounamu");
        toolProjectNode = new DefaultMutableTreeNode("tool projects");
        nodeAndItsValueMapping.put(toolProjectNode, "tool projects");
        root.add(toolProjectNode);
        modelProjectNode = new DefaultMutableTreeNode("model projects");
        nodeAndItsValueMapping.put(modelProjectNode, "model projects");
        root.add(modelProjectNode);
        treeModel = new DefaultTreeModel(root);
        managerTree = new JTree(treeModel);
        //treeModel.addTreeModelListener(this);
        managerTree.setCellRenderer(new PounamuTreeCellRenderer(this));
        ToolTipManager.sharedInstance().registerComponent(managerTree);
        managerTree.setRootVisible(true);
        managerTree.getSelectionModel()
        .setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        managerTree.setShowsRootHandles(true);
        managerTree.setEditable(true);
        managerTree.setPreferredSize(new Dimension(2000, 4000));
        managerTree.setBorder(BorderFactory.createEmptyBorder());
        nodeAndMenuItemsMapping.put(root, initMenuItemsForRoot());
        nodeAndToolButtonsMapping.put(root, initToolButtonsForRoot());
        nodeAndMenuItemsMapping.put(toolProjectNode, initMenuItemsForToolProjectNode());
        nodeAndToolButtonsMapping.put(toolProjectNode, initToolButtonsForToolProjectNode());
        nodeAndMenuItemsMapping.put(modelProjectNode, initMenuItemsForBaseModelProjectNode());
        //nodeAndMenuItemsMapping.put(modelProjectNode, new Vector());
        nodeAndToolButtonsMapping.put(modelProjectNode, new Vector());
        managerTree.addMouseListener(this);
        managerTree.addTreeSelectionListener(this);
        managerTree.getModel().addTreeModelListener(new PounamuTreeModelListener(this));
        managerTree.setSelectionRow(0);
        this.add(managerTree);
        this.setBackground(Color.white);
    }

    /**
     * set the node for tool project manager
     * @param toolProjectNode the node for tool project manager
     */
    public void setToolProjectNode(DefaultMutableTreeNode toolProjectNode){
        this.toolProjectNode = toolProjectNode;
    }

    /**
     * set the node for model project manager
     * @param toolProjectNode the node for tool project manager
     */
    public void setModelProjectNode(DefaultMutableTreeNode modelProjectNode){
        this.modelProjectNode = modelProjectNode;
    }

    /**
     * get the node for tool project manager
     * @return toolProjectNode the node for tool project manager
     */
    public DefaultMutableTreeNode getToolProjectNode(){
        return toolProjectNode;
    }

    /**
     * get the node for model project manager
     * @return toolProjectNode the node for model project manager
     */
    public DefaultMutableTreeNode getModelProjectNode(){
        return modelProjectNode;
    }

    public Hashtable getNodeAndToolButtonsMapping(){
        return nodeAndToolButtonsMapping;
    }

    public Hashtable getNodeAndMenuItemsMapping(){
        return nodeAndMenuItemsMapping;
    }

    public Hashtable getNodeAndItsValueMapping(){
        return nodeAndItsValueMapping;
    }

    /**
     * get previously registered tools from pounamu property
     */
    public void initRegisteredTools(){
    /*registeredTools.removeAllElements();
    StringTokenizer st = new StringTokenizer((String)pounamu.properties.get("tools"), ",");
    while(st.hasMoreTokens()){
      registeredTools.add(st.nextToken());
    }*/
    }

    /**
     * get pounamu working instance
     * @return pounamu working instance
     */
    public Pounamu getPounamu(){
        return pounamu;
    }

    /**
     * get the current tool project
     * @return the current tool project
     */
    public PounamuToolProject getCurrentTool(){
        return currentTool;
    }

    /**
     * set the current tool project
     * @param tool the current tool project
     */
    public void  setCurrentTool(PounamuToolProject tool){
        this.currentTool = tool;
    }

    /**
     * get manager tree in this panel
     * @return the manager tree
     */
    public JTree getManagerTree(){
        return managerTree;
    }

    /**
     * get the project indexed by the specified node
     * @param node the index node
     * @return the project indexed by the specified node
     */
    public PounamuProject getProject(DefaultMutableTreeNode node){
        return (PounamuProject)nodeAndProjectMapping.get(node);
    }

    /**
     * get user object from a node in manager tree
     * @param node the manager tree node
     * @return the  user object which is a string
     */
    public String getStringFromNode(DefaultMutableTreeNode node){
        return (String)node.getUserObject();
    }

    public Hashtable getToolProjectNodeAndToolNodeUnderModelProjectMapping(){
        return toolProjectNodeAndToolNodeUnderModelProjectMapping;
    }


    /**
     * get all registered tools
     * @return all registered tools in a vector
     */
    public Hashtable getRegisteredTools(){
        return registeredTools;
    }

    /**
     * get all opened tools
     * @return the opened tools in a hashtable with the name of the tool as a key
     */
  /*public Hashtable getOpenedTools(){
    return openedTools;
  }*/

    /**
     * get all opened models
     * @return all opened models in a hashtable with the name of the model as a key
     */
    public Hashtable getOpenedModels(){
        return openedModels;
    }

    public void doCloseAllModelProjects(DefaultMutableTreeNode dmtn){
    }
    /**
     * register the tool with the specified name
     * @param name the tool name
     */
    public void registerTool(String name, PounamuToolProject tool){
        //if there is a opened model using this tool, reload the properties for this model
        for (Enumeration e = getOpenedModels().keys(); e.hasMoreElements() ;) {
            String key = (String)e.nextElement();
            //System.out.println("key is " + key);
            PounamuModelProject pmp = (PounamuModelProject)getOpenedModels().get(key);
            //System.out.println("tool name is " + pmp.getToolName());
            //System.out.println("name is " + name);
            if(pmp.getToolName().equals(name)){
                //System.out.println("here is what");
                pmp.getTool().reloadProperties();
                //System.out.println("here is what !");
                pmp.re_registerVisualEventHandlers();
                pmp.re_registerVisualUserHandlers();
                //System.out.println("here is what !!");
            }
            //System.out.println(e.nextElement());
        }

        if(registeredTools.containsKey(name)){
            return;
        }
        registeredTools.put(name, tool);
        String s = (String)pounamu.properties.get("tools");
        s = s + ","+name;
        pounamu.properties.put("tools", s);
        MaintainFileSystem cf  = new MaintainFileSystem("\""+pounamu.getPounamuHome()+fileSeparator+"models"+fileSeparator+"using_"+name+"\"", pounamu, "createfolder");
        //new Thread(cf).start();
        cf.run();
    }

    /**
     * get the popup menu for the specified tree node
     * @param node a tree node
     * @return the popup menu for the specified tree node
     */
    public JPopupMenu getPopupMenu(DefaultMutableTreeNode node){
        Vector menuItems = null;
        PounamuProject project = getProject(node);
        if(project == null){
            //System.out.println("here visited");
            menuItems = (Vector)nodeAndMenuItemsMapping.get(node);
        }
        else
            menuItems = project.getMenuItems(node);
        JPopupMenu popup = new JPopupMenu();
        for(int i = 0; i < menuItems.size(); i++){
            if(menuItems.elementAt(i)!=null){
                JMenuItem item = (JMenuItem)menuItems.elementAt(i);
                item.setVisible(true);
                popup.add(item);
            }
            else
                popup.addSeparator();
        }
        return popup;
    }

    /**
     * get selected node
     * @return selected node
     */
    public DefaultMutableTreeNode getSelectedNode(){
        return selectedNode;
    }

    /**
     * set selected node
     * @param selectedNode the node to be selected
     */
    public void setSelectedNode(DefaultMutableTreeNode selectedNode){
        this.selectedNode = selectedNode;
        TreePath tp = new TreePath(selectedNode.getPath());
        getManagerTree().setSelectionPath(tp);
    }



    /**
     * display any runtime messages or exceptions
     * @param info the information to be shown
     */
    public void displayMessage(String info){
        pounamu.displayMessage(info);
    }


    /**
     * add an object as a tree node to the current selectd node
     * @param child the object to be aded as a tree node
     * @return the child node
     */
    public DefaultMutableTreeNode addObject(Object child){
        DefaultMutableTreeNode parentNode = null;
        TreePath parentPath = managerTree.getSelectionPath();
        if(parentPath == null){
            //parentNode = getNode(project.getName());
        }
        else{
            parentNode = (DefaultMutableTreeNode)(parentPath.getLastPathComponent());
        }
        return addObject(parentNode, child);
    }

    /**
     * add an object as a tree node to the parent node
     * @param parent the parent node
     * @param child the object to be aded as a tree node
     * @return the child node
     */
    public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent, Object child){
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);
        int i;
        for(i = 0; i < parent.getChildCount(); i++){
            DefaultMutableTreeNode temp = (DefaultMutableTreeNode)parent.getChildAt(i);
            String s = (String)temp.getUserObject();
            if(s.compareTo(child)>0)
                break;
        }
        treeModel.insertNodeInto(childNode, parent, i);
        managerTree.scrollPathToVisible(new TreePath(childNode.getPath()));
        return childNode;
    }

    /**
     * add the specified tree node to the current selected node
     * @param childNode the node to be added
     */
    public void addTreeNode(DefaultMutableTreeNode childNode){
        String childString = (String)childNode.getUserObject();
        DefaultMutableTreeNode parentNode = null;
        TreePath parentPath = managerTree.getSelectionPath();
        if(parentPath == null){
            if(getSelectedNode() != null)
                parentNode = getSelectedNode();
            else
                return;
        }
        else{
            parentNode = (DefaultMutableTreeNode)(parentPath.getLastPathComponent());
        }
        int i;
        for(i = 0; i < parentNode.getChildCount(); i++){
            DefaultMutableTreeNode temp = (DefaultMutableTreeNode)parentNode.getChildAt(i);
            String s = (String)temp.getUserObject();
            if(s.compareTo(childString)>0)
                break;
        }
        if(treeModel!=null){
            if(childNode!=null){
                if(parentNode !=null){
                    treeModel.insertNodeInto(childNode, parentNode, i);
                }
            }
        }
        managerTree.scrollPathToVisible(new TreePath(childNode.getPath()));
    }

    /**
     * add the specified tree node to a specified node
     * @param childNode the node to be added
     */
    public void addTreeNode(DefaultMutableTreeNode parentNode, DefaultMutableTreeNode childNode){
        String childString = (String)childNode.getUserObject();
        int i;
        for(i = 0; i < parentNode.getChildCount(); i++){
            DefaultMutableTreeNode temp = (DefaultMutableTreeNode)parentNode.getChildAt(i);
            String s = (String)temp.getUserObject();
            if(s.compareTo(childString)>0)
                break;
        }
        if(treeModel!=null){
            if(childNode!=null){
                if(parentNode !=null){
                    treeModel.insertNodeInto(childNode, parentNode, i);
                }
            }
        }
        managerTree.scrollPathToVisible(new TreePath(childNode.getPath()));
    }

    /**
     * Remove the currently selected node.
     */
    public void removeCurrentNode() {
        TreePath currentSelection = managerTree.getSelectionPath();
        if (currentSelection != null) {
            DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode)
            (currentSelection.getLastPathComponent());
            MutableTreeNode parent = (MutableTreeNode)(currentNode.getParent());
            if (parent != null) {
                treeModel.removeNodeFromParent(currentNode);
                return;
            }
        }
    }

    /**
     * Remove the specified tree node from the manager tree.
     */
    public void removeTreeNode(DefaultMutableTreeNode node) {
        if(node == null)
            return;
        if (node.getParent() != null)
            treeModel.removeNodeFromParent(node);
    }


    /**
     * prepare menu items for the root of the tree
     * @return menu items for the root of the tree
     */
    public Vector initMenuItemsForRoot(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("configure this tool");
        //jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                Configuration configuration = new Configuration(pounamu);
                configuration.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("exit right now");
        //jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                pounamu.dispose();
                System.exit(0);
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    /**
     * prepare menu items for the root of the tree
     * @return menu items for the root of the tree
     */
    public Vector initToolButtonsForRoot(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("configure this tool");
        jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                Configuration configuration = new Configuration(pounamu);
                configuration.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("exit right now");
        jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                pounamu.dispose();
                System.exit(0);
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    /**
     * prepare menu items for the node of tool project manager
     * @return menu items for the node of tool project manager
     */
    public Vector initMenuItemsForToolProjectNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("new tool project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doNewToolProject();
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("open existed tool project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenToolProject();
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("close all tool projects");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseAllToolProjects(getSelectedNode());
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }


    /**
     * prepare menu items for the node of tool project manager
     * @return menu items for the node of tool project manager
     */
    public Vector initToolButtonsForToolProjectNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("new tool project");
        jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doNewToolProject();
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("open existed tool project");
        jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenToolProject();
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("close all tool projects");
        jmi.setToolTipText("function: " + jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseAllToolProjects(getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    //original Akhil's code
    /**
     * prepare menu items for the node of model project manager
     * @return menu items for the node of model project manager
     */

    public Vector initMenuItemsForBaseModelProjectNode(){

        Vector menuItems = new Vector();
        final PounamuManagerPanel thisRef = this;

        JMenuItem jmi = new JMenuItem("Add Collaborative Editing");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                CollaborativeEditing instance = CollaborativeEditing.getCollabrativePluginInstance();
                instance.addCollaborativeEditing(thisRef);
            }
        });
        menuItems.add(jmi);

        jmi = new JMenuItem("Remove Collaborative Editing");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doNewToolProject();
                CollaborativeEditing instance = CollaborativeEditing.getCollabrativePluginInstance();
                instance.removeCollaborativeEditing(thisRef);
            }
        });
        menuItems.add(jmi);

        //Added by Penny
        jmi = new JMenuItem("Add thin-client editing");
        jmi.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent ev){
            ThinClientEditing instance = ThinClientEditing.getThinClientPluginInstance();
            instance.addThinclientEditing(thisRef);
          }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("Remove thin-client editing");
        jmi.addActionListener(new ActionListener(){
          public void actionPerformed(ActionEvent ev){
            //doNewToolProject();
            ThinClientEditing instance = ThinClientEditing.getThinClientPluginInstance();
            instance.removeThinclientEditing(thisRef);
          }
        });
        menuItems.add(jmi);
        return menuItems;
      }


   //Added by Penny
  /**
   * prepare menu items for the node of model project manager
   * @return menu items for the node of model project manager
   */
  /*
  public Vector initMenuItemsForBaseModelProjectNode(){

    Vector menuItems = new Vector();
    final PounamuManagerPanel thisRef = this;

    JMenuItem jmi = new JMenuItem("Add thin-client editing");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ThinClientEditing instance = ThinClientEditing.getThinClientPluginInstance();
        instance.addThinclientEditing(thisRef);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("Remove thin-client editing");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doNewToolProject();
        ThinClientEditing instance = ThinClientEditing.getThinClientPluginInstance();
        instance.removeThinclientEditing(thisRef);
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
*/


    /**
     * create  a new tool project
     */
    public void doNewToolProject(){
        String name = "tool"+toolProjectCount;
        while(registeredTools.contains(name)){
            toolProjectCount++;
            name = "tool"+toolProjectCount;
        }
        toolProjectCount++;
        String lo = pounamu.getPounamuHome()+fileSeparator+"tools"+fileSeparator+""+name;
        PounamuToolProject tool = new PounamuToolProject(this, name, lo, "");
        tool.doRegisterToolProject(tool.getProjectNode());
        pounamu.displayMessage("the new tool project named " + name + " has been created!");
    }

    /**
     * open an existed project tool
     */
    public void doOpenToolProject(){
        File inputFile = null;
        pounamu.getFileChooser().setCurrentDirectory(new File((String)pounamu.getProperties().get("pounamu")+""+fileSeparator+"tools"));
        pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
        int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
        if(returnVal == JFileChooser.APPROVE_OPTION){
            inputFile = pounamu.getFileChooser().getSelectedFile();
        }
        else return;
        String fileName = inputFile.getName();
        if(!fileName.endsWith(".xml")){
            pounamu.displayMessage("The tool you chose is not a proper tool file! Please try another one!\n");
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        String name = fileName.substring(0, fileName.indexOf("."));

        //Changed by Penny
        if(registeredTools.containsKey(name)){
            pounamu.displayMessage("The tool you chose is currently opened\n");
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuToolProject tool = new PounamuToolProject(this, lxf.getDocument());

        //added by Penny
        registeredTools.put(name, tool);
        tool.doRegisterToolProject(tool.getProjectNode());
        pounamu.displayMessage("the tool project named " + name + " has been opened!");
    }


    /**
     * open an tool project with the specified name
     * @param name the name of the tool project
     * @return true if the project opened successfully
     */
    public boolean doOpenToolProject(String name){
        File inputFile = new File((String)pounamu.getProperties().get("pounamu")+""+fileSeparator+"tools"+fileSeparator+""+name+""+fileSeparator+""+name+".xml");
        if(inputFile.exists()){
            LoadXMLFile lxf = new LoadXMLFile(inputFile);
            PounamuToolProject tool = new PounamuToolProject(this, lxf.getDocument());
            registeredTools.put(name, tool);
            pounamu.displayMessage("the tool project named " + name + " has been opened!");
            //added by Penny
            tool.doRegisterToolProject(tool.getProjectNode());
            return true;
        }
        else{
            pounamu.displayMessage("The corresponding xml file for the tool " + name +" does not exist. new model project can not be created. Please choose another tool");
            Toolkit.getDefaultToolkit().beep();
            return false;
        }
    }

    /**
     * close all tool projects
     */
    public void doCloseAllToolProjects(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i);
            PounamuToolProject tool = (PounamuToolProject)getNodeAndProjectMapping().get(temp);
            //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
            tool.doDeregisterToolProject(temp);
        }
    }


    //Added by Penny
    public String getSystemDirectoryForTools(){
      //String fileSeparator = System.getProperty("file.separator");
      String lo = pounamu.getPounamuHome() + "" + fileSeparator + "tools";
      return lo;
    }

    public String getSystemDirectoryForModels(){
      String lo = pounamu.getPounamuHome()+fileSeparator+"models";
      return lo;
    }

    /**
     * prepare menu items for the node of model project manager
     * @return menu items for the node of modle project manager
     */
    public Vector initMenuItemsForModelProjectNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("new model project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doNewModelProject();
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("open existed model project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenModelProject();
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("close all Model Projects");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseAllModelProjects();
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    /**
     * prepare menu items for the node of model project manager
     * @return menu items for the node of modle project manager
     */
    public Vector initToolButtonsForModelProjectNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("new model project");
        jmi.setToolTipText("function: "+jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doNewModelProject();
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("open existed model project");
        jmi.setToolTipText("function: "+jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenModelProject();
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("close all Model Projects");
        jmi.setToolTipText("function: "+jmi.getText());
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseAllModelProjects();
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }


    /**
     * create a new model project
     */
    public void doNewModelProject(){
        String s = (String)getSelectedNode().getUserObject();
        String toolName = s.substring(6);
    /*if(!getRegisteredTools().containsKey(toolName)){
      TreePath oldPath = getManagerTree().getSelectionPath();
      TreePath tp = new TreePath(getToolProjectNode().getPath());
      getManagerTree().setSelectionPath(tp);
      if(doOpenToolProject(toolName) == false)
        return;
      //tp = new TreePath(manager.getModelProjectNode().getPath());
      getManagerTree().setSelectionPath(oldPath);
    }*/
        PounamuToolProject tool = (PounamuToolProject)getRegisteredTools().get(toolName);
        setCurrentTool(tool);
        String name = "model"+modelProjectCount;
        while(openedModels.containsKey(name)){
            modelProjectCount++;
            name = "model"+modelProjectCount;
        }
        modelProjectCount++;
        String lo = pounamu.getPounamuHome()+fileSeparator+"models"+fileSeparator+"using_"+toolName+fileSeparator+name;
        PounamuModelProject project = new PounamuModelProject(this, name, lo, "", toolName);
        openedModels.put(name, project);
        pounamu.displayMessage("the new model project named " + "project"+modelProjectCount + " using "+toolName+" has been created!");

    }

    /**
     * open an exoisted model project
     */
    public void doOpenModelProject(){
        File inputFile = null;
        pounamu.getFileChooser().setCurrentDirectory(new File((String)pounamu.getProperties().get("pounamu")+""+fileSeparator+"models"));
        pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
        int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
        if(returnVal == JFileChooser.APPROVE_OPTION){
            inputFile = pounamu.getFileChooser().getSelectedFile();
        }
        else return;
        String fileName = inputFile.getName();
        if(!fileName.endsWith(".xml")){
            pounamu.displayMessage("The model you chose is not a xml file! Please try another one!\n");
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        String namee = fileName.substring(0, fileName.indexOf("."));
        if(openedModels.containsKey(namee)){
            pounamu.displayMessage("The model you chose is currently opened\n");
            Toolkit.getDefaultToolkit().beep();
            return;
        }
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuModelProject model = new PounamuModelProject(this, lxf.getDocument());
        openedModels.put(namee, model);
        pounamu.displayMessage("the model project named " + namee + " has been opened!");
    }

    /**
     * close all opened model projects
     */
    public void doCloseAllModelProjects(){}

    /**
     * get the mappings from a tree node to a project
     * @return the mappings from a tree node to a project in a hashtable
     */
    public Hashtable getNodeAndProjectMapping(){
        return nodeAndProjectMapping;
    }

    public void setRegisteredSign(){
        if(previousSelectedNode == null)
            return;
        String s = "";
        PounamuToolProject tool = null;
        PounamuModelProject model = null;
        if(nodeAndProjectMapping.get(previousSelectedNode) != null){
            if(nodeAndProjectMapping.get(previousSelectedNode) instanceof PounamuToolProject){
                tool = (PounamuToolProject)nodeAndProjectMapping.get(previousSelectedNode);
                s = (String)tool.getNodeAndRegisteredXMLStringMapping().get(previousSelectedNode);
            }//locate previously selected tool
            else if(nodeAndProjectMapping.get(previousSelectedNode) instanceof PounamuModelProject){
                model = (PounamuModelProject)nodeAndProjectMapping.get(previousSelectedNode);
                s = (String)model.getNodeAndSavedXMLStringMapping().get(previousSelectedNode);
            }//locate previously selected model
            else{}
        }
        if(tool != null && s != null){//previous node has a corresponding tool
            if(tool.getEntityTypeObject(previousSelectedNode) != null ||
            tool.getAssociationTypeObject(previousSelectedNode) != null){//previous node is a node for entity type
                PounamuMetaModelElement pmme = null;
                if(tool.getEntityTypeObject(previousSelectedNode) != null)
                    pmme = (PounamuMetaModelElement)tool.getEntityTypeObject(previousSelectedNode);
                else
                    pmme = (PounamuMetaModelElement)tool.getAssociationTypeObject(previousSelectedNode);
                if(!s.equals(pmme.getXMLRepresentation())){//something changed since last registered
                    if(pmme.isRegistered())
                        pmme.setWasRegistered(true);
                    pmme.setRegistered(false);
                    PounamuView view = (PounamuView)tool.getView(previousSelectedNode);
                    if(view.isRegistered())
                        view.setWasRegistered(true);
                    view.setRegistered(false);
                    if(tool.isRegistered())
                        tool.setWasRegistered(true);
                    tool.setRegistered(false);
                }
            }
            else if(tool.getView(previousSelectedNode) != null){//previous node has a corresponding view
                PounamuView view = (PounamuView)tool.getView(previousSelectedNode);
                if(!s.equals(view.getXMLRepresentation())){//something changed since last registered

                    if(view.isRegistered())
                        view.setWasRegistered(true);
                    view.setRegistered(false);
                    if(tool.isRegistered())
                        tool.setWasRegistered(true);
                    tool.setRegistered(false);
                }
            }
            else{
                if(s != null){//previous node is a node of tool node
                    if(!s.equals(tool.getXMLRepresentation())){
                        if(tool.isRegistered())
                            tool.setWasRegistered(true);
                        tool.setRegistered(false);
                    }
                }
            }
        }
        if(model != null && s != null){
            if(model.getEntity(previousSelectedNode)!= null||
            model.getAssociation(previousSelectedNode)!= null){
                PounamuModelElement pme = null;
                if(model.getEntity(previousSelectedNode)!= null)
                    pme = (PounamuModelElement)model.getEntity(previousSelectedNode);
                else
                    pme = (PounamuModelElement)model.getAssociation(previousSelectedNode);
                if(!s.equals(pme.getXMLRepresentation())){
                    if(pme.isSaved())
                        pme.setWasSaved(true);
                    pme.setSaved(false);
                    PounamuView view = (PounamuView)model.getView(previousSelectedNode);
                    if(view.isSaved())
                        view.setWasSaved(true);
                    view.setSaved(false);
                    if(model.isSaved())
                        model.setWasSaved(true);
                    model.setSaved(false);
                }
            }
            else if(model.getView(previousSelectedNode) != null){//previous node has a corresponding view
                PounamuView view = (PounamuView)model.getView(previousSelectedNode);
                if(!s.equals(view.getXMLRepresentation())){//something changed since last registered
                    if(view.isSaved())
                        view.setWasSaved(true);
                    view.setSaved(false);
                    if(model.isSaved())
                        model.setWasSaved(true);
                    model.setSaved(false);
                }
            }
            else{//previous node is a node of tool node
                if(!s.equals(model.getXMLRepresentation())){
                    if(model.isSaved())
                        model.setWasSaved(true);
                    model.setSaved(false);
                }
            }
        }
        getManagerTree().repaint();
        previousSelectedNode = null;
    }
     /*
      else if(nodeAndProjectMapping.get(previousSelectedNode) instanceof PounamuModelProject){
        PounamuModelProject model = (PounamuModelProject)nodeAndProjectMapping.get(previousSelectedNode);
        model.updateStates(previousSelectedNode);
        if(!(model.getView(previousSelectedNode) == null)){
          PounamuView pv  = model.getView(previousSelectedNode);
          pv.updateStates(previousSelectedNode);
        }
        if(model.getEntity(previousSelectedNode)!= null){
          PounamuModelElement pme = (PounamuModelElement)model.getEntity(previousSelectedNode);
          pme.updateStates(previousSelectedNode);
        }
        else if(model.getAssociation(previousSelectedNode)!= null){
          PounamuModelElement pme = (PounamuModelElement)model.getAssociation(previousSelectedNode);
          pme.updateStates(previousSelectedNode);
        }
        else()
      }
      else{}
    }*/

    /**
     * implements tree selection listener
     * @param e the tree selection event
     */
    public void valueChanged(TreeSelectionEvent e){

        //get Selected path
        TreePath selectedPath = e.getNewLeadSelectionPath();
        //if nothing selected, just return
        if(selectedPath == null)
            return;
        //get selected node
        selectedNode = (DefaultMutableTreeNode)selectedPath.getLastPathComponent();
        setRegisteredSign();
        //prepare dynamic menu for this selected node
        prepareDynamicMenu();
        //if new selected project is not the current project
        if(getProject(selectedNode)!= project){
            //and if the new selected project do not existed, then no project tab will be selected
            if(getProject(selectedNode) == null){
                project = null;
                pounamu.setProjectTab(null);
                pounamu.setPropertyPanel(null);
                return;
            }
            //otherwise, assign the selected project as the current project
            project = getProject(selectedNode);
            //and set the project tab (show tabed pane of the selected project in the mian diaplaying area
            pounamu.setProjectTab(project.getProjectTab());
        }


        //if the current projact does not existed, just return
        if(project == null)
            return;
        //then if the current project existed, the project tabbed pane select the views tabbed pane corresponding to the selected node
        if(project.getViewsTab(selectedNode) != null){
            PounamuTabbedPane tabP = (PounamuTabbedPane)project.getProjectTab();
            tabP.setProject(null);
            //project.getProjectTab().setSelectedComponent(project.getViewsTab(selectedNode));
            tabP.setSelectedComponent(project.getViewsTab(selectedNode));
            tabP.setProject(project);
        }
        //if the view corresponding to the selected node existed, the selectd views tabbed pane select the selected view
        if(project.getView(selectedNode) != null){
            PounamuTabbedPane tabP = (PounamuTabbedPane)project.getViewsTab(selectedNode);
            tabP.setProject(null);
            //project.getViewsTab(selectedNode).setSelectedComponent(project.getView(selectedNode).getDisplayPanel());
            tabP.setSelectedComponent(project.getView(selectedNode).getDisplayPanel());
            tabP.setProject(project);
        }
        //now begin to select the property panel logic
        //if the object corresponding to the selected node is a component (PounamuShapePrimetive, PounamuLable,,,etc)
        if(project.getComponent(selectedNode) != null){
            Component c = project.getComponent(selectedNode);
            PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(c);
            pounamu.setPropertyPanel(pcs);
        }
        //if the selected view has a IconDisplayPanel
        else if(project.getView(selectedNode) != null &&
        project.getView(selectedNode).getDisplayPanel() instanceof IconDisplayPanel){
            //if the target of the selected IconDisplayPanel is a PounamuConnector
            if(((IconDisplayPanel)project.getView(selectedNode).getDisplayPanel()).getTarget() instanceof PounamuConnector){
                PounamuConnector pc =  (PounamuConnector)((IconDisplayPanel)project.getView(selectedNode).getDisplayPanel()).getTarget();
                PounamuConnectorSpecifier pce = new PounamuConnectorSpecifier(pc);
                pounamu.setPropertyPanel(pce);
            }
            //then  the taget must be a PounamuShape
            else{
                PounamuShapeSpecifier pss = new PounamuShapeSpecifier((IconDisplayPanel)project.getView(selectedNode).getDisplayPanel());
                pounamu.setPropertyPanel(pss);
            }
        }
        //selected item is a node for entity type object
        else if (project.getEntityTypeObject(selectedNode) != null){
            //PounamuMetaModelElement pmme = (PounamuMetaModelElement)project.getEntityTypeObject(selectedNode);
            PounamuMetaModelElementSpecifier pmmes = new PounamuMetaModelElementSpecifier(project.getIcon(selectedNode), project.getView(selectedNode));
            pounamu.setPropertyPanel(pmmes);
            PounamuPanel shape =(PounamuPanel)project.getNodeAndIconMapping().get(selectedNode);
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            shape.setSelected(true);
            //if(!(panel.getState().equals("select"))&&!(panel.getState().equals("edit")))
            panel.setState("select");
        }
        //selected item is a node for association type object
        else if (project.getAssociationTypeObject(selectedNode) != null){
            PounamuMetaModelElement pmme = (PounamuMetaModelElement)project.getAssociationTypeObject(selectedNode);
            PounamuMetaModelElementSpecifier pmmes = new PounamuMetaModelElementSpecifier(pmme, project.getView(selectedNode));
            pounamu.setPropertyPanel(pmmes);
            PounamuPanel shape =(PounamuPanel)project.getNodeAndIconMapping().get(selectedNode);
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            shape.setSelected(true);
            //if(!(panel.getState().equals("select"))&&!(panel.getState().equals("edit")))
            panel.setState("select");
        }
        //selected item is a node for entity object
        else if (project.getEntity(selectedNode) != null){
            PounamuPanel shape =(PounamuPanel)(((PounamuModelProject)project).getIcon(selectedNode));
            PounamuView view = project.getView(selectedNode);
            PounamuEntitySpecifier pmes = new PounamuEntitySpecifier(shape.getPounamuShape(), project.getView(selectedNode));
            pounamu.setPropertyPanel(pmes);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            shape.setSelected(true);
            panel.setState("select");
        }
        //selected item is a node for association object
        else if (project.getAssociation(selectedNode) != null){
            PounamuConnector connector =(PounamuConnector)(((PounamuModelProject)project).getIcon(selectedNode));
            PounamuView view = project.getView(selectedNode);
            PounamuAssociationSpecifier pmes = new PounamuAssociationSpecifier(connector, project.getView(selectedNode));
            pounamu.setPropertyPanel(pmes);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            connector.setSelected(true);
            panel.setState("select");
        }
        //selected item is a node for "entity type" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode).getUserObject())).equals("entity type")){
            ((PounamuToolProject)project).doCreateNewEntityTypeObject();
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
        }
        //selected item is a node for "association type" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode).getUserObject())).equals("association type")){
            ((PounamuToolProject)project).doCreateNewAssociationTypeObject();
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
        }
        //selected item is a node for "entity" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode).getUserObject())).equals("entity")){
            //((PounamuModelProject)project).doCreateNewEntity((String)selectedNode.getUserObject());
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
        }
        //selected item is a node for "association" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode).getUserObject())).equals("association")){
            //((PounamuModelProject)project).doCreateNewAssociation((String)selectedNode.getUserObject());
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
        }
        //selected item is a node for "entity" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode.getParent()).getUserObject())).equals("entity")){
            ((PounamuModelProject)project).doCreateNewEntity((String)selectedNode.getUserObject());
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
        }
        //selected item is a node for "association" node
        else if (((String)(((DefaultMutableTreeNode)selectedNode.getParent()).getUserObject())).equals("association")){
            //System.out.println("in pounamuManagerpanel, here start add association");
            ((PounamuModelProject)project).doCreateNewAssociation((String)selectedNode.getUserObject());
            //System.out.println("in pounamuManagerpanel, here end add association");
            //PounamuView view = project.getView(selectedNode);
            //ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            //panel.setSelected(false);
            //panel.setIdleCursors();
            //pounamu.setPropertyPanel(null);
        }
        //selected item is a node for a meta model view
        else if (((String)(((DefaultMutableTreeNode)selectedNode.getParent()).getUserObject())).equals("meta_model_definer")){
            PounamuView view = project.getView(selectedNode);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            panel.setSelected(false);
            pounamu.setPropertyPanel(null);
            panel.setState("select");
        }
        //selected item is a node for a model view
        else if ((selectedNode.getParent().getParent())!= null){
            if((selectedNode.getParent().getParent().getParent())!= null){
                if(((String)((DefaultMutableTreeNode)(selectedNode.getParent().getParent().getParent())).getUserObject()).startsWith("Using_")){
                    PounamuView view = project.getView(selectedNode);
                    ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                    panel.setSelected(false);
                    panel.setState("select");
                    pounamu.setPropertyPanel(null);
                }
                else{
                    pounamu.setPropertyPanel(null);
                }
            }
            else{
                pounamu.setPropertyPanel(null);
            }
        }
        else{
            pounamu.setPropertyPanel(null);
        }
        previousSelectedNode = selectedNode;
        while(project.getComponent(previousSelectedNode) != null)
            previousSelectedNode = (DefaultMutableTreeNode)previousSelectedNode.getParent();
    }

    /**
     * prepare the dynamic menu
     */
    public void prepareDynamicMenu(){

        JMenu menu = pounamu.getDynamicMenu();
        menu.removeAll();
        Vector menuItems = null;
        Vector toolButtons = null;
        PounamuProject project = getProject(selectedNode);
        if(project == null){
            menuItems = (Vector)nodeAndMenuItemsMapping.get(selectedNode);
            toolButtons = (Vector)nodeAndToolButtonsMapping.get(selectedNode);
        }
        else{
            menuItems = project.getMenuItems(selectedNode);
            toolButtons = project.getToolButtons(selectedNode);
        }
        if(menuItems != null){
            for(int i = 0; i < menuItems.size(); i++){
                if(menuItems.elementAt(i)!=null){
                    JMenuItem item = (JMenuItem)menuItems.elementAt(i);
                    item.setVisible(true);
                    menu.add(item);
                }
                else
                    menu.addSeparator();
            }
        }
        pounamu.setToolIconPanel(new ToolIconPanel(this, toolButtons));
    }

    /**
     * implementing mouse listener
     * @param e the mouse event
     */
    public void mouseExited(MouseEvent e){};

    /**
     * implementing mouse listener
     * @param e the mouse event
     */
    public void mouseEntered(MouseEvent e){};

    /**
     * implementing mouse listener
     * @param e the mouse event
     */
    public void mouseReleased(MouseEvent e){
        TreePath path = getManagerTree().getClosestPathForLocation(e.getX(), e.getY());
        getManagerTree().setSelectionPath(path);
        if(e.getButton() == MouseEvent.BUTTON3){
            JPopupMenu pop = (JPopupMenu)getPopupMenu(getSelectedNode());
            pop.addPopupMenuListener(new PopupMenuListener(){
                public void popupMenuWillBecomeVisible(PopupMenuEvent e){}
                public void popupMenuWillBecomeInvisible(PopupMenuEvent e){
                    rearrangeMenuItem(e);
                }
                public void popupMenuCanceled(PopupMenuEvent e){
                    rearrangeMenuItem(e);
                }
                public void rearrangeMenuItem(PopupMenuEvent e){
                    JPopupMenu p = (JPopupMenu)e.getSource();
                    p.removeAll();
                    prepareDynamicMenu();
                }
            });
            pop.show(this, e.getX(), e.getY());
        }
    }

    /**
     * implementing mouse listener
     * @param e the mouse event
     */
    public void mousePressed(MouseEvent e){

    }

    /**
     * implementing mouse listener
     * @param e the mouse event
     */
    public void mouseClicked(MouseEvent e){};


    /**
     * a help method to Change the first letter of a String to Capital
     * @param s the string to be changed
     * @return the changed string
     */
    protected String capitalizeFirstLetter(String s) {
        char chars[] = s.toCharArray();
        if(chars[0]>='a'&&chars[0]<='z')
            chars[0] = (char)(chars[0]-('a' - 'A'));
        return new String(chars);
    }

}