/*
 * @(#)OpenMetaModelElementFromXMLFile.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;

/**
 * Title: NewObjectDialogForMetaModelView
 * Description:  A dialog for user to create an object by three ways
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class OpenMetaModelElementFromXMLFile extends JDialog {

  JTextField fileName = new JTextField("", 13);
  JButton browser = new JButton("Browse");
  JButton ok = new JButton("   OK   ");
  JButton cancel = new JButton("Cancel");
  Pounamu pounamu = null;
  PounamuToolProject tool = null;
  PounamuView view = null;
  ModellerPanel panel = null;
  PounamuMetaModelElement target = null;
  DefaultMutableTreeNode node = null;
  String targetName = null;
  String type = null;
  /**
   * construct a dialog which allow user to add a object to meta model view by thre ways
   * @param tool the tool project this dialog works for
   * @param view the view where the new object will be added to
   * @param type the type of the new object
   */
  public OpenMetaModelElementFromXMLFile(PounamuToolProject tool, DefaultMutableTreeNode node, String type){
    super(tool.getPounamu(), "Open meta model element from xml file", true);
    this.tool = tool;
    this.node = node;
    this.type = type;
    this.view = (PounamuView)tool.getNodeAndViewMapping().get(node);
    if(type.equals("entity type")) 
      this.target = (PounamuMetaModelElement)tool.getEntityTypeObject(node);
    else
      this.target = (PounamuMetaModelElement)tool.getAssociationTypeObject(node);
    this.targetName = target.getName();
    this.pounamu = tool.getPounamu();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {

    JPanel jPanel3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
    jPanel3.add(fileName);
    jPanel3.add(browser);
    jPanel3.setBorder(BorderFactory.createTitledBorder("open an " + type +  " object from file: "));

    JPanel jPanel7 = new JPanel();
    jPanel7.add(ok);
    jPanel7.add(cancel);
    this.getContentPane().setLayout(new VerticalFlowLayout(4));
    this.getContentPane().add(jPanel3);
    this.getContentPane().add(jPanel7);
    this.setResizable(false);
    this.pack();
    browser.addActionListener(new ActionListener() {
       public void actionPerformed(ActionEvent e) {
        int returnVal = pounamu.getFileChooser().showOpenDialog(pounamu);
        pounamu.getFileChooser().setCurrentDirectory(new File(tool.getLocation()));
        pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
        if(returnVal == JFileChooser.APPROVE_OPTION){
          File inputFile = pounamu.getFileChooser().getSelectedFile();
          fileName.setText(inputFile.getPath());
        }
        else {
          pounamu.displayMessage("You have not choose a valid xml file" );
        }
      }
    });
    ok.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        createNewObject();
        doCancel();
      }
    });

    cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doCancel();
      }
    });
  }

  /**
   * create a object by one of the three ways
   */
  private void createNewObject(){
    ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
    if(fileName.getText()==null ||fileName.getText().equals("")){
        pounamu.displayMessage("Please chooose a xml file of this " + type);
        return;
    }
    LoadXMLFile lxf = new LoadXMLFile(new File(fileName.getText()));
    PounamuMetaModelElement pme = new PounamuMetaModelElement(lxf.getDocument(), tool);
    String name = pme.getName();
    if(type.equals("entity type")){
      if(!(pme.getType().equals("entitytype"))){
          pounamu.displayMessage("Please choose a entity type xml file" );
          return;
      }
      Hashtable hash = tool.getRegisteredEntityTypeObjects();
      if(hash.get(name) != null)
        pme = (PounamuMetaModelElement)hash.get(name);
    }
    else{
      if(!(pme.getType().equals("associationtype"))){
        pounamu.displayMessage("Please choose a association type xml file" );
        return;
      }
      Hashtable hash = tool.getRegisteredAssociationTypeObjects();
      if(hash.get(name) != null)
        pme = (PounamuMetaModelElement)hash.get(name);
    }
    /*if(pme.getIcon(view)!=null){
      pounamu.displayMessage("The " + type + " object " + pme.getName() +" has been added to this view already!");
      panel.setCurrentObject(null);
      panel.setState("idle");
    }*/
    target.setIconNumber(target.getIconNumber()-1);
    if(target.getIconNumber() == 0){//new entity
      if(type.equals("entity type")){
        tool.getRegisteredEntityTypeObjects().remove(targetName);
        tool.getRegisteredEntityTypeProperty().remove(targetName);
        tool.updateAvailableTypesAndIcons();
         //RemoveEntityTypeEvent nee = new RemoveEntityTypeEvent(project, target);
         //tool.eventReceived(nee);
       }
       else{
         tool.getRegisteredAssociationTypeObjects().remove(targetName);
         tool.getRegisteredAssociationTypeProperty().remove(targetName);
         tool.updateAvailableTypesAndIcons();
         //RemoveAssociationTypeEvent nae = new RemoveAssociationTypeEvent(project, target);  
         //tool.eventReceived(nae);
       }       
    } 
    
    //now map entity and shape
    if(type.equals("entity type")){
      //tool.getNodeAndEntityTypeObjectMapping().remove(node);
      //tool.getNodeAndEntityTypeObjectMapping().put(node, pme);
      PounamuPanel pp = (PounamuPanel)tool.getNodeAndIconMapping().get(node);
      PounamuShape p = pp.getPounamuShape();
      p.setRelatedObject(pme);
      pme.addIcon(view, p);
      pme.setIconNumber(pme.getIconNumber()+1);
      node.setUserObject(pme.getName());
      PounamuMetaModelElementSpecifier pmmes = new PounamuMetaModelElementSpecifier(pme, tool.getView(node));
      pounamu.setPropertyPanel(pmmes);
      pmmes.ok_pressed(); 
      tool.registerEntityType(node);
    }
    else{
      //tool.getNodeAndAssociationTypeObjectMapping().remove(node);
      //tool.getNodeAndAssociationTypeObjectMapping().put(node, pme);
      PounamuPanel pp = (PounamuPanel)tool.getNodeAndIconMapping().get(node);
      PounamuShape p = pp.getPounamuShape();
      p.setRelatedObject(pme);
      pme.addIcon(view, p);
      pme.setIconNumber(pme.getIconNumber()+1);
      node.setUserObject(pme.getName());
      PounamuMetaModelElementSpecifier pmmes = new PounamuMetaModelElementSpecifier(pme, tool.getView(node));
      pounamu.setPropertyPanel(pmmes);
      pmmes.ok_pressed();
      tool.registerAssociationType(node);
    }
    
  }

   /*
   * this dialog disappear when cancel button is clicked
   */
  private void doCancel(){
    this.dispose();
  }

  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  /*protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }*/
}