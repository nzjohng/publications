/*
 * @(#)Compile.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.io.*;
import javax.swing.*;
import pounamu.core.*;
import pounamu.data.*;

/**
 * Title: Compile
 * Description:  Compile a java file with the specified full name
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class Compile implements Runnable {

   String fullName = null;
   PounamuToolProject project = null;
   Pounamu pounamu = null;
   boolean compiled = true;
   /**
    * conatructor
    * @param fullName the full name opf he jave file
    * @param name the nale of the jave file
    */
   public Compile(String fullName, PounamuToolProject project) {
     this.fullName = fullName;
     this.project = project;
     this.pounamu = project.getPounamu();
   }
   
   public void setCompiled(boolean compiled){
     this.compiled = compiled;
   }
   
   public boolean getCompiled(){
     return compiled;
   }

   /**
    * compile the java file into corresponding class file in the same folder
    */
   public void run() {
     try{
      String compileInfo = "The following is the error message from compiling " + fullName + ":\n";
      //pounamu.displayMessage(compileInfo);
      Runtime runtime=Runtime.getRuntime();
      //System.out.println("what happened here?0");
      //Process p = runtime.exec("copy "+fullName+" C:"+fileSeparator+"");
      Process p = runtime.exec("javac \""+fullName+"\"");
      //System.out.println("what happened here?0");
      InputStream in = p.getErrorStream();
      //System.out.println("what happened here?00");
      int k;
      String compileInformation = "";
      while((k = in.read()) != -1){
         compileInformation = compileInformation + (char)k;
         //System.out.print((char)k);
      }
      //pounamu.displayMessage(compileInfo);
      if(compileInformation.equals("")){
        pounamu.displayMessage("Compiling "+fullName+" finished successfully!");
        /*if(fullName.indexOf("modelhandlers")>0)
          project.doRegisterModelHandler();  
        else
          project.doRegisterVisualHandler(); */
      }
      else{
        compileInfo = compileInfo + compileInformation+ "Compiling "+fullName+" faild. Please debug your code and recompile it!\n "+fullName+" has not been registyered as compilation filled!";
        pounamu.displayMessage(compileInfo);
      }
      //System.out.println("what happened here?00");
      p.waitFor();
      //System.out.println("what happened here?00");
    }
    catch(IOException eeee){
      compiled = false;
      eeee.printStackTrace();
      pounamu.displayMessage("IOException:" + eeee.getMessage());
    }
    catch(InterruptedException eee){
      compiled = false;
      pounamu.displayMessage("InterruptedException" + eee.getMessage());
    }
   }
}