/*
 * UserPlugIn.java
 *
 * Created on 5 August 2003, 10:05
 */

package pounamu.core;

/**
 *
 * @author  nzhu002
 */
public interface PounamuUserPlugIn {
    
    
    
    public String getDescription();
    
    public void setDescription(String description);
    
    public String getClassName();
    
    public void setClassName(String className);
    
}