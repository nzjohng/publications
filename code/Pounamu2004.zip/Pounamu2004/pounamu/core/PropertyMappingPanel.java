/*
 * @(#)PropertyMappingPanel.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * Title: PropertyMappingPanel
 * Description:  A panel to map properties from a meta model element to an icon
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class PropertyMappingPanel extends JPanel{

  JRadioButton[] radio = null;
  JComboBox[] box = null;
  PounamuToolProject project = null;
  String metaModelType = null;
  String iconType = null;
  String[] attributeName = null;
  String[] attributeType = null;
  Hashtable radioBoxMapping = new Hashtable();

  /**
   * construct a panel to map properties between a meta model type and an icon type
   * @param project the Pounamu project this panel works for
   * @param metaModelType the type of meta model element
   * @param iconType the type of icon
   */
  public PropertyMappingPanel(PounamuToolProject project, String metaModelType, String iconType){

    this.project = project;
    this.metaModelType = metaModelType;
    this.iconType = iconType;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {
    Vector v = new Vector();
    if(project.getRegisteredEntityTypeProperty().get(metaModelType)==null)
      v = (Vector)project.getRegisteredAssociationTypeProperty().get(metaModelType);
    else
      v = (Vector)project.getRegisteredEntityTypeProperty().get(metaModelType);
    Vector modelNames = new Vector();
    Vector modelTypes = new Vector();
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.get(i);
      modelNames.add(s.substring(0, s.indexOf(':')));
      modelTypes.add(s.substring(s.indexOf(':')+1, s.lastIndexOf(':')));
    }
    Vector fieldProperties = project.getTextFieldProperties(iconType);
    Vector areaProperties = project.getTextAreaProperties(iconType);
    radio = new JRadioButton[modelNames.size()];
    box = new JComboBox[modelNames.size()];
    JPanel panel = new JPanel(new VerticalFlowLayout(2));
    for(int i = 0; i < modelNames.size(); i++){
      radio[i] = new JRadioButton();
      radio[i].setText((String)modelNames.get(i));
      radio[i].setSelected(false);
      box[i] = new JComboBox();
      box[i].setEnabled(false);
      if(((String)modelTypes.get(i)).equals("MultiLinesText")){
        for(int j = 0; j < areaProperties.size(); j++){
          String s = (String)areaProperties.get(j);
          box[i].addItem(s);
        }
      }
      else{
        for(int j = 0; j < fieldProperties.size(); j++){
          String s = (String)fieldProperties.get(j);
          box[i].addItem(s);
        }
      }
      JPanel p = new JPanel();
      p.setLayout(new GridLayout(1,2));
      p.add(radio[i]);
      p.add(box[i]);
      panel.add(p);
      radioBoxMapping.put(radio[i], box[i]);
      radio[i].addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent iee){
          JRadioButton jb = (JRadioButton)iee.getSource();
          JComboBox jc = (JComboBox)radioBoxMapping.get(jb);
          jc.setEnabled(jb.isSelected());
        }
      });
    }
    JScrollPane scrollPane1 = new JScrollPane(panel);
    scrollPane1.setPreferredSize(new Dimension(380, 120));
    this.add(scrollPane1);
  }

  /**
   * register information from this panel
   * @param key the name o fthe view type
   * @param project the tool project this panel belongs to
   */
  public void registerViewType(String key, PounamuToolProject project){
    Vector v  = new Vector();
    for(int i = 0; i < radio.length; i++){
      if(radio[i].isSelected()){
        String s = radio[i].getText();
        String ss = (String)box[i].getSelectedItem();
        v.add(s+":"+ss);
      }
    }
    project.getViewTypeAndPropertyMapping().put(key, v);
  }

  /**
   * save information from this panel
   * @param buf the stingbuff to hold the generated string
   * @param space a empty string to keep alinment
   */
  public void save(StringBuffer buf, String space){
    for(int i = 0; i < radio.length; i++){
      if(radio[i].isSelected()){
        buf.append(space+"<value>"+i+":"+box[i].getSelectedIndex()+"</value>\n");
      }
    }
  }

  /**
   * to restore information of this panel from the saved file
   * @param i
   * @param j
   */
  public void restore(int i, int j){
    radio[i].setSelected(true);
    box[i].setSelectedIndex(j);
  }
}