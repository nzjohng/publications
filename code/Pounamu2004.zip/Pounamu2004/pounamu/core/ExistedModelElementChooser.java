/*
 * @(#)ExistedModelElementChooser.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.editor.*;
/**
 * Title: ExistedModelElementChooser
 * Description:  A dialog for user to create an object by three ways
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ExistedModelElementChooser extends JDialog {
    
    
    JComboBox box = new JComboBox();
    JButton ok = new JButton("   OK   ");
    JButton cancel = new JButton("Cancel");
    Pounamu pounamu = null;
    PounamuModelProject project = null;
    PounamuToolProject tool = null;
    PounamuView view = null;
    ModellerPanel panel = null;
    PounamuModelElement target = null;
    String targetType = null;
    String targetName = null;
    DefaultMutableTreeNode node = null;
    String type = null;
    Hashtable keyAndModelElementMapping = new Hashtable();
    //Hashtable hash = null;
    /**
     * construct a dialog which allow user to add a object to model view by thre ways
     * @param tool the tool project this dialog works for
     * @param view the view where the new object will be added to
     * @param targetType the targetType of the new object
     */
    public ExistedModelElementChooser(PounamuModelProject project, DefaultMutableTreeNode node, String type){
        super(project.getPounamu(), "object dialog for model views", true);
        this.project = project;
        this.node = node;
        this.tool = project.getTool();
        this.view = project.getView(node);
        this.type = type;
        this.panel = (ModellerPanel)view.getDisplayPanel();
        if(type.equals("entity")){
            this.target = project.getEntity(node);
        }
        else{
            this.target = project.getAssociation(node);
        }
        this.targetName = target.getName();
        this.targetType = target.getType();
        this.pounamu = tool.getPounamu();
        try {
            jbInit();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Component initialization
     */
    private void jbInit() throws Exception {
        
        JPanel jPanel5 = new JPanel();
        initJComboBox();
        jPanel5.add(box);
        jPanel5.setBorder(BorderFactory.createTitledBorder("choose an existed" + targetType +  " object here:"));
        JPanel jPanel7 = new JPanel();
        jPanel7.add(ok);
        jPanel7.add(cancel);
        this.getContentPane().setLayout(new VerticalFlowLayout(5));
        this.getContentPane().add(jPanel5);
        this.getContentPane().add(jPanel7);
        this.setResizable(false);
        this.pack();
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                mapObject();
                doCancel();
            }
        });
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doCancel();
            }
        });
    }
    
    /**
     * init the combo box and put all added objects with the same targetType into it
     */
    public void initJComboBox(){
        Vector elements = new Vector();
        Vector v  = new Vector();
        if(type.equals("entity"))
            elements = project.getEntities(targetType);
        else
            elements = project.getAssociations(targetType);
        for(int i = 0; i < elements.size(); i++){
            PounamuModelElement element = (PounamuModelElement)elements.get(i);
            if((element != target) && !(element.getKey().equals(""))){
                keyAndModelElementMapping.put(element.getKey(), element);
                v.add(element.getKey());
            }
        }
        Object[] array = v.toArray();
        Arrays.sort(array);
        for(int i = 0; i < array.length; i++){
            String s = (String)array[i];
            box.addItem(s);
        }
        box.addItem("                                                                  ");
    }
    
    /**
     * add the selected property values to the properties
     */
    private void mapObject(){
        //get the existed objetc
        if(((String)box.getSelectedItem()).equals("                                                                  ")){
            pounamu.displayMessage("You have not chosen a target");
            return;
        }
        PounamuModelElement pme = (PounamuModelElement)keyAndModelElementMapping.get((String)box.getSelectedItem());
        if(type.equals("entity")){
            project.removeEntity(target);
        }
        else{
            project.removeAssociation(target);
        }
        //now map entity and shape
        if(type.equals("entity")){
            PounamuPanel pp = (PounamuPanel)project.getNodeAndIconMapping().get(node);
            PounamuShape p = pp.getPounamuShape();
            p.setRelatedObject(pme);
            pme.addIcon(view, pp);
            node.setUserObject(pme.getName());
            PounamuEntitySpecifier pmes = new PounamuEntitySpecifier(p, project.getView(node));
            pounamu.setPropertyPanel(pmes);
            pmes.ok_pressed();
            pme.updateTreeNode();
        }
        else
            project.doRemoveAnAssociationFromAView(node);
        doCancel();
    }
    
   /*
    * this dialog disappear when cancel button is clicked
    */
    private void doCancel(){
        this.dispose();
    }
    
}