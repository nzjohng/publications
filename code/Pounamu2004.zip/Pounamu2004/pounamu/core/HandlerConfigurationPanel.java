/*
 * @(#)HandlerConfigurationPanel.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.util.*;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import pounamu.data.*;
import pounamu.visualcomp.*;

/**
 * Title: HandlerConfigurationPanel
 * Description:  A panel used to specify the new event handler.
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class HandlerConfigurationPanel extends JPanel{

  PounamuProject project = null;
  JCheckBox[] visualEvents = new JCheckBox[8];
  JCheckBox[] modelEvents = new JCheckBox[6];
  String[] visualEventNames = new String[]{"NewShapeEvent",
                                  "NewConnectorEvent",
                                  "RemoveShapeEvent",
                                  "RemoveConnectorEvent",
                                  "MoveShapeEvent",
                                  "ResizeShapeEvent",
                                  "ChangePropertyEvent",
                                  "all"
                                   };
  String[] modelEventNames = new String[]{"NewEntityEvent",
                                  "NewAssociationEvent",
                                  "RemoveEntityEvent",
                                  "RemoveAssociationEvent",
                                  "ChangePropertyEvent",
                                  "all"
                                   };
  String name = "";
  String type = "";
  String description = "";
  String menuItemText = "";
  JTextArea actionCode = new JTextArea();
  JTextArea importArea = new JTextArea();
  JTextArea methodArea = new JTextArea();
  JTextArea descriptionArea = new JTextArea();
  JTextArea menuItemTextArea = new JTextArea();
  String fileSeparator = null;
  JPanel visualEventPanel = new JPanel();
  JPanel modelEventPanel = new JPanel();
  JPanel importPanel = new JPanel(); 
  JPanel codePanel = new JPanel();
  JPanel methodPanel = new JPanel();
  JPanel descriptionPanel = new JPanel();
  JPanel menuItemTextPanel = new JPanel();
   
 
  /**
   * construct this handler configuration panel
   * @param emp the EventManagerPanel
   * @param name the name of this handler to be created
   */
  public HandlerConfigurationPanel(PounamuProject project, String name, String type){
    super();
    this.project = project;
    this.name = name;
    this.type = type;
    fileSeparator = System.getProperty("file.separator");
    init();
  }

  
  private void initVisualEventPanel(){
    visualEventPanel.setLayout(new GridLayout(3, 3, 15, 4));
    for(int i = 0; i < visualEventNames.length; i++){
      visualEvents[i] = new JCheckBox();
      visualEvents[i].setText(visualEventNames[i]);
      visualEvents[i].setEnabled(false);
      visualEventPanel.add(visualEvents[i]);
    }
    visualEvents[7].setEnabled(true);
    visualEvents[7].setSelected(true);
    visualEvents[7].addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        JCheckBox jcb = (JCheckBox)e.getSource();
        if(jcb.isSelected()){
          for(int i = 0; i < visualEvents.length-1; i++){
            //if(i != 6){
              //visualEvents[i].setSelected(false);
              visualEvents[i].setEnabled(false);
            //}
          }
        }
        else{
          for(int i = 0; i < visualEvents.length-1; i++){
            //if(i != 6){
              //visualEvents[i].setSelected(false);
              visualEvents[i].setEnabled(true);
            //}
          }
        }  
      }
    });
    /*visualEvents[7].addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        JCheckBox jcb = (JCheckBox)e.getSource();
        if(jcb.isSelected()){
          for(int i = 0; i < visualEvents.length; i++){
            if(i != 7){
              //visualEvents[i].setSelected(false);
              visualEvents[i].setEnabled(false);
            }
          }
        }
        else{
          for(int i = 0; i < visualEvents.length; i++){
            if(i != 7){
              //visualEvents[i].setSelected(false);
              visualEvents[i].setEnabled(true);
            }
          }
          visualEvents[6].setSelected(false); 
        }  
      }
    });*/
   
    for(int i = 0; i < visualEvents.length-1; i++){
      visualEvents[i].addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JCheckBox jcb = (JCheckBox)e.getSource();
          if(visualEvents[0].isSelected()&&
             visualEvents[1].isSelected()&&
             visualEvents[2].isSelected()&&
             visualEvents[3].isSelected()&&
             visualEvents[4].isSelected()&&
             visualEvents[5].isSelected()&&
             visualEvents[6].isSelected()){
             visualEvents[7].setSelected(true);
             jcb.setSelected(false);
             visualEvents[0].setEnabled(false);
             visualEvents[1].setEnabled(false);
             visualEvents[2].setEnabled(false);
             visualEvents[3].setEnabled(false);
             visualEvents[4].setEnabled(false);
             visualEvents[5].setEnabled(false);
             visualEvents[6].setEnabled(false);
             //visualEvents[8].setEnabled(false);
          }
          /*else if (!visualEvents[0].isSelected()&&
             !visualEvents[1].isSelected()&&
             !visualEvents[2].isSelected()&&
             !visualEvents[3].isSelected()&&
             !visualEvents[4].isSelected()&&
             !visualEvents[5].isSelected()&&
             !visualEvents[6].isSelected()){
             visualEvents[8].setSelected(true);
             jcb.setSelected(false);
             visualEvents[0].setEnabled(false);
             visualEvents[1].setEnabled(false);
             visualEvents[2].setEnabled(false);
             visualEvents[3].setEnabled(false);
             visualEvents[4].setEnabled(false);
             visualEvents[5].setEnabled(false);
             visualEvents[6].setEnabled(false);
             visualEvents[7].setEnabled(false);
          }*/
        }
      });
    }
    visualEventPanel.setBorder(BorderFactory.createTitledBorder("Please specify the events this visual handler will response to"));
  }
  
  private void initModelEventPanel(){
    modelEventPanel.setLayout(new GridLayout(3, 3, 15, 4));
    for(int i = 0; i < modelEventNames.length; i++){
      modelEvents[i] = new JCheckBox();
      modelEvents[i].setText(modelEventNames[i]);
      modelEvents[i].setEnabled(false);
      modelEventPanel.add(modelEvents[i]);
    }
    modelEvents[5].setEnabled(true);
    modelEvents[5].setSelected(true);
    modelEvents[5].addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        JCheckBox jcb = (JCheckBox)e.getSource();
        if(jcb.isSelected()){
          for(int i = 0; i < modelEvents.length-1; i++){
            //if(i != 5){
              //modelEvents[i].setSelected(false);
              modelEvents[i].setEnabled(false);
            //}
          }
        }
        else{
          for(int i = 0; i < modelEvents.length-1; i++){
            //if(i != 5){
              //modelEvents[i].setSelected(false);
              modelEvents[i].setEnabled(true);
            //}
          }
         
        }  
      }
    });
    /*modelEvents[6].addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        JCheckBox jcb = (JCheckBox)e.getSource();
        if(jcb.isSelected()){
          for(int i = 0; i < modelEvents.length; i++){
            if(i != 6){
              //modelEvents[i].setSelected(false);
              modelEvents[i].setEnabled(false);
            }
          }
        }
        else{
          for(int i = 0; i < modelEvents.length; i++){
            if(i != 6){
              //modelEvents[i].setSelected(false);
              modelEvents[i].setEnabled(true);
            }
          }
          modelEvents[5].setSelected(false);
        }  
      }
    });*/
    for(int i = 0; i < modelEvents.length-2; i++){
      modelEvents[i].addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JCheckBox jcb = (JCheckBox)e.getSource();
          if(jcb.isSelected()&&
             modelEvents[0].isSelected()&&
             modelEvents[1].isSelected()&&
             modelEvents[2].isSelected()&&
             modelEvents[3].isSelected()&&
             modelEvents[4].isSelected()){
             modelEvents[5].setSelected(true);
             jcb.setSelected(false);
             modelEvents[0].setEnabled(false);
             modelEvents[1].setEnabled(false);
             modelEvents[2].setEnabled(false);
             modelEvents[3].setEnabled(false);
             modelEvents[4].setEnabled(false);
             //modelEvents[6].setEnabled(false);
          }
          /*else if(!jcb.isSelected()&&
             !modelEvents[0].isSelected()&&
             !modelEvents[1].isSelected()&&
             !modelEvents[2].isSelected()&&
             !modelEvents[3].isSelected()&&
             !modelEvents[4].isSelected()){
             //modelEvents[6].setSelected(true);
             jcb.setSelected(false);
             modelEvents[0].setEnabled(false);
             modelEvents[1].setEnabled(false);
             modelEvents[2].setEnabled(false);
             modelEvents[3].setEnabled(false);
             modelEvents[4].setEnabled(false);
             modelEvents[5].setEnabled(false);
          }*/
        }
      });
    }            
    modelEventPanel.setBorder(BorderFactory.createTitledBorder("Please specify the events this model handler will response to"));
  }
  
  
  /**
   * initial visual components
   */
  public void init(){
    
    JScrollPane importScroll = new JScrollPane(importArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    importScroll.setPreferredSize(new Dimension(450, 40));
    importPanel.add(importScroll);
    importArea.setBackground(Color.white);
    importPanel.setBorder(BorderFactory.createTitledBorder("Please import any class you want here"));
    actionCode.setBackground(Color.white);   
    JScrollPane codeScroll = new JScrollPane(actionCode, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    codeScroll.setPreferredSize(new Dimension(450, 110));
    codePanel.add(codeScroll);
    codePanel.setBorder(BorderFactory.createTitledBorder("Please input the action code here"));
    methodArea.setBackground(Color.white);    
    JScrollPane methodScroll = new JScrollPane(methodArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    methodScroll.setPreferredSize(new Dimension(450, 80));
    methodPanel.add(methodScroll);
    methodPanel.setBorder(BorderFactory.createTitledBorder("Please input the helper methods code here"));
    descriptionArea.setBackground(Color.white);    
    JScrollPane descriptionScroll = new JScrollPane(descriptionArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    descriptionScroll.setPreferredSize(new Dimension(450, 40));
    descriptionPanel.add(descriptionScroll);
    descriptionPanel.setBorder(BorderFactory.createTitledBorder("Please briefly describe this handler here"));
    this.setLayout(new VerticalFlowLayout());
    if(type.equals("modeleventhandler")){
      initModelEventPanel();
      this.add(modelEventPanel);
    }
    else if(type.equals("visualeventhandler")){
      initVisualEventPanel();
      this.add(visualEventPanel);
    }
    else{}
    this.add(importPanel);
    this.add(codePanel);
    this.add(methodPanel);
    this.add(descriptionPanel);
    if(type.equals("modeluserhandler")||type.equals("visualuserhandler")){
      JScrollPane menuItemTextScroll = new JScrollPane(menuItemTextArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
      menuItemTextScroll.setPreferredSize(new Dimension(450, 40));
      menuItemTextPanel.add(menuItemTextScroll);
      menuItemTextPanel.setBorder(BorderFactory.createTitledBorder("Please specify the menu item text here"));
      this.add(menuItemTextPanel);
    }
    this.validate();
  }
  
   
  /**
   * generate java code based on the input information
   * @return the generated java code
   */
  public String getJavaCode(String uniqueNum){
     
    description = descriptionArea.getText();
    String space = "    ";
    StringBuffer buf = new StringBuffer (400000);
    if(type.equals("modeleventhandler"))
      buf.append("package pounamu.tools."+project.getName()+".handlers.modelhandlers.eventtriggeringhandlers;\n\n");      
    else if(type.equals("modeluserhandler"))
      buf.append("package pounamu.tools."+project.getName()+".handlers.modelhandlers.usertriggeringhandlers;\n\n");      
    else if(type.equals("visualeventhandler"))
      buf.append("package pounamu.tools."+project.getName()+".handlers.visualhandlers.eventtriggeringhandlers;\n\n"); 
    else if(type.equals("visualuserhandler"))
      buf.append("package pounamu.tools."+project.getName()+".handlers.visualhandlers.usertriggeringhandlers;\n\n"); 
    else{} 
    buf.append("import pounamu.event.*;\n");
    buf.append("import pounamu.command.*;\n");
    buf.append("import pounamu.core.*;\n");
    buf.append("import pounamu.data.*;\n");
    buf.append("import pounamu.visualcomp.*;\n");
    buf.append("import pounamu.editor.*;\n");
    buf.append("import pounamu.help.*;\n");
    buf.append("import java.util.*;\n");
    if(importArea.getText().equals(""))
      buf.append("\n");
    else
      buf.append(importArea.getText()+"\n\n");
    if(type.equals("modeleventhandler")) 
      buf.append("public class " + name+uniqueNum+" extends PounamuModelHandler implements PounamuEventTriggeringHandler{\n\n");
    else if(type.equals("modeluserhandler")) 
      buf.append("public class " + name+uniqueNum+" extends PounamuModelHandler implements PounamuUserTriggeringHandler{\n\n");
    else if(type.equals("visualeventhandler")) 
      buf.append("public class " + name+uniqueNum+" extends PounamuVisualHandler implements PounamuEventTriggeringHandler{\n\n");
    else if(type.equals("visualuserhandler")) 
      buf.append("public class " + name+uniqueNum+" extends PounamuVisualHandler implements PounamuUserTriggeringHandler{\n\n");
    else{}  
    //else
      //buf.append("public class " + name+uniqueNum+" extends PounamuUserTriggerHandler{\n\n");   
    buf.append(space+"public "+ name+uniqueNum+"(){\n");
    buf.append(space+space + "super();\n");
    buf.append(space+space + "setClassName(\""+name+"\");\n");
    buf.append(space+space + "setDescription(\""+descriptionArea.getText()+"\");\n");
    buf.append(space+space + "setType(\""+type+"\");\n");
    
    if(type.equals("modeleventhandler")/*&&modelEvents[6].isSelected()==false*/){
      buf.append(space+space + "Vector v = new Vector();\n");
      for(int i = 0; i < modelEvents.length-2; i++){
        if(modelEvents[5].isSelected()){
          buf.append(space+space + "v.add(\""+modelEventNames[i]+"\");\n");
        }
        else if(modelEvents[i].isSelected()&&modelEvents[i].isEnabled()){
          buf.append(space+space + "v.add(\""+modelEventNames[i]+"\");\n");
        }
        else{}
      }
      buf.append(space+space+"setRespondingEvents(v);\n");
    }
    else if(type.equals("visualeventhandler")/*&&visualEvents[8].isSelected()==false*/){
      buf.append(space+space + "Vector v = new Vector();\n");
      for(int i = 0; i < visualEvents.length-2; i++){
        if(visualEvents[7].isSelected()){
          buf.append(space+space + "v.add(\""+visualEventNames[i]+"\");\n");
        }
        else if(visualEvents[i].isSelected()&&visualEvents[i].isEnabled()){
          buf.append(space+space + "v.add(\""+visualEventNames[i]+"\");\n");
        }
        else{}
      }
      buf.append(space+space+"setRespondingEvents(v);\n");
    }
    else{
      buf.append(space+space+"setMenuItemText(\""+menuItemTextArea.getText()+"\");\n");
    }
    buf.append(space+ "}\n\n");
    if((type.equals("modeleventhandler")/*&&modelEvents[6].isSelected()==false*/)||(type.equals("visualeventhandler")/*&&visualEvents[8].isSelected()==false*/)){
      buf.append(space+"public void eventReceived(PounamuEvent e){\n");
      buf.append(space + space + "if(isEnabled()==false)\n"); 
      buf.append(space + space + space+"return;\n"); 
      buf.append(space+space+"if(!(");
      if(type.equals("modeleventhandler")/*&&modelEvents[6].isSelected()==false*/){
          String s = ""; 
          for(int i = 0; i < modelEvents.length-2; i++){
            if(modelEvents[5].isSelected()){
              s = s + "e instanceof " + (String)modelEventNames[i]+"||";
            }
            else if(modelEvents[i].isSelected()&&modelEvents[i].isEnabled()){
              s = s + "e instanceof " + (String)modelEventNames[i]+"||";
            }
          }
          if(!s.equals(""))
            s = s.substring(0, s.length()-2);
          buf.append(s+"))\n");         
      } 
      if(type.equals("visualeventhandler")/*&&visualEvents[8].isSelected()==false*/){
          String s = ""; 
          for(int i = 0; i < visualEvents.length-2; i++){
            if(visualEvents[7].isSelected()){
              s = s + "e instanceof " + (String)visualEventNames[i]+"||";
            }
            else if (visualEvents[i].isSelected()&&visualEvents[i].isEnabled()){
              s = s + "e instanceof " + (String)visualEventNames[i]+"||";
            }
          }
          s = s.substring(0, s.length()-2);
          buf.append(s+"))\n");        
      } 
      buf.append(space+space+space+"return;\n");
    }
    else{
      buf.append(space+"public void execute(){\n");
      buf.append(space + space + "if(isEnabled() == false)\n"); 
      buf.append(space + space + space+"return;\n"); 
    }
    StringTokenizer st = new StringTokenizer(actionCode.getText(), "\n", false);
    while(st.hasMoreTokens())
      buf.append(space+space+st.nextToken()+"\n");
    buf.append(space+"}\n\n");
    if(!(methodArea.getText().equals(""))){
      StringTokenizer sb = new StringTokenizer(methodArea.getText(), "\n");
      while(sb.hasMoreTokens()){
        buf.append(space+sb.nextToken()+"\n");
      }
      buf.append("\n");
    }
    buf.append("}");
    return buf.toString();
  }

  /**
   * get the name of this handler
   */
  public String getHandlerName(){
    return name;
  }
  
   /**
   * set the name of this handler
   */
  public void setHandlerName(String name){
    this.name = name;
  }
  
  public void setName(String name){
    this.name = name;
  }
  
   public String getName(){
    return name;
  }
  
      
  
  /**
   * get the type of this handler
   */
  public String getHandlerType(){
    return type;
  }
  
   /**
   * set the type of this handler
   */
  public void setHandlerType(String type){
    this.type = type;
  }
  
  /**
   * get the description of this handler
   */
  public String getHandlerDescription(){
    return description;
  }
  
   /**
   * set the description of this handler
   */
  public void setHandlerDescription(String description){
    this.description = description;
  }

  public boolean isValid(){
    /*if(type.equals("modeleventhandler")&&modelEvents[6].isSelected())
      return false;
    else if(type.equals("visualeventhandler")&&visualEvents[8].isSelected())
      return false;*/
    if(type.equals("modeleventhandler")){
      for(int i = 0; i < modelEvents.length; i++){
        if(modelEvents[i].isSelected())
          return true;
      }
    }
    else if(type.equals("visualeventhandler")){
      for(int i = 0; i < visualEvents.length; i++){
        if(visualEvents[i].isSelected())
          return true;
      }
    }
    else if((type.equals("visualuserhandler")&&menuItemTextArea.getText().equals(""))
          ||(type.equals("modeluserhandler")&&menuItemTextArea.getText().equals("")))
      return false;
    else
      return true;
    return false;
  }
    
  /**
   * save the Java code to default folder
   */
  public void saveJavaCode(int uniqueNum){

    Pounamu pounamu = project.getPounamu();
    String outputPath = null;
    if(type.equals("modeleventhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+name+uniqueNum+".java";
    else if(type.equals("modeluserhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+name+uniqueNum+".java";
    else if(type.equals("visualeventhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+name+uniqueNum+".java";
    else if(type.equals("visualuserhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+name+uniqueNum+".java";
    else{}
    try{
      FileWriter fw = new FileWriter(outputPath);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      String s = getJavaCode(uniqueNum+"");
      //s = encodeJavaCode(s, name, uniqueNum);
      bw.write(s);
      bw.flush();
      fw.close();
    }
    catch(Exception ee){
      pounamu.displayMessage("Exception in class HandlerConfigurationPanel "+ee.toString());
      //System.out.println(ee.toString());
    }
  }

  /**
   * save xml file to the default folder
   */
  public void save(){
    Pounamu pounamu = project.getPounamu();
    String outputPath = null;
    if(type.equals("modeleventhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+name+".xml";
    else if(type.equals("modeluserhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+name+".xml";
    else if(type.equals("visualeventhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+name+".xml";
    else if(type.equals("visualuserhandler"))
      outputPath = ((PounamuToolProject)project).getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+name+".xml";
    else{}
    try{
      FileWriter fw = new FileWriter(outputPath);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(getXML());
      bw.flush();
      fw.close();
    }
    catch(Exception ee){
      //System.out.println("in class toolProject "+ee.toString());
      pounamu.displayMessage("Exception in class HandlerConfigurationPanel "+ee.toString());
    }
  }

  /**
   * generate xml file wich contains all information of this handler
   * @return the xml format string
   */
  public String getXML(){
    description = descriptionArea.getText();
    StringBuffer buf = new StringBuffer (400000);
    //buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE pounamuhandler SYSTEM \""+project.getPounamu().getPounamuHome()+""+fileSeparator+"nonjavafiles"+fileSeparator+"pounamuhandler.dtd\">\n");
    buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE pounamuhandler SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"pounamuhandler.dtd\">\n");
    buf.append ("<pounamuhandler>\n");
    buf.append ("<name>"+name+"</name>\n");
    buf.append ("<type>"+type+"</type>\n");
    if(type.equals("modeleventhandler")){      
      for(int i = 0; i < modelEvents.length-1; i++){
        if(modelEvents[5].isSelected()){
          buf.append ("<event>"+modelEventNames[i]+"</event>\n");
        }
        else if(modelEvents[i].isSelected()&&modelEvents[i].isEnabled()){
          buf.append ("<event>"+modelEventNames[i]+"</event>\n");
        }
        else{}
      }
    }
    else if(type.equals("visualeventhandler")){
      for(int i = 0; i < visualEvents.length-1; i++){
        if(visualEvents[7].isSelected()){
          buf.append ("<event>"+visualEventNames[i]+"</event>\n");
        }
        else if(visualEvents[i].isSelected()&&visualEvents[i].isEnabled()){
          buf.append ("<event>"+visualEventNames[i]+"</event>\n");
        }
        else{}
      }
    }
    else{
      buf.append ("<menuitemtext>"+menuItemTextArea.getText()+"</menuitemtext>\n");
    }
    //buf.append ("<description>"+actionDescription.getText()+"</description>\n");
    buf.append ("<import>"+importArea.getText()+"</import>\n");
    buf.append ("<code>"+encodeSpecialChar(actionCode.getText())+"</code>\n");
    buf.append ("<method>"+encodeSpecialChar(methodArea.getText())+"</method>\n");
    buf.append ("<description>"+encodeSpecialChar(descriptionArea.getText())+"</description>\n");
    buf.append ("</pounamuhandler>\n");
    return buf.toString();
  }
  
   /**
   * attach a unique number to the name of handler in the jave code
   * @param javaCode the original String to be encoded
   */
  public String encodeJavaCode(String javaCode, String name, int uniqueNum){
    return javaCode.replaceAll(name, name+uniqueNum);    
  }
  
  /**
   * delete the attached unique number from the name of handler in the jave code
   * @param javaCode the original String to be decoded
   */
  public String decodeJavaCode(String encodedJavaCode, String encodedName, String name){
    return encodedJavaCode.replaceAll(encodedName, name);    
  }
  
  

  /**
   * replace the '<' and '>' in the string wiht '@' and '#'
   * @param originalString the original String to be encoded
   */
  public String encodeSpecialChar(String originalString){
    String s = originalString.replaceAll("<", "&lt");
    s = s.replaceAll(">", "&gt");
    s = s.replaceAll("&", "&amp");
    return s;
  }

  /**
   * replace the '@' and '#' in the string wiht '<' and '>'
   * @param originalString the original String to be decoded
   */
  public String decodeSpecialChar(String originalString){
    //String s = originalString.replace('@', '<');
    //s = s.replace('#', '>');
    //return s;
    return originalString;
  }
  /**
   * restore an existed handler from a xml document
   * @param xmlDocument the Document object which contains all imformation about a handler
   */

   public void restoreAHandlerFromXML(Document xmlDocument){
     Node m = xmlDocument.getDocumentElement();
     NodeList nll = ((Element)m).getElementsByTagName("name");
     Node n = nll.item(0);
     name = n.getFirstChild().getNodeValue();      
     String handlerCode = "";
     nll = ((Element)m).getElementsByTagName("code");
     if(nll.item(0) != null && nll.item(0).getFirstChild() != null){
       n = nll.item(0);
       handlerCode = n.getFirstChild().getNodeValue();
     }
     actionCode.setText(decodeSpecialChar(handlerCode));
     nll = ((Element)m).getElementsByTagName("import");
     String impo = "";
     if(nll.item(0) != null && nll.item(0).getFirstChild() != null){
       n = nll.item(0);
       impo = n.getFirstChild().getNodeValue();
     }
     importArea.setText(decodeSpecialChar(impo));
     nll = ((Element)m).getElementsByTagName("method");
     String meth = "";
     if(nll.item(0) != null && nll.item(0).getFirstChild() != null){
       n = nll.item(0);
       meth = n.getFirstChild().getNodeValue();
     }
     methodArea.setText(decodeSpecialChar(meth));
     nll = ((Element)m).getElementsByTagName("description");
     String des = "";
     if(nll.item(0) != null && nll.item(0).getFirstChild() != null){
       n = nll.item(0);
       des = n.getFirstChild().getNodeValue();
     }
     descriptionArea.setText(decodeSpecialChar(des));
     nll = ((Element)m).getElementsByTagName("type");
     n = nll.item(0);
     type = n.getFirstChild().getNodeValue();
     if(type.equals("visualuserhandler")||type.equals("modeluserhandler")){
       nll = ((Element)m).getElementsByTagName("menuitemtext");
       n = nll.item(0);
       String text = n.getFirstChild().getNodeValue();
       menuItemTextArea.setText(decodeSpecialChar(text));
     }
     else{
     nll = ((Element)m).getElementsByTagName("event");
     if(type.equals("visualeventhandler")&&nll.getLength()==7){
       visualEvents[7].setSelected(true); 
       visualEvents[0].setEnabled(false); 
       visualEvents[1].setEnabled(false); 
       visualEvents[2].setEnabled(false); 
       visualEvents[3].setEnabled(false); 
       visualEvents[4].setEnabled(false); 
       visualEvents[5].setEnabled(false); 
       visualEvents[6].setEnabled(false); 
       //visualEvents[8].setEnabled(false);
     }
     else if(type.equals("modeleventhandler")&&nll.getLength()==5){
       modelEvents[5].setSelected(true); 
       modelEvents[0].setEnabled(false); 
       modelEvents[1].setEnabled(false); 
       modelEvents[2].setEnabled(false); 
       modelEvents[3].setEnabled(false); 
       modelEvents[4].setEnabled(false); 
       //modelEvents[6].setEnabled(false); 
     }
     else{
       //create a new vector holds all selected events from the xml file
       Vector selectedEvents = new Vector();
       int i = 0;
       //put all selected event into this vector
       while(nll.item(i)!=null){
         n = nll.item(i); 
         i++;
         String event = n.getFirstChild().getNodeValue();
         selectedEvents.add(event);
         //System.oput.println("Selected event is "+ 
       }
       //go though the events array, if the event is contained in the event vector, selecte it
       if(type.equals("visualeventhandler")){
         for(int j = 0; j < visualEventNames.length-1; j++){
           if(selectedEvents.contains(visualEventNames[j])){
             visualEvents[j].setSelected(true);
             visualEvents[j].setEnabled(true); 
           }
           else{
             visualEvents[j].setEnabled(false); 
             visualEvents[j].setSelected(false);
           }
         }
       }
       else if (type.equals("modeleventhandler")){
         for(int k = 0; k<modelEventNames.length-1; k++){
           if(selectedEvents.contains(modelEventNames[k])){
               modelEvents[k].setSelected(true);
               modelEvents[k].setEnabled(true);
           }
           else{
               modelEvents[k].setSelected(false);
               modelEvents[k].setEnabled(false);
           }
         }
       }
     }
     }
  }
}