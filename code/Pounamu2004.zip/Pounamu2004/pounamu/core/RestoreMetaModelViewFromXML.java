/*
 * @(#)RestoreMetaModelViewFromXML.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: RestoreMetaModelViewFromXML
 * Description:  restore a meta model view from its xml file
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class RestoreMetaModelViewFromXML{

  Document xmlDocument= null;
  ModellerPanel modellerPanel = null;
  Element root = null;
  StringBuffer sb = new StringBuffer(40000);
  static int count = 0;
  String name = null;
  String type = null;
  Hashtable shapeHash = new Hashtable();
  PounamuManagerPanel manager = null;
  PounamuView view = null;
  PounamuToolProject tool = null;
  DefaultMutableTreeNode entityTypeNode = null;
  DefaultMutableTreeNode associationTypeNode = null;
  String fileSeparator = null;
  /**
   * constructor
   * @param xmlDocument the xml document which contains the view information
   * @param modellerPanel the panel to redisplay the view
   */
  public RestoreMetaModelViewFromXML(Document xmlDocument, ModellerPanel modellerPanel, DefaultMutableTreeNode entityTypeNode, DefaultMutableTreeNode associationTypeNode){
    this.xmlDocument = xmlDocument;
    this.modellerPanel = modellerPanel;
    this.view = modellerPanel.getView();
    fileSeparator = System.getProperty("file.separator");
    //this.type = view.getType();
    this.tool = (PounamuToolProject)modellerPanel.getProject();
    this.manager = tool.getManager();
    this.root = xmlDocument.getDocumentElement();
    this.entityTypeNode = entityTypeNode;
    this.associationTypeNode = associationTypeNode;
    //System.out.println("in class RestoreMetaModelViewFromXML, here 0");
  }

  /**
   * redisplay the view from the xml document
   */
  public void restore(){
    //System.out.println("in class RestoreMetaModelViewFromXML, here 0");
    NodeList nl = root.getElementsByTagName("shape");
    int i = 0;
    while(nl.item(i)!=null){
      //System.out.println("in class RestoreMetaModelViewFromXML, here 1");
      try{
        //  System.out.println("in class RestoreMetaModelViewFromXML, here 2");
        PounamuMetaModelElement pme = null;
        PounamuShape ps = new PounamuShape();
        //ps.setProject(tool);
        //ps.setManager(manager);
        //System.out.println("here visited 0");
        PounamuPanel basePanel = ps.getBasePanel();
        //System.out.println("here visited 1");
        Node m = nl.item(i);
        //System.out.println("here visited 2");
        NodeList nll = ((Element)m).getElementsByTagName("name");
        //System.out.println("here visited 3");
        Node n = nll.item(0);
        //System.out.println("here visited 4");
        name = n.getFirstChild().getNodeValue();
        //System.out.println("here visited 5");
        nll = ((Element)m).getElementsByTagName("type");
        //System.out.println("here visited 6");
        n = nll.item(0);
        //System.out.println("here visited 7");
        type = n.getFirstChild().getNodeValue();
        //System.out.println("here visited 8");
        Hashtable hash = tool.getRegisteredEntityTypeObjects();
        //System.out.println("here visited 9");
        if(hash.get(name) != null){
            
          //System.out.println("here visited 10");
          pme = (PounamuMetaModelElement)hash.get(name);
        }
        else{
	  LoadXMLFile lxf = null;
          //System.out.println("here visited 11");
          if(type.startsWith("entitytype")){
            //System.out.println("here visited 12");
            lxf = new LoadXMLFile(new File(tool.getLocation()+fileSeparator+"metamodel"+fileSeparator+"entitytypes"+fileSeparator+name+".xml"));
            //System.out.println(tool.getLocation()+""+fileSeparator+"entitytypes"+fileSeparator+""+name+".xml");
            //System.out.println("here visited 13");
          }
	  else{
            //System.out.println("here visited 14");
	    lxf = new LoadXMLFile(new File(tool.getLocation()+fileSeparator+"metamodel"+fileSeparator+"associationtypes"+fileSeparator+name+".xml"));
            //System.out.println("here visited 15");
          }
          //System.out.println("here visited 16");
          pme = new PounamuMetaModelElement(lxf.getDocument(), tool);
          //System.out.println("here visited 116");
          hash.put(name, pme);
          //System.out.println("here visited 17");
        }
        //System.out.println("here visited 18");
        nll = ((Element)m).getElementsByTagName("icontype");
        n = nll.item(0);
        String iconType = n.getFirstChild().getNodeValue();
        ps.setType(iconType);
        nll = ((Element)m).getElementsByTagName("iconname");
        n = nll.item(0);
        String iconName = n.getFirstChild().getNodeValue();
        ps.setName(iconName);
        File inputFile = null;
        //System.out.println("here visited 19");
        if(iconType.equals("S_DefaultShapeForEntityType"))
          inputFile = new File(tool.getPounamu().getPounamuHome()+""+fileSeparator+"nonjavafiles"+fileSeparator+""+iconType+".xml");
        else if(iconType.equals("S_DefaultShapeForAssociationType"))
          inputFile = new File(tool.getPounamu().getPounamuHome()+""+fileSeparator+"nonjavafiles"+fileSeparator+""+iconType+".xml");
        else
          inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconType+".xml");
        //System.out.println("here visited 20");
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        ps.setXMLDocument(lxf.getDocument());
        nll = ((Element)m).getElementsByTagName("basex");
        n = nll.item(0);
        int baseX = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("basey");
        n = nll.item(0);
        int baseY = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("width");
        n = nll.item(0);
        int width = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("height");
        n = nll.item(0);
        int height = new Integer(n.getFirstChild().getNodeValue()).intValue();
        basePanel.setBounds(baseX, baseY, width, height);
        //basePanel.addMouseListeners(modellerPanel);
        restoreProperties(m, ps, null);
        nll = ((Element)m).getElementsByTagName("id");
        n = nll.item(0);
        String id = n.getFirstChild().getNodeValue();
        //System.out.println("here visited 21");
        pme.addIcon(view, basePanel);
        ps.setRelatedObject(pme);
        //modellerPanel.getShapes().add(basePanel);
        modellerPanel.add(basePanel);
        basePanel.addMouseListeners(modellerPanel);
        ps.setView(view);
        ps.addDocumentListeners();
        modellerPanel.validate();
        //modellerPanel.setState("select");
        shapeHash.put(id, ps);        
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, tool);
        tool.getNodeAndViewsTabMapping().put(dmtn, tool.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        tool.getNodeAndViewMapping().put(dmtn, view);
        tool.getNodeAndIconMapping().put(dmtn, basePanel);        
        tool.getIconAndNodeMapping().put(basePanel, dmtn);
        tool.getNodeAndRegisteredXMLStringMapping().put(dmtn, pme.getXMLRepresentation());
        if(type.startsWith("entitytype")){
          //System.out.println("here visited 22");
          //tool.getNodeAndEntityTypeObjectMapping().put(dmtn, pme);
          tool.getNodeAndMenuItemsMapping().put(dmtn, tool.initMenuItemsForEntityTypeObject());
          tool.getNodeAndToolButtonsMapping().put(dmtn, tool.initToolIconsForEntityTypeObject());
          //tool.getRegisteredEntityTypeObjects().put(name, pme);
          tool.addEntityTypeObject(pme);
          tool.getRegisteredEntityTypeProperty().put(name, pme.getProperties());
          entityTypeNode.add(dmtn);
          //System.out.println("here visited 23");
        }
        else if(type.startsWith("associationtype")){
          //tool.getNodeAndAssociationTypeObjectMapping().put(dmtn, pme);
          tool.getNodeAndMenuItemsMapping().put(dmtn, tool.initMenuItemsForAssociationTypeObject());
          tool.getNodeAndToolButtonsMapping().put(dmtn, tool.initToolIconsForEntityTypeObject());
          //tool.getRegisteredAssociationTypeObjects().put(name, pme);
          tool.addAssociationTypeObject(pme);
          tool.getRegisteredAssociationTypeProperty().put(name, pme.getProperties());
          associationTypeNode.add(dmtn);
        }
        else{}
        //System.out.println("here visited 24");
        pme.setRegistered(true);
        pme.setWasRegistered(true);
        manager.getManagerTree().repaint();
        //System.out.println("here visited 25");
      }
      catch(Exception eeee){
        tool.getPounamu().displayMessage("Exception from Class RestoreMetaModelViewFromXML: "+eeee.toString());
        Toolkit.getDefaultToolkit().beep();
      }
      i++;
    }
    /*nl = root.getElementsByTagName("connector");
    i = 0;
    while(nl.item(i)!=null){
      Node m = nl.item(i);
      i++;
      NodeList nll = ((Element)m).getElementsByTagName("name");
      Node n = nll.item(0);
      String iconname = n.getFirstChild().getNodeValue();
      PounamuConnector pc = new PounamuConnector(iconname);
      nll = ((Element)m).getElementsByTagName("icontype");
      n = nll.item(0);
      String icontype = n.getFirstChild().getNodeValue();
      File inputFile = new File(modellerPanel.getProject().getLocation()+""+fileSeparator+""+icontype+".xml");;
      LoadXMLFile lxf = new LoadXMLFile(inputFile);
      pc.setXMLDocument(lxf.getDocument());
      nll = ((Element)m).getElementsByTagName("startshape");
      n = nll.item(0);
      String startShape = n.getFirstChild().getNodeValue();
      PounamuShape ps = (PounamuShape)shapeHash.get(startShape);
      PounamuPanel p = ps.getBasePanel();
      PounamuHandler[] handlers = p.getHandlers();
      nll = ((Element)m).getElementsByTagName("starthandler");
      n = nll.item(0);
      String s = n.getFirstChild().getNodeValue();
      int in = new Integer(s).intValue();
      pc.setStartHandler(handlers[in]);
      nll = ((Element)m).getElementsByTagName("endshape");
      n = nll.item(0);
      String endShape = n.getFirstChild().getNodeValue();
      ps = (PounamuShape)shapeHash.get(endShape);
      p = ps.getBasePanel();
      handlers = p.getHandlers();
      nll = ((Element)m).getElementsByTagName("endhandler");
      n = nll.item(0);
      s = n.getFirstChild().getNodeValue();
      in = new Integer(s).intValue();
      pc.setEndHandler(handlers[in]);
      nll = ((Element)m).getElementsByTagName("property");
      restoreProperties(m, null, pc);
      pc.setSelected(false);
      modellerPanel.getConnectors().add(pc);
      modellerPanel.add(pc);
      modellerPanel.validate();
    }*/
  }

  /**
   * restore properties from the Node m
   * @param m the Node which contains property information
   * @param ps the PounamuShape
   * @param pc the PounamuConnector
   */
  private void restoreProperties(Node m, PounamuShape ps, PounamuConnector pc){
    NodeList nl = ((Element)m).getElementsByTagName("property");
    int i = 0;
    while(nl.item(i)!=null){
      Node prop = nl.item(i); //node prperty
      NodeList nll = ((Element)prop).getElementsByTagName("propertypath");
      Node n = nll.item(0);//node propertypath
      String propertyPath = n.getFirstChild().getNodeValue();
      Object comp = null;
      if(ps!=null)
        comp = ps.pathComponentMapping.get(propertyPath);
      else
        comp = pc;
      setProperties(prop, comp);
      i++;
    }
  }

  /**
   * set the properties of the object comp
   * @param prop the node which contains all properties information
   * @param comp the object
   */
  private void setProperties(Node prop, Object comp){
    NodeList nl = null;
    Node m = null, n = null;
    try{
        nl = ((Element)prop).getElementsByTagName("propertyoldname");
        m = nl.item(0);//node proprtyname
        String propertyOldName = m.getFirstChild().getNodeValue();
        nl = ((Element)prop).getElementsByTagName("propertytype");
        m = nl.item(0);//node propertytype
        String propertyType = m.getFirstChild().getNodeValue();
        Class c = comp.getClass();
        String methodName = "set"+capitalizeFirstLetter(propertyOldName);
        nl = ((Element)prop).getElementsByTagName("propertyvalue");
        m = nl.item(0); //node propertyvalue
        if(propertyType.equals("int")){
          Method method = c.getMethod(methodName, new Class[]{int.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); //node simplevalue
          Integer value = new Integer(n.getFirstChild().getNodeValue());//value
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("boolean")){
          Method method = c.getMethod(methodName, new Class[]{boolean.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); //node simplevalue
          Boolean value = new Boolean(n.getFirstChild().getNodeValue());//value
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("String")||propertyType.equals("ArrowShape")){
          Method method = c.getMethod(methodName, new Class[]{String.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); ; //node simplevalue
          String value = "";
          if(n.getFirstChild()!=null)
            value = n.getFirstChild().getNodeValue();
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("Color")){
          Method method = c.getMethod(methodName, new Class[]{Color.class});
          nl = ((Element)m).getElementsByTagName("red");
          n = nl.item(0); //node red
          int red = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("green");
          n = nl.item(0);//node green
          int green = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("blue");
          n = nl.item(0);//node blue
          int blue = new Integer(n.getFirstChild().getNodeValue()).intValue();
          Color value = new Color(red, green, blue);
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("Font")){
          Method method = c.getMethod(methodName, new Class[]{Font.class});
          nl = ((Element)m).getElementsByTagName("family");
          n = nl.item(0); //node family
          String family = n.getFirstChild().getNodeValue();
          nl = ((Element)m).getElementsByTagName("style");
          n = nl.item(0);//node style
          int style = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("size");
          n = nl.item(0);//node size
          int size = new Integer(n.getFirstChild().getNodeValue()).intValue();
          Font value = new Font(family, style, size);
          method.invoke(comp, new Object[]{value});
        }

        else if(propertyType.equals("Border")){
          Method method = c.getMethod(methodName, new Class[]{Border.class});
          Border value = BorderFactory.createEmptyBorder();
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0);//node simplevalue
          if(n==null||n.getFirstChild()==null){
            value = BorderFactory.createEmptyBorder();
          }
          else{
            String border = n.getFirstChild().getNodeValue();
            if(border.equals("EmptyBorder"))
              value = BorderFactory.createEmptyBorder();
            else if(border.equals("LineBorder"))
              value = BorderFactory.createLineBorder(Color.black);
            else if(border.equals("EtchedBorder"))
              value = BorderFactory.createEtchedBorder();
            else if(border.equals("SharedRaisedBevel"))
              value = BorderFactory.createRaisedBevelBorder();
            else if(border.equals("SharedLoweredBevel"))
              value = BorderFactory.createLoweredBevelBorder();
            else{}
          }
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("Layout")){
          Method method = c.getMethod(methodName, new Class[]{LayoutManager.class});
          nl = ((Element)m).getElementsByTagName("layouttype");
          n = nl.item(0);//node layouttype
          LayoutManager value=null;
          String layouttype = n.getFirstChild().getNodeValue();
          if(layouttype.equals("null"))
            value = null;
          else if(layouttype.equals("FlowLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("alignment");
            n = nl.item(0);//node alignment
            int alignment = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new FlowLayout(alignment, hgap, vgap);
          }
          else if(layouttype.equals("VerticalFlowLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new VerticalFlowLayout(vgap);
          }
          else if(layouttype.equals("BorderLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new BorderLayout(hgap, vgap);
          }
          else if(layouttype.equals("GridLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("cols");
            n = nl.item(0);//node cols
            int cols = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("rows");
            n = nl.item(0);//node rows
            int rows = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new GridLayout(hgap, vgap, rows, cols);
          }
          else if(layouttype.equals("GridBagLayout")){
            value = new GridBagLayout();
          }
          else{}
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("HorizontalAlignment")||propertyType.equals("VerticalAlignment")){
          Method method = c.getMethod(methodName, new Class[]{int.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0);//node simplevalue
          Integer value = new Integer(n.getFirstChild().getNodeValue());
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("MultiLinesText")){
          Method method = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = new Vector();
          nl = ((Element)m).getElementsByTagName("item");//try to get the first node item
          int i = 0;
          while(nl.item(i)!=null){
            n = nl.item(i);
            value.add(n.getFirstChild().getNodeValue());
            i++;
          }
          method.invoke(comp, new Object[]{value});
        }
        else{}
    }
    catch(Exception e){
      tool.getPounamu().displayMessage("Exception from Class RestoreMetaModelViewFromXML: "+e.toString());
      Toolkit.getDefaultToolkit().beep();
    }
  }

  /**
   * a help method to change the first letter of a string into capital letter
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }
}