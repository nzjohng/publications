/*
 * @(#)RestoreModelViewFromXML.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: RestoreModelViewFromXML
 * Description:  restore a modelling view from its xml file
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class RestoreModelViewFromXML{

  Document xmlDocument= null;
  ModellerPanel modellerPanel = null;
  Element root = null;
  StringBuffer sb = new StringBuffer(40000);
  static int count = 0;
  String name = null;
  String type = null;
  Hashtable shapeHash = new Hashtable();
  PounamuManagerPanel manager = null;
  PounamuView view = null;
  PounamuModelProject model = null;
  PounamuToolProject tool = null;
  String fileSeparator = null;
  /**
   * constructor
   * @param xmlDocument the xml document which contains the modelling view information
   * @param modellerPanel the panel to redisplay the modelling view
   */
  public RestoreModelViewFromXML(Document xmlDocument, ModellerPanel modellerPanel){
    this.xmlDocument = xmlDocument;
    fileSeparator = System.getProperty("file.separator");
    this.modellerPanel = modellerPanel;
    this.view = modellerPanel.getView();
    this.type = view.getType();
    this.model = (PounamuModelProject)modellerPanel.getProject();
    this.tool = model.getTool();
    this.manager = model.getManager();
    this.root = xmlDocument.getDocumentElement();
    //System.out.println("in class RestoreModelViewFromXML, constructor visited 0");
  }

  /**
   * redisplay the view from the xml document
   */
  public void restore(){
    NodeList nl = root.getElementsByTagName("shape");
    int i = 0;
    while(nl.item(i)!=null){
      try{
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 0");
        PounamuModelElement pme = null;
        PounamuShape ps = new PounamuShape();
        ps.setProject(model);
        ps.setManager(manager); 
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 1");
        PounamuPanel basePanel = ps.getBasePanel();
        Node m = nl.item(i);
        NodeList nll = ((Element)m).getElementsByTagName("name");
        Node n = nll.item(0);
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 2");
        String name = n.getFirstChild().getNodeValue();
        nll = ((Element)m).getElementsByTagName("type");
        n = nll.item(0);
        String t = n.getFirstChild().getNodeValue();
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 3");
        PounamuModelElement entity = model.getEntity(t, name);
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 33");
        if(entity != null)
          pme = entity;
        else{
          LoadXMLFile lxf = new LoadXMLFile(new File(model.getLocation()+fileSeparator+"entity_objects"+fileSeparator+t+""+fileSeparator+""+name+".xml"));
          System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 333");
          pme = new PounamuModelElement(lxf.getDocument(), model);
          //model.addEntity(pme);
        }
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 4");
        nll = ((Element)m).getElementsByTagName("icontype");
        n = nll.item(0);
        String iconType = n.getFirstChild().getNodeValue();
        ps.setType(iconType);
        nll = ((Element)m).getElementsByTagName("iconname");
        n = nll.item(0);
        String iconName = n.getFirstChild().getNodeValue();
        ps.setName(iconName);
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 5");
        File inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconType+".xml");
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        ps.setXMLDocument(lxf.getDocument());
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 6");
        nll = ((Element)m).getElementsByTagName("basex");
        n = nll.item(0);
        int baseX = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("basey");
        n = nll.item(0);
        int baseY = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("width");
        n = nll.item(0);
        int width = new Integer(n.getFirstChild().getNodeValue()).intValue();
        nll = ((Element)m).getElementsByTagName("height");
        n = nll.item(0);
        int height = new Integer(n.getFirstChild().getNodeValue()).intValue();
        basePanel.setBounds(baseX, baseY, width, height);
        restoreProperties(m, ps, null);
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 7");
        nll = ((Element)m).getElementsByTagName("id");
        n = nll.item(0);
        String id = n.getFirstChild().getNodeValue();
        nll = ((Element)m).getElementsByTagName("rootid");
        n = nll.item(0);
        String rootid = n.getFirstChild().getNodeValue();        
        nll = ((Element)m).getElementsByTagName("objectid");
        n = nll.item(0);
        String objectid = n.getFirstChild().getNodeValue();        
        ps.setRootID(rootid);
        ps.setObjectID(objectid);
        pme.addIcon(view, basePanel);
        ps.setRelatedObject(pme);
        modellerPanel.add(basePanel);
        basePanel.addMouseListeners(modellerPanel);
        ps.setView(view);
        ps.addDocumentListeners();
        modellerPanel.validate();
        shapeHash.put(id, ps);
        model.addEntity(pme);
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 8");
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, model);
        manager.getNodeAndItsValueMapping().put(dmtn, name);
        model.getNodeAndViewsTabMapping().put(dmtn, model.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        model.getNodeAndViewMapping().put(dmtn, view);
        model.getNodeAndIconMapping().put(dmtn, basePanel);
        model.getNodeAndMenuItemsMapping().put(dmtn, model.initMenuItemsForEntity());
        model.getNodeAndToolButtonsMapping().put(dmtn, model.initToolButtonsForEntity());
        model.getIconAndNodeMapping().put(basePanel, dmtn);
        model.getNodeAndSavedXMLStringMapping().put(dmtn, pme.getXMLRepresentation());
        System.out.println("in class RestoreMOdelViewFromXML.restore(), visited 9");
        DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getTempHashForOpenModel().get(view.getName()+"_"+t);
        manager.addTreeNode(parent, dmtn);
        pme.setKey();
      }
      catch(Exception eeee){
        model.getPounamu().displayMessage("Exception from Class RestoreModelViewFromXML: "+eeee.toString());
        Toolkit.getDefaultToolkit().beep();
      }
      i++;
    }
    nl = root.getElementsByTagName("connector");
    i = 0;
    while(nl.item(i)!=null){
      PounamuModelElement pme = null;
      Node m = nl.item(i);
      i++;
      NodeList nll = ((Element)m).getElementsByTagName("name");
      Node n = nll.item(0);
      String name = n.getFirstChild().getNodeValue();
      nll = ((Element)m).getElementsByTagName("type");
      n = nll.item(0);
      String t = n.getFirstChild().getNodeValue();
      PounamuModelElement association = model.getAssociation(t, name);
      if(association != null)
        pme = association;
      else{
        LoadXMLFile lxf = new LoadXMLFile(new File(model.getLocation()+""+fileSeparator+"association_objects"+fileSeparator+""+t+""+fileSeparator+""+name+".xml"));
        pme = new PounamuModelElement(lxf.getDocument(), model); 
        model.addAssociation(pme);
      }
      PounamuConnector pc = new PounamuConnector(name);
      nll = ((Element)m).getElementsByTagName("rootid");
      n = nll.item(0);      
      String rootid = n.getFirstChild().getNodeValue();        
      nll = ((Element)m).getElementsByTagName("objectid");
      n = nll.item(0);
      String objectid = n.getFirstChild().getNodeValue();        
      pc.setRootID(rootid);
      pc.setObjectID(objectid);      
      
      nll = ((Element)m).getElementsByTagName("icontype");
      n = nll.item(0);
      String iconType = n.getFirstChild().getNodeValue();
      File inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+iconType+".xml");;
      LoadXMLFile lxf = new LoadXMLFile(inputFile);
      pc.setType(iconType);
      pc.setXMLDocument(lxf.getDocument());
      nll = ((Element)m).getElementsByTagName("startshape");
      n = nll.item(0);
      String startShape = n.getFirstChild().getNodeValue();
      PounamuShape ps = (PounamuShape)shapeHash.get(startShape);
      PounamuPanel p = ps.getBasePanel();
      PounamuHandle[] handlers1 = p.getHandlers();
      nll = ((Element)m).getElementsByTagName("starthandler");
      n = nll.item(0);
      String startHandler = n.getFirstChild().getNodeValue();
      int first = new Integer(startHandler).intValue();
      nll = ((Element)m).getElementsByTagName("endshape");
      n = nll.item(0);
      String endShape = n.getFirstChild().getNodeValue();
      ps = (PounamuShape)shapeHash.get(endShape);
      p = ps.getBasePanel();
      PounamuHandle[] handlers2 = p.getHandlers();
      nll = ((Element)m).getElementsByTagName("endhandler");
      n = nll.item(0);
      String endHandler = n.getFirstChild().getNodeValue();
      int second = new Integer(endHandler).intValue();
      pc.setHandlers(handlers1[first], handlers2[second]);
      nll = ((Element)m).getElementsByTagName("property");
      restoreProperties(m, null, pc);
      pc.setSelected(false);
      pc.setRelatedObject(pme);
      pme.addIcon(view, pc);
      modellerPanel.add(pc);
      modellerPanel.repaint();
      modellerPanel.validate();
      model.addAssociation(pme);
      DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndProjectMapping().put(dmtn, model);
      manager.getNodeAndItsValueMapping().put(dmtn, name);
      model.getNodeAndViewsTabMapping().put(dmtn, model.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
      model.getNodeAndViewMapping().put(dmtn, view);
      model.getNodeAndIconMapping().put(dmtn, pc);
      model.getNodeAndMenuItemsMapping().put(dmtn, model.initMenuItemsForAssociation());
      model.getNodeAndToolButtonsMapping().put(dmtn, model.initToolButtonsForAssociation());
      model.getIconAndNodeMapping().put(pc, dmtn);
      model.getNodeAndSavedXMLStringMapping().put(dmtn, pme.getXMLRepresentation());
      DefaultMutableTreeNode parent = (DefaultMutableTreeNode)model.getTempHashForOpenModel().get(view.getName()+"_"+t);
      manager.addTreeNode(parent, dmtn);
      pme.setKey();
    }
  }

  /**
   * restore properties from the Node m
   * @param m the Node which contains property information
   * @param ps the PounamuShape
   * @param pc the PounamuConnector
   */
  private void restoreProperties(Node m, PounamuShape ps, PounamuConnector pc){
    NodeList nl = ((Element)m).getElementsByTagName("property");
    int i = 0;
    while(nl.item(i)!=null){
      Node prop = nl.item(i); //node prperty
      NodeList nll = ((Element)prop).getElementsByTagName("propertypath");
      Node n = nll.item(0);//node propertypath
      String propertyPath = n.getFirstChild().getNodeValue();
      Object comp = null;
      if(ps!=null)
        comp = ps.pathComponentMapping.get(propertyPath);
      else
        comp = pc;
      setProperties(prop, comp);
      i++;
    }
  }

  /**
   * set the properties of the object comp
   * @param prop the node which contains all properties information
   * @param comp the object
   */
  private void setProperties(Node prop, Object comp){
    NodeList nl = null;
    Node m = null, n = null;
    try{
        nl = ((Element)prop).getElementsByTagName("propertyoldname");
        m = nl.item(0);//node proprtyname
        String propertyOldName = m.getFirstChild().getNodeValue();
        nl = ((Element)prop).getElementsByTagName("propertytype");
        m = nl.item(0);//node propertytype
        String propertyType = m.getFirstChild().getNodeValue();
        Class c = comp.getClass();
        String methodName = "set"+capitalizeFirstLetter(propertyOldName);
        nl = ((Element)prop).getElementsByTagName("propertyvalue");
        m = nl.item(0); //node propertyvalue
        if(propertyType.equals("int")){
          Method method = c.getMethod(methodName, new Class[]{int.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); //node simplevalue
          Integer value = new Integer(n.getFirstChild().getNodeValue());//value
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("boolean")){
          Method method = c.getMethod(methodName, new Class[]{boolean.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); //node simplevalue
          Boolean value = new Boolean(n.getFirstChild().getNodeValue());//value
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("String")||propertyType.equals("ArrowShape")){
          Method method = c.getMethod(methodName, new Class[]{String.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0); ; //node simplevalue
          String value = "";
          if(n.getFirstChild()!=null)
            value = n.getFirstChild().getNodeValue();
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("Color")){
          Method method = c.getMethod(methodName, new Class[]{Color.class});
          nl = ((Element)m).getElementsByTagName("red");
          n = nl.item(0); //node red
          int red = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("green");
          n = nl.item(0);//node green
          int green = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("blue");
          n = nl.item(0);//node blue
          int blue = new Integer(n.getFirstChild().getNodeValue()).intValue();
          Color value = new Color(red, green, blue);
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("Font")){
          Method method = c.getMethod(methodName, new Class[]{Font.class});
          nl = ((Element)m).getElementsByTagName("family");
          n = nl.item(0); //node family
          String family = n.getFirstChild().getNodeValue();
          nl = ((Element)m).getElementsByTagName("style");
          n = nl.item(0);//node style
          int style = new Integer(n.getFirstChild().getNodeValue()).intValue();
          nl = ((Element)m).getElementsByTagName("size");
          n = nl.item(0);//node size
          int size = new Integer(n.getFirstChild().getNodeValue()).intValue();
          Font value = new Font(family, style, size);
          method.invoke(comp, new Object[]{value});
        }

        else if(propertyType.equals("Border")){
          Method method = c.getMethod(methodName, new Class[]{Border.class});
          Border value = BorderFactory.createEmptyBorder();
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0);//node simplevalue
          if(n==null||n.getFirstChild()==null){
            value = BorderFactory.createEmptyBorder();
          }
          else{
            String border = n.getFirstChild().getNodeValue();
            if(border.equals("EmptyBorder"))
              value = BorderFactory.createEmptyBorder();
            else if(border.equals("LineBorder"))
              value = BorderFactory.createLineBorder(Color.black);
            else if(border.equals("EtchedBorder"))
              value = BorderFactory.createEtchedBorder();
            else if(border.equals("SharedRaisedBevel"))
              value = BorderFactory.createRaisedBevelBorder();
            else if(border.equals("SharedLoweredBevel"))
              value = BorderFactory.createLoweredBevelBorder();
            else{}
          }
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("LayoutParameters")){
          Method method = c.getMethod(methodName, new Class[]{LayoutManager.class});
          nl = ((Element)m).getElementsByTagName("layouttype");
          n = nl.item(0);//node layouttype
          LayoutManager value=null;
          String layouttype = n.getFirstChild().getNodeValue();
          if(layouttype.equals("null"))
            value = null;
          else if(layouttype.equals("FlowLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("alignment");
            n = nl.item(0);//node alignment
            int alignment = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new FlowLayout(alignment, hgap, vgap);
          }
          else if(layouttype.equals("VerticalFlowLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new VerticalFlowLayout(vgap);
          }
          else if(layouttype.equals("BorderLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new BorderLayout(hgap, vgap);
          }
          else if(layouttype.equals("GridLayout")){
            nl = ((Element)m).getElementsByTagName("vgap");
            n = nl.item(0);//node vgap
            int vgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("hgap");
            n = nl.item(0);//node hgap
            int hgap = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("cols");
            n = nl.item(0);//node cols
            int cols = new Integer(n.getFirstChild().getNodeValue()).intValue();
            nl = ((Element)m).getElementsByTagName("rows");
            n = nl.item(0);//node rows
            int rows = new Integer(n.getFirstChild().getNodeValue()).intValue();
            value = new GridLayout(hgap, vgap, rows, cols);
          }
          else if(layouttype.equals("GridBagLayout")){
            value = new GridBagLayout();
          }
          else{}
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("HorizontalAlignment")||propertyType.equals("VerticalAlignment")){
          Method method = c.getMethod(methodName, new Class[]{int.class});
          nl = ((Element)m).getElementsByTagName("simplevalue");
          n = nl.item(0);//node simplevalue
          Integer value = new Integer(n.getFirstChild().getNodeValue());
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("MultiLinesText")){
          Method method = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = new Vector();
          nl = ((Element)m).getElementsByTagName("item");//try to get the first node item
          int i = 0;
          while(nl.item(i)!=null){
            n = nl.item(i);
            value.add(n.getFirstChild().getNodeValue());
            i++;
          }
          method.invoke(comp, new Object[]{value});
        }
        else if(propertyType.equals("GridBagConstraints")){
				          Method method = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
				          GridBagConstraints value = new GridBagConstraints();
				          nl = ((Element)m).getElementsByTagName("gridx");
				          n = nl.item(0);
				          value.gridx = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("gridy");
				          n = nl.item(0);
				          value.gridy = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("gridwidth");
				          n = nl.item(0);
				          value.gridwidth = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("gridheight");
				          n = nl.item(0);
				          value.gridheight = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("ipadx");
				          n = nl.item(0);
				          value.ipadx = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("ipady");
				          n = nl.item(0);
				          value.ipady = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("weightx");
				          n = nl.item(0);
				          value.weightx = new Double(n.getFirstChild().getNodeValue()).doubleValue();
				          nl = ((Element)m).getElementsByTagName("weighty");
				          n = nl.item(0);
				          value.weighty = new Double(n.getFirstChild().getNodeValue()).doubleValue();
				          nl = ((Element)m).getElementsByTagName("insets_bottom");
				          n = nl.item(0);
				          value.insets.bottom = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_left");
				          n = nl.item(0);
				          value.insets.left = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_right");
				          n = nl.item(0);
				          value.insets.right = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_top");
				          n = nl.item(0);
				          value.insets.top = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("fill");
				          n = nl.item(0);
				          value.fill = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("anchor");
				          n = nl.item(0);
				          value.anchor = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          method.invoke(comp, new Object[]{value});
				        }
				        else if(propertyType.equals("Insets")){
				          Method method = c.getMethod(methodName, new Class[]{Insets.class});
				          Insets value = new Insets(0, 0, 0, 0);
				          nl = ((Element)m).getElementsByTagName("insets_top");
				          n = nl.item(0);
				          value.top = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_bottom");
				          n = nl.item(0);
				          value.bottom = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_left");
				          n = nl.item(0);
				          value.left = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("insets_right");
				          n = nl.item(0);
				          value.right = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          method.invoke(comp, new Object[]{value});
				        }
				        else if(propertyType.equals("Position")){
				          Method method = c.getMethod(methodName, new Class[]{String.class});
				          nl = ((Element)m).getElementsByTagName("simplevalue");
				          n = nl.item(0);
				          String value = n.getFirstChild().getNodeValue();
				          method.invoke(comp, new Object[]{value});
				        }
				        else if(propertyType.equals("ShapeType")){
				          Method method = c.getMethod(methodName, new Class[]{String.class});
				          nl = ((Element)m).getElementsByTagName("simplevalue");
				          n = nl.item(0);
				          String value = n.getFirstChild().getNodeValue();
				          method.invoke(comp, new Object[]{value});
				        }
				        else if(propertyType.equals("Location")){
				          Method method = c.getMethod(methodName, new Class[]{Point.class});
				          Point value = new Point();
				          nl = ((Element)m).getElementsByTagName("x");
				          n = nl.item(0);
				          value.x = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("y");
				          n = nl.item(0);
				          value.y = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          method.invoke(comp, new Object[]{value});
				        }
				        else if(propertyType.equals("Size")){
				          Method method = c.getMethod(methodName, new Class[]{Dimension.class});
				          Dimension value = new Dimension();
				          nl = ((Element)m).getElementsByTagName("width");
				          n = nl.item(0);
				          value.width = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          nl = ((Element)m).getElementsByTagName("height");
				          n = nl.item(0);
				          value.height = new Integer(n.getFirstChild().getNodeValue()).intValue();
				          method.invoke(comp, new Object[]{value});
				          if(comp instanceof PounamuPanel){
				          	((PounamuPanel)comp).setSize(value);
				          	((PounamuPanel)comp).setPreferredSize(value);
					  }
		          }
		        else if(propertyType.equals("BasicStroke")){
						          Method method = c.getMethod(methodName, new Class[]{BasicStroke.class});
						          nl = ((Element)m).getElementsByTagName("linewidth");
						          n = nl.item(0); //node linewidth
						          float linewidth = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("endcaps");
						          n = nl.item(0);//node endcaps
						          int endcaps = new Integer(n.getFirstChild().getNodeValue()).intValue();
						          nl = ((Element)m).getElementsByTagName("linejoints");
						          n = nl.item(0);//node linejoints
						          int linejoints = new Integer(n.getFirstChild().getNodeValue()).intValue();
						          nl = ((Element)m).getElementsByTagName("dasharray0");
						          n = nl.item(0); //node dasharray0
						          float dasharray0 = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("dasharray1");
						          n = nl.item(0); //node dasharray1
						          float dasharray1 = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("dasharray2");
						          n = nl.item(0); //node dasharray2
						          float dasharray2 = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("dasharray3");
						          n = nl.item(0); //node dasharray3
						          float dasharray3 = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("dashphase");
						          n = nl.item(0); //node dashphase
						          float dashphase = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          nl = ((Element)m).getElementsByTagName("miterlimit");
						          n = nl.item(0); //node miterlimit
						          float miterlimit = new Float(n.getFirstChild().getNodeValue()).floatValue();
						          float[] dash = new float[]{dasharray0, dasharray1, dasharray2, dasharray3};
						          BasicStroke value = new BasicStroke(linewidth, endcaps, linejoints, miterlimit, dash, dashphase);
						          method.invoke(comp, new Object[]{value});
        }
        else{}
    }
    catch(Exception e){
      model.getPounamu().displayMessage("Exception from Class RestoreModelViewFromXML: "+e.toString());
      Toolkit.getDefaultToolkit().beep();
    }
  }

  /**
   * a help method to change the first letter of a string into capital letter
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }
}