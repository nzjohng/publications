/*
 * @(#)ConfigureMetaModelDefiner.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.util.*;
import pounamu.data.*;
import pounamu.visualcomp.*;


/**
 * Title: ConfigureMetaModelDefiner
 * Description:  A dialog to be used to configure a metamodel definer, mainly, to choose icon for entity type or association type
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class ConfigureMetaModelDefiner extends JDialog {

  JRadioButton entityName = new JRadioButton("name");
  JRadioButton entityProperty = new JRadioButton("property");
  JRadioButton associationName = new JRadioButton("name");
  JRadioButton associationProperty = new JRadioButton("property");
  JComboBox availableShapes1 = new JComboBox();
  JComboBox availableShapes2 = new JComboBox();
  JComboBox textFieldProperties1 = new JComboBox();
  JComboBox textFieldProperties2 = new JComboBox();
  JComboBox textAreaProperties1 = new JComboBox();
  JComboBox textAreaProperties2 = new JComboBox();
  JButton ok = new JButton("   Apply   ");
  JButton def = new JButton("   Use Default   ");
  JButton cancel = new JButton("Cancel");
  PounamuManagerPanel manager = null;
  PounamuToolProject project = null;
  /**
   * construct a dialog which allow user to choose an icon for a metamodel element
   * @param project the PounamuProject instance which contains the meta model definer
   */
  public ConfigureMetaModelDefiner(PounamuProject project){
    super(project.getPounamu(), "Configure Meta Model Definer", true);
    this.project = (PounamuToolProject)project;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Component initialization
   */
  private void jbInit() throws Exception {
    initAvailableShapes();
    entityName.setEnabled(false);
    entityProperty.setEnabled(false);
    associationName.setEnabled(false);
    associationProperty.setEnabled(false);
    textFieldProperties1.setEnabled(false);
    textFieldProperties2.setEnabled(false);
    textAreaProperties1.setEnabled(false);
    textAreaProperties2.setEnabled(false);
    JLabel jl0 = new JLabel("shape for entity type:");
    JPanel jPanel0 = new JPanel(new GridLayout(1, 2));
    jPanel0.add(jl0);
    jPanel0.add(availableShapes1);
    jPanel0.setBorder(BorderFactory.createTitledBorder("select a shape"));
    JPanel jPanel1 = new JPanel(new GridLayout(2, 2));
    jPanel1.add(entityName);
    jPanel1.add(textFieldProperties1);
    jPanel1.add(entityProperty);
    jPanel1.add(textAreaProperties1);
    jPanel1.setBorder(BorderFactory.createTitledBorder("match properties"));
    JPanel upper = new JPanel(new VerticalFlowLayout());
    upper.add(jPanel0);
    upper.add(jPanel1);
    upper.setBorder(BorderFactory.createTitledBorder("entity type"));
    textFieldProperties1.setEnabled(false);
    textAreaProperties1.setEnabled(false);
    JLabel jl3 = new JLabel("shape for association type:");
    JPanel jPanel3 = new JPanel(new GridLayout(1, 2));
    jPanel3.add(jl3);
    jPanel3.add(availableShapes2);
    jPanel3.setBorder(BorderFactory.createTitledBorder("select a shape"));
    JPanel jPanel4 = new JPanel(new GridLayout(2, 2));
    jPanel4.add(associationName);
    jPanel4.add(textFieldProperties2);
    jPanel4.add(associationProperty);
    jPanel4.add(textAreaProperties2);
    jPanel4.setBorder(BorderFactory.createTitledBorder("match properties"));
    JPanel lower = new JPanel(new VerticalFlowLayout());
    lower.add(jPanel3);
    lower.add(jPanel4);
    lower.setBorder(BorderFactory.createTitledBorder("association type"));
    JPanel jPanel6 = new JPanel();
    jPanel6.add(ok);
    jPanel6.add(def);
    jPanel6.add(cancel);
    this.getContentPane().setLayout(new VerticalFlowLayout());
    this.getContentPane().add(upper);
    this.getContentPane().add(lower);
    this.getContentPane().add(jPanel6);
    this.setResizable(false);
    this.pack();
    availableShapes1.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        entityName.setEnabled(true);
        entityProperty.setEnabled(true);
        initPropertyBoxForEntityType((String)availableShapes1.getSelectedItem());
      }
    });
    availableShapes2.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        associationName.setEnabled(true);
        associationProperty.setEnabled(true);
        initPropertyBoxForAssociationType((String)availableShapes2.getSelectedItem());
      }
    });
    entityName.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        JRadioButton jb = (JRadioButton)ie.getItem();
        textFieldProperties1.setEnabled(jb.isSelected());
      }
    });
    entityProperty.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        JRadioButton jb = (JRadioButton)ie.getItem();
        textAreaProperties1.setEnabled(jb.isSelected());
      }
    });
    associationName.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        JRadioButton jb = (JRadioButton)ie.getItem();
        textFieldProperties2.setEnabled(jb.isSelected());
      }
    });
    associationProperty.addItemListener(new ItemListener(){
      public void itemStateChanged(ItemEvent ie){
        JRadioButton jb = (JRadioButton)ie.getItem();
        textAreaProperties2.setEnabled(jb.isSelected());
      }
    });
    //entityName.setSelected(true);
    ok.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        okPressed();
      }
    });
    def.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        defPressed();
      }
    });
    cancel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e){
        cancelPressed();
      }
    });
    //initPropertyBoxOfSelectedShape((String)availableShapes.getSelectedItem());*/
  }

  /**
   * init available shapes which can be used as icons for both entity type or association type
   */
  public void initAvailableShapes(){
    availableShapes1.addItem("");
    availableShapes2.addItem("");
    Vector v = ((PounamuToolProject)project).getRegisteredShapes();
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.elementAt(i);
      availableShapes1.addItem(s);
      availableShapes2.addItem(s);
    }
  }

  /**
   * init a combo box which contains all properties of the specified Entity type
   * @param name the name of the entity type
   */
  public void initPropertyBoxForEntityType(String name){
    if(name==""){
      entityName.setEnabled(false);
      entityName.setSelected(false);
      textFieldProperties1.removeAllItems();
      textFieldProperties1.setEnabled(false);
      entityProperty.setEnabled(false);
      entityProperty.setSelected(false);
      textAreaProperties1.removeAllItems();
      textAreaProperties1.setEnabled(false);
      return;
    }
    textFieldProperties1.removeAllItems();
    textAreaProperties1.removeAllItems();
    textFieldProperties1.addItem("");
    textAreaProperties1.addItem("");
    Vector v = (Vector)((PounamuToolProject)project).getTextFieldProperties(name);
    if(v != null){
      Object[] s = v.toArray();
      Arrays.sort(s);
      for(int i = 0; i < s.length; i++){
        String temp = (String)s[i];
        textFieldProperties1.addItem(temp);
      }
    }
    else
      textFieldProperties1.setEnabled(false);
    v = (Vector)((PounamuToolProject)project).getTextAreaProperties(name);
    if(v != null){
      Object[] s = v.toArray();
      Arrays.sort(s);
      for(int i = 0; i < s.length; i++){
        String temp = (String)s[i];
        textAreaProperties1.addItem(temp);
      }
    }
    else
      textAreaProperties2.setEnabled(false);
  }

  /**
   * init a combo box which contains all properties of the specified association type
   * @param name the name of the association type
   */
  public void initPropertyBoxForAssociationType(String name){
    if(name==""){
      associationName.setEnabled(false);
      associationName.setSelected(false);
      textFieldProperties2.removeAllItems();
      textFieldProperties2.setEnabled(false);
      associationProperty.setEnabled(false);
      associationProperty.setSelected(false);
      textAreaProperties2.removeAllItems();
      textAreaProperties2.setEnabled(false);
      return;
    }
    textFieldProperties2.removeAllItems();
    textAreaProperties2.removeAllItems();
    textFieldProperties2.addItem("");
    textAreaProperties2.addItem("");
    Vector v = (Vector)((PounamuToolProject)project).getTextFieldProperties(name);
    if(v != null){
      Object[] s = v.toArray();
      Arrays.sort(s);
      for(int i = 0; i < s.length; i++){
        String temp = (String)s[i];
        textFieldProperties2.addItem(temp);
      }
    }
    v = (Vector)((PounamuToolProject)project).getTextAreaProperties(name);
    if(v != null){
      Object[] s = v.toArray();
      Arrays.sort(s);
      for(int i = 0; i < s.length; i++){
        String temp = (String)s[i];
        textAreaProperties2.addItem(temp);
      }
    }
  }

  /**
   * check that the property mapping is "one to one"
   */
  private boolean checkValid(){
    if(!entityName.isEnabled()){
      project.getPounamu().displayMessage("name property of entity type must map to a property");
      return false;
    }
    if(!associationName.isEnabled()){
      project.getPounamu().displayMessage("name property of association type must map to a property");
      return false;
    }
    if(entityName.isEnabled() && ((String)textFieldProperties1.getSelectedItem()).equals("")){
      project.getPounamu().displayMessage("name property of entity typecan not map to null");
      return false;
    }
    if(associationName.isEnabled() && ((String)textFieldProperties2.getSelectedItem()).equals("")){
      project.getPounamu().displayMessage("name property of association type can not map to null");
      return false;
    }
    return true;
  }

  private void cancelPressed(){
    this.dispose();
  }

  private void defPressed(){
    project.setEntityTypeIcon("Shape_ForEntityType");
    project.setAssociationTypeIcon("Shape_ForAssociationType");
    project.getPropertyMappingFromAssociationTypeToIcon().put("name", "Shape_ForAssociationType_name");
    project.getPropertyMappingFromIconToAssociationType().put("Shape_ForAssociationType_name", "name");
    project.getPropertyMappingFromAssociationTypeToIcon().put("property", "Shape_ForAssociationType_property");
    project.getPropertyMappingFromIconToAssociationType().put("Shape_ForAssociationType_property", "property");
    project.getPropertyMappingFromEntityTypeToIcon().put("name", "Shape_ForEntityType_name");
    project.getPropertyMappingFromIconToEntityType().put("Shape_ForEntityType_name", "name");
    project.getPropertyMappingFromEntityTypeToIcon().put("property", "Shape_ForEntityType_property");
    project.getPropertyMappingFromIconToEntityType().put("Shape_ForEntityType_property", "property");
    this.dispose();
  }
  /*
   * specify what to be started when ok pressed..
   */
  private void okPressed(){
    if(!checkValid()){
      return;
    }
    if(!(((String)availableShapes1.getSelectedItem()).equals(""))){
      project.setEntityTypeIcon((String)availableShapes1.getSelectedItem());
      project.getPropertyMappingFromEntityTypeToIcon().put("name", (String)textFieldProperties1.getSelectedItem());
      project.getPropertyMappingFromIconToEntityType().put((String)textFieldProperties1.getSelectedItem(), "name");
      if(entityProperty.isEnabled() && !(((String)textAreaProperties1.getSelectedItem()).equals(""))){
        project.getPropertyMappingFromEntityTypeToIcon().put("property", (String)textAreaProperties1.getSelectedItem());
        project.getPropertyMappingFromIconToEntityType().put((String)textAreaProperties1.getSelectedItem(), "property");
      }
    }
    if(!(((String)availableShapes2.getSelectedItem()).equals(""))){
      project.setAssociationTypeIcon((String)availableShapes2.getSelectedItem());
      project.getPropertyMappingFromAssociationTypeToIcon().put("name", (String)textFieldProperties2.getSelectedItem());
      project.getPropertyMappingFromIconToAssociationType().put((String)textFieldProperties2.getSelectedItem(), "name");
      if(associationProperty.isEnabled() && !(((String)textAreaProperties1.getSelectedItem()).equals(""))){
        project.getPropertyMappingFromAssociationTypeToIcon().put("property", (String)textAreaProperties2.getSelectedItem());
        project.getPropertyMappingFromIconToAssociationType().put((String)textAreaProperties2.getSelectedItem(), "property");
      }
    }
    this.dispose();
  }
}