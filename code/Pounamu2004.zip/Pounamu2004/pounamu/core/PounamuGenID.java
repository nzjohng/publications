/*
 * @(#)PounamuID.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

 /**
  * Title: PounamuGenID
  * Description:  A mechanizm to give each Pounamu Object an ID
  * Copyright:    Copyright (c) 2003
  * Company:      Auckland UniServices Limited
  * @author       Akhil Mehra
  * @version 1.0
 */


public class PounamuGenID {


		public static String genID() {

				RandomGUID myGUID = new RandomGUID();
				return myGUID.toString();

		}

}