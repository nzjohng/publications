/*
 * @(#)PounamuCommandListener.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.core;

import pounamu.command.*;

/**
 * Title: PounamuCommandListener
 * Description:  A interface to specify any pounamu command
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public interface PounamuCommandListener{
  /**
   * specify what will happen when this command performed
   * @param command the PounamuCommand object
   * @param type the command type:excute, undo, redo
   */
  public void commandPerformed(PounamuCommand command, int type);
}
