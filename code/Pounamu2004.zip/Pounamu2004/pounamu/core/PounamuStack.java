/*
 * @(#)PounamuStack.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */
package pounamu.core;

import javax.swing.DefaultListModel;
import java.util.Vector;
import java.util.Hashtable;
import pounamu.command.*;

/**
 * Title: PounamuStack
 * Description:  extends DefaultListModel to hold pounamu undo/redo list items as a stack
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuStack extends DefaultListModel{
  Vector stack = new Vector();
  Hashtable itemAndObjectMapping = new Hashtable();
  static int count = 0;

  /**
   * the constructor
   * i) super
   */
  public PounamuStack(){
    super();
  }
  /**
   * push a pounamu command object to the top of this stack
   * @param pc the PounamuCommand object
   */
  public void push(PounamuCommand pc){
    String item = count+": "+pc.getDescription();
    count++;
    itemAndObjectMapping.put(item, pc);
    insertElementAt(item, 0);
    stack.add(pc);
  }

  /**
   * pop the PounamuCommand that is on the top of this stack
   * @return the PounamuCommand object on the top of this stack
   */
  public PounamuCommand pop(){
    String item = (String)firstElement();
    PounamuCommand pc = (PounamuCommand)itemAndObjectMapping.get(item);
    removeElementAt(0);
    stack.remove(pc);
    itemAndObjectMapping.remove(item);
    return pc;
  }

  /**
   * remove a pounamu command object from this stack
   * @param key the key related to the object to be removed
   */
  public void removeEntry(String key){
    PounamuCommand pc = (PounamuCommand)itemAndObjectMapping.get(key);
    stack.remove(pc);
    itemAndObjectMapping.remove(key);
  }

  /**
   * remove all elements in this stack
   */
  public void removeAllEntries(){
    stack.clear();
    itemAndObjectMapping.clear();
  }

  /**
   * get a pounamu command object by key
   * @return the pounamu command object
   */
  public PounamuCommand getCommandObject(String key){
    return (PounamuCommand)itemAndObjectMapping.get(key);
  }
}

