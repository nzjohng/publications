/*
 * @(#)NewConnectorEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: NewConnectorEvent
 * Description:  A new connector event
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class NewConnectorEvent extends PounamuEvent{

  protected PounamuConnector connector = null;
  
  /** Holds value of property startHandler. */
  private PounamuHandle startHandler;
  
  /** Holds value of property endHandler. */
  private PounamuHandle endHandler;
  
  /**
   * construct this event
   * @param source the panel where this new connector is on
   * @param connector the new added new connector
   */
  public NewConnectorEvent(Object source, PounamuConnector connector) {
  	super(source);
  	this.connector = connector;
  }

  /**
   * get the new connector
   * @return connector
   */
  public PounamuConnector getConnector() {
  	return connector;
  }

  /**
   * the String representation
   * @return the string representation of this event
   */
  public String toString(){
    return "NewConnectorEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"connector\" is " + connector.getClass().getName();
  }
  
  /** Getter for property startHandler.
   * @return Value of property startHandler.
   *
   */
  public PounamuHandle getStartHandler() {
      return this.startHandler;
  }
  
  /** Setter for property startHandler.
   * @param startHandler New value of property startHandler.
   *
   */
  public void setStartHandler(PounamuHandle startHandler) {
      this.startHandler = startHandler;
  }
  
  /** Getter for property endHandler.
   * @return Value of property endHandler.
   *
   */
  public PounamuHandle getEndHandler() {
      return this.endHandler;
  }
  
  /** Setter for property endHandler.
   * @param endHandler New value of property endHandler.
   *
   */
  public void setEndHandler(PounamuHandle endHandler) {
      this.endHandler = endHandler;
  }
  
}
