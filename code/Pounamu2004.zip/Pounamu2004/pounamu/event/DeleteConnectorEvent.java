/*
 * @(#)DeleteConnectorEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;

/**
 * Title: DeleteConnectorEvent
 * Description:  The event generated when a connector is deleted
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class DeleteConnectorEvent extends PounamuEvent{

  PounamuConnector connector = null;

  /**
   * construct this event
   * @param source the panel where this connector is on
   * @param connector the connector to be deleted
   */
  public DeleteConnectorEvent(Object source, PounamuConnector connector) {
  	super(source);
  	this.connector = connector;
  }

  /**
   * get the connector to be deleted
   * @return connector
   */
  public PounamuConnector getConnector() {
  	return connector;
  }

  /**
   * the string representation
   * @return the string representation of this event
   */
  public String toString(){
    return "DeleteConnectorEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"connector\" is " + connector.getClass().getName();
  }
}
