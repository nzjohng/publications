/*
 * @(#)ChangePropertyEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;
import pounamu.core.*;
import pounamu.data.*;
import javax.swing.*;

/**
 * Title: ChangePropertyEvent
 * Description:  A property change event
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class ChangePropertyEvent extends PounamuEvent{
    
    ModellerPanel panel = null;
    PounamuModelElement target = null;
    PounamuShape shape = null;
    PounamuConnector connector = null;
    String type = null;
    Object[] oldModelValue = null;
    Object[] newModelValue = null;
    Object[] oldIconValue = null;
    Object[] newIconValue = null;
    /* Variable added by Akhil */
    JPanel specifier;
    /**
     * construct this event
     * @param panel the panel holds the icon of the object whose properties changed
     * @param target the object whose properties changed
     * @param icon the icon of the object whose properties changed
     * @param newModelValue the model property value list after change
     * @param oldModelValue the model property value list before change
     * @param newIconValue the icon property value list after change
     * @param oldIconValue the icon property value list before change
     * @param type to specify if the object is an "entity" ("association" otherwise);
     */
    public ChangePropertyEvent(ModellerPanel panel, PounamuModelElement target, Object icon, Object[] newModelValue, Object[] oldModelValue, Object[] newIconValue, Object[] oldIconValue, String type) {
        super(panel);
        this.type = type;
        this.target = target;
        this.oldModelValue = oldModelValue;
        this.newModelValue = newModelValue;
        this.oldIconValue = oldIconValue;
        this.newIconValue = newIconValue;
        if(type.equals("entity"))
            shape = (PounamuShape)icon;
        else
            connector = (PounamuConnector)icon;
    }
    
    /**
     * get the target whose properties changed
     * @return the target, an Pounamu model element, whose properties changed
     */
    public PounamuModelElement getTarget() {
        return target;
    }
    
    /**
     * get the type of this target
     * @return the target type ("entity" or "association")
     */
    public String getType() {
        return type;
    }
    
    
    /**
     * get the icon of this target, the icon is a shape if type is "entity"
     * @return the icon of this target
     */
    public PounamuShape getShape() {
        return shape;
    }
    
    /**
     * get the icon of this target, the icon is a connector if type is "association"
     * @return the icon of this target
     */
    public PounamuConnector getConnector() {
        return connector;
    }
    
    /**
     * get the new model property value list
     * @return the new model property value list
     */
    public Object[] getNewModelValue() {
        return newModelValue;
    }
    
    /**
     * get the old model property value list
     * @return the old model property value list
     */
    public Object[] getOldModelValue() {
        return oldModelValue;
    }
    
    /**
     * get the new icon property value list
     * @return the new icon property value list
     */
    public Object[] getNewIconValue() {
        return newIconValue;
    }
    
    /**
     * get the old icon property value list
     * @return the old icon property value list
     */
    public Object[] getOldIconValue() {
        return oldIconValue;
    }
    
    
    /**
     * string representation
     * @return the string representation of this event
     */
    public String toString(){
        return "properties of "+target.getName()+" has been changed";
        //"UnivModellerPropertyChangeEvent: the type of object \"source\" is " + source.getClass().getName()
        // +" , and the property name to be changed is " + getPropertyName() + ", and the old value is "
        //+ getOldValue() +", and the new value is " + getNewValue() + ", and isVisualProperty is " +  isVisualProperty();;
    }
    
    /* Setting the specifier property */
    public void setPounamuSpecifier(JPanel specifier) {
        
        this.specifier = specifier;
        
    }
    
    /* Getting the specifier property */
    public JPanel getPounamuSpecifier() {
        
        return specifier;
        
    }
}
