/*
 * @(#)NewAssociationEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: NewAssociationEvent
 * Description:  an event generated when a new association is added to a panel
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class NewAssociationEvent extends PounamuEvent{

  PounamuModelElement association = null;
  /**
   * construct this event
   * @param source the panel where this new association's icon is on
   * @param shape the new added association
   */
  public NewAssociationEvent(Object source, PounamuModelElement association) {
    super(source); // The source is the JCComponent
    this.association = association;
  }

  /**
   * get the new association
   * @return association
   */
  public PounamuModelElement getAssociation() {
    return association;
  }

  /**
   * String representation
   * @return the string representation of this event
   */
  public String toString(){
    return "NewAssociationEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"association\" is " + association.getClass().getName();
  }


  }
