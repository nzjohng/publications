/*
 * @(#)NewShapeEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;

/**
 * Title: NewShapeEvent
 * Description:  an event generated when a new shape is added to a panel
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class NewShapeEvent extends PounamuEvent{

  PounamuShape shape = null;
  /**
   * construct this event
   * @param source the panel where this new shape is on
   * @param shape the new added shape
   */
  public NewShapeEvent(Object source, PounamuShape shape) {
    super(source); // The source is the JCComponent
    this.shape = shape;
  }

  /**
   * get the new shape
   * @return shape
   */
  public PounamuShape getShape() {
    return shape;
  }

  /**
   * String representation
   * @return the string representation of this event
   */
  public String toString(){
    return "NewShapeEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"shape\" is " + shape.getClass().getName();
  }

  }
