/*
 * @(#)NewEntityEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: NewEntityEvent
 * Description:  an event generated when a new entity is added to a panel
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class NewEntityEvent extends PounamuEvent{

  PounamuModelElement entity = null;
  /**
   * construct this event
   * @param source the panel where this new entity's icon is on
   * @param entity the new added entity
   */
  public NewEntityEvent(Object source, PounamuModelElement entity) {
    super(source); // The source is the JCComponent
    this.entity = entity;
  }

  /**
   * get the new entity
   * @return entity
   */
  public PounamuModelElement getEntity() {
    return entity;
  }

  /**
   * String representation
   * @return the string representation of this event
   */
  public String toString(){
    return "NewEntityEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"entity\" is " + entity.getClass().getName();
  }


  }
