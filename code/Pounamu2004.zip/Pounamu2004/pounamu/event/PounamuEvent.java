/*
 * @(#)PounamuEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;



import java.util.*;

/**
 * Title: PounamuEvent
 * Description:  the super class of all pounamu event classes
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public abstract class PounamuEvent extends EventObject{

  /**
   * construct this event
   * @param source the object which generate this event
   */
  public PounamuEvent(Object source) {
  	super(source);
  	}

  /**
   * the sting representtion
   * @return the string representation of this event
   */
  public String toString(){
    return "PounamuEvent: the type of object \"source\" is " + source.getClass().getName();
  }
}