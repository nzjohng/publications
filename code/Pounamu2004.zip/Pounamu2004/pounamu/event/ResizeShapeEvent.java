/*
 * @(#)ResizeShapeEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;
import pounamu.data.*;

/**
 * Title: ResizeShapeEvent
 * Description:  A resize shape event
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class ResizeShapeEvent extends PounamuEvent{
 	PounamuModelElement element = null;   
    /**
     * construct this event
     * @param source the panel where this shape is on
     * @param shape the shape which has been resized
     * @param oldX the x-coordinate of mouse point before resize
     * @param oldY the y-coordinate of mouse point before resize
     * @param newX the x-coordinate of mouse point after resize
     * @param newY the y-coordinate of mouse point after resize
     */
    public ResizeShapeEvent(Object source, PounamuPanel shape, int oldX, int oldY, int newX, int newY) {
        super(source); // The source is the JCComponent
        this.shape = shape;
        this.oldX = oldX;
        this.oldY = oldY;
        this.newX = newX;
        this.newY = newY;
    }
    
    /**
     * get the shape which has been moved
     * @return shape
     */
    public PounamuPanel getShape() {
        return shape;
    }
    
    /**
     * get string representation of this class
     * @return the string representation of this event
     */
    public String toString(){
        return "ResizeShapeEvent: the type of object \"source\" is " + source.getClass().getName()
        +" . and the type of \"shape\" is " + shape.getClass().getName();
    }	
    
    /* Added by Akhil */
    /* Setting the appropriate PounamuModelElement */
    public void setElement(PounamuModelElement ele) {
        element = ele;
        
    }
    
    /* Getting the appropirate pounamu element */
    public PounamuModelElement getElement() {
        return element;
        
    }
    
    PounamuPanel shape = null;
    int oldX = 0;
    int oldY = 0;
    int newX = 0;
    int newY = 0;
    int startX = 0;
    int startY = 0;
    
    /* Setting StartX */
    public void setStartX(int x) {
        
        startX = x;
        
    }
    
    /* Setting StartY */
    public void setStartY(int y) {
        
        startY = y;
        
    }
    
    /* Getting StartX */
    public int getStartX() {
        
        return startX;
        
    }
    
    /* Getting StartY */
    public int getStartY() {
        
        return startY;
        
    }
    
    /* Getting OldX */
    public int getOldX() {
        
        return oldX;
        
    }
    
    /* Getting  OldY*/
    public int getOldY() {
        
        return oldY;
        
    }
    
    /* Getting NewX */
    public int getNewX() {
        
        return newX;
        
    }
    
    /* Getting NewY */
    public int getNewY() {
        
        return newY;
        
    }
}
