/*
 * @(#)DeleteShapeEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;

import pounamu.visualcomp.*;

/**
 * Title: DeleteShapeEvent
 * Description:  The event generated when a shape is deleted
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */

public class DeleteShapeEvent extends PounamuEvent{

  /**
   * construct this event
   * @param source the panel where this shape is on
   * @param shape the shape which is to be deleted
   */
  public DeleteShapeEvent(Object source, PounamuShape shape) {
    super(source); // The source is the JCComponent
    this.shape = shape;
  }

  /**
   * get the shape to be deleted
   * @return shape
   */
  public PounamuShape getShape() {
    return shape;
  }

  /**
   * the String representation
   * @return the string representation of this event
   */
  public String toString(){
    return "DeleteShapeEvent: the type of object \"source\" is " + source.getClass().getName()
           +" . and the type of \"shape\" is " + shape.getClass().getName();
  }

  PounamuShape shape = null;
}
