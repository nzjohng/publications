/*
 * @(#)PounamuPropertyChangeEvent.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.event;


/**
 * Title: PounamuPropertyChangeEvent
 * Description:  A property change event
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuPropertyChangeEvent extends PounamuEvent{

  String propertyName = null;
  Object oldValue = null;
  Object newValue = null;
  boolean isVisualProperty = false;

  /**
   * construct this event
   * @param source the object where this new connector is on
   * @param propertyName the name of this property
   * @param oldValue the old value of this property
   * @param newValue the new value of this property
   * @param isVisualProperty true is the property is a visual property
   */
  public PounamuPropertyChangeEvent(Object source, String propertyName, Object oldValue, Object newValue, boolean isVisualProperty) {
  	super(source);
  	this.propertyName = propertyName;
        this.oldValue = oldValue;
        this.newValue = newValue;
        this.isVisualProperty = isVisualProperty;
  }

  /**
   * get the name of this Property
   * @return propertyName
   */
  public String getPropertyName() {
  	return propertyName;
  }

  /**
   * get the new value of this Property
   * @return newValue
   */
  public Object getNewValue() {
  	return newValue;
  }

  /**
   * get the old value of this Property
   * @return oldValue
   */
  public Object getOldValue() {
  	return oldValue;
  }

  /**
   * to check if this property is a visual property
   * @return isVisualProperty
   */
  public boolean isVisualProperty() {
  	return isVisualProperty;
  }

  /**
   * string representation
   * @return the string representation of this event
   */
  public String toString(){
    return "";
    //"UnivModellerPropertyChangeEvent: the type of object \"source\" is " + source.getClass().getName()
          // +" , and the property name to be changed is " + getPropertyName() + ", and the old value is "
           //+ getOldValue() +", and the new value is " + getNewValue() + ", and isVisualProperty is " +  isVisualProperty();;
  }
}
