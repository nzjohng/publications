/*
 * @(#)PounamuToolProject.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.data;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.tree.*;
import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.sun.image.codec.jpeg.*;
import java.awt.image.*;
import java.io.*;
/**
 * Title: PounamuToolProject
 * Description:  defines a pounamu tool project
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuToolProject extends PounamuProject{

  /**
   * all shapes (one kind of icon) which have been created,
   * available to be used and registed for this project
   * String name, the type name of a shape, will be hold in this vector
   */
  Vector registeredShapes = new Vector();
  //Vector openedShapeNames = new Vector();
  /**
   * all connectors (one kind of icon) which have been created,
   * available to be used and registed for this project
   * String name, the type name of a connector, will be hold in this vector
   */
  Vector registeredConnectors = new Vector();
  //Vector openedConnectorNames = new Vector();
  /**
   * all event handlers  which have been registered,
   * available to be used for this project
   * String name, the type name of a handler, will be hold in this vector
   */
  Hashtable registeredModelEventHandlers = new Hashtable();
  Hashtable registeredModelUserHandlers = new Hashtable();
  //Hashtable currentRegisteredModelHandlers = new Hashtable();
  Hashtable registeredVisualEventHandlers = new Hashtable();
  Hashtable registeredVisualUserHandlers = new Hashtable();
  static int uniqueNum = 0;
  //Vector openedModelHandlerNames = new Vector();
  //Vector openedVisualHandlerNames = new Vector();
  //Vector openedSpecialHandlerNames = new Vector();
  /**
   * all entity types  which have been registered
   * and available to be used for this project
   * String name, the type name of an entity type, will be hold in this vector
   */
  Hashtable registeredEntityTypeObjects = new Hashtable();
  //Hashtable openedEntityTypeObjectNames = new Hashtable();
  /**
   * all association types  which have been registered
   * and available to be used for this project
   * String name, the name of an association type, will be hold in this vector
   */
  Hashtable registeredAssociationTypeObjects = new Hashtable();
  //Hashtable openedAssociationTypeObjectNames = new Hashtable();
  /**
   * all view types  which have been defined, registered
   * and available to be used for this project
   * String name, the name of a view type, will be hold in this vector
   */
  Vector registeredViewTypes = new Vector();

  /**
   * hold all names of created PounamuView objects of metamodel views
   */
  Vector registeredMetaModelViews = new Vector();

  /**
   * register all properties of all enetity type
   * the key is the name of the entity type and the value is the vector which holds all properties of this entity type
   */
  Hashtable registeredEntityTypeProperty = new Hashtable();

  /**
   * register all properties of all association type
   * the key is the name of the association type and the value is the vector which holds all properties of this association type
   */
  Hashtable registeredAssociationTypeProperty = new Hashtable();


  /**
   * map the id of an "entity type" object to the object itself
   * KEY (String id); Value (PounamuMetaModelElement object)
   */
  //Hashtable idAndEntityTypeObjectMapping = new Hashtable();
  /**
   * map the id of an "association type" object to the object itself
   * KEY (String id); Value (PounamuMetaModelElement object)
   */
  //Hashtable idAndAssociationTypeObjectMapping = new Hashtable();
  /**
   * map the id of an "entity" object to the object itself
   * KEY (String id); Value (PounamuModelElement object)
   */
  //Hashtable idAndEntityObjectMapping = new Hashtable();
  /**
   * map the id of an "association" object to the object itself
   * KEY (String id); Value (PounamuModelElement object)
   */
  //Hashtable idAndAssociationObjectMapping = new Hashtable();

  /**
   * map the the name of an XML file to the xml itself
   * KEY (String fileName); VALUE (File xmlFile)
   */
  //Hashtable xmlFileNameMapping = new Hashtable();
  /**
   * A Pounamu model element or meta model element can have different visual appearance in different views
   * map the the name of a PounamuMoaelElement of PounamuMetaModelElement plus
   * the name of the view type to the icon type name
   * KEY (String modelType+"_"+viewType); VALUE (String iconType)
   */
  //Hashtable iconTypes = new Hashtable();
  /**
   * A property of a Pounamu meta model element or a pounamu model element can be
   * shown in the visual text area of its corresponding icon
   * this hashtable map the type of (meta)model element and the type of icon pairs
   * to the property mapping hashtables between the pair
   * from icon to model:
   * KEY (String modelType+"_"+iconType); Value (Hashtable propertyHashtable)
   */
   //Hashtable iconToModelPropertyHashtable = new Hashtable();
   /**
   * A property of a Pounamu meta model element or a pounamu model element can be
   * shown in the visual text area of its corresponding icon
   * this hashtable map the type of (meta)model element and the type of icon pairs
   * to the property mapping hashtables between the pair
   * from model to icon:
   * KEY (String modelType+"_"+iconType); Value (Hashtable propertyHashtable)
   */
   //Hashtable modelToIconPropertyHashtable = new Hashtable();
   /**
    * Each icon has some areas to show the property of the (meta)model element
    * This Hashtable map the name of icon to its shown area names
    * KEY (String iconName); Value (Vector shownPropertyNames)
    */
   DefaultMutableTreeNode iconCreatorNode = null;
   DefaultMutableTreeNode shapeCreatorNode = null;
   DefaultMutableTreeNode connectorCreatorNode = null;
   DefaultMutableTreeNode handlerDefinerNode = null;
   DefaultMutableTreeNode modelHandlerDefinerNode = null;
   DefaultMutableTreeNode modelEventHandlerDefinerNode = null;
   DefaultMutableTreeNode modelUserHandlerDefinerNode = null;
   DefaultMutableTreeNode visualHandlerDefinerNode = null;
   DefaultMutableTreeNode visualEventHandlerDefinerNode = null;
   DefaultMutableTreeNode visualUserHandlerDefinerNode = null;
   DefaultMutableTreeNode metaModelDefinerNode = null;
   DefaultMutableTreeNode viewTypeDefinerNode = null;
   Hashtable iconNameToTextFieldPropertiesMapping = new Hashtable();
   Hashtable iconNameToTextAreaPropertiesMapping = new Hashtable();
   //Document document = null;
   Hashtable nodeAndConnectorMapping = new Hashtable();
   Hashtable nodeAndShapeMapping = new Hashtable();
   Hashtable nodeAndComponentMapping = new Hashtable();
   //Hashtable nodeAndIconMapping = new Hashtable();
   //Hashtable nodeAndEntityTypeObjectMapping = new Hashtable();
   //Hashtable nodeAndAssociationTypeObjectMapping = new Hashtable();
   Hashtable nodeAndRegisteredXMLStringMapping = new Hashtable();
   Hashtable metaModelViewNodeAndEntityTypeNodeMapping = new Hashtable();
   Hashtable metaModelViewNodeAndAssociationTypeNodeMapping = new Hashtable();
   Vector entityTypeObjects = new Vector();
   Vector associationTypeObjects = new Vector();
   int pounamuPanelCount = 0;
   int pounamuLabelCount = 0;
   int pounamuButtonCount = 0;
   int pounamuOneLineInputCount = 0;
   int pounamuMultiLinesInputCount = 0;
   int shapeCount = 0;
   int connectorCount = 0;
   int entityTypeObjectCount = 0;
   int associationTypeObjectCount = 0;
   int metaModelViewCount = 0;
   int viewTypeViewCount = 0;
   int modelEventHandlerCount = 0;
   int modelUserHandlerCount = 0;
   int visualEventHandlerCount = 0;
   int visualUserHandlerCount = 0;
    
   
   String entityTypeIcon = null;
   String associationTypeIcon = null;
   Hashtable propertyMappingFromAssociationTypeToIcon = new Hashtable();
   Hashtable propertyMappingFromIconToAssociationType = new Hashtable();
   Hashtable propertyMappingFromEntityTypeToIcon = new Hashtable();
   Hashtable propertyMappingFromIconToEntityType = new Hashtable();
   Hashtable viewTypeAndAllowedEntityTypesMapping = new Hashtable();
   Hashtable viewTypeAndAllowedAssociationTypesMapping = new Hashtable();
   Hashtable viewTypeAndAllowedVisualEventHandlersMapping = new Hashtable();
   Hashtable viewTypeAndAllowedVisualUserHandlersMapping = new Hashtable();
   Hashtable viewTypeAndEntityTypeAndShapeMapping = new Hashtable();
   Hashtable viewTypeAndAssociationTypeAndConnectorMapping = new Hashtable();
   Hashtable viewTypeAndPropertyMapping = new Hashtable();
   Hashtable openedViewTypeDefinerWindows = new Hashtable();
   Hashtable openedMetaModelViews = new Hashtable();
   String space = "            ";
   Document xmlDocument = null;
   Element root = null;
   String fileSeparator = null;
  /**
   * an empty constructor
   */
  public PounamuToolProject(){
    super();
  }

  /**
   * a constructor
   * @param name the name of this project
   */
  public PounamuToolProject(String name){
    super(name);
    fileSeparator = System.getProperty("file.separator");
  }

  /**
   * a constructor
   * @param name the name of this project
   * @param location the location this projet will be saved to
   * @param description the description of this project
   */
  public PounamuToolProject(String name, String location, String description){
    super(name, location, description);
    fileSeparator = System.getProperty("file.separator");
  }

  /**
   * a constructor
   * @param name the name of this project
   * @param location the location this projet will be saved to
   * @param description the description of this project
   * @param manager the manager panel of pounamu
   */
  public PounamuToolProject(PounamuManagerPanel manager, String name, String location, String description){
    super(manager, name, location, description);
    fileSeparator = System.getProperty("file.separator");    
    setEntityTypeIcon("S_DefaultShapeForEntityType");
    setAssociationTypeIcon("S_DefaultShapeForAssociationType");
    propertyMappingFromAssociationTypeToIcon.put("name", "name");
    propertyMappingFromIconToAssociationType.put("name", "name");
    propertyMappingFromAssociationTypeToIcon.put("property", "properties");
    propertyMappingFromIconToAssociationType.put("properties", "property");
    propertyMappingFromEntityTypeToIcon.put("name", "name");
    propertyMappingFromIconToEntityType.put("name", "name");
    propertyMappingFromEntityTypeToIcon.put("property", "properties");
    propertyMappingFromIconToEntityType.put("properties", "property");
    nodeAndMenuItemsMapping.put(projectNode, initMenuItemsForToolProjectNode());
    nodeAndToolButtonsMapping.put(projectNode, initToolIconsForToolProjectNode());
    init();
    createFolders();
    manager.addTreeNode(projectNode);
    manager.getNodeAndItsValueMapping().put(projectNode, name);
    nodeAndRegisteredXMLStringMapping.put(projectNode, "");
    TreePath tp = new TreePath(projectNode.getPath());
    manager.getManagerTree().setSelectionPath(tp);
    pounamu.setProjectTab(projectTab);
  }

  /**
   * Constructor
   * @param manager the manager panel of the pounamu tool
   * @param xmlDocument the xml document contains all information of this tool project
   */
  public PounamuToolProject(PounamuManagerPanel manager, Document xmlDocument){

    this.xmlDocument = xmlDocument;
    this.manager = manager;
    this.pounamu = manager.getPounamu();
    this.managerTree = manager.getManagerTree();
    this.root = xmlDocument.getDocumentElement();
    fileSeparator = System.getProperty("file.separator");
    NodeList nl = root.getElementsByTagName("name");
    Node n = nl.item(0);
    setName(n.getFirstChild().getNodeValue());
    this.location = pounamu.getPounamuHome()+ fileSeparator + "tools" + fileSeparator +""+name;
    nl = root.getElementsByTagName("description");
    n = nl.item(0);
    if(n.getFirstChild() == null)
      setDescription("");
    else
      setDescription(n.getFirstChild().getNodeValue());
    nl = root.getElementsByTagName("uniquenum");
    n = nl.item(0);
    setUniqueNum(Integer.parseInt(n.getFirstChild().getNodeValue())+1);
    nl = root.getElementsByTagName("associationtypeicon");
    n = nl.item(0);
    if(n.getFirstChild() == null)
      setAssociationTypeIcon("S_DefaultShapeForAssociationType");
    else
      setAssociationTypeIcon(n.getFirstChild().getNodeValue());
    nl = root.getElementsByTagName("entitytypeicon");
    n = nl.item(0);
    if(n.getFirstChild() == null)
      setEntityTypeIcon("S_DefaultShapeForEntityType");
    else
      setEntityTypeIcon(n.getFirstChild().getNodeValue());
    this.projectNode = new DefaultMutableTreeNode(name);
    this.projectTab = new PounamuTabbedPane(this);
    manager.getNodeAndItsValueMapping().put(projectNode, name);
    nodeAndMenuItemsMapping.put(projectNode, initMenuItemsForToolProjectNode());
    nodeAndToolButtonsMapping.put(projectNode, initToolIconsForToolProjectNode());
    projectTab.setTabPlacement(JTabbedPane.BOTTOM);
    manager.getNodeAndProjectMapping().put(projectNode, this);
    manager.addTreeNode(projectNode);
    init();
    restorePropertyMappingFromAssociationTypeToIcon();
    restorePropertyMappingFromEntityTypeToIcon();
    restorePropertyMappingFromIconToAssociationType();
    restorePropertyMappingFromIconToEntityType();
    restoreRegisteredAssociationTypeProperty();
    restoreRegisteredEntityTypeProperty();
    restoreIconNameToTextAreaPropertiesMapping();
    restoreIconNameToTextFieldPropertiesMapping();
    restoreViewTypeAndAllowedVisualEventHandlersMapping();
    restoreViewTypeAndAllowedVisualUserHandlersMapping();
    restoreViewTypeAndAllowedEntityTypesMapping();
    restoreViewTypeAndAllowedAssociationTypesMapping();
    restoreViewTypeAndEntityTypeAndShapeMapping();
    restoreViewTypeAndAssociationTypeAndConnectorMapping();
    restoreViewTypeAndPropertyMapping();
    restoreRegisteredAssociationTypes();
    restoreRegisteredEntityTypes();
    restoreRegisteredShapes();
    restoreRegisteredConnectors();
    //restoreCurrentRegisteredModelHandlers();
    restoreRegisteredModelEventHandlers();
    restoreRegisteredModelUserHandlers();
    restoreRegisteredVisualEventHandlers();
    restoreRegisteredVisualUserHandlers();
    //restoreRegisteredVisualHandlers();
    //restoreRegisteredSpecialHandlers();
    //System.out.println("in class pounamutoolproject, here visited 0");
    restoreRegisteredMetaModelViews();
    //System.out.println("in class pounamutoolproject, here visited 0");
    restoreRegisteredViewTypes();
    //TreePath tp = new TreePath(projectNode.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    manager.setSelectedNode(projectNode);
    pounamu.setProjectTab(projectTab);
    nodeAndRegisteredXMLStringMapping.put(projectNode, getXMLRepresentation());
  }

  public void reloadProperties(){
    File inputFile = new File(getLocation()+""+fileSeparator+""+getName()+".xml");
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    xmlDocument = lxf.getDocument();
    root = xmlDocument.getDocumentElement();
    NodeList nl = root.getElementsByTagName("associationtypeicon");
    Node n = nl.item(0);
    if(n.getFirstChild() == null)
      setAssociationTypeIcon("S_DefaultShapeForAssociationType");
    else
      setAssociationTypeIcon(n.getFirstChild().getNodeValue());
    nl = root.getElementsByTagName("entitytypeicon");
    n = nl.item(0);
    if(n.getFirstChild() == null)
      setEntityTypeIcon("S_DefaultShapeForEntityType");
    else
      setEntityTypeIcon(n.getFirstChild().getNodeValue());
    restorePropertyMappingFromAssociationTypeToIcon();
    restorePropertyMappingFromEntityTypeToIcon();
    restorePropertyMappingFromIconToAssociationType();
    restorePropertyMappingFromIconToEntityType();
    restoreRegisteredAssociationTypeProperty();
    restoreRegisteredEntityTypeProperty();
    restoreIconNameToTextAreaPropertiesMapping();
    restoreIconNameToTextFieldPropertiesMapping();
    restoreViewTypeAndAllowedVisualEventHandlersMapping();
    restoreViewTypeAndAllowedVisualUserHandlersMapping();
    //restoreViewTypeAndAllowedHandlersMapping();
    //restoreViewTypeAndAllowedMetaModelTypesMapping();
    restoreViewTypeAndAllowedEntityTypesMapping();
    restoreViewTypeAndAllowedAssociationTypesMapping();
    //restoreViewTypeAndMetaModelTypesAndIconMapping();
    restoreViewTypeAndEntityTypeAndShapeMapping();
    restoreViewTypeAndAssociationTypeAndConnectorMapping();
    restoreViewTypeAndPropertyMapping();
    restoreRegisteredAssociationTypes();
    restoreRegisteredEntityTypes();
    reloadRegisteredShapes();
    reloadRegisteredConnectors();
    reloadRegisteredModelEventHandlers();
    reloadRegisteredModelUserHandlers();
    reloadRegisteredVisualEventHandlers();
    reloadRegisteredVisualUserHandlers();
    //reloadRegisteredSpecialHandlers();
    reloadRegisteredMetaModelViews();
    reloadRegisteredViewTypes();
  }
  
  public void deleteFolders(){
    String fullPath = "\""+getLocation()+"\"";
    MaintainFileSystem cf  = new MaintainFileSystem(fullPath, pounamu, "deletefolder");
    //new Thread(cf).start();
    cf.run();
  }
  
  public void createFolders(){
    //System.out.println("getLocation() is " + getLocation());
    String fullPath = "\""+getLocation()+"\"";
    MaintainFileSystem cf  = new MaintainFileSystem(fullPath, pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"icons", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"icons"+fileSeparator+"shapes", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"icons"+fileSeparator+"connectors", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"modelhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"visualhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"metamodel", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"metamodel"+fileSeparator+"entitytypes", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"metamodel"+fileSeparator+"associationtypes", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"metamodel"+fileSeparator+"metamodelviews", pounamu, "createfolder");
    cf.run();
    //new Thread(cf).start();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"viewtypes", pounamu, "createfolder");
    cf.run();
    //new Thread(cf).start();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"images", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"images"+fileSeparator+"forlabels", pounamu, "createfolder");
    cf.run();
    cf  = new MaintainFileSystem(fullPath+fileSeparator+"images"+fileSeparator+"fortoolbars", pounamu, "createfolder");
    cf.run();
    //new Thread(cf).start();
  }

  private void init(){

    iconCreatorNode = new DefaultMutableTreeNode("icon_creator");
    projectNode.add(iconCreatorNode);
    manager.getNodeAndItsValueMapping().put(iconCreatorNode, "icon_creator");
    //PounamuTabbedPane tab = new PounamuTabbedPane(this);
    //nodeAndViewsTabMapping.put(shapeCreatorNode, tab);
    //projectTab.addTab("shapes", tab);
    //viewsTabAndNodeMapping.put(tab, shapeCreatorNode);
    //nodeAndMenuItemsMapping.put(shapeCreatorNode, initMenuItemsForShapeCreatorNode());
    //nodeAndToolButtonsMapping.put(shapeCreatorNode, initToolIconsForShapeCreatorNode());
    manager.getNodeAndProjectMapping().put(iconCreatorNode, this);
    
    shapeCreatorNode = new DefaultMutableTreeNode("shape_creator");
    iconCreatorNode.add(shapeCreatorNode);
    manager.getNodeAndItsValueMapping().put(shapeCreatorNode, "shape_creator");
    PounamuTabbedPane tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(shapeCreatorNode, tab);
    projectTab.addTab("shapes", tab);
    viewsTabAndNodeMapping.put(tab, shapeCreatorNode);
    nodeAndMenuItemsMapping.put(shapeCreatorNode, initMenuItemsForShapeCreatorNode());
    nodeAndToolButtonsMapping.put(shapeCreatorNode, initToolIconsForShapeCreatorNode());
    manager.getNodeAndProjectMapping().put(shapeCreatorNode, this);

    connectorCreatorNode = new DefaultMutableTreeNode("connector_creator");
    iconCreatorNode.add(connectorCreatorNode);
    manager.getNodeAndItsValueMapping().put(connectorCreatorNode, "connector_creator");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(connectorCreatorNode, tab);
    projectTab.addTab("connectors", tab);
    viewsTabAndNodeMapping.put(tab, connectorCreatorNode);
    nodeAndMenuItemsMapping.put(connectorCreatorNode, initMenuItemsForConnectorCreatorNode());
    nodeAndToolButtonsMapping.put(connectorCreatorNode, initToolIconsForConnectorCreatorNode());
    manager.getNodeAndProjectMapping().put(connectorCreatorNode, this);

    handlerDefinerNode = new DefaultMutableTreeNode("handler_definer");
    projectNode.add(handlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(handlerDefinerNode, "handler_definer");
    //tab = new PounamuTabbedPane(this);
    //nodeAndViewsTabMapping.put(modelHandlerDefinerNode, tab);
    //projectTab.addTab("model_handlers", tab);
    //viewsTabAndNodeMapping.put(tab, modelHandlerDefinerNode);
    //nodeAndMenuItemsMapping.put(modelHandlerDefinerNode, initMenuItemsForModelHandlerDefinerNode());
    //nodeAndToolButtonsMapping.put(modelHandlerDefinerNode, initToolIconsForModelHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(handlerDefinerNode, this);

    modelHandlerDefinerNode = new DefaultMutableTreeNode("model_handler_definer");
    handlerDefinerNode.add(modelHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(modelHandlerDefinerNode, "model_handler_definer");
    //tab = new PounamuTabbedPane(this);
    //nodeAndViewsTabMapping.put(modelHandlerDefinerNode, tab);
    //projectTab.addTab("model_handlers", tab);
    //viewsTabAndNodeMapping.put(tab, modelHandlerDefinerNode);
    //nodeAndMenuItemsMapping.put(modelHandlerDefinerNode, initMenuItemsForModelHandlerDefinerNode());
    //nodeAndToolButtonsMapping.put(modelHandlerDefinerNode, initToolIconsForModelHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(modelHandlerDefinerNode, this);
    
    modelEventHandlerDefinerNode = new DefaultMutableTreeNode("model_event_handler_definer");
    modelHandlerDefinerNode.add(modelEventHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(modelEventHandlerDefinerNode, "model_event_handler_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(modelEventHandlerDefinerNode, tab);
    projectTab.addTab("model_event_handlers", tab);
    viewsTabAndNodeMapping.put(tab, modelEventHandlerDefinerNode);
    nodeAndMenuItemsMapping.put(modelEventHandlerDefinerNode, initMenuItemsForModelEventHandlerDefinerNode());
    nodeAndToolButtonsMapping.put(modelEventHandlerDefinerNode, initToolIconsForModelEventHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(modelEventHandlerDefinerNode, this);

    modelUserHandlerDefinerNode = new DefaultMutableTreeNode("model_user_handler_definer");
    modelHandlerDefinerNode.add(modelUserHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(modelUserHandlerDefinerNode, "model_user_handler_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(modelUserHandlerDefinerNode, tab);
    projectTab.addTab("model_user_handlers", tab);
    viewsTabAndNodeMapping.put(tab, modelUserHandlerDefinerNode);
    nodeAndMenuItemsMapping.put(modelUserHandlerDefinerNode, initMenuItemsForModelUserHandlerDefinerNode());
    nodeAndToolButtonsMapping.put(modelUserHandlerDefinerNode, initToolIconsForModelUserHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(modelUserHandlerDefinerNode, this);

    visualHandlerDefinerNode = new DefaultMutableTreeNode("visual_handler_definer");
    handlerDefinerNode.add(visualHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(visualHandlerDefinerNode, "visual_handler_definer");
    //tab = new PounamuTabbedPane(this);
    //nodeAndViewsTabMapping.put(visualHandlerDefinerNode, tab);
    //projectTab.addTab("visual_handlers", tab);
    //viewsTabAndNodeMapping.put(tab, visualHandlerDefinerNode);
    //nodeAndMenuItemsMapping.put(visualHandlerDefinerNode, initMenuItemsForVisualHandlerDefinerNode());
    //nodeAndToolButtonsMapping.put(visualHandlerDefinerNode, initToolIconsForVisualHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(visualHandlerDefinerNode, this);
    
    visualEventHandlerDefinerNode = new DefaultMutableTreeNode("visual_event_handler_definer");
    visualHandlerDefinerNode.add(visualEventHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(visualEventHandlerDefinerNode, "visual_event_handler_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(visualEventHandlerDefinerNode, tab);
    projectTab.addTab("visual_event_handlers", tab);
    viewsTabAndNodeMapping.put(tab, visualEventHandlerDefinerNode);
    nodeAndMenuItemsMapping.put(visualEventHandlerDefinerNode, initMenuItemsForVisualEventHandlerDefinerNode());
    nodeAndToolButtonsMapping.put(visualEventHandlerDefinerNode, initToolIconsForVisualEventHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(visualEventHandlerDefinerNode, this);
    
    visualUserHandlerDefinerNode = new DefaultMutableTreeNode("visual_user_handler_definer");
    visualHandlerDefinerNode.add(visualUserHandlerDefinerNode);
    manager.getNodeAndItsValueMapping().put(visualUserHandlerDefinerNode, "visual_user_handler_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(visualUserHandlerDefinerNode, tab);
    projectTab.addTab("visual_user_handlers", tab);
    viewsTabAndNodeMapping.put(tab, visualUserHandlerDefinerNode);
    nodeAndMenuItemsMapping.put(visualUserHandlerDefinerNode, initMenuItemsForVisualUserHandlerDefinerNode());
    nodeAndToolButtonsMapping.put(visualUserHandlerDefinerNode, initToolIconsForVisualUserHandlerDefinerNode());
    manager.getNodeAndProjectMapping().put(visualUserHandlerDefinerNode, this);
   
    metaModelDefinerNode = new DefaultMutableTreeNode("meta_model_definer");
    projectNode.add(metaModelDefinerNode);
    manager.getNodeAndItsValueMapping().put(metaModelDefinerNode, "meta_model_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(metaModelDefinerNode, tab);
    projectTab.addTab("meta_model_views", tab);
    viewsTabAndNodeMapping.put(tab, metaModelDefinerNode);
    nodeAndMenuItemsMapping.put(metaModelDefinerNode, initMenuItemsForMetaModelDefinerNode());
    nodeAndToolButtonsMapping.put(metaModelDefinerNode, initToolIconsForMetaModelDefinerNode());
    manager.getNodeAndProjectMapping().put(metaModelDefinerNode, this);

    viewTypeDefinerNode = new DefaultMutableTreeNode("view_type_definer");
    projectNode.add(viewTypeDefinerNode);
    manager.getNodeAndItsValueMapping().put(viewTypeDefinerNode, "view_type_definer");
    tab = new PounamuTabbedPane(this);
    nodeAndViewsTabMapping.put(viewTypeDefinerNode, tab);
    projectTab.addTab("view_types", tab);
    viewsTabAndNodeMapping.put(tab, viewTypeDefinerNode);
    nodeAndToolButtonsMapping.put(viewTypeDefinerNode, initToolIconsForViewTypeDefinerNode());
    nodeAndMenuItemsMapping.put(viewTypeDefinerNode, initMenuItemsForViewTypeDefinerNode());
    manager.getNodeAndProjectMapping().put(viewTypeDefinerNode, this);
  }

  public void setUniqueNum(int uniqueNum){
    this.uniqueNum = uniqueNum;
  }

  public int getUniqueNum(){
    return uniqueNum;
  }
  
  public Hashtable getIconNameToTextAreaPropertiesMapping(){
    return iconNameToTextAreaPropertiesMapping;
  }
  
  public Hashtable getIconNameToTextFieldPropertiesMapping(){
    return iconNameToTextFieldPropertiesMapping;
  }
  /**
   * get the tree node for the icon creator
   * @return the tree node for the icon creator
   */
  public DefaultMutableTreeNode getIconCreatorNode(){
    return iconCreatorNode;
  }

  /**
   * set the tree node for the icon creator
   * @param iconCreatorNode the new tree node for the icon creator
   */
  public void setCreatorNode(DefaultMutableTreeNode iconCreatorNode){
    this.iconCreatorNode = iconCreatorNode;
  }
  
  /**
   * get the tree node for the shape creator
   * @return the tree node for the shape creator
   */
  public DefaultMutableTreeNode getShapeCreatorNode(){
    return shapeCreatorNode;
  }

  /**
   * set the tree node for the shape creator
   * @param shapeCreatorNode the new tree node for the shape creator
   */
  public void setShapeCreatorNode(DefaultMutableTreeNode shapeCreatorNode){
    this.shapeCreatorNode = shapeCreatorNode;
  }
  /**
   * get the tree node for the connector creator
   * @return the tree node for the connector creator
   */
  public DefaultMutableTreeNode getConnectorCreatorNode(){
    return connectorCreatorNode;
  }

  /**
   * set the tree node for the connector creator
   * @param connectorCreatorNode the new tree node for the connector creator
   */
  public void setConnectorCreatorNode(DefaultMutableTreeNode connectorCreatorNode){
    this.connectorCreatorNode = connectorCreatorNode;
  }
  
  
  
  /**
   * get the tree node for the visual handler creator
   * @return the tree node for the visual handler creator
   */
  public DefaultMutableTreeNode getVisualEventHandlerDefinerNode(){
    return visualEventHandlerDefinerNode;
  }
  
  public DefaultMutableTreeNode getVisualUserHandlerDefinerNode(){
    return visualUserHandlerDefinerNode;
  }
  
  
  /**
   * get the tree node for the model user handler creator
   * @return the tree node for the model user handler creator
   */
  public DefaultMutableTreeNode getModelUserHandlerDefinerNode(){
    return modelUserHandlerDefinerNode;
  }
  
  
  /**
   * get the tree node for the model event handler creator
   * @return the tree node for the model event handler creator
   */
  public DefaultMutableTreeNode getModelEventHandlerDefinerNode(){
    return modelEventHandlerDefinerNode;
  }
 
 
  /**
   * get the tree node for the metamodel definer
   * @return the tree node for the metamodel definer
   */
  public DefaultMutableTreeNode getMetaModelDefinerNode(){
    return metaModelDefinerNode;
  }

  /**
   * set the tree node for the metamodel definer
   * @param metaModelDefinerNode the new tree node for the metamodel definer
   */
  public void setMetaModelDefinerNode(DefaultMutableTreeNode metaModelDefinerNode){
    this.metaModelDefinerNode = metaModelDefinerNode;
  }

  /**
   * get the tree node for the view type definer
   * @return the tree node for the view type definer
   */
  public DefaultMutableTreeNode getViewTypeDefinerNode(){
    return viewTypeDefinerNode;
  }

  /**
   * set the tree node for the view type definer
   * @param viewTypeDefinerNode the new tree node for the view type definer
   */
  public void setViewTypeDefinerNode(DefaultMutableTreeNode viewTypeDefinerNode){
    this.viewTypeDefinerNode = viewTypeDefinerNode;
  }

  /**
   * set the icon type for the entity type objects in the metamodel definer views
   * @param iconTypeName the name of the icon type
   */
  public void setEntityTypeIcon(String iconTypeName){
    entityTypeIcon = iconTypeName;
  }

  /**
   * get the current icon type for the entity type object
   * @return the icon type for the entity type objects
   */
  public String getEntityTypeIcon(){
    return entityTypeIcon;
  }

  /**
   * set the icon type for the association type objects in the metamodel definer views
   * @param iconTypeName the name of the icon type
   */
  public void setAssociationTypeIcon(String iconTypeName){
    associationTypeIcon = iconTypeName;
  }

  /**
   * get the current icon type for the association type object
   * @return the icon type for the entity type objects
   */
  public String getAssociationTypeIcon(){
    return associationTypeIcon;
  }

  /**
   * get the property mapping from the association type to icon
   * @return the hashtable contains those mappings
   */
  public Hashtable getPropertyMappingFromAssociationTypeToIcon(){
    return propertyMappingFromAssociationTypeToIcon;
  }

  /**
   * get the property mapping from the icon to association type
   * @return the hashtable contains those mappings
   */
  public Hashtable getPropertyMappingFromIconToAssociationType(){
    return propertyMappingFromIconToAssociationType;
  }

  /**
   * get the property mapping from the entity type to icon
   * @return the hashtable contains those mappings
   */
  public Hashtable getPropertyMappingFromEntityTypeToIcon(){
    return propertyMappingFromEntityTypeToIcon;
  }

  /**
   * get the property mapping from the icon to entity type
   * @return the hashtable contains those mappings
   */
  public Hashtable getPropertyMappingFromIconToEntityType(){
    return propertyMappingFromIconToEntityType;
  }

  /**
   * get the component indexed by the specified node
   * @param node the index tree node
   * @return the component indexed by the specified node
   */
  public Component getComponent(DefaultMutableTreeNode node){
    return (Component)nodeAndComponentMapping.get(node);
  }

  /**
   * get the mapping from an index node to its corresponding component
   * @return a hashtable contains the mapping from an index node to its corresponding component
   */
  public Hashtable getNodeAndComponentMapping(){
    return nodeAndComponentMapping;
  }

  /**
   * get the mapping from an index node to its corresponding icon
   * @return a hashtable contains the mapping from an index node to its corresponding icon
   */
  public Hashtable getNodeAndIconMapping(){
    return nodeAndIconMapping;
  }

  public Hashtable getNodeAndRegisteredXMLStringMapping(){
    return nodeAndRegisteredXMLStringMapping;
  }

  /**
   * get the mapping from the name of the registered association type to its properties list
   * @return the hashtable which holds the mapping from the name of the registerd association type to its propertier list
   */
  public Hashtable getRegisteredAssociationTypeProperty(){
    return registeredAssociationTypeProperty;
  }

  /**
   * get the mapping from the name of the registered entity type to its properties list
   * @return the hashtable which holds the mapping from the name of the registerd entity type to its propertier list
   */
  public Hashtable getRegisteredEntityTypeProperty(){
    return registeredEntityTypeProperty;
  }

  public Hashtable getViewTypeAndAllowedEntityTypesMapping(){
    return viewTypeAndAllowedEntityTypesMapping;
  }
  
  public Hashtable getViewTypeAndAllowedAssociationTypesMapping(){
    return viewTypeAndAllowedAssociationTypesMapping;
  }
  
  /* public Hashtable getViewTypeAndAllowedMetaModelTypesMapping(){
    return viewTypeAndAllowedMetaModelTypesMapping;
  }*/

  public Hashtable getViewTypeAndEntityTypeAndShapeMapping(){
    return viewTypeAndEntityTypeAndShapeMapping;
  }
  
  public Hashtable getViewTypeAndAssociationTypeAndConnectorMapping(){
    return viewTypeAndAssociationTypeAndConnectorMapping;
  }

  /*public Hashtable getOpenedAssociationTypeObjectNames(){
    return openedAssociationTypeObjectNames;
  }

  public Hashtable getOpenedEntityTypeObjectNames(){
    return openedEntityTypeObjectNames;
  }*/

  /*public Vector getOpenedShapeNames(){
    return openedShapeNames;
  }

  public Vector getOpenedConnectorNames(){
    return openedConnectorNames;
  }*/

  /*public Vector getOpenedModelHandlerNames(){
    return openedModelHandlerNames;
  }

  public Vector getOpenedVisualHandlerNames(){
    return openedVisualHandlerNames;
  }
*/
  public Hashtable getNodeAndConnectorMapping(){
    return nodeAndConnectorMapping;
  }
  
  public Hashtable getNodeAndShapeMapping(){
    return nodeAndShapeMapping;
  }
  /*public Vector getOpenedHandlerNames(){
    return openedHandlerNames;
  }*/

 /* public String getIconType(String modelType, String viewType){
    Vector metaModelAndIconMapping = (Vector)getViewTypeAndMetaModelTypesAndIconMapping().get(viewType);
    for(int i = 0; i < metaModelAndIconMapping.size(); i++){
      String s = (String)metaModelAndIconMapping.get(i);
      if(s.substring(0, s.indexOf(':')).equals(modelType))
        return s.substring(s.indexOf(':')+1);
    }
    return "";
  }*/
  
 
  public String getShapeType(String entityType, String viewType){
    Vector metaModelAndIconMapping = (Vector)getViewTypeAndEntityTypeAndShapeMapping().get(viewType);
    for(int i = 0; i < metaModelAndIconMapping.size(); i++){
      String s = (String)metaModelAndIconMapping.get(i);
      if(s.substring(0, s.indexOf(':')).equals(entityType))
        return s.substring(s.indexOf(':')+1);
    }
    return "";
  }
   
  public String getConnectorType(String associationType, String viewType){
    Vector metaModelAndIconMapping = (Vector)getViewTypeAndAssociationTypeAndConnectorMapping().get(viewType);
    for(int i = 0; i < metaModelAndIconMapping.size(); i++){
      String s = (String)metaModelAndIconMapping.get(i);
      if(s.substring(0, s.indexOf(':')).equals(associationType))
        return s.substring(s.indexOf(':')+1);
    }
    return "";
  }
  
  public Hashtable getViewTypeAndPropertyMapping(){
    return viewTypeAndPropertyMapping;
  }

  public Hashtable getViewTypeAndAllowedVisualEventHandlersMapping(){
    return viewTypeAndAllowedVisualEventHandlersMapping;
  }
  
  public Hashtable getViewTypeAndAllowedVisualUserHandlersMapping(){
    return viewTypeAndAllowedVisualUserHandlersMapping;
  }

  public Vector getAllowedVisualEventHandlers(String viewType){
    return (Vector)viewTypeAndAllowedVisualEventHandlersMapping.get(viewType);
  }
  
  public Vector getAllowedVisualUserHandlers(String viewType){
    return (Vector)viewTypeAndAllowedVisualUserHandlersMapping.get(viewType);
  }
  
  public DefaultMutableTreeNode getAssociationTypeNode(DefaultMutableTreeNode metaModelViewNode){
    return (DefaultMutableTreeNode)metaModelViewNodeAndAssociationTypeNodeMapping.get(metaModelViewNode);
  }
  
  public DefaultMutableTreeNode getEntityTypeNode(DefaultMutableTreeNode metaModelViewNode){
    return (DefaultMutableTreeNode)metaModelViewNodeAndEntityTypeNodeMapping.get(metaModelViewNode);
  }
  
  /**
   * init menu items for shape creator node
   * @return the vector contains all of the menu items for a shape creator node
   */
  public Vector initMenuItemsForShapeCreatorNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new shape");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewShape();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed shape");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedShape();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all shapes");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllShapes(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items for shape creator node
   * @return the vector contains all of the menu items for a shape creator node
   */
  public Vector initToolIconsForShapeCreatorNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new shape");
    jmi.setToolTipText("function: " + "creat a new shape");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewShape();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed shape");
    jmi.setToolTipText("function: " + "Open an existed shape");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedShape();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all shapes");
    jmi.setToolTipText("function: " + "deregister all shapes");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllShapes(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }


  /**
   * create new shape
   */
  public void doCreatNewShape(){
    String name = "shape"+shapeCount;
    while(getRegisteredShapes().contains(name)){
      shapeCount++;
      name = "shape"+shapeCount;
    }
    shapeCount++;
    String panelName = "panel"+pounamuPanelCount++;
    /////////////////////////////////////////////////////////////////////
    PounamuShape shape = new PounamuShape();
    PounamuPanel pp = shape.getBasePanel();
    shape.setDisplayName(name);
    pp.setDisplayName(panelName);
      PounamuView view = new PounamuView("shapes", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      pp.setBounds(210, 210, 100, 122);
      pp.setType("Rectangle");
      pp.setVisible(true);
      IconDisplayPanel idp = new IconDisplayPanel(pounamu, this, pp, name);
      view.setDisplayPane(idp);
      tab.addTab(name, idp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, name);
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndShapeMapping.put(dmtn, shape);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForShapeNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForShapeNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(idp, dmtn);
      manager.addTreeNode(dmtn);
      DefaultMutableTreeNode dm = new DefaultMutableTreeNode(panelName);
      manager.getNodeAndItsValueMapping().put(dm, panelName);
      manager.getNodeAndProjectMapping().put(dm, this);
      nodeAndMenuItemsMapping.put(dm, initMenuItemsForPanelNode());
      nodeAndToolButtonsMapping.put(dm, initToolIconsForPanelNode());
      nodeAndComponentMapping.put(dm, pp);
      nodeAndViewsTabMapping.put(dm, tab);
      nodeAndViewMapping.put(dm, view);
      dmtn.add(dm);
      TreePath tp = new TreePath(dmtn.getPath());
      managerTree.setSelectionPath(tp);
      doRegisterShape(dmtn);
      pounamu.validate();
      pounamu.displayMessage("the new shape named " + name + " has been created!");
    
  }
  /**
   * init menu items for a shape node
   * @return the vector contains all of the menu items for a shape node
   */
  public Vector initMenuItemsForShapeNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doSaveIcon(manager.getSelectedNode());
        //doGenerateIconImage(manager.getSelectedNode());
        doRegisterShape(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        IconDisplayPanel panel = (IconDisplayPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("Save this Shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveIcon(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);

    jmi = new JMenuItem("Save this Shape as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveShapeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);*/
    //menuItems.add(null);

    /*jmi = new JMenuItem("deregister this Shape window");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseShape(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/

    jmi = new JMenuItem("deregister this Shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterShape(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items for a shape node
   * @return the vector contains all of the menu items for a shape node
   */
  public Vector initToolIconsForShapeNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this shape");
    jmi.setToolTipText("function: " + "rename this shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this Shape");
    jmi.setVisible(true);
    jmi.setToolTipText("function: " + "register this Shape");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doSaveIcon(manager.getSelectedNode());
        //doGenerateIconImage(manager.getSelectedNode());
        doRegisterShape(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: " + "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        IconDisplayPanel panel = (IconDisplayPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("Save this Shape");
    jmi.setToolTipText("function: " + "Save this Shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveIcon(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);

    jmi = new JButton("Save this Shape as");
    jmi.setToolTipText("function: " + "Save this Shape as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveShapeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);*/
    //toolIcons.add(null);

    /*jmi = new JButton("Close this Shape window");
    jmi.setVisible(true);
    jmi.setToolTipText("function: " + "Close this Shape window");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseShape(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/

    jmi = new JButton("deregister this Shape");
    jmi.setToolTipText("function: " + "deregister this Shape");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterShape(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }

  /**
   * init menu items for a component node
   * @return the vector contains all of the menu items for a component node
   */
  public Vector initMenuItemsForComponentNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this component");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("remove this component");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveComp(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items for a component node
   * @return the vector contains all of the menu items for a component node
   */
  public Vector initToolIconsForComponentNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this component");
    jmi.setToolTipText("function: " + "rename this component");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("remove this component");
    jmi.setToolTipText("function " +"remove this component");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveComp(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }

  
  public Vector initMenuItemsForEntityTypeNode(){
    Vector menuItems = new Vector();
    /*JMenuItem jmi = new JMenuItem("add a new entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreateNewEntityTypeObject();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("add an existed entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser dialog = new ExistedMetaModelElementChooser(PounamuToolProject.this, (DefaultMutableTreeNode)manager.getSelectedNode(), "entitytype");
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an entity type from xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile dialog = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, (DefaultMutableTreeNode)manager.getSelectedNode(), "entitytype");
        dialog.setVisible(true);//doDefineNewEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);*/
    return menuItems;
  }
  
  public Vector initMenuItemsForAssociationTypeNode(){
    Vector menuItems = new Vector();
    /*JMenuItem jmi = new JMenuItem("add a new association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreateNewAssociationTypeObject();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("add an existed association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser dialog = new ExistedMetaModelElementChooser(PounamuToolProject.this, (DefaultMutableTreeNode)manager.getSelectedNode(), "association type");
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an association type from xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile dialog = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, (DefaultMutableTreeNode)manager.getSelectedNode(), "association type");
        dialog.setVisible(true);//doDefineNewEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);*/
    return menuItems;
  }
  
  public void doRegisterMetaModelView(DefaultMutableTreeNode dmtn){
    doSaveView(dmtn);
    if(!registeredMetaModelViews.contains((String)dmtn.getUserObject()))
          registeredMetaModelViews.add((String)dmtn.getUserObject());
    nodeAndRegisteredXMLStringMapping.put(dmtn, getView(dmtn).getXMLRepresentation());
    getView(dmtn).setRegistered(true);
    getView(dmtn).setWasRegistered(true);
    manager.getManagerTree().repaint();
  }
  
  public void doDeregisterMetaModelView(DefaultMutableTreeNode dmtn){
    DefaultMutableTreeNode entityTypeNode = (DefaultMutableTreeNode)dmtn.getFirstChild();
    DefaultMutableTreeNode associationTypeNode = entityTypeNode.getNextSibling();
    Enumeration en = entityTypeNode.children();
    while(en.hasMoreElements()){
      doRemoveEntityType((DefaultMutableTreeNode)en.nextElement());
    }
    en = associationTypeNode.children();
    while(en.hasMoreElements()){
      doRemoveAssociationType((DefaultMutableTreeNode)en.nextElement());
    }
    registeredMetaModelViews.remove(dmtn);
    String name = (String)dmtn.getUserObject();
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    ModellerPanel panel = (ModellerPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    updateAvailableTypesAndIcons();
    String fullPath = "\""+getLocation()+fileSeparator+"metamodelviews"+fileSeparator+name+".xml\"";
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run(); 
  }
    
  /**
   * init menu items for a metamodel view node
   * @return the vector contains all of the menu items for a metamodel view node
   */
  public Vector initMenuItemsForMetaModelViewNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterMetaModelView(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml of this meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("save this view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveView();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("save this view as");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //NewObjectDialogForMetaModelView dialog = new NewObjectDialogForMetaModelView(PounamuToolProject.this, getView(manager.getSelectedNode()), "associationtype");
        //dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    /*jmi = new JMenuItem("enter select state");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("select");
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("enter edit state");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("edit");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    /*jmi = new JMenuItem("specify inheritance relationship");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("Inheritance");
        panel.setSelected(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("specify connectible relationship");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("Connectible");
        panel.setSelected(true);
      }
    });
    menuItems.add(jmi);*/
    jmi = new JMenuItem("deregister this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterMetaModelView(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

   public void doCreateNewEntityTypeObject(){
     PounamuView view = getView(manager.getSelectedNode());
     ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
     panel.setState("entitytype");
     String name = "entity type " + entityTypeObjectCount;
     while(registeredEntityTypeObjects.get(name) != null){
       entityTypeObjectCount++;
       name = "entity type " + entityTypeObjectCount;
     }
     entityTypeObjectCount++;
     PounamuMetaModelElement pme = new PounamuMetaModelElement(name, "entitytype", this);
     panel.setCurrentObject(pme);
   }
   
   public void doCreateNewAssociationTypeObject(){
     PounamuView view = getView(manager.getSelectedNode());
     ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
     panel.setState("associationtype");
     String name = "association type " + associationTypeObjectCount;
     while(registeredAssociationTypeObjects.get(name) != null){
       associationTypeObjectCount++;
       name = "association type " + associationTypeObjectCount;
     }
     associationTypeObjectCount++;
     PounamuMetaModelElement pme = new PounamuMetaModelElement(name, "associationtype", this);
     panel.setCurrentObject(pme);
   }
   
   public Vector initToolIconsForAssociationTypeNode(){
    Vector toolIcons = new Vector();
    /*JButton jmi = new JButton("add a new association type");
    jmi.setToolTipText("function: " + "add a new association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreateNewAssociationTypeObject();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("add an existed association type");
    jmi.setToolTipText("function: " + "add an existed association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser dialog = new ExistedMetaModelElementChooser(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an association type from xml file");
    jmi.setToolTipText("function: " + "open an association type from xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile dialog = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        dialog.setVisible(true);//doDefineNewEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);*/
    return toolIcons;
  }
   
    public Vector initToolIconsForEntityTypeNode(){
    Vector toolIcons = new Vector();
    /*JButton jmi = new JButton("add a new entity type");
    jmi.setToolTipText("function: " + "add a new entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreateNewEntityTypeObject();}
    });
    toolIcons.add(jmi);
    jmi = new JButton("add an existed entity type");
    jmi.setToolTipText("function: " + "add an existed entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser dialog = new ExistedMetaModelElementChooser(PounamuToolProject.this, getView(manager.getSelectedNode()), "entitytype");
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an entity type from xml file");
    jmi.setToolTipText("function: " + "open an entity type from xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile dialog = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, getView(manager.getSelectedNode()), "entitytype");
        dialog.setVisible(true);//doDefineNewEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);*/
    return toolIcons;
  }
  
  /**
   * init menu items for a metamodel view node
   * @return the vector contains all of the menu items for a metamodel view node
   */
  public Vector initToolIconsForMetaModelViewNode(){
    Vector toolIcons = new Vector();
    /*JButton jmi = new JButton("add an entity type");
    jmi.setToolTipText("function: " + "add an entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        NewObjectDialogForMetaModelView dialog = new NewObjectDialogForMetaModelView(PounamuToolProject.this, getView(manager.getSelectedNode()), "entitytype");
        dialog.setVisible(true);//doDefineNewEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);

    jmi = new JButton("add an association type");
    jmi.setToolTipText("function: " + "add an association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        NewObjectDialogForMetaModelView dialog = new NewObjectDialogForMetaModelView(PounamuToolProject.this, getView(manager.getSelectedNode()), "associationtype");
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    JButton jmi = new JButton("rename this meta model view");
    jmi.setToolTipText("function: " + "rename this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this meta model view");
    jmi.setToolTipText("function: " + "register this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterMetaModelView(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml of this meta model view");
    jmi.setToolTipText("function: " + "view xml of this meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("save this view");
    jmi.setToolTipText("function: " + "save this view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveView();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("save this view as");
    jmi.setToolTipText("function: " + "save this view as");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //NewObjectDialogForMetaModelView dialog = new NewObjectDialogForMetaModelView(PounamuToolProject.this, getView(manager.getSelectedNode()), "associationtype");
        //dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    /*jmi = new JButton("enter select state");
    jmi.setToolTipText("function: " + "enter select state");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("select");
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("enter edit state");
    jmi.setToolTipText("function: " + "enter edit state");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("edit");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    /*jmi = new JButton("specify inheritance relation");
    jmi.setToolTipText("function: " + "specify inheritance relation");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("Inheritance");
        panel.setSelected(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("specify connectible relation");
    jmi.setToolTipText("function: " + "specify connectible relation");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("Connectible");
        panel.setSelected(true);
      }
    });
    toolIcons.add(jmi);*/
    jmi = new JButton("deregister this meta model view");
    jmi.setToolTipText("function: " + "deregister this meta model view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterMetaModelView(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }
  /**
   * save a view
   */
  public void doSaveView(DefaultMutableTreeNode dmtn){
    PounamuView view = getView(dmtn);
    String name = (String)dmtn.getUserObject();
    ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
    panel.setName(name);
    panel.save(name);
  }

  /**
   * define a new association in the view indexed by the specified tree node
   * @param dmtn the index tree node
   */
  /*public void doDefineNewAssociationType(DefaultMutableTreeNode dmtn){
    String name = JOptionPane.showInputDialog(pounamu, "Please input the name for the new association type here:\nPlease note that \"AT_\" will be added as prefix automatically!", "New Association Type Name Dialog", JOptionPane.OK_CANCEL_OPTION);
    if (name==null)
      return;
    else if(name.equals("")){
      pounamu.displayMessage("Please give a name to the new association type!\n");
      Toolkit.getDefaultToolkit().beep();
      doDefineNewAssociationType(dmtn);
    }
    else{
      name = "AT_"+capitalizeFirstLetter(name);
      PounamuMetaModelElement pmee = new PounamuMetaModelElement(name, "associationtype", this);
      PounamuView view = getView(dmtn);
      ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
      panel.setCurrentObject(pmee);
      panel.setState("associationtype");
    }
  }*/

  /**
   * import a definered entity type indexed by the specified tree node
   * @param dmtn the index tree node
   */
  public void doImportDefinedEntityType(DefaultMutableTreeNode dmtn){
    File inputFile = null;
    int returnVal = pounamu.getFileChooser().showOpenDialog(pounamu);
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+""+fileSeparator+"entitytypes"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else {
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuMetaModelElement pmee = new PounamuMetaModelElement(lxf.getDocument(), this);
    if(pmee.getType().equals("associationtype")){
      pounamu.displayMessage("Please choose a entity type xml file" );
      doImportDefinedEntityType(dmtn);
    }
    PounamuView view = getView(manager.getSelectedNode());
    ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
    panel.setCurrentObject(pmee);
    panel.setState("entitytype");
  }
  /**
   * import a definered association type indexed by the specified tree node
   * @param dmtn the index tree node
   */
  public void doImportDefinedAssociationType(DefaultMutableTreeNode dmtn){
    File inputFile = null;
    int returnVal = pounamu.getFileChooser().showOpenDialog(pounamu);
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+""+fileSeparator+"associationtypes"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else {
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuMetaModelElement pmee = new PounamuMetaModelElement(lxf.getDocument(), this);
    if(pmee.getType().equals("entitytype")){
      pounamu.displayMessage("Please choose a association type xml file" );
      doImportDefinedAssociationType(dmtn);
    }
    PounamuView view = getView(manager.getSelectedNode());
    ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
    panel.setCurrentObject(pmee);
    panel.setState("associationtype");
  }

  /**
   * define the new entity type in the view indexed by the specified tree node
   * @param dmtn the index tree node
   */
  /*public void doDefineNewEntityType(DefaultMutableTreeNode dmtn){
    String name = JOptionPane.showInputDialog(pounamu, "Please input the name for the new entity type here:\nPlease note that \"ET_\" will be added as prefix automatically!", "New Entity Type Name Dialog", JOptionPane.OK_CANCEL_OPTION);
    if (name==null)
      return;
    else if(name.equals("")){
      pounamu.displayMessage("Please give a name to the new entity type!\n");
      Toolkit.getDefaultToolkit().beep();
      doDefineNewEntityType(dmtn);
    }
    else{
      name = "ET_"+capitalizeFirstLetter(name);
      PounamuMetaModelElement pmee = new PounamuMetaModelElement(name, "entitytype", this);
      PounamuView view = getView(dmtn);
      ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
      panel.setCurrentObject(pmee);
      panel.setState("entitytype");
    }
  }*/
  /**
   * remoive the component indexed by the specified tree node
   * @param dmtn the index tree node
   */
  public void doRemoveComp(DefaultMutableTreeNode dmtn){
    DefaultMutableTreeNode dtn = (DefaultMutableTreeNode)dmtn.getParent();
    PounamuPanel con =(PounamuPanel)nodeAndComponentMapping.get(dtn);
    con.removeComp((Component)nodeAndComponentMapping.get(dmtn));
    con.validate();
    con.getParent().validate();
    con.repaint();
    manager.removeCurrentNode();
    pounamu.setPropertyPanel(null);
    pounamu.validate();
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndComponentMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    //nodeAndSpecifierMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
  }

  /**
   * init menu items for a panel node
   * @return the vector contains all of the menu items for a panel node
   */
  public Vector initMenuItemsForPanelNode(){
    Vector menuItems = new Vector();
    JMenuItem newComponent = new JMenuItem("rename this panel");
    newComponent.setVisible(true);
    newComponent.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(newComponent);
    menuItems.add(null);
    newComponent = new JMenuItem("add a panel");
    newComponent.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        String s ="panel"+pounamuPanelCount++;
        //PounamuPanel panel = (PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode());
        //Component  c = (Component)panel;
        //while( !(c instanceof IconDisplayPanel) ) c = c.getParent();
        PounamuPanel jsp = new PounamuPanel();
        jsp.setDisplayName(s);
        /*if( panel.getLayout() != null ){
        	jsp.removeListeners();
                //jsp.removeMouseListener(jsp.getMouseListeners()[0]);
                //jsp.removeMouseMotionListener(jsp.getMouseMotionListeners()[0]);
                jsp.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }*/
        //jsp.setCommonContainer((IconDisplayPanel)c);
        //PounamuLayoutEditor pfe = new PounamuLayoutEditor(jsp, pounamu);
        //pfe.setVisible(true);
        jsp.setPreferredSize(new Dimension(40, 40));
        PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
        PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
        PounamuProject project = manager.getProject(manager.getSelectedNode());
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jsp);
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
        String parentName = (String)manager.getSelectedNode().getUserObject();
        DefaultMutableTreeNode dmtn = manager.addObject(s); 
        manager.getNodeAndItsValueMapping().put(dmtn, s);
        manager.getNodeAndProjectMapping().put(dmtn, project);
        nodeAndComponentMapping.put(dmtn, jsp);
        nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForPanelNode());
        nodeAndToolButtonsMapping.put(dmtn, initToolIconsForPanelNode());
        nodeAndViewsTabMapping.put(dmtn, tab);
        nodeAndViewMapping.put(dmtn, view);
        //TreePath tp = new TreePath(dmtn.getPath());
        //manager.getManagerTree().setSelectionPath(tp);
        manager.setSelectedNode(dmtn);
        pounamu.validate();
        String name = (String)manager.getSelectedNode().getUserObject();
        pounamu.displayMessage("a panel " + name+ " has been added to " + parentName);
     }
		});
    menuItems.add(newComponent);

    newComponent = new JMenuItem("add a label");
    newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="label"+pounamuLabelCount++;
          PounamuLabel jl = new PounamuLabel();
          jl.setText(s);
          jl.setDisplayName(s);
          jl.setTool(PounamuToolProject.this);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jl);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();           
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jl);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jl, jl.propertyNameList(), jl.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a label " + name+ " has been added to " + parentName);
        }
     });
     menuItems.add(newComponent);

     newComponent = new JMenuItem("add a text field");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="textfield"+pounamuOneLineInputCount++;
          PounamuOneLineInput jtf = new PounamuOneLineInput();
          jtf.setText(s);
          jtf.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jtf);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jtf);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jtf, jtf.propertyNameList(), jtf.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          //nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a text field " + name+ " has been added to " + parentName);
	}
     });
     menuItems.add(newComponent);
     newComponent = new JMenuItem("add a text area");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="textarea"+pounamuMultiLinesInputCount++;
          PounamuMultiLinesInput jta = new PounamuMultiLinesInput();
          jta.setText(s);
          jta.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jta);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jta);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jta, jta.propertyNameList(), jta.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a text area " + name+ " has been added to " + parentName);
	}
     });
     menuItems.add(newComponent);
     newComponent = new JMenuItem("add a button");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="button"+pounamuButtonCount++;
          PounamuButton jb = new PounamuButton();
          jb.setText(s);
          jb.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jb);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jb);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jb, jb.propertyNameList(), jb.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a button " + name+ " has been added to " + parentName);
         }
     });
     menuItems.add(newComponent);
     menuItems.add(null);

     newComponent = new JMenuItem("remove this component");
     newComponent.setVisible(true);
     newComponent.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent ev){
         DefaultMutableTreeNode dmtn = manager.getSelectedNode();
         DefaultMutableTreeNode parent = (DefaultMutableTreeNode)dmtn.getParent().getParent();
         String s = (String)parent.getUserObject();
         if(s.equals("shape_creator")){
           pounamu.displayMessage("you can not remove this panel; It is the base panel of a shape!");
           Toolkit.getDefaultToolkit().beep();
           return;
         }
         else
           doRemoveComp(dmtn);
        }
    });
    menuItems.add(newComponent);
    return menuItems;
  }

  /**
   * init menu items for a panel node
   * @return the vector contains all of the menu items for a panel node
   */
  public Vector initToolIconsForPanelNode(){
    Vector toolIcons = new Vector();
    JButton newComponent = new JButton("rename this panel");
    newComponent.setToolTipText("function: " + "rename this panel");
    newComponent.setVisible(true);
    newComponent.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(newComponent);
    toolIcons.add(null);
    newComponent = new JButton("add a panel");
    newComponent.setToolTipText("function: " + "add a panel");
    newComponent.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        String s ="panel"+pounamuPanelCount++;
        //PounamuPanel panel = (PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode());
        //Component  c = (Component)panel;
        //while( !(c instanceof IconDisplayPanel) ) c = c.getParent();
        PounamuPanel jsp = new PounamuPanel();
        jsp.setDisplayName(s);
        /*if( panel.getLayout() != null ){
        	jsp.removeListeners();
                //jsp.removeMouseListener(jsp.getMouseListeners()[0]);
                //jsp.removeMouseMotionListener(jsp.getMouseMotionListeners()[0]);
                jsp.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }*/
        //jsp.setCommonContainer((IconDisplayPanel)c);
        //PounamuLayoutEditor pfe = new PounamuLayoutEditor(jsp, pounamu);
        //pfe.setVisible(true);
        jsp.setPreferredSize(new Dimension(40, 40));
        PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
        PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
        PounamuProject project = manager.getProject(manager.getSelectedNode());
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jsp);
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
        ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
        String parentName = (String)manager.getSelectedNode().getUserObject();
        DefaultMutableTreeNode dmtn = manager.addObject(s);
        manager.getNodeAndItsValueMapping().put(dmtn, s);
        manager.getNodeAndProjectMapping().put(dmtn, project);
        nodeAndComponentMapping.put(dmtn, jsp);
        nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForPanelNode());
        nodeAndToolButtonsMapping.put(dmtn, initToolIconsForPanelNode());
        nodeAndViewsTabMapping.put(dmtn, tab);
        nodeAndViewMapping.put(dmtn, view);
        //TreePath tp = new TreePath(dmtn.getPath());
        //manager.getManagerTree().setSelectionPath(tp);
        manager.setSelectedNode(dmtn);
        pounamu.validate();
        String name = (String)manager.getSelectedNode().getUserObject();
        pounamu.displayMessage("a panel " + name+ " has been added to " + parentName);
     }
		});
    toolIcons.add(newComponent);

    newComponent = new JButton("add a label");
    newComponent.setToolTipText("function: " + "add a label");
    newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="label"+pounamuLabelCount++;
          PounamuLabel jl = new PounamuLabel();
          jl.setText(s);
          jl.setDisplayName(s);
          jl.setTool(PounamuToolProject.this);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jl);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jl);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jl, jl.propertyNameList(), jl.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a label " + name+ " has been added to " + parentName);
        }
     });
     toolIcons.add(newComponent);

     newComponent = new JButton("add a text field");
     newComponent.setToolTipText("function: " + "add a text field");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="textfield"+pounamuOneLineInputCount++;
          PounamuOneLineInput jtf = new PounamuOneLineInput();
          jtf.setText(s);
          jtf.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jtf);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jtf);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jtf, jtf.propertyNameList(), jtf.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          //nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a text field " + name+ " has been added to " + parentName);
	}
     });
     toolIcons.add(newComponent);
     newComponent = new JButton("add a text area");
     newComponent.setToolTipText("function: " + "add a textarea");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="textarea"+pounamuMultiLinesInputCount++;
          PounamuMultiLinesInput jta = new PounamuMultiLinesInput();
          jta.setText(s);
          jta.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jta);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jta);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jta, jta.propertyNameList(), jta.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a text area " + name+ " has been added to " + parentName);
	}
     });
     toolIcons.add(newComponent);
     newComponent = new JButton("add a button");
     newComponent.setToolTipText("function: " + "add a button");
     newComponent.addActionListener(new ActionListener(){
	public void actionPerformed(ActionEvent ev){
          String s ="button"+pounamuButtonCount++;
          PounamuButton jb = new PounamuButton();
          jb.setText(s);
          jb.setDisplayName(s);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).addComp(jb);
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).validate();
          ((PounamuPanel)nodeAndComponentMapping.get(manager.getSelectedNode())).getParent().validate();
          PounamuView view = getView(manager.getSelectedNode());//nameAndViewMapping.put(s, getView(selectedDefaultMutableTreeNode));
          PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
          PounamuProject project = manager.getProject(manager.getSelectedNode());
          String parentName = (String)manager.getSelectedNode().getUserObject();
          DefaultMutableTreeNode dmtn = manager.addObject(s);
          manager.getNodeAndItsValueMapping().put(dmtn, s);
          manager.getNodeAndProjectMapping().put(dmtn, project);
          nodeAndComponentMapping.put(dmtn, jb);
          //PounamuComponentSpecifier pcs = new PounamuComponentSpecifier(jb, jb.propertyNameList(), jb.propertyTypeList());
          //nodeAndSpecifierMapping.put(dmtn, pcs);
          nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForComponentNode());
          nodeAndToolButtonsMapping.put(dmtn, initToolIconsForComponentNode());
          nodeAndViewsTabMapping.put(dmtn, tab);
          nodeAndViewMapping.put(dmtn, view);
          //TreePath tp = new TreePath(dmtn.getPath());
          //manager.getManagerTree().setSelectionPath(tp);
          manager.setSelectedNode(dmtn);
          pounamu.validate();
          String name = (String)manager.getSelectedNode().getUserObject();
          pounamu.displayMessage("a button " + name+ " has been added to " + parentName);
         }
     });
     toolIcons.add(newComponent);
     toolIcons.add(null);

     newComponent = new JButton("remove this component");
     newComponent.setToolTipText("function: " + "remove this component");
     newComponent.setVisible(true);
     newComponent.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent ev){
         DefaultMutableTreeNode dmtn = manager.getSelectedNode();
         DefaultMutableTreeNode parent = (DefaultMutableTreeNode)dmtn.getParent().getParent();
         String s = (String)parent.getUserObject();
         if(s.equals("shape_creator")){
           pounamu.displayMessage("you can not remove this panel; It is the base panel of a shape!");
           Toolkit.getDefaultToolkit().beep();
           return;
         }
         else
           doRemoveComp(dmtn);
        }
    });
    toolIcons.add(newComponent);
    return toolIcons;
  }
  /**
   * open an existed shape
   */
  public void doOpenExistedShape(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String fileName = inputFile.getName();

    if(!(fileName.endsWith(".xml"))){
      pounamu.displayMessage("The icon you chose is not a proper shape file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    String name = fileName.substring(0, fileName.indexOf("."));
    if(registeredShapes.contains(name)){
      pounamu.displayMessage("A shape with this name already existed. Please choose another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    PounamuView view = new PounamuView("shape", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuShape shape = new PounamuShape(name, lxf.getDocument(), this, view);
    IconDisplayPanel pp = new IconDisplayPanel(pounamu, this, shape.getBasePanel(), name);
    shape.getBasePanel().setSelected(true);
    PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    projectTab.setSelectedComponent(tab);
    tab.setSelectedComponent(pp);
    DefaultMutableTreeNode dmtn = shape.getTreeNode();
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForShapeNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForShapeNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    nodeAndShapeMapping.put(dmtn, shape);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedShapeNames.add(name);
    manager.addTreeNode(dmtn);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    manager.setSelectedNode(dmtn);
    doRegisterShape(dmtn);
    pounamu.validate();
    pounamu.displayMessage("the shape named " + name + " has been opened successfully!");
  }

  /**
   * open an existed shape with teh specified name
   * @param name the name of the shape
   */
  public void doOpenExistedShape(String name){
    File inputFile = new File(getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+""+name+".xml");
    PounamuView view = new PounamuView("shape", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuShape shape = new PounamuShape(name, lxf.getDocument(), this, view);
    IconDisplayPanel pp = new IconDisplayPanel(pounamu, this, shape.getBasePanel(), name);
    shape.getBasePanel().setSelected(true);
    PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    projectTab.setSelectedComponent(tab);
    tab.setSelectedComponent(pp);
    DefaultMutableTreeNode dmtn = shape.getTreeNode();
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndViewMapping.put(dmtn, view);
    manager.addTreeNode(dmtn);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForShapeNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForShapeNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
     nodeAndShapeMapping.put(dmtn, shape);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedShapeNames.add(name);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    manager.setSelectedNode(dmtn);
    doRegisterShape(dmtn);
    pounamu.validate();
    //pounamu.displayMessage("the shape named " + name + " has been opened successfully!");
  }

  /**
   * close all shape creation windows
   */
  public void doCloseAllShapes(DefaultMutableTreeNode dmtn){
    Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      doDeregisterShape(temp);
    }
  }

  /**
   * init menu items for tool project node
   * @return the vector contains all of the menu items for tool project node node
   */
  public Vector initMenuItemsForToolProjectNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this tool");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterToolProject(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    /*menuItems.add(null);
    jmi = new JMenuItem("save this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        save();
      }
    });
    menuItems.add(jmi);*/
    menuItems.add(null);
    jmi = new JMenuItem("view xml of this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doViewXMLForToolProject();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterToolProject(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public void doRegisterAllComponents(){
    
    if(shapeCreatorNode.getChildCount() != 0){
      //System.out.println("why? wow! shape");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)shapeCreatorNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterShape(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(connectorCreatorNode.getChildCount() != 0){  
      //System.out.println("why? wow! connector");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)connectorCreatorNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterConnector(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(metaModelDefinerNode.getChildCount() != 0){
      //System.out.println("why? wow! model view");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)metaModelDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterMetaModelView(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(modelEventHandlerDefinerNode.getChildCount() != 0){ 
      //System.out.println("why? wow! model handler");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)modelEventHandlerDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterModelEventHandler(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(modelUserHandlerDefinerNode.getChildCount() != 0){ 
      //System.out.println("why? wow! model handler");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)modelUserHandlerDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterModelUserHandler(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(visualEventHandlerDefinerNode.getChildCount() != 0){
      //System.out.println("why? wow! visual handler");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)visualEventHandlerDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterVisualEventHandler(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(visualUserHandlerDefinerNode.getChildCount() != 0){
      //System.out.println("why? wow! visual handler");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)visualUserHandlerDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterVisualUserHandler(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
    
    if(viewTypeDefinerNode.getChildCount() != 0){ 
      //System.out.println("why? wow! view type");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)viewTypeDefinerNode.getFirstChild();       
      while(dmtn != null){         
        doRegisterViewType(dmtn);         
        dmtn = dmtn.getNextSibling();         
      }
    }
  }
  
  public void doRegisterToolProject(DefaultMutableTreeNode node){
    this.save();
    doRegisterAllComponents();
    manager.registerTool(this.name, this);
    setRegistered(true);
    setWasRegistered(true);        
    nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), getXMLRepresentation());
    if(manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(getProjectNode()) == null){
      DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode("Using_"+this.name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().put(getProjectNode(), dmtn);
      manager.getNodeAndMenuItemsMapping().put(dmtn, manager.initMenuItemsForModelProjectNode());
      manager.getNodeAndToolButtonsMapping().put(dmtn, manager.initToolButtonsForModelProjectNode());
      manager.addTreeNode(manager.getModelProjectNode(), dmtn);
    }
    manager.getManagerTree().repaint(); 
  }
  /**
   * init menu items for tool project node
   * @return the vector contains all of the menu items for tool project node node
   */
  public Vector initToolIconsForToolProjectNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this tool");
    jmi.setToolTipText("function: " + "rename this tool");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this tool");
    jmi.setToolTipText("function: " + "register this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterToolProject(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("save this tool");
    jmi.setToolTipText("function: " + "save this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        save();
      }
    });
    toolIcons.add(jmi);*/
    jmi = new JButton("view xml of this tool");
    jmi.setToolTipText("function: " + "view xml of this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doViewXMLForToolProject();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this tool");
    jmi.setToolTipText("function: " + "deregister this tool");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterToolProject(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    
    return toolIcons;
  }
  
  public void registerEntityType(DefaultMutableTreeNode dmtn){
    doSaveEntityType(dmtn);
    doRegisterEntityType(dmtn);
    //nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), getEntityTypeObject(manager.getSelectedNode()).getXMLRepresentation());
  }
  
  public void registerAssociationType(DefaultMutableTreeNode dmtn){
    doSaveAssociationType(dmtn);
    doRegisterAssociationType(dmtn);
    //nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), getAssociationTypeObject(manager.getSelectedNode()).getXMLRepresentation());
  }
  /**
   * view the xml file for this tool project
   */
  public void doViewXMLForToolProject(){
    PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
    xmlView.setXML(getXMLRepresentation());
    JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
    dialog.setBounds(150, 100, 600, 600);
    dialog.getContentPane().add(new JScrollPane(xmlView));
    dialog.validate();
    dialog.setVisible(true);
  }
  /**
   * close this tool project
   */
  public void doDeregisterToolProject(DefaultMutableTreeNode dmtn){
    //get the name of this tool
    String name = (String)dmtn.getUserObject();
    //remove the entry from the registered tools 
    manager.getRegisteredTools().remove(name);
    //remove the entry from properties string
    /*String s = (String)pounamu.getProperties().get("tools");
    s = s + ","+name;
    pounamu.properties.put("tools", s);*/
    //remove the entry from node and xml mapping, node and menuitems mapping, node and toolButtons ampping
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndMenuItemsMapping().remove(dmtn);
    manager.getNodeAndToolButtonsMapping().remove(dmtn);
    if(manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(dmtn) != null){
      DefaultMutableTreeNode dm = (DefaultMutableTreeNode)manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(dmtn);
      String n = (String)dm.getUserObject();
      manager.getNodeAndItsValueMapping().remove(dm);
      manager.getNodeAndMenuItemsMapping().remove(dm);
      manager.getNodeAndToolButtonsMapping().remove(dm);
      manager.doCloseAllModelProjects(dm);
      manager.removeTreeNode(dm);
      manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().remove(dmtn);
      String fullPath = "\""+pounamu.getPounamuHome()+fileSeparator+"models"+fileSeparator+n+"\"";
      //System.out.println("fullPath in class toolProject is " + fullPath);
      MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefolder");
      mfs.run();
    }
    manager.removeTreeNode(dmtn);
    manager.getManagerTree().repaint(); 
    String fullPath = "\""+getLocation()+"\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefolder");
    mfs.run();
  }

  /**
   * init menu items for entity type object node
   * @return the vector contains all of the menu items for a entity type object node
   */
  public Vector initMenuItemsForEntityTypeObject(){
    Vector menuItems = new Vector(); 
    JMenuItem jmi = new JMenuItem("rename this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("map to an existed entity");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser chooser = new ExistedMetaModelElementChooser(PounamuToolProject.this, manager.getSelectedNode(), "entity type");
        chooser.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("load from an xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile chooser = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, manager.getSelectedNode(), "entity type");
        chooser.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        registerEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml of this entity type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuMetaModelElement object = getEntityTypeObject(manager.getSelectedNode());
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(object.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 400);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("Save this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveEntityType(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);

    jmi = new JMenuItem("Save this entity type as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveEntityTypeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);

    jmi = new JMenuItem("Deregister this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    jmi = new JMenuItem("remove this type from this view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterEntityType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("bring to front");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("front");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("push to back");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("back");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("forward one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("forward");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("down one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("backward");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null); 
    return menuItems;
  }

  /**
   * init menu items for entity type object node
   * @return the vector contains all of the menu items for a entity type object node
   */
  public Vector initToolIconsForEntityTypeObject(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this entity type");
    jmi.setToolTipText("function: " + "rename this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("map to an existed entity type");
    jmi.setToolTipText("function: " + "map to an existed entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser chooser = new ExistedMetaModelElementChooser(PounamuToolProject.this, manager.getSelectedNode(), "entity type");
        chooser.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("load from an xml file");
    jmi.setToolTipText("function: " + "load from an xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile chooser = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, manager.getSelectedNode(), "entity type");
        chooser.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this entity type");
    jmi.setToolTipText("function: " + "Register this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        registerEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: " + "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuMetaModelElement object = getEntityTypeObject(manager.getSelectedNode());
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(object.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 400);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("Save this entity type");
    jmi.setToolTipText("function: " + "Save this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveEntityType(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);

    jmi = new JButton("Save this entity type as");
    jmi.setToolTipText("function: " + "Save this entity type as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveEntityTypeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);

    jmi = new JButton("Deregister this entity type");
    jmi.setToolTipText("function: " + "Deregister this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    jmi = new JButton("remove this type from this view");
    jmi.setToolTipText("function: " + "remove this type from this view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("deregister this entity type");
    jmi.setToolTipText("function: " + "deregister this entity type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterEntityType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("bring to front");
    jmi.setToolTipText("function: " + "bring to front");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("front");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("push to back");
    jmi.setToolTipText("function: " + "push to back");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("back");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("forward one level");
    jmi.setToolTipText("function: " + "forward one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("forward");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("down one level");
    jmi.setToolTipText("function: " + "down one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("backward");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }
  /**
   * init menu items for association type object node
   * @return the vector contains all of the menu items for a association type object node
   */
  public Vector initMenuItemsForAssociationTypeObject(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("map to an existed association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser chooser = new ExistedMetaModelElementChooser(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        chooser.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("load from an xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile chooser = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        chooser.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        registerAssociationType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml of this association type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuMetaModelElement object = getAssociationTypeObject(manager.getSelectedNode());
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(object.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 400);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("Save this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveAssociationType(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);

    jmi = new JMenuItem("Save this association type as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveAssociationTypeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);

    jmi = new JMenuItem("Deregister this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterAssociationType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    jmi = new JMenuItem("remove this type from this view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveAssociationType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterAssociationType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("bring to front");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("front");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("push to back");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("back");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("forward one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("forward");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("down one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("backward");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null); 
    return menuItems;
  }

  /**
   * init menu items for association type object node
   * @return the vector contains all of the menu items for a association type object node
   */
  public Vector initToolIconsForAssociationTypeObject(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this association type");
    jmi.setToolTipText("function: " + "rename this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("map to an existed association type");
    jmi.setToolTipText("function: " + "map to an existed association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedMetaModelElementChooser chooser = new ExistedMetaModelElementChooser(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        chooser.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("load from an xml file");
    jmi.setToolTipText("function: " + "load from an xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        OpenMetaModelElementFromXMLFile chooser = new OpenMetaModelElementFromXMLFile(PounamuToolProject.this, manager.getSelectedNode(), "association type");
        chooser.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this association type");
    jmi.setToolTipText("function: " + "register this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        registerAssociationType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml of this association type");
    jmi.setToolTipText("function: " + "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuMetaModelElement object = getAssociationTypeObject(manager.getSelectedNode());
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(object.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 400);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("Save this association type");
    jmi.setToolTipText("function: " + "Save this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveAssociationType(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);

    jmi = new JButton("Save this association type as");
    jmi.setToolTipText("function: " + "Save this association type as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveAssociationTypeAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);

    jmi = new JButton("Deregister this association type");
    jmi.setToolTipText("function: " + "Deregister this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterAssociationType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    jmi = new JButton("remove this type from this view");
    jmi.setToolTipText("function: " + "remove this type from this view");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRemoveAssociationType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this association type");
    jmi.setToolTipText("function: " + "deregister this association type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterAssociationType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("bring to front");
    jmi.setToolTipText("function: " + "bring to front");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("front");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("push to back");
    jmi.setToolTipText("function: " + "push to back");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("back");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("forward one level");
    jmi.setToolTipText("function: " + "forward one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("forward");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("down one level");
    jmi.setToolTipText("function: " + "down one level");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        changeIconPositionInZCoordinate("backward");
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }
  /**
   * register the entity type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doRegisterEntityType(DefaultMutableTreeNode node){
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getEntityTypeObject(node);
    registeredEntityTypeProperty.put((String)node.getUserObject(), pmme.getProperties());
    updateAvailableTypesAndIcons();
    nodeAndRegisteredXMLStringMapping.put(node, pmme.getXMLRepresentation());
    pmme.setRegistered(true);
    pmme.setWasRegistered(true);
    manager.getManagerTree().repaint();
  }
  /**
   * save the entity type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doSaveEntityType(DefaultMutableTreeNode node){
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getEntityTypeObject(node);
    pmme.setName((String)manager.getSelectedNode().getUserObject());
    pmme.save(getLocation()+fileSeparator+"metamodel"+fileSeparator+"entitytypes"+fileSeparator+(String)manager.getSelectedNode().getUserObject()+".xml");
  }
  /**
   * save the entity type indexed by the specified tree node with another name
   * @param node the index tree node
   */
  public void doSaveEntityTypeAs(DefaultMutableTreeNode node){}
  /**
   * deregister the entity type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doDeregisterEntityType(DefaultMutableTreeNode dmtn){
    //get the name of the entity type object to be deregistered
    String name = (String)dmtn.getUserObject();
    //get the entity type object
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getEntityTypeObject(dmtn);
    //get out all shapes related to this entity type object
    Hashtable hash = pmme.getViewAndIconsMapping();
    Enumeration en = hash.elements();
    //perform the following operation for each shape and its related node
    while(en.hasMoreElements()){
      //get the shape
      PounamuPanel shape = ((PounamuShape)en.nextElement()).getBasePanel();
      //get its related node
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)getIconAndNodeMapping().get(shape);
      //get the modeller panel the shape is on
      ModellerPanel panel = (ModellerPanel)(getView(node).getDisplayPanel()); 
      //remove the shape from the panel
      panel.remove(shape);
      //panel.getShapes().remove(shape);
      //remove this shape from this entity type
      //pmme.getViewAndIconMapping().remove(getView(node));
      //remove all entries related to this node or shape
      manager.getNodeAndItsValueMapping().remove(node);
      manager.getNodeAndProjectMapping().remove(node);
      getNodeAndViewsTabMapping().remove(node);
      getNodeAndViewMapping().remove(node);
      //getNodeAndEntityTypeObjectMapping().remove(node);
      getNodeAndMenuItemsMapping().remove(node);
      getNodeAndToolButtonsMapping().remove(node);
      getIconAndNodeMapping().remove(shape);
      nodeAndRegisteredXMLStringMapping.remove(node);
      //remove the node from the manager tree
      manager.removeTreeNode(node); 
    }
    //repaint the manager tree
    manager.getManagerTree().repaint(); 
    //set property panel null
    pounamu.setPropertyPanel(null);
    //deregister the entity type object
    registeredEntityTypeObjects.remove(name);
    registeredEntityTypeProperty.remove(name);
    //update the available entity type information
    updateAvailableTypesAndIcons(); 
    //maintain the file system
    String fullPath = "\""+getLocation()+fileSeparator+"entitytypes"+fileSeparator+name+".xml\"";
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run();
  }
  /**
   * remove the icon of entity type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doRemoveEntityType(DefaultMutableTreeNode dmtn){
    //get the entity type object
    /*PounamuMetaModelElement pmme = (PounamuMetaModelElement)getEntityTypeObject(dmtn);
    //reduce the number of icons related to this entity type by 1
    pmme.setIconNumber(pmme.getIconNumber()-1);
    //if icon number is 0, that means this entity type should be deregistered
    if(pmme.getIconNumber()==0)
      doDeregisterEntityType(dmtn);
    //if icon number is not 0, that means this entity type must existed in at least one of the other meta model views
    else{
      //get the modeller panel
      ModellerPanel panel = (ModellerPanel)(getView(dmtn).getDisplayPanel()); 
      //get the shape to be removed
      PounamuPanel shape = (PounamuPanel)getNodeAndIconMapping().get(dmtn);
      //remove the shape from the panel
      panel.remove(shape);
      //panel.getShapes().remove(shape);
      //remove this shape from this entity type
      pmme.getViewAndIconMapping().remove(getView(dmtn));
      //remove entries related to this node or shape
      manager.getNodeAndItsValueMapping().remove(dmtn);
      manager.getNodeAndProjectMapping().remove(dmtn);
      getNodeAndViewsTabMapping().remove(dmtn);
      getNodeAndViewMapping().remove(dmtn);
      getNodeAndEntityTypeObjectMapping().remove(dmtn);
      getNodeAndMenuItemsMapping().remove(dmtn);
      getNodeAndToolButtonsMapping().remove(dmtn);
      getIconAndNodeMapping().remove(shape);
      nodeAndRegisteredXMLStringMapping.remove(dmtn);
      //remove this node
      manager.removeTreeNode(dmtn); 
      manager.getManagerTree().repaint();  
      //set property panel null
      pounamu.setPropertyPanel(null);
    }*/
  }
  /**
   * register the association type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doRegisterAssociationType(DefaultMutableTreeNode node){
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getAssociationTypeObject(node);
    registeredAssociationTypeProperty.put((String)manager.getSelectedNode().getUserObject(), pmme.getProperties());
    updateAvailableTypesAndIcons();
    nodeAndRegisteredXMLStringMapping.put(node, pmme.getXMLRepresentation());
    pmme.setRegistered(true);
    pmme.setWasRegistered(true);
    manager.getManagerTree().repaint();
  }
  /**
   * save the association type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doSaveAssociationType(DefaultMutableTreeNode node){
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getAssociationTypeObject(node);
    //System.out.println("what happened here!");
    //if(pmme==null)
      //System.out.println("what!!!");
    pmme.setName((String)node.getUserObject());
    pmme.save(getLocation()+fileSeparator+"metamodel"+fileSeparator+"associationtypes"+fileSeparator+(String)node.getUserObject()+".xml");
  }
  /**
   * save the association type indexed by the specified tree node with another name
   * @param node the index tree node
   */
  public void doSaveAssociationTypeAs(DefaultMutableTreeNode node){}
  /**
   * deregister the association type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doDeregisterAssociationType(DefaultMutableTreeNode dmtn){
    //get the name of the  type object to be deregistered
    /*String name = (String)dmtn.getUserObject();
    //get the association type object
    PounamuMetaModelElement pmme = (PounamuMetaModelElement)getAssociationTypeObject().get(dmtn);
    //get out all shapes related to this association type object
    Hashtable hash = pmme.getViewAndIconMapping();
    Enumeration en = hash.elements();
    //perform the following operation for each shape and its related node
    while(en.hasMoreElements()){
      //get the shape
      PounamuPanel shape = ((PounamuShape)en.nextElement()).getBasePanel();
      //get its related node
      DefaultMutableTreeNode node = (DefaultMutableTreeNode)getIconAndNodeMapping().get(shape);
      //get the modeller panel the shape is on
      ModellerPanel panel = (ModellerPanel)(getView(node).getDisplayPanel()); 
      //remove the shape from the panel
      panel.remove(shape);
      //panel.getShapes().remove(shape);
      //remove this shape from this association type
      pmme.getViewAndIconMapping().remove(getView(node));
      //remove all entries related to this node or shape
      manager.getNodeAndItsValueMapping().remove(node);
      manager.getNodeAndProjectMapping().remove(node);
      getNodeAndViewsTabMapping().remove(node);
      getNodeAndViewMapping().remove(node);
      getNodeAndAssociationTypeObjectMapping().remove(node);
      getNodeAndMenuItemsMapping().remove(node);
      getNodeAndToolButtonsMapping().remove(node);
      getIconAndNodeMapping().remove(shape);
      nodeAndRegisteredXMLStringMapping.remove(node);
      //remove the node from the manager tree
      manager.removeTreeNode(node); 
    }
    //repaint the manager tree
    manager.getManagerTree().repaint(); 
    //set property panel null
    pounamu.setPropertyPanel(null);
    //deregister the association type object
    registeredAssociationTypeObjects.remove(name);
    registeredAssociationTypeProperty.remove(name);
    //update the available association type information
    updateAvailableTypesAndIcons(); 
    //maintain the file system
    String fullPath = "\""+getLocation()+fileSeparator+"associationtypes"+fileSeparator+name+".xml\"";
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run();*/
  }
  
  /**
   * remove the association type indexed by the specified tree node
   * @param node the index tree node
   */
  public void doRemoveAssociationType(DefaultMutableTreeNode dmtn){
    //get the association type object
    /*PounamuMetaModelElement pmme = (PounamuMetaModelElement)getNodeAndAssociationTypeObjectMapping().get(dmtn);
    //reduce the number of icons related to this association type by 1
    pmme.setIconNumber(pmme.getIconNumber()-1);
    //if icon number is 0, that means this association type should be deregistered
    if(pmme.getIconNumber()==0)
      doDeregisterAssociationType(dmtn);
    //if icon number is not 0, that means this entity type must existed in at least one of the other meta model views
    else{
      //get the modeller panel
      ModellerPanel panel = (ModellerPanel)(getView(dmtn).getDisplayPanel()); 
      //get the shape to be removed
      PounamuPanel shape = (PounamuPanel)getNodeAndIconMapping().get(dmtn);
      //remove the shape from the panel
      panel.remove(shape);
      //panel.getShapes().remove(shape);
      //remove this shape from this entity type
      pmme.getViewAndIconMapping().remove(getView(dmtn));
      //remove entries related to this node or shape
      manager.getNodeAndItsValueMapping().remove(dmtn);
      manager.getNodeAndProjectMapping().remove(dmtn);
      getNodeAndViewsTabMapping().remove(dmtn);
      getNodeAndViewMapping().remove(dmtn);
      getNodeAndAssociationTypeObjectMapping().remove(dmtn);
      getNodeAndMenuItemsMapping().remove(dmtn);
      getNodeAndToolButtonsMapping().remove(dmtn);
      getIconAndNodeMapping().remove(shape);
      nodeAndRegisteredXMLStringMapping.remove(dmtn);
      //remove this node
      manager.removeTreeNode(dmtn); 
      manager.getManagerTree().repaint();  
      //set property panel null
      pounamu.setPropertyPanel(null);
    }*/
  } 
  /**
   * init menu items for connetor node
   * @return the vector contains all of the menu items for a connetor node
   */
  public Vector initMenuItemsForConnectorNode(){

    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doSaveIcon(manager.getSelectedNode());
        //doGenerateIconImage(manager.getSelectedNode());
        doRegisterConnector(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        IconDisplayPanel panel = (IconDisplayPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("Save this Connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveIcon(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);

    jmi = new JMenuItem("Save this Connector as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveConnectorAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/

    /*jmi = new JMenuItem("Close this Connector window");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseConnector(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/

    jmi = new JMenuItem("deregister this Connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterConnector(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

   /**
   * init menu items for connetor node
   * @return the vector contains all of the menu items for a connetor node
   */
  public Vector initToolIconsForConnectorNode(){

    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this component");
    jmi.setToolTipText("function: " + "rename this connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this connector");
    jmi.setToolTipText("function: "+ "Register this connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doSaveIcon(manager.getSelectedNode());
        //doGenerateIconImage(manager.getSelectedNode());
        doRegisterConnector(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: "+ "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        IconDisplayPanel panel = (IconDisplayPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXMLRepresentation());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("Save this Connector");
    jmi.setToolTipText("function: "+ "Save this Connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveIcon(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);

    jmi = new JButton("Save this Connector as");
    jmi.setToolTipText("function: "+ "Save this Connector as");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveConnectorAs(manager.getSelectedNode());
        pounamu.displayMessage((String)manager.getSelectedNode().getUserObject() + " has been saved to " + getLocation()+" successfully!");
      }
    });
    toolIcons.add(jmi);*/
   // toolIcons.add(null);

   /* jmi = new JButton("Close this Connector window");
    jmi.setToolTipText("function: "+ "Close this Connector window");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseConnector(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/

    jmi = new JButton("deregister this connector");
    jmi.setToolTipText("function: "+ "deregister this connector");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterConnector(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }

  /**
   * save an icon indexed byteh specified tree node
   * @param dmtn the index node
   */
  public void doSaveIcon(DefaultMutableTreeNode dmtn){
    PounamuView view = getView(dmtn);
    String name = (String)dmtn.getUserObject();
    IconDisplayPanel iconView = (IconDisplayPanel)view.getDisplayPanel();
    iconView.setName(name);
    iconView.save();
    //pounamu.displayMessage(name + " has been saved to " + getLocation()+" successfully!");
  }

  public void doGenerateIconImage(DefaultMutableTreeNode dmtn){
    ThumbnailSettingDialog tsp = new ThumbnailSettingDialog(this, dmtn);
    tsp.setVisible(true);
    /*try{
      PounamuView view = getView(dmtn);
      String name = (String)dmtn.getUserObject();
      IconDisplayPanel iconView = (IconDisplayPanel)view.getDisplayPanel();
      Rectangle recta = iconView.getBounds();
      Image fileImage = iconView.createImage(recta.width,recta.height);
      Graphics g = fileImage.getGraphics();
      iconView.paint(g);
      g.dispose();
      JPanel icon = iconView.getTarget();
      Rectangle rect = icon.getBounds();
      ImageFilter filter = null;
      if(icon instanceof PounamuConnector)
        filter = new CropImageFilter((int)(rect.getX()+40), (int)(rect.getY()+30), (int)(rect.getWidth()-80), (int)(rect.getHeight()-60));
      else if(rect.getWidth()>=rect.getHeight())
        filter = new CropImageFilter((int)rect.getX(), (int)(rect.getY()-(rect.getWidth()-rect.getHeight())/2), (int)rect.getWidth(), (int)rect.getWidth());
      else
        filter = new CropImageFilter((int)(rect.getX()-(rect.getHeight()-rect.getWidth())/2), (int)rect.getY(), (int)rect.getHeight(), (int)rect.getHeight());
      FilteredImageSource fis = new FilteredImageSource(fileImage.getSource(), filter);
      Image subImage = iconView.createImage(fis);
      int imageWidth = subImage.getWidth(null);
      int imageHeight = subImage.getHeight(null);
      int thumbWidth = 150;
      int thumbHeight = 150;
      BufferedImage thumbImage = null;
      if(icon instanceof PounamuConnector)
        thumbImage = new BufferedImage(imageWidth, imageHeight, BufferedImage.TYPE_INT_RGB);
      else
        thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
      Graphics2D graphics2D = thumbImage.createGraphics();
      graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      if(icon instanceof PounamuConnector)
        graphics2D.drawImage(subImage, 0, 0, imageWidth, imageHeight, null);
      else
        graphics2D.drawImage(subImage, 0, 0, thumbWidth, thumbHeight, null);
      BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(name+".JPG"));
      JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
      JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(thumbImage);
      //int quality = Integer.parseInt(args[4]);
      //quality = Math.max(0, Math.min(quality, 100));
      //param.setQuality((float)quality / 100.0f, false);
      param.setQuality(1000, false);
      encoder.setJPEGEncodeParam(param);
      encoder.encode(thumbImage);
    }
    catch(Exception e){
      pounamu.displayMessage("In class PounamuToolProject, got exception: " + e.toString());
    }*/
  }


  public void doSaveConnectorAs(DefaultMutableTreeNode dmtn){}

  /**
   * save the shape indexed by the specified tree node as another shape
   * @param dmtn
   */
  public void doSaveShapeAs(DefaultMutableTreeNode dmtn){}
  
  /**
   * deregister a shape indexed by the specified tree node
   * @param dmtn the index node
   */
  public void doDeregisterShape(DefaultMutableTreeNode dmtn){
    String name = (String)dmtn.getUserObject();
    //System.out.println("in claaa PounamuToolProject, name is 0 " + name);
    getRegisteredShapes().remove(name);
    iconNameToTextAreaPropertiesMapping.remove(name);
    iconNameToTextFieldPropertiesMapping.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    //System.out.println("in claaa PounamuToolProject, name is 1 " + name);
    updateAvailableTypesAndIcons();
    //System.out.println("in claaa PounamuToolProject, name is 2 " + name);
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    IconDisplayPanel panel = (IconDisplayPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    //System.out.println("in claaa PounamuToolProject, name is 3 " + name);
    nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    //System.out.println("in claaa PounamuToolProject, name is 4 " + name);
    String fullPath = "\""+getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run();
    //System.out.println("in claaa PounamuToolProject, name is 5 " + name);
  }
  /**
   * register the shape indexed by the specified tree node
   * @param dmtn the index node
   */
  public void doRegisterShape(DefaultMutableTreeNode dmtn){
      doSaveIcon(dmtn);
      doGenerateIconImage(dmtn);
      String name = (String)dmtn.getUserObject();
      //System.out.println("class Pounamutoolproject, method doregidtershape, path is " + getLocation()+fileSeparator+"shapes"+fileSeparator+name+".xml");
      LoadXMLFile load = new LoadXMLFile(new File(getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+name+".xml"));
      PounamuShape ps = new PounamuShape(name, load.getDocument(), this, new PounamuView());
      //PounamuShape ps = (PounamuShape)nodeAndShapeMapping.get(dmtn);
      if(getRegisteredShapes().contains(name)){
        getRegisteredShapes().remove(name);
      }
      registerPounamuShape(name);
      registerIconTextFieldProperties(name, ps.getTextFieldProperties());
      registerIconTextAreaProperties(name, ps.getTextAreaProperties());
      nodeAndRegisteredXMLStringMapping.put(dmtn, getView(dmtn).getXMLRepresentation());
      updateAvailableTypesAndIcons();
      getView(dmtn).setRegistered(true);
      getView(dmtn).setWasRegistered(true);
      manager.getManagerTree().repaint();
      pounamu.displayMessage(name + " has been registered to " + getName());
  }

  /**
   * update the available view meta model elements and icons
   */
  public void updateAvailableTypesAndIcons(){
    if(viewTypeDefinerNode.getChildCount() == 0)
      return;
    DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)viewTypeDefinerNode.getFirstChild();
    while(dmtn != null){
      PounamuView view = getView(dmtn);
      ViewTypeDefinerPanel definer = (ViewTypeDefinerPanel)view.getDisplayPanel();
      definer.updateAvailableTypesAndIcons();
      dmtn = dmtn.getNextSibling();
    }    
  }

  /**
   * register a definered connector indexed by the specified tree node
   * @param dmtn the index node
   */
  public void doRegisterConnector(DefaultMutableTreeNode dmtn){
      doSaveIcon(dmtn);
      doGenerateIconImage(dmtn);
      String name = (String)dmtn.getUserObject();
      /*LoadXMLFile load = new LoadXMLFile(new File(getLocation()+""+fileSeparator+"connectors"+fileSeparator+""+name+".xml"));
      PounamuConnector pc = new PounamuConnector(load.getDocument());*/
      PounamuConnector pc  = (PounamuConnector)nodeAndConnectorMapping.get(dmtn);
      if(getRegisteredConnectors().contains(name)){
         getRegisteredConnectors().remove(name);
      }
      //registerIconAndItsShownProperties(name, pc.getShownProperties());
      registerPounamuConnector(name);
      registerIconTextFieldProperties(name, pc.getTextFieldProperties());
      registerIconTextAreaProperties(name, pc.getTextAreaProperties());
      nodeAndRegisteredXMLStringMapping.put(dmtn, getView(dmtn).getXMLRepresentation());
      updateAvailableTypesAndIcons();
      getView(dmtn).setRegistered(true);
      getView(dmtn).setWasRegistered(true);
      manager.getManagerTree().repaint();
      pounamu.displayMessage(name + " has been registered to " + getName());
  }

  /**
   * close the window of the connector, indexed by the specified tree node
   * @param dmtn the index node
   */
  //public void doCloseConnector(DefaultMutableTreeNode dmtn){}
  /**
   * deregister a connector indexed by the specified tree node
   * @param dmtn the index node
   */
  public void doDeregisterConnector(DefaultMutableTreeNode dmtn){
    String name = (String)dmtn.getUserObject();
    getRegisteredConnectors().remove(name);
    iconNameToTextAreaPropertiesMapping.remove(name);
    iconNameToTextFieldPropertiesMapping.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    updateAvailableTypesAndIcons();
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    IconDisplayPanel panel = (IconDisplayPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    String fullPath = "\""+getLocation()+fileSeparator+"connectors"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run();  
  }
  /**
   * close the window of the shape, indexed by the specified tree node
   * @param dmtn the index node
   */
  //public void doCloseShape(DefaultMutableTreeNode dmtn){}
  
  /**
   * init menu items for connetor creator node
   * @return the vector contains all of the menu items for a connetor creator node
   */
  public Vector initMenuItemsForConnectorCreatorNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new connector");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewConnector();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed connector");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedConnector();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all connectors");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllConnectors(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items for connetor creator node
   * @return the vector contains all of the menu items for a connetor creator node
   */
  public Vector initToolIconsForConnectorCreatorNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new connector");
    jmi.setToolTipText("function: "+ "Creat a new connector");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewConnector();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed connector");
    jmi.setToolTipText("function: "+ "Open an existed connector");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedConnector();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all connectors");
    jmi.setToolTipText("function: "+ "deregister all connectors");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllConnectors(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }


  /**
   * create a new connector
   */
  public void doCreatNewConnector(){
    String name = "connector"+connectorCount;
    while(getRegisteredConnectors().contains(name)){
      connectorCount++;
      name = "connector"+connectorCount;
    }
    connectorCount++;
      PounamuView view = new PounamuView("connectors", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      PounamuConnector con = new PounamuConnector(name);
      con.setDisplayName(name);
      IconDisplayPanel pp = new IconDisplayPanel(pounamu, this, con, name);
      view.setDisplayPane(pp);
      tab.addTab(name, pp);
      //dmtn = manager.addObject(name);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, name);
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndConnectorMapping.put(dmtn, con);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForConnectorNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForConnectorNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(pp, dmtn);
      //openedConnectorNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      //doSaveIcon(dmtn);
      //doGenerateIconImage(dmtn);
      doRegisterConnector(dmtn);
      pounamu.validate();
      pounamu.displayMessage("the new connector named " + name + " has been created!");
    
  }
  /**
   * open the existed connector
   */
  public void doOpenExistedConnector(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String fileName = inputFile.getName();
    if(!(fileName.endsWith(".xml"))){
      pounamu.displayMessage("The icon you chose is not a proper connector file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    String name = fileName.substring(0, fileName.indexOf("."));
    if(registeredConnectors.contains(name)){
      pounamu.displayMessage("A connector with this name already existed. Please choose another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    PounamuView view = new PounamuView("connector", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuConnector connector = new PounamuConnector(lxf.getDocument());
    IconDisplayPanel pp = new IconDisplayPanel(pounamu, this, connector, name);
    PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    projectTab.setSelectedComponent(tab);
    tab.setSelectedComponent(pp);
    DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForConnectorNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForConnectorNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    nodeAndConnectorMapping.put(dmtn, connector);
    viewTabAndNodeMapping.put(pp, dmtn);
    manager.addTreeNode(dmtn);
    manager.setSelectedNode(dmtn);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    doRegisterConnector(dmtn);
    pounamu.validate();
    pounamu.displayMessage("the connector named " + name + " has been opened successfully!");
  }
   /**
    * open existed connector indexed by the specified connector name
    * @param name the specified connector name
    */
   public void doOpenExistedConnector(String name){
    File inputFile = new File(getLocation()+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+""+name+".xml");
    PounamuView view = new PounamuView("connector", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuConnector connector = new PounamuConnector(lxf.getDocument());
    IconDisplayPanel pp = new IconDisplayPanel(pounamu, this, connector, name);
    PounamuTabbedPane tab = getViewsTab(manager.getSelectedNode());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    projectTab.setSelectedComponent(tab);
    tab.setSelectedComponent(pp);
    DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForConnectorNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForConnectorNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    nodeAndConnectorMapping.put(dmtn, connector);
    viewTabAndNodeMapping.put(pp, dmtn);
    manager.addTreeNode(dmtn);
    manager.setSelectedNode(dmtn);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    doRegisterConnector(dmtn);
    pounamu.validate();
  }

  /**
   * close all connectors window
   */
  public void doCloseAllConnectors(DefaultMutableTreeNode dmtn){
    Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      doDeregisterConnector(temp);
    }
  }

  /*public void doRegisterModelHandler(){
    PounamuView view = getView(manager.getSelectedNode());
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
    String name = panel.getHandlerName();
    if(registeredModelHandlers.containsKey(name)){
      registeredModelHandlers.remove(name);
    }
    if(currentRegisteredModelHandlers.containsKey(name)){
      currentRegisteredModelHandlers.remove(name);
    }
    registerPounamuModelHandler(name, name+uniqueNum);
    currentRegisteredModelHandlers.put(name, name+uniqueNum);
    nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
    updateAvailableTypesAndIcons();
    uniqueNum++;
    view.setRegistered(true);
    view.setWasRegistered(true);
    manager.getManagerTree().repaint();
    pounamu.displayMessage(name + " has been registed!");
  }*/
   
  public void doDeregisterVisualEventHandler(DefaultMutableTreeNode dmtn){
    /*String name = (String)dmtn.getUserObject();
    registeredVisualHandlers.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    updateAvailableTypesAndIcons();
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    //nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    String fullPath = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run(); 
    String fullPath1 = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+"*.java\"";
    MaintainFileSystem mfs1 = new MaintainFileSystem(fullPath1, pounamu, "deletefile");
    mfs1.run(); 
    String fullPath2 = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+"*.class\"";
    MaintainFileSystem mfs2 = new MaintainFileSystem(fullPath2, pounamu, "deletefile");
    mfs2.run(); */  
  }
   
  public void doDeregisterVisualUserHandler(DefaultMutableTreeNode dmtn){
    /*String name = (String)dmtn.getUserObject();
    registeredVisualHandlers.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    updateAvailableTypesAndIcons();
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    //nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    String fullPath = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run(); 
    String fullPath1 = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+"*.java\"";
    MaintainFileSystem mfs1 = new MaintainFileSystem(fullPath1, pounamu, "deletefile");
    mfs1.run(); 
    String fullPath2 = "\""+getLocation()+fileSeparator+"visualhandlers"+fileSeparator+name+"*.class\"";
    MaintainFileSystem mfs2 = new MaintainFileSystem(fullPath2, pounamu, "deletefile");
    mfs2.run(); */  
  }
   public void doDeregisterModelEventHandler(DefaultMutableTreeNode dmtn){
    /*String name = (String)dmtn.getUserObject();
    registeredModelHandlers.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    updateAvailableTypesAndIcons();
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    //nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    String fullPath = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run(); 
    String fullPath1 = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+"*.java\"";
    MaintainFileSystem mfs1 = new MaintainFileSystem(fullPath1, pounamu, "deletefile");
    mfs1.run(); 
    String fullPath2 = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+"*.class\"";
    MaintainFileSystem mfs2 = new MaintainFileSystem(fullPath2, pounamu, "deletefile");
    mfs2.run(); */
   }
   
   public void doDeregisterModelUserHandler(DefaultMutableTreeNode dmtn){
    /*String name = (String)dmtn.getUserObject();
    registeredModelHandlers.remove(name);
    nodeAndRegisteredXMLStringMapping.remove(dmtn);
    updateAvailableTypesAndIcons();
    PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)(getView(dmtn).getDisplayPanel());
    tab.remove(panel);
    //nodeAndShapeMapping.remove(dmtn);
    nodeAndMenuItemsMapping.remove(dmtn);
    nodeAndToolButtonsMapping.remove(dmtn);
    nodeAndViewsTabMapping.remove(dmtn);
    nodeAndViewMapping.remove(dmtn);
    viewTabAndNodeMapping.remove(panel);
    pounamu.setPropertyPanel(null);
    manager.getNodeAndItsValueMapping().remove(dmtn);
    manager.getNodeAndProjectMapping().remove(dmtn);
    manager.removeTreeNode(dmtn);
    String fullPath = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run(); 
    String fullPath1 = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+"*.java\"";
    MaintainFileSystem mfs1 = new MaintainFileSystem(fullPath1, pounamu, "deletefile");
    mfs1.run(); 
    String fullPath2 = "\""+getLocation()+fileSeparator+"modelhandlers"+fileSeparator+name+"*.class\"";
    MaintainFileSystem mfs2 = new MaintainFileSystem(fullPath2, pounamu, "deletefile");
    mfs2.run(); */
   }
   
   public void doRegisterVisualUserHandler(DefaultMutableTreeNode node){
     PounamuView view = getView(node);
     HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
     if(panel.isValid() == false){
       pounamu.displayMessage(panel.getHandlerName() + " has not input text for menu item!");
       return;
     }
     panel.save();
     panel.saveJavaCode(uniqueNum);
     Compile compiler = new Compile(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+panel.getHandlerName()+uniqueNum+".java", PounamuToolProject.this);
     compiler.run();
     if(compiler.getCompiled() == false){
       pounamu.displayMessage(panel.getHandlerName()+" got compile error, thus can not be registered!");
       return;
     }
     if(registeredVisualUserHandlers.containsKey(panel.getHandlerName())){
       registeredVisualUserHandlers.remove(panel.getHandlerName());
     }
     registerVisualUserHandler(panel.getHandlerName(), panel.getHandlerName()+uniqueNum);
     nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
     updateAvailableTypesAndIcons();
     uniqueNum++;
     view.setRegistered(true);
     view.setWasRegistered(true);
     manager.getManagerTree().repaint();
     pounamu.displayMessage(panel.getHandlerName() + " has been registed!");
   
   }
   public void doRegisterVisualEventHandler(DefaultMutableTreeNode node){
     PounamuView view = getView(node);
     HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
     if(panel.isValid() == false){
       pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
       return;
     }
     panel.save();
     panel.saveJavaCode(uniqueNum);
     Compile compiler = new Compile(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+panel.getHandlerName()+uniqueNum+".java", PounamuToolProject.this);
     compiler.run();
     if(compiler.getCompiled() == false){
       pounamu.displayMessage(panel.getHandlerName()+" got compile error, thus can not be registered!");
       return;
     }
     if(registeredVisualEventHandlers.containsKey(panel.getHandlerName())){
       registeredVisualEventHandlers.remove(panel.getHandlerName());
     }
     registerVisualEventHandler(panel.getHandlerName(), panel.getHandlerName()+uniqueNum);
     nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
     updateAvailableTypesAndIcons();
     uniqueNum++;
     view.setRegistered(true);
     view.setWasRegistered(true);
     manager.getManagerTree().repaint();
     pounamu.displayMessage(panel.getHandlerName() + " has been registed!");
  }

   /**
   * init menu items fr an event triggering visual handler node
   * @return the vector contains all of the menu items for an event triggering visual handler
   */
  public Vector initMenuItemsForVisualEventHandlerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this event triggering visual handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterVisualEventHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this Handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterVisualEventHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    return menuItems;
  }

  /**
   * init menu items fr an user triggering visual handler node
   * @return the vector contains all of the menu items for an user triggering visual handler
   */
  public Vector initMenuItemsForVisualUserHandlerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this user triggering visual handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterVisualUserHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this Handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterVisualUserHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    return menuItems;
  }

  public void doRegisterModelUserHandler(DefaultMutableTreeNode node){
    PounamuView view = getView(node);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
    if(panel.isValid() == false){
      pounamu.displayMessage(panel.getHandlerName() + " has not input text for menu item!");
      return;
    }
    panel.save();
    panel.saveJavaCode(uniqueNum);
    Compile compiler = new Compile(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+panel.getHandlerName()+uniqueNum+".java", PounamuToolProject.this);
    compiler.run();
    if(compiler.getCompiled() == false){
      pounamu.displayMessage(panel.getHandlerName()+" got compile error, thus can not be registered!");
      return;
    }
    if(registeredModelUserHandlers.containsKey(panel.getHandlerName())){
      registeredModelUserHandlers.remove(panel.getHandlerName());
    }
    registerModelUserHandler(panel.getHandlerName(), panel.getHandlerName()+uniqueNum);
    nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
    updateAvailableTypesAndIcons();
    uniqueNum++;
    view.setRegistered(true);
    view.setWasRegistered(true);
    manager.getManagerTree().repaint();
    pounamu.displayMessage(panel.getHandlerName() + " has been registed!");
  }
  
  public void doRegisterModelEventHandler(DefaultMutableTreeNode node){
    PounamuView view = getView(node);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
    if(panel.isValid() == false){
      pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
      return;
    }
    panel.save();
    panel.saveJavaCode(uniqueNum);
    Compile compiler = new Compile(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+panel.getHandlerName()+uniqueNum+".java", PounamuToolProject.this);
    compiler.run();
    if(compiler.getCompiled() == false){
      pounamu.displayMessage(panel.getHandlerName()+" got compile error, thus can not be registered!");
      return;
    }
    if(registeredModelEventHandlers.containsKey(panel.getHandlerName())){
      registeredModelEventHandlers.remove(panel.getHandlerName());
    }
    registerModelEventHandler(panel.getHandlerName(), panel.getHandlerName()+uniqueNum);
    nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
    updateAvailableTypesAndIcons();
    uniqueNum++;
    view.setRegistered(true);
    view.setWasRegistered(true);
    manager.getManagerTree().repaint();
    pounamu.displayMessage(panel.getHandlerName() + " has been registed!");
  }

  /*public void doRegisterVisualHandler(DefaultMutableTreeNode node){
      
    PounamuView view = getView(node);
    HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
    if(panel.isValid() == false){
      pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
      return;
    }
    panel.save();
    panel.saveJavaCode(uniqueNum);
    Compile compiler = new Compile(getLocation()+""+fileSeparator+"visualhandlers"+fileSeparator+""+panel.getHandlerName()+uniqueNum+".java", PounamuToolProject.this);
    compiler.run();
    if(compiler.getCompiled() == false){
      pounamu.displayMessage(panel.getHandlerName()+" got compile error, thus can not be registered!");
      return;
    }
    if(registeredVisualHandlers.containsKey(panel.getHandlerName())){
      registeredVisualHandlers.remove(panel.getHandlerName());
    }
    registerPounamuVisualHandler(panel.getHandlerName(), panel.getHandlerName()+uniqueNum);
    nodeAndRegisteredXMLStringMapping.put(manager.getSelectedNode(), view.getXMLRepresentation());
    updateAvailableTypesAndIcons();
    uniqueNum++;
    view.setRegistered(true);
    view.setWasRegistered(true);
    manager.getManagerTree().repaint();
    pounamu.displayMessage(panel.getHandlerName() + " has been registed!");
  }*/
 
 
  
  /**
   * init menu items fr an event triggering model handler node
   * @return the vector contains all of the menu items for an event triggering  model handler
   */
  public Vector initMenuItemsForModelEventHandlerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this event triggering model handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi =  new JMenuItem("register this event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterModelEventHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this Handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterModelEventHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    return menuItems;
  }
  
  /**
   * init menu items fr an event triggering model handler node
   * @return the vector contains all of the menu items for an event triggering  model handler
   */
  public Vector initMenuItemsForModelUserHandlerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this user triggering model handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi =  new JMenuItem("register this user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterModelUserHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister this Handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterModelUserHandler(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    return menuItems;
  }

  /**
   * init menu items fr an event triggering model handler node
   * @return the vector contains all of the menu items for an event triggering model handler
   */
  public Vector initToolIconsForModelEventHandlerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this event triggering model handler");
    jmi.setToolTipText("function: " + "rename this event triggering model handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this event triggering model handler");
    jmi.setToolTipText("function: "+ "register this event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterModelEventHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view java code");
    jmi.setToolTipText("function: "+ "view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: "+ "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this handler");
    jmi.setToolTipText("function: "+ "deregister this handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterModelEventHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }

  /**
   * init menu items fr an user triggering visual handler node
   * @return the vector contains all of the menu items for an user triggering visual handler
   */
  public Vector initToolIconsForVisualUserHandlerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this user triggering visual handler");
    jmi.setToolTipText("function: " + "rename this user triggering visual handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this user triggering visual handler");
    jmi.setToolTipText("function: "+ "register this user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterVisualUserHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view java code");
    jmi.setToolTipText("function: "+ "view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: "+ "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this handler");
    jmi.setToolTipText("function: "+ "deregister this handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterVisualUserHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }
  
  /**
   * init menu items fr an event triggering visual handler node
   * @return the vector contains all of the menu items for an event triggering visual handler
   */
  public Vector initToolIconsForVisualEventHandlerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this event triggering visual handler");
    jmi.setToolTipText("function: " + "rename this event triggering visual handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this event triggering visual handler");
    jmi.setToolTipText("function: "+ "register this event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterVisualEventHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view java code");
    jmi.setToolTipText("function: "+ "view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: "+ "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this handler");
    jmi.setToolTipText("function: "+ "deregister this handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterVisualEventHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }
  /**
   * init menu items fr an user triggering model handler node
   * @return the vector contains all of the menu items for an user triggering model handler
   */
  public Vector initToolIconsForModelUserHandlerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this user triggering model handler");
    jmi.setToolTipText("function: " + "rename this user triggering model handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this user triggering model handler");
    jmi.setToolTipText("function: "+ "register this user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterModelUserHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view java code");
    jmi.setToolTipText("function: "+ "view java code");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuJavaCodeViewingPanel javaView = new PounamuJavaCodeViewingPanel();
        javaView.setJavaCode(panel.getJavaCode(""));
        JDialog dialog = new JDialog(pounamu, "Java code for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(javaView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("view xml representation");
    jmi.setToolTipText("function: "+ "view xml representation");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        HandlerConfigurationPanel panel = (HandlerConfigurationPanel)view.getDisplayPanel();
        if(panel.isValid() == false){
          pounamu.displayMessage(panel.getHandlerName() + " has not choose what event it will response to!");
          //pounamu.displayMessage(panel.getHandlerName() + " can not been registered!");
          return;
        }
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+panel.getHandlerName());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister this handler");
    jmi.setToolTipText("function: "+ "deregister this handler");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doDeregisterModelUserHandler(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    return toolIcons;
  }
  /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
  /*public Vector initMenuItemsForModelHandlerDefinerNode(){

    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }*/

  public Vector initMenuItemsForModelEventHandlerDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelEventHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelEventHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all event triggering model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelEventHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public void doCreatNewModelEventHandler(){
    String name = "ModelEventHandler" + modelEventHandlerCount;
    while(registeredModelEventHandlers.containsKey(name)){
      modelEventHandlerCount++;
      name = "ModelEventHandler" + modelEventHandlerCount;
    }
    modelEventHandlerCount++;
      PounamuView view = new PounamuView("model_event_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "modeleventhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelEventHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelEventHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedModelHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      manager.setSelectedNode(dmtn);
      pounamu.validate();
      pounamu.displayMessage("the new event triggering model handler named " + name + " is being configured!");
      doRegisterModelEventHandler(dmtn);
  } 
  
  public void doOpenExistedModelEventHandler(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String name = inputFile.getName();
    if(!name.endsWith(".xml")){
      pounamu.displayMessage("The handler you chose is not a proper handler file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    name = name.substring(0, name.indexOf("."));
    if(registeredModelEventHandlers.containsKey(name)){
      pounamu.displayMessage("A handler with the same name is showing. Please try another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("model_event_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "modeleventhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelEventHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelEventHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.displayMessage("the event triggering model handler named " + name + " is opened!");
    doRegisterModelEventHandler(dmtn);
  } 
  public void doCloseAllModelEventHandlers(DefaultMutableTreeNode dmtn){} 
  public void doCreatNewModelUserHandler(){
    String name = "ModelUserHandler" + modelUserHandlerCount;
    while(registeredModelUserHandlers.containsKey(name)){
      modelUserHandlerCount++;
      name = "ModelUserHandler" + modelUserHandlerCount;
    }
    modelUserHandlerCount++;
      PounamuView view = new PounamuView("model_user_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "modeluserhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelUserHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelUserHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedModelHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new user triggering model handler named " + name + " is being configured!");
      doRegisterModelUserHandler(dmtn);
  } 
  
  public void doOpenExistedModelUserHandler(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String name = inputFile.getName();
    if(!name.endsWith(".xml")){
      pounamu.displayMessage("The handler you chose is not a proper handler file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    name = name.substring(0, name.indexOf("."));
    if(registeredModelUserHandlers.containsKey(name)){
      pounamu.displayMessage("A handler with the same name is showing. Please try another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("model_user_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "modeluserhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelUserHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelUserHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.displayMessage("the user triggering model handler named " + name + " is opened!");
    doRegisterModelUserHandler(dmtn);
  } 
  public void doCloseAllModelUserHandlers(DefaultMutableTreeNode dmtn){} 
  public void doCreatNewVisualEventHandler(){
    String name = "VisualEventHandler" + visualEventHandlerCount;
    while(registeredModelUserHandlers.containsKey(name)){
      visualEventHandlerCount++;
      name = "VisualEventHandler" + visualEventHandlerCount;
    }
    visualEventHandlerCount++;
      PounamuView view = new PounamuView("visual_event_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "visualeventhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualEventHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualEventHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedModelHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new event triggering visual handler named " + name + " is being configured!");
      doRegisterVisualEventHandler(dmtn);
  } 
  public void doOpenExistedVisualEventHandler(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String name = inputFile.getName();
    if(!name.endsWith(".xml")){
      pounamu.displayMessage("The handler you chose is not a proper handler file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    name = name.substring(0, name.indexOf("."));
    if(registeredVisualEventHandlers.containsKey(name)){
      pounamu.displayMessage("A handler with the same name is showing. Please try another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("visual_event_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "visualeventhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualEventHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualEventHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.displayMessage("the event triggering visual handler named " + name + " is opened!");
    doRegisterVisualEventHandler(dmtn);
  } 
  public void doCloseAllVisualEventHandlers(DefaultMutableTreeNode dmtn){} 
  public void doCreatNewVisualUserHandler(){
    String name = "VisualUserHandler" + visualUserHandlerCount;
    while(registeredModelUserHandlers.containsKey(name)){
      visualUserHandlerCount++;
      name = "VisualUserHandler" + visualUserHandlerCount;
    }
    visualUserHandlerCount++;
      PounamuView view = new PounamuView("visual_user_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "visualuserhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualUserHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualUserHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedModelHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new user triggering visual handler named " + name + " is being configured!");
      doRegisterVisualUserHandler(dmtn);
  } 
  public void doOpenExistedVisualUserHandler(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String name = inputFile.getName();
    if(!name.endsWith(".xml")){
      pounamu.displayMessage("The handler you chose is not a proper handler file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    name = name.substring(0, name.indexOf("."));
    if(registeredVisualUserHandlers.containsKey(name)){
      pounamu.displayMessage("A handler with the same name is showing. Please try another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("model_user_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "visualuserhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualUserHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualUserHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.displayMessage("the user triggering visual handler named " + name + " is opened!");
    doRegisterVisualUserHandler(dmtn);
  } 
  public void doCloseAllVisualUserHandlers(DefaultMutableTreeNode dmtn){} 
  
  public Vector initMenuItemsForModelUserHandlerDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelUserHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelUserHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all user triggering model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelUserHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public Vector initMenuItemsForVisualUserHandlerDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualUserHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualUserHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all user triggering visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualUserHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public Vector initMenuItemsForVisualEventHandlerDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualEventHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualEventHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all event triggering visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualEventHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public Vector initToolIconsForModelEventHandlerDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new event triggering model handler");
    jmi.setToolTipText("function: "+"creat a new event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelEventHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed event triggering model handler");
    jmi.setToolTipText("function: "+"open an existed event triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelEventHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all event triggering model handlers");
    jmi.setToolTipText("function: "+"deregister all event triggering model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelEventHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }
  public Vector initToolIconsForModelUserHandlerDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new user triggering model handler");
    jmi.setToolTipText("function: "+"creat a new user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelUserHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed user triggering model handler");
    jmi.setToolTipText("function: "+"open an existed user triggering model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelUserHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all user triggering model handlers");
    jmi.setToolTipText("function: "+"deregister all user triggering model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelUserHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }
  public Vector initToolIconsForVisualEventHandlerDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new event triggering visual handler");
    jmi.setToolTipText("function: "+"creat a new event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualEventHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed event triggering visual handler");
    jmi.setToolTipText("function: "+"open an existed event triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualEventHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all event triggering visual handlers");
    jmi.setToolTipText("function: "+"deregister all event triggering visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualEventHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }
  public Vector initToolIconsForVisualUserHandlerDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new user triggering visual handler");
    jmi.setToolTipText("function: "+"creat a new user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualUserHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed user triggering visual handler");
    jmi.setToolTipText("function: "+"open an existed user triggering visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualUserHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all user triggering visual handlers");
    jmi.setToolTipText("function: "+"deregister all user triggering visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualUserHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }
  /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
  /*public Vector initToolIconsForModelHandlerDefinerNode(){

    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new model handler");
    jmi.setToolTipText("function: "+ "Creat a new model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewModelHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed model handler");
    jmi.setToolTipText("function: "+ "open an existed model handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedModelHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all model handlers");
    jmi.setToolTipText("function: "+ "deregister all model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllModelHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }*/
 
   /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
  /*public Vector initMenuItemsForSpecialHandlerDefinerNode(){

    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new special handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewSpecialHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed special handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedSpecialHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all special handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllSpecialHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }*/
  
   /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
  /*public Vector initToolIconsForSpecialHandlerDefinerNode(){

    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new special handler");
    jmi.setToolTipText("function: "+"creat a new special handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewSpecialHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed special handler");
    jmi.setToolTipText("function: "+"open an existed special handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedSpecialHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all special handlers");
    jmi.setToolTipText("function: "+"deregister all special handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllSpecialHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }*/

  /*public void doCreatNewSpecialHandler(){
    String name = "SpecialHandler" + specialHandlerCount;
    while(registeredSpecialHandlers.containsKey(name)){
      specialHandlerCount++;
      name = "SpecialHandler" + specialHandlerCount;
    }
    specialHandlerCount++;
      PounamuView view = new PounamuView("special_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "specialhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForSpecialHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForSpecialHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedVisualHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      manager.setSelectedNode(dmtn);
      pounamu.validate();
      pounamu.displayMessage("the new special handler named " + name + " is being configured!");
      doRegisterSpecialHandler(dmtn);
  }
  public void doOpenExistedSpecialHandler(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+""+fileSeparator+"specialhandlers"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String name = inputFile.getName();
    if(!name.endsWith(".xml")){
      pounamu.displayMessage("The handler you chose is not a proper handler file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    name = name.substring(0, name.indexOf("."));
    if(registeredSpecialHandlers.containsKey(name)){
      pounamu.displayMessage("A handler with the same name is showing. Please try another file!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("special_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "specialhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForSpecialHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForSpecialHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    openedSpecialHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.displayMessage("the special handler named " + name + " is opened!");
    doRegisterSpecialHandler(dmtn);
  }*/
  /*public void doCloseAllSpecialHandlers(DefaultMutableTreeNode selectedNode){
  
  }*/
  
  /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
  /*public Vector initMenuItemsForVisualHandlerDefinerNode(){

    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("creat a new visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualHandler();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualHandler();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualHandlers(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }*/

   /**
   * init menu items fr the handler definer node
   * @return the vector contains all of the menu items for the handler definer
   */
 /* public Vector initToolIconsForVisualHandlerDefinerNode(){

    Vector toolIcons = new Vector();
    JButton jmi = new JButton("creat a new visual handler");
    jmi.setToolTipText("function: "+"creat a new visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewVisualHandler();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed visual handler");
    jmi.setToolTipText("function: "+"open an existed visual handler");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedVisualHandler();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all visual handlers");
    jmi.setToolTipText("function: "+"deregister all visual handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllVisualHandlers(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }*/



  /**
   * do create a new model handler
   */
  /*public void doCreatNewModelHandler(){
    String name = "ModelHandler" + modelHandlerCount;
    while(registeredModelHandlers.containsKey(name)){
      modelHandlerCount++;
      name = "ModelHandler" + modelHandlerCount;
    }
    modelHandlerCount++;
      PounamuView view = new PounamuView("model_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "modelhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedModelHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new model handler named " + name + " is being configured!");
      doRegisterModelHandler(dmtn);
  }*/

  /**
   * do create a new visual handler
   */
  /*public void doCreatNewVisualHandler(){
    String name = "VisualHandler" + visualHandlerCount;
    while(registeredVisualHandlers.containsKey(name)){
      visualHandlerCount++;
      name = "VisualHandler" + visualHandlerCount;
    }
    visualHandlerCount++;
      PounamuView view = new PounamuView("visual_handlers", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      HandlerConfigurationPanel hcp = new HandlerConfigurationPanel(this, name, "visualhandler");
      view.setDisplayPane(hcp);
      tab.addTab(name, hcp);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualHandlerNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualHandlerNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(hcp, dmtn);
      //openedVisualHandlerNames.add(name);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new visual handler named " + name + " is being configured!");
      doRegisterVisualHandler(dmtn);
  }*/

  /**
   * open an existed model handler secified by its name
   * @param name the name of the model handler
   */
  public void doOpenExistedModelEventHandler(String name){
    File inputFile = new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+name+".xml");
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("model_event_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "modeleventhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelEventHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelEventHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelEventHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
  }

   public void doOpenExistedModelUserHandler(String name){
    File inputFile = new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"modelhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+name+".xml");
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("model_user_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "modeluserhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelUserHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForModelUserHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedModelEventHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
  }
   /**
   * open an existed visual handler secified by its name
   * @param name the name of the visual handler
   */
  public void doOpenExistedVisualEventHandler(String name){
    File inputFile = new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"eventtriggeringhandlers"+fileSeparator+""+name+".xml");
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("visual_event_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "visualeventhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //  dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualEventHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualEventHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedVisualEventHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
  }
  
  public void doOpenExistedVisualUserHandler(String name){
    File inputFile = new File(getLocation()+fileSeparator+"handlers"+fileSeparator+"visualhandlers"+fileSeparator+"usertriggeringhandlers"+fileSeparator+""+name+".xml");
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    PounamuView view = new PounamuView("visual_user_handlers", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    HandlerConfigurationPanel pp = new HandlerConfigurationPanel(this, name, "visualuserhandler");
    pp.restoreAHandlerFromXML(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    tab.setSelectedComponent(pp);
    view.setDisplayPane(pp);
    //  dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForVisualUserHandlerNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForVisualUserHandlerNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    //openedVisualEventHandlerNames.add(name);
    pounamu.validate();
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
  }
  

   /**
   * close all model handler definer windows
   */
  public void doCloseAllModelHandlers(DefaultMutableTreeNode dmtn){
    /*Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      doDeregisterModelHandler(temp);
    }*/
  }

   /**
   * close all visual handler definer windows
   */
  public void doCloseAllVisualHandlers(DefaultMutableTreeNode dmtn){
    /*Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      doDeregisterVisualHandler(temp);
    }*/
  }


  /**
   * init menu items fr the metamodel definer definer node
   * @return the vector contains all of the menu items for the metamodel definer
   */
  public Vector initMenuItemsForMetaModelDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("create a new meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewMetaModelView();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an existed meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedMetaModelView();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);    
    jmi = new JMenuItem("deregister all meta model views");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllMetaModelViews(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        RegisterModelHandlerDialog rmhd = new RegisterModelHandlerDialog(PounamuToolProject.this);
        rmhd.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("configure meta model definer");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doConfigureMetaModelDefiner();
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items fr the metamodel definer definer node
   * @return the vector contains all of the menu items for the metamodel definer
   */
  public Vector initToolIconsForMetaModelDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("create a new meta model view");
    jmi.setToolTipText("function: "+"create a new meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewMetaModelView();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an existed meta model view");
    jmi.setToolTipText("function: "+"Open an existed meta model view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedMetaModelView();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all meta model views");
    jmi.setToolTipText("function: "+"deregister all meta model views");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllMetaModelViews(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register model handlers");
    jmi.setToolTipText("function: "+"register model handlers");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        RegisterModelHandlerDialog rmhd = new RegisterModelHandlerDialog(PounamuToolProject.this);
        rmhd.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("configure meta model definer");
    jmi.setToolTipText("function: "+"configure meta model definer");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doConfigureMetaModelDefiner();
      }
    });
    toolIcons.add(jmi);
    
    return toolIcons;
  }

  /**
   * to configure meta model definer
   */
  public void doConfigureMetaModelDefiner(){
    ConfigureMetaModelDefiner cmmd = new ConfigureMetaModelDefiner(this);
    cmmd.setVisible(true);
  }

  /**
   * create a new metamodel view
   */
  public void doCreatNewMetaModelView(){
    String name = "meta model view "+metaModelViewCount;
    while(registeredMetaModelViews.contains(name)){
      metaModelViewCount++;
      name = "meta model view "+metaModelViewCount;
    }
    metaModelViewCount++;
      PounamuView view = new PounamuView("metamodelview", name, this, pounamu);
      //registerMetaModelView(name);
      ModellerPanel mp = new ModellerPanel(this, "metamodelview", view);
      //DefaultMutableTreeNode dmtn = manager.addObject(name);
      DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      view.setDisplayPane(mp);
      manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
      nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
      nodeAndViewMapping.put(dmtn, view);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForMetaModelViewNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForMetaModelViewNode());
      iconAndNodeMapping.put(mp, dmtn);
      getViewsTab(manager.getSelectedNode()).addTab(name, mp);
      getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
      viewTabAndNodeMapping.put(mp, dmtn);
      //openedMetaModelViews.put(name, view);
      /////////////////////////////////////////////////////////
      DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity type");
      manager.getNodeAndItsValueMapping().put(dm, dm.getUserObject());
      manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
      nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
      nodeAndViewMapping.put(dm, view);
      nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityTypeNode());
      nodeAndToolButtonsMapping.put(dm, initToolIconsForEntityTypeNode());
      dmtn.add(dm);
      dm = new DefaultMutableTreeNode("association type");
      manager.getNodeAndItsValueMapping().put(dm, dm.getUserObject());
      manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
      nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
      nodeAndViewMapping.put(dm, view);
      nodeAndMenuItemsMapping.put(dm, initMenuItemsForAssociationTypeNode());
      nodeAndToolButtonsMapping.put(dm, initToolIconsForAssociationTypeNode());
      dmtn.add(dm);
      manager.addTreeNode(dmtn);
      TreePath tp = new TreePath(dmtn.getPath());
      managerTree.setSelectionPath(tp);
      doRegisterMetaModelView(dmtn);
      pounamu.validate();
    
  }

  /**
   * open an existed meta model view
   */
  public void doOpenExistedMetaModelView(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+fileSeparator+"metamodel"+fileSeparator+"metamodelviews"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open this view");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String fileName = inputFile.getName();
    if(!(fileName.endsWith(".xml"))){
      pounamu.displayMessage("The file you chose is not a proper view type file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    String name = fileName.substring(0, fileName.indexOf("."));
    if(registeredMetaModelViews.contains(name)){
      pounamu.displayMessage("A view with the same name already existed. Please choose another file of view!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    PounamuView view = new PounamuView("metamodelview", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    ModellerPanel mp = new ModellerPanel(this, "metamodelview", view);
    DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    //DefaultMutableTreeNode dmtn = manager.addObject(name);
    view.setDisplayPane(mp);
    manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dmtn, view);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForMetaModelViewNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForMetaModelViewNode());
    iconAndNodeMapping.put(mp, dmtn);
    getViewsTab(manager.getSelectedNode()).addTab(name, mp);
    getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
    viewTabAndNodeMapping.put(mp, dmtn);
    //openedMetaModelViews.put(name, view);
    /////////////////////////////////////////////////////////////
    DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity type");
    manager.getNodeAndItsValueMapping().put(dm, dm.getUserObject());
    manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dm, view);
    nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityTypeNode());
    nodeAndToolButtonsMapping.put(dm, initToolIconsForEntityTypeNode());
    dmtn.add(dm);
    DefaultMutableTreeNode dn = new DefaultMutableTreeNode("association type");
    manager.getNodeAndItsValueMapping().put(dn, dn.getUserObject());
    manager.getNodeAndProjectMapping().put(dn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dn, view);
    nodeAndMenuItemsMapping.put(dn, initMenuItemsForAssociationTypeNode());
    nodeAndToolButtonsMapping.put(dn, initToolIconsForAssociationTypeNode());
    dmtn.add(dn);
    /////////////////////////////////////////////////////////////
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.validate();
    RestoreMetaModelViewFromXML restore = new RestoreMetaModelViewFromXML(lxf.getDocument(), mp, dm, dn);
    restore.restore();
    //TreePath tp = new TreePath(dmtn.getPath());
    //managerTree.setSelectionPath(tp);
    doRegisterMetaModelView(dmtn);
  }

  /**
   * open an existed meta model view
   * @param name the name of the view to be opened
   */
  public void doOpenExistedMetaModelView(String name){
    File inputFile = new File(getLocation()+fileSeparator+"metamodel"+fileSeparator+"metamodelviews"+fileSeparator+name+".xml");
    PounamuView view = new PounamuView("metamodelview", name, this, pounamu);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    ModellerPanel mp = new ModellerPanel(this, "metamodelview", view);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 0");
    //DefaultMutableTreeNode dmtn = manager.addObject(name);
    DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    view.setDisplayPane(mp);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 1");
    manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dmtn, view);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 2");
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForMetaModelViewNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForMetaModelViewNode());
    iconAndNodeMapping.put(mp, dmtn);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 3");
    getViewsTab(manager.getSelectedNode()).addTab(name, mp);
    getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
    viewTabAndNodeMapping.put(mp, dmtn);
    openedMetaModelViews.put(name, view);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 4");
    /////////////////////////////////////////////////////////////
    DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity type");
    manager.getNodeAndItsValueMapping().put(dm, dm.getUserObject());
    manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dm, view);
    nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityTypeNode());
    nodeAndToolButtonsMapping.put(dm, initToolIconsForEntityTypeNode());
    dmtn.add(dm);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 5");
    DefaultMutableTreeNode dn = new DefaultMutableTreeNode("association type");
    manager.getNodeAndItsValueMapping().put(dn, dn.getUserObject());
    manager.getNodeAndProjectMapping().put(dn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dn, view);
    nodeAndMenuItemsMapping.put(dn, initMenuItemsForAssociationTypeNode());
    nodeAndToolButtonsMapping.put(dn, initToolIconsForAssociationTypeNode());
    dmtn.add(dn);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 6");
    /////////////////////////////////////////////////////////////
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.validate();
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 7");
    RestoreMetaModelViewFromXML restore = new RestoreMetaModelViewFromXML(lxf.getDocument(), mp, dm, dn);
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 8");
    restore.restore();
    //System.out.println("in class pounamutoolproject, doOpenExistedMetaModelView visited 9");
    doRegisterMetaModelView(dmtn);
  }

  /**
   * close all metamodel definer windows...
   */
  public void doCloseAllMetaModelViews(DefaultMutableTreeNode dmtn){
    Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      doDeregisterMetaModelView(temp);
    }
  }

  /**
   * init menu items fr the view type definer node
   * @return the vector contains all of the menu items for the view type definer
   */
  public Vector initMenuItemsForViewTypeDefinerNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("define a new view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewViewType();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("open an defined view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedViewType();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("deregister all view types");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllViewTypes(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }

  /**
   * init menu items fr the view type definer node
   * @return the vector contains all of the menu items for the view type definer
   */
  public Vector initToolIconsForViewTypeDefinerNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("define a new view type");
    jmi.setToolTipText("function: "+"define a new view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCreatNewViewType();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("open an defined view type");
    jmi.setToolTipText("function: "+"Open an defined view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doOpenExistedViewType();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("deregister all view types");
    jmi.setToolTipText("function: "+"deregister all view types");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doCloseAllViewTypes(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }

  /**
   * Create a new view type
   */
  public void doCreatNewViewType(){
    String name = "view type " + viewTypeViewCount;
    while(getRegisteredViewTypes().contains(name)){
      viewTypeViewCount++;
      name = "view type " + viewTypeViewCount;
    }
    viewTypeViewCount++;
      PounamuView view = new PounamuView("viewtypedefiner", name, this, pounamu);
      DefaultMutableTreeNode dmtn = manager.getSelectedNode();
      PounamuTabbedPane tab = getViewsTab(dmtn);
      ViewTypeDefinerPanel pp = new ViewTypeDefinerPanel(name, this);
      if(getRegisteredViewTypes().contains(name)){
        pounamu.displayMessage("a view type with the name you input existed already! operation ignored!");
        return;
      }
      view.setDisplayPane(pp);
      tab.addTab(name, pp);
      //dmtn = manager.addObject(name);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
      manager.getNodeAndProjectMapping().put(dmtn, this);
      nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForViewTypeNode());
      nodeAndToolButtonsMapping.put(dmtn, initToolIconsForViewTypeNode());
      nodeAndViewsTabMapping.put(dmtn, tab);
      nodeAndViewMapping.put(dmtn, view);
      viewTabAndNodeMapping.put(pp, dmtn);
      manager.addTreeNode(dmtn);
      manager.setSelectedNode(dmtn);
      //TreePath tp = new TreePath(dmtn.getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      pounamu.validate();
      pounamu.displayMessage("the new view type named " + name + " is being configured!");
      doRegisterViewType(dmtn);
  }

  /**
   * init menu items fr the view type node
   * @return the vector contains all of the menu items for this view type
   */
  public Vector initMenuItemsForViewTypeNode(){
    Vector menuItems = new Vector();
    JMenuItem jmi = new JMenuItem("rename this view type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("register this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterViewType(manager.getSelectedNode());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    jmi = new JMenuItem("view xml file for this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);
    /*jmi = new JMenuItem("save this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel();
        panel.save();
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("save as this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doRegisterViewType();
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    jmi = new JMenuItem("deregister this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)manager.getSelectedNode();
        doDeregisterViewType(node, "delete", (String)node.getUserObject());
      }
    });
    menuItems.add(jmi);
    return menuItems;
  }
  
  public void changeIconPositionInZCoordinate(String type){
    PounamuMetaModelElement pmme = null;
    PounamuView view = getView(manager.getSelectedNode());
    Object icon = getIcon(manager.getSelectedNode());
    if(icon instanceof PounamuPanel){
      PounamuShape shape = (PounamuShape)((PounamuPanel)icon).getPounamuShape();
      if(type.equals("front"))
        shape.upToTop();
      else if(type.equals("back"))
        shape.downToBottom();
      else if(type.equals("forward"))
        shape.upOneLevel();
      else if(type.equals("backward"))
        shape.downOneLevel();
    }
    else{
      PounamuConnector connector = (PounamuConnector)icon;
      if(type.equals("front"))
        connector.upToTop();
      else if(type.equals("back"))
        connector.downToBottom();
      else if(type.equals("forward"))
        connector.upOneLevel();
      else if(type.equals("backward"))
        connector.downOneLevel();
    }
  }

  /**
   * init menu items fr the view type node
   * @return the vector contains all of the menu items for this view type
   */
  public Vector initToolIconsForViewTypeNode(){
    Vector toolIcons = new Vector();
    JButton jmi = new JButton("rename this view type");
    jmi.setToolTipText("function: " + "rename this view type");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
       manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("register this view type");
    jmi.setToolTipText("function: "+"register this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doRegisterViewType(manager.getSelectedNode());
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    jmi = new JButton("view xml file for this view type");
    jmi.setToolTipText("function: "+"view xml file for this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel();
        PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
        xmlView.setXML(panel.getXML());
        JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
        dialog.setBounds(150, 100, 600, 600);
        dialog.getContentPane().add(new JScrollPane(xmlView));
        dialog.validate();
        dialog.setVisible(true);
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);
    /*jmi = new JButton("save this view type");
    jmi.setToolTipText("function: "+"save this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel();
        panel.save();
      }
    });
    toolIcons.add(jmi);
    jmi = new JButton("save as this view type");
    jmi.setToolTipText("function: "+"save as this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        //doRegisterViewType();
      }
    });
    toolIcons.add(jmi);
    toolIcons.add(null);*/
    jmi = new JButton("deregister this view type");
    jmi.setToolTipText("function: "+"deregister this view type");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)manager.getSelectedNode();
        doDeregisterViewType(node, "delete", (String)node.getUserObject());
      }
    });
    toolIcons.add(jmi);
    return toolIcons;
  }

  /**
   * register a defined view type
   */
  public void doRegisterViewType(DefaultMutableTreeNode dmtn){
    PounamuView view = (PounamuView)nodeAndViewMapping.get(dmtn);
    ViewTypeDefinerPanel vtdp = (ViewTypeDefinerPanel)view.getDisplayPanel();
    vtdp.save();
    vtdp.registerViewType(this);
    nodeAndRegisteredXMLStringMapping.put(dmtn, view.getXMLRepresentation());
    view.setRegistered(true);
    view.setWasRegistered(true);
    manager.getManagerTree().repaint();
  }
  
  /**
   * register a defined view type
   */
  public void doDeregisterViewType(DefaultMutableTreeNode dmtn, String type, String name){
    
    //String name = (String)dmtn.getUserObject();
    getRegisteredViewTypes().remove(name);
    getViewTypeAndAllowedVisualEventHandlersMapping().remove(name);
    getViewTypeAndAllowedVisualUserHandlersMapping().remove(name);
    getViewTypeAndAllowedEntityTypesMapping().remove(name);
    getViewTypeAndAllowedAssociationTypesMapping().remove(name);
    getViewTypeAndEntityTypeAndShapeMapping().remove(name);
    getViewTypeAndAssociationTypeAndConnectorMapping().remove(name);
    Enumeration em = getViewTypeAndPropertyMapping().keys();
    while(em.hasMoreElements()){
      String key = (String)em.nextElement();
      if(key.startsWith(name+":"))
        getViewTypeAndPropertyMapping().remove(key);
    }
    nodeAndRegisteredXMLStringMapping.remove(dmtn);   
    if(type.equals("delete")){
      PounamuTabbedPane tab = (PounamuTabbedPane)nodeAndViewsTabMapping.get(dmtn);
      PounamuView view = (PounamuView)nodeAndViewMapping.get(dmtn);
      ViewTypeDefinerPanel panel = (ViewTypeDefinerPanel)view.getDisplayPanel(); 
      tab.remove(panel);
      nodeAndMenuItemsMapping.remove(dmtn);
      nodeAndToolButtonsMapping.remove(dmtn);
      nodeAndViewsTabMapping.remove(dmtn);
      nodeAndViewMapping.remove(dmtn);
      viewTabAndNodeMapping.remove(panel);
      pounamu.setPropertyPanel(null);
      manager.getNodeAndItsValueMapping().remove(dmtn);
      manager.getNodeAndProjectMapping().remove(dmtn);
      manager.removeTreeNode(dmtn);
    }
    String fullPath = "\""+getLocation()+fileSeparator+"viewtypes"+fileSeparator+name+".xml\"";
    //System.out.println("fullPath in class toolProject is " + fullPath);
    MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
    mfs.run();
  }


  /**
   * close a view type definer window
   */
  //public void doCloseViewType(){}
  /**
   * open existed view type
   */
  public void doOpenExistedViewType(){
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+""+fileSeparator+"viewtypes"));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String fileName = inputFile.getName();
    if(!fileName.endsWith(".xml")){
      pounamu.displayMessage("The file you chose is not a proper view type file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    String name = fileName.substring(0, fileName.indexOf("."));
    if(openedViewTypeDefinerWindows.containsKey(name)){
      pounamu.displayMessage("A view type with the same name already existed. Please choose another file of view type!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    PounamuView view = new PounamuView("viewtypedefiner", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    ViewTypeDefinerPanel pp = new ViewTypeDefinerPanel(name, this);
    openedViewTypeDefinerWindows.put(name, pp);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    pp.restore(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    //dmtn = manager.addObject(name);
    dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForViewTypeNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForViewTypeNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    manager.addTreeNode(dmtn);
    manager.setSelectedNode(dmtn);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    pounamu.validate();
    pounamu.displayMessage("the view type named " + name + " is being configured!");
  } 


   /**
    * do open an existed view type
    * @param name the name of the view type
    */
   public void doOpenExistedViewType(String name){
    File inputFile = new File(getLocation()+""+fileSeparator+"viewtypes"+fileSeparator+""+name+".xml");
    PounamuView view = new PounamuView("viewtypedefiner", name, this, pounamu);
    DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    PounamuTabbedPane tab = getViewsTab(dmtn);
    ViewTypeDefinerPanel pp = new ViewTypeDefinerPanel(name, this);
    openedViewTypeDefinerWindows.put(name, pp);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    pp.restore(lxf.getDocument());
    view.setDisplayPane(pp);
    tab.addTab(name, pp);
    //dmtn = manager.addObject(name);
      dmtn = new DefaultMutableTreeNode(name);
      manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
    manager.getNodeAndProjectMapping().put(dmtn, this);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForViewTypeNode());
    nodeAndToolButtonsMapping.put(dmtn, initToolIconsForViewTypeNode());
    nodeAndViewsTabMapping.put(dmtn, tab);
    nodeAndViewMapping.put(dmtn, view);
    viewTabAndNodeMapping.put(pp, dmtn);
    manager.addTreeNode(dmtn);
    manager.setSelectedNode(dmtn);
    //TreePath tp = new TreePath(dmtn.getPath());
    //manager.getManagerTree().setSelectionPath(tp);
    pounamu.validate();
    //pounamu.displayMessage("the view type named " + name + " is being configured!");
  }

  /**
   * not applicable
   */
  public void doCloseAllViewTypes(DefaultMutableTreeNode dmtn){
    Enumeration en = dmtn.children();
    Vector v = new Vector();
    while(en.hasMoreElements()){
      v.add((DefaultMutableTreeNode)en.nextElement());
    }
    for(int i = 0; i < v.size(); i++){
      DefaultMutableTreeNode temp = (DefaultMutableTreeNode)v.get(i); 
      //System.out.println("in class pounamuToolProject, en.nextElement() is " + temp.getUserObject());
      //DefaultMutableTreeNode node = (DefaultMutableTreeNode)manager.getSelectedNode();
      doDeregisterViewType(temp, "delete", (String)temp.getUserObject());
      //doDeregisterViewType(temp, "delete");
    }
  }
  /**
   * restore a project from its xml document
   * @param xmlDocument the xml document which contains the project information
   */
  /*public void setDocument(Document xmlDocument){
    this.document = document;
    Element root = xmlDocument.getDocumentElement();
    NodeList nl = root.getElementsByTagName("location");
    Node n = nl.item(0);
    setLocation(n.getFirstChild().getNodeValue());
    nl = root.getElementsByTagName("description");
    n = nl.item(0);
    setDescription(n.getFirstChild().getNodeValue());
    nl = root.getElementsByTagName("registeredviewtype");
    if(nl!=null)
      for(int i = 0; i < nl.getLength(); i++){
        n = nl.item(i);
        restoreRegisteredViewType(n.getFirstChild().getNodeValue());
      }
    nl = root.getElementsByTagName("registeredshape");
    if(nl!=null)
      for(int i = 0; i < nl.getLength(); i++){
        n = nl.item(i);
        restoreRegisteredShape(n.getFirstChild().getNodeValue());
      }
    nl = root.getElementsByTagName("registeredconnector");
    if(nl!=null)
      for(int i = 0; i < nl.getLength(); i++){
        n = nl.item(i);
        restoreRegisteredConnector(n.getFirstChild().getNodeValue());
      }
    nl = root.getElementsByTagName("registeredhandler");
    if(nl!=null)
      for(int i = 0; i < nl.getLength(); i++){
        n = nl.item(i);
        restoreRegisteredHandler(n.getFirstChild().getNodeValue());
      }
  }*/


  private void restoreRegisteredViewTypes(){
    NodeList nl = root.getElementsByTagName("registeredviewtype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      registeredViewTypes.add(s);
      manager.setSelectedNode(getViewTypeDefinerNode());
      //TreePath tp = new TreePath(getViewTypeDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedViewType(s);
    }
  }

  private void reloadRegisteredViewTypes(){
    NodeList nl = root.getElementsByTagName("registeredviewtype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredViewTypes.contains(s))
        return;
      registeredViewTypes.add(s);
      /*TreePath tp = new TreePath(getViewTypeDefinerNode().getPath());
      manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedViewType(s);*/
    }
  }

  private void restoreRegisteredMetaModelViews(){
    NodeList nl = root.getElementsByTagName("registeredmetamodelview");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      registeredMetaModelViews.add(s);
      manager.setSelectedNode(getMetaModelDefinerNode());
      //TreePath tp = new TreePath(getMetaModelDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedMetaModelView(s);
      //System.out.println("in class pounamutoolproject, here visited 1");
    }
  }

  private void reloadRegisteredMetaModelViews(){
    NodeList nl = root.getElementsByTagName("registeredmetamodelview");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredMetaModelViews.contains(s))
        return;
      registeredMetaModelViews.add(s);
      /*TreePath tp = new TreePath(getMetaModelDefinerNode().getPath());
      manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedMetaModelView(s);*/
    }
  }

  private void restoreRegisteredShapes(){
    NodeList nl = root.getElementsByTagName("registeredshape");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      registeredShapes.add(s);
      manager.setSelectedNode(getShapeCreatorNode());
      //TreePath tp = new TreePath(getShapeCreatorNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedShape(s);
    }
  }

  private void reloadRegisteredShapes(){
    NodeList nl = root.getElementsByTagName("registeredshape");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredShapes.contains(s))
        return;
      registeredShapes.add(s);
      /*TreePath tp = new TreePath(getShapeCreatorNode().getPath());
      manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedShape(s);*/
    }
  }

  private void restoreRegisteredConnectors(){
   NodeList nl = root.getElementsByTagName("registeredconnector");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      registeredConnectors.add(s);
      manager.setSelectedNode(getConnectorCreatorNode());
      //TreePath tp = new TreePath(getConnectorCreatorNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedConnector(s);
    }
  }

  private void reloadRegisteredConnectors(){
   NodeList nl = root.getElementsByTagName("registeredconnector");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredConnectors.contains(s))
        return;
      registeredConnectors.add(s);
      /*TreePath tp = new TreePath(getConnectorCreatorNode().getPath());
      manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedConnector(s);*/
    }
  }
 
  private void restoreRegisteredModelEventHandlers(){
    NodeList nl = root.getElementsByTagName("registeredmodeleventhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredModelEventHandlers.put(key, value);
      manager.setSelectedNode(getModelEventHandlerDefinerNode());
      //TreePath tp = new TreePath(getModelEventHandlerDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedModelEventHandler(key);
    }
  }
  
  private void restoreRegisteredModelUserHandlers(){
    NodeList nl = root.getElementsByTagName("registeredmodeluserhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredModelUserHandlers.put(key, value);
      manager.setSelectedNode(getModelUserHandlerDefinerNode());
      //TreePath tp = new TreePath(getModelUserHandlerDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedModelUserHandler(key);
    }
  }


  private void restoreRegisteredVisualEventHandlers(){
    NodeList nl = root.getElementsByTagName("registeredvisualeventhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredVisualEventHandlers.put(key, value);
      manager.setSelectedNode(getVisualEventHandlerDefinerNode());
      //TreePath tp = new TreePath(getVisualEventHandlerDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedVisualEventHandler(key);
    }
  }
  
  private void restoreRegisteredVisualUserHandlers(){
    NodeList nl = root.getElementsByTagName("registeredvisualuserhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredVisualUserHandlers.put(key, value);
      manager.setSelectedNode(getVisualUserHandlerDefinerNode());
      //TreePath tp = new TreePath(getVisualUserHandlerDefinerNode().getPath());
      //manager.getManagerTree().setSelectionPath(tp);
      doOpenExistedVisualUserHandler(key);
    }
  }

  private void reloadRegisteredModelEventHandlers(){
    NodeList nl = root.getElementsByTagName("registeredmodeleventhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredModelEventHandlers.put(key, value);       
    }
  }
  
  private void reloadRegisteredModelUserHandlers(){
    NodeList nl = root.getElementsByTagName("registeredmodeluserhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredModelUserHandlers.put(key, value);       
    }
  }

  private void reloadRegisteredVisualEventHandlers(){
    NodeList nl = root.getElementsByTagName("registeredvisualeventhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredVisualEventHandlers.put(key, value);       
    }
  }

  private void reloadRegisteredVisualUserHandlers(){
    NodeList nl = root.getElementsByTagName("registeredvisualuserhandler");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      registeredVisualUserHandlers.put(key, value);       
    }
  }


   private void restoreRegisteredAssociationTypes(){
    /*NodeList nl = root.getElementsByTagName("registeredassociationtype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredAssociationTypes.contains(s))
        return;
      registeredAssociationTypes.add(s);
    }*/
  }

   private void restoreRegisteredEntityTypes(){
    /*NodeList nl = root.getElementsByTagName("registeredentitytype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      String s = n.getFirstChild().getNodeValue();
      if(registeredEntityTypes.contains(s))
        return;
      registeredEntityTypes.add(s);
    }*/
  }

  /**
   * get the name of the project
   * @return the project name
   */
  public String getName(){
    return name;
  }

  /**
   * set the name of the project
   * @param name the project name
   */
  public void setName(String name){
    this.name = name;
  }

  /**
   * get the location where the project saved
   * @return the location of this project
   */
  public String getLocation(){
    return location;
  }

  /**
   * set the location of ths project
   * @param location the location to be set
   */
  public void setLocation(String location){
    this.location = location;
  }

  /**
   * get the desription of this project
   * @return the description of this project
   */
  public String getDescription(){
    return description;
  }

  /**
   * set the desription of this project
   * @param description the description of this project
   */
  public void setDescription(String description){
    this.description = description;
  }

  /**
   * register a xml file and name pair to this project
   * @param name the name of the xml file
   * @param file the xml file
   */
 /* public void registerXMLFile(String name, File file){
    xmlFileNameMapping.put(name, file);
  }*/

  /**
   * get the corresponding xml file
   * @param name the name of the xml file
   * @return the xml file
   */
 /* public File getXMLFile(String name){
    return (File)xmlFileNameMapping.get(name);
  }*/

  /**
   * get all registered shapes
   * @return the vector which holds all registered shape names
   */
  public Vector getRegisteredShapes(){
    return registeredShapes;
  }

  /**
   * rigister a pounamu shape to this project to be used later on
   * @param name the name of the shape to be registered
   */
  public void registerPounamuShape(String name){
    registeredShapes.add(name);
  }

  /**
   * remove a shape from this project
   * @param name the name of the shape
   */
  public void deregisterPounamuShape(String name){
    registeredShapes.removeElement(name);
  }

 /**
   * get all registered connectors
   * @return the vector which holds all registered connector names
   */
  public Vector getRegisteredConnectors(){
    return registeredConnectors;
  }

  /**
   * rigister a pounamu connector to this project to be used later on
   * @param name the name of the connector to be registered
   */
  public void registerPounamuConnector(String name){
    registeredConnectors.add(name);
  }

  /**
   * remove a connector from this project
   * @param name the name of the connector
   */
  public void deregisterPounamuConnector(String name){
    registeredConnectors.removeElement(name);
  }

  /**
   * get all registered model event handlers
   * @return the vector which holds all registered model event handler names
   */
  public Hashtable getRegisteredModelEventHandlers(){
    return registeredModelEventHandlers;
  }

  /**
   * get all registered model user handlers
   * @return the vector which holds all registered model user handler names
   */
  public Hashtable getRegisteredModelUserHandlers(){
    return registeredModelUserHandlers;
  }
  
  
  /**
   * get all registered visual user handlers
   * @return the vector which holds all registered visual user handler names
   */
  public Hashtable getRegisteredVisualUserHandlers(){
    return registeredVisualUserHandlers;
  }
  
  /**
   * get all registered visual event handlers
   * @return the vector which holds all registered visual event handler names
   */
  public Hashtable getRegisteredVisualEventHandlers(){
    return registeredVisualEventHandlers;
  }

 
   /**
   * rigister a pounamu model handler to this project to be used later on
   * @param name the name of the handler to be registered
   */
  public void registerModelEventHandler(String name, String encodedName){
    registeredModelEventHandlers.put(name, encodedName);
  }
  
  public void registerModelUserHandler(String name, String encodedName){
    registeredModelUserHandlers.put(name, encodedName);
  }

    /**
   * rigister a visual event handler to this project to be used later on
   * @param name the name of the handler to be registered
   */
  public void registerVisualEventHandler(String name, String encodedName){
    registeredVisualEventHandlers.put(name, encodedName);
  }
  
    /**
   * rigister a visual user handler to this project to be used later on
   * @param name the name of the handler to be registered
   */
  public void registerVisualUserHandler(String name, String encodedName){
    registeredVisualUserHandlers.put(name, encodedName);
  }

  /**
   * remove a model handler from this project
   * @param name the name of the model handler
   */
  public void deregisterModelEventHandler(String name){
    registeredModelEventHandlers.remove(name);
  }
  
  public void deregisterModelUserHandler(String name){
    registeredModelUserHandlers.remove(name);
  }

   /**
   * remove a visual handler from this project
   * @param name the name of the visual handler
   */
  public void deregisterVisualEventHandler(String name){
    registeredVisualEventHandlers.remove(name);
  }
  
  public void deregisterVisualUserHandler(String name){
    registeredVisualUserHandlers.remove(name);
  }



  /**
   * get registered view types
   * @return  the vector which contains sll registered view types
   */
  public Vector getRegisteredViewTypes(){
    return registeredViewTypes;
  }

  /**
   * register a view type
   * @param viewType the view type to be registered
   */
  /*public void registerViewType(String viewType){
    registeredViewTypes.add(viewType);
  }*/

  /**
   * deregister a view type
   * @param viewType the view type to be deregistered
   */
  public boolean deregisterViewType(String viewType){
    return registeredViewTypes.removeElement(viewType);
  }


  /**
   * get defines metamodel views
   * @return a vector contains the names of al defined metamodel views
   */
  public Vector getRegisteredMetaModelViews(){
    return registeredMetaModelViews;
  }

  /**
   * register a defined metamodel view
   * @param name the name of the view
   */
  public void registerMetaModelView(String name){
    registeredMetaModelViews.add(name);
  }

  /**
   * remove a defined metamodel view
   * @param name the name of the view
   * @return yes if removed successful
   */
  public boolean deregisterDefinedMetaModelViews(String name){
    return registeredMetaModelViews.removeElement(name);
  }

  /**
   * register an entity type
   * @param name the nam eof the entity type to be registered
   */
  /*public void registerEntityType(String name){
    if(registeredEntityTypes.contains(name)){
      pounamu.displayMessage(name + " has been registered to " + this.getName()+ " already");
      return;
    }
    registeredEntityTypes.add(name);
  }*/

  /**
   * get registered entity type
   * @return a vector of registere entity type
   */
  public Hashtable getRegisteredEntityTypeObjects(){
    return registeredEntityTypeObjects;
  }

  /**
   * deregister the specified entity type
   * @param associationType the name of the entity type to be deregistered
   * @return true if the name of the specified entity type has been removed
   */
  public void deregisterEntityType(String entityType){
    registeredEntityTypeObjects.remove(entityType);
  }

  /**
   * register an association type
   * @param name the nam eof the association type to be registered
   */
  /*public void registerAssociationType(String name){
    if(registeredAssociationTypes.contains(name)){
      pounamu.displayMessage(name + " has been registered to " + this.getName()+ " already");
      return;
    }
    registeredAssociationTypes.add(name);
  }*/

  /**
   * get registered association type
   * @return a vector of registere association type
   */
  public Hashtable getRegisteredAssociationTypeObjects(){
    return registeredAssociationTypeObjects;
  }

  /**
   * deregister the specified association type
   * @param associationType the name of the association type to be deregistered
   * @return true if the name of the specified association type has been removed
   */
  public void deregisterAssociationType(String associationType){
    registeredAssociationTypeObjects.remove(associationType);
  }


  /**
   * get the map between ID of entity object and entity object itself
   * @return a hahtable contains these maps
   */
  /*public Hashtable getIDAndEntityTypeObjectMapping(){
    return idAndEntityTypeObjectMapping;
  }*/

  /**
   * add new entity type object
   * @param name the name of this object
   * @param object the PounamuMetaModelElement object
   */
  /*public void addNewEntityTypeObject(String name, PounamuMetaModelElement object){
    //if(idAndEntityTypeObjectMapping.containsKey(name)){
      idAndEntityTypeObjectMapping.put(name, object);
    //}
  }*/

 /*public void removeEntityTypeObject(String name){
    idAndEntityTypeObjectMapping.remove(name);
  }*/

 /* public PounamuMetaModelElement getEntityTypeObject(String name){
    return (PounamuMetaModelElement)idAndEntityTypeObjectMapping.get(name);
  }*/

 /* public Enumeration getEntityTypeObjectIDs(){
    return idAndEntityTypeObjectMapping.keys();
  }

  public Hashtable getIDAndAssociationTypeObjectMapping(){
    return idAndAssociationTypeObjectMapping;
  }*/

 /* public void addNewAssociationTypeObject(String name, PounamuMetaModelElement object){
    //if(idAndEntityTypeObjectMapping.containsKey(name)){
      idAndAssociationTypeObjectMapping.put(name, object);
    //}
  }*/

  /*public void removeAssociationTypeObject(String name){
    idAndAssociationTypeObjectMapping.remove(name);
  }*/

  /*public PounamuMetaModelElement getAssociationTypeObject(String name){
    return (PounamuMetaModelElement)idAndAssociationTypeObjectMapping.get(name);
  }*/

  /*public Enumeration getAssociationTypeObjectIDs(){
    return idAndAssociationTypeObjectMapping.keys();
  }

  public Hashtable getIDAndEntityObjectMapping(){
    return idAndEntityObjectMapping;
  }

  public void addNewEntityObject(String name, PounamuModelElement object){
    //if(idAndEntityTypeObjectMapping.containsKey(name)){
      idAndEntityObjectMapping.put(name, object);
    //}
  }

  public void removeEntityObject(String name){
    idAndEntityObjectMapping.remove(name);
  }

  public PounamuModelElement getEntityObject(String name){
    return (PounamuModelElement)idAndEntityObjectMapping.get(name);
  }

  public Enumeration getEntityObjectIDs(){
    return idAndEntityObjectMapping.keys();
  }

  public Hashtable getIDAndAssociationObjectMapping(){
    return idAndAssociationObjectMapping;
  }

   public void addNewAssociationObject(String name, PounamuModelElement object){
    //if(idAndEntityTypeObjectMapping.containsKey(name)){
      idAndAssociationObjectMapping.put(name, object);
    //}
  }*/

 /* public void removeAssociationObject(String name){
    idAndAssociationObjectMapping.remove(name);
  }*/

 /* public PounamuModelElement getAssociationObject(String name){
    return (PounamuModelElement)idAndAssociationObjectMapping.get(name);
  }*/

  /*public Enumeration getAssociationObjectIDs(){
    return idAndAssociationObjectMapping.keys();
  }

  public String getIconType(String modelType, String viewType){
    return (String)iconTypes.get(modelType+"_"+viewType);
  }

  public void registerIconType(String modelType, String viewType, String iconType){
    iconTypes.put(modelType+"_"+viewType, iconType);
  }*/

  /*public Hashtable getModelToIconPropertyMapping(String modelType, String iconType){
    return (Hashtable)modelToIconPropertyHashtable.get(modelType+"_"+iconType);
  }

  public void registerModelToIconPropertyMapping(String modelType, String iconType, Hashtable propertyMapping){
    modelToIconPropertyHashtable.put(modelType+"_"+iconType, propertyMapping);
  }

  public Hashtable getIconToModelPropertyMapping(String iconType, String modelType){
    return (Hashtable)iconToModelPropertyHashtable.get(iconType+"_"+modelType);
  }

  public void registerIconToModelPropertyMapping(String iconType, String modelType, Hashtable propertyMapping){
    iconToModelPropertyHashtable.put(iconType+"_"+modelType, propertyMapping);
  }*/

  /**
   * get the corresponding icon property name for the specified model type, model property name  and icon type
   * @param iconType the type of an icon
   * @param viewType the type of the view
   * @param modelType the type of an model
   * @param propertyName the name of the property
   */
  public String getIconPropertyName(String viewType, String modelType, String iconType, String propertyName){
    String key = viewType+":"+modelType+":"+iconType;
    Vector v = (Vector)getViewTypeAndPropertyMapping().get(key);
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.get(i);
      if(s.substring(0, s.indexOf(':')).equals(propertyName))
        return s.substring(s.indexOf(':')+1);
    }
    return "";
  }

  /**
   * get the corresponding model property name for the specified icon type, icon property name, model type and view type
   * @param viewType the type of the view
   * @param iconType the type of an icon
   * @param modelType the type of an model
   * @param propertyName the name of the property
   */
  public String getModelPropertyName(String viewType, String modelType, String iconType, String propertyName){
    String key = viewType+":"+modelType+":"+iconType;
    Vector v = (Vector)getViewTypeAndPropertyMapping().get(key);
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.get(i);
      if(s.substring(s.indexOf(':')+1).equals(propertyName))
        return s.substring(0, s.indexOf(':'));
    }
    return "";
  }

  /**
   * register an icon and its textField properties to this project
   */
  public void registerIconTextFieldProperties(String name, Vector textFieldProperties){
    iconNameToTextFieldPropertiesMapping.put(name, textFieldProperties);
  }

  /**
   * get the textField property list of the specified icon
   * @param name the name of the icon
   * @return the vector which contains showing property names of this icon
   */
  public Vector getTextFieldProperties(String name){
    return (Vector)iconNameToTextFieldPropertiesMapping.get(name);
  }

  /**
   * register an icon and its textArea properties to this project
   */
  public void registerIconTextAreaProperties(String name, Vector textAreaProperties){
    iconNameToTextAreaPropertiesMapping.put(name, textAreaProperties);
  }

  /**
   * get the textArea property list of the specified icon
   * @param name the name of the icon
   * @return the vector which contains textArea property names of this icon
   */
  public Vector getTextAreaProperties(String name){
    return (Vector)iconNameToTextAreaPropertiesMapping.get(name);
  }

  /**
   * get the hashtable which holds the mappings from a index node to an entity type object
   * @return the hashtable which holds the mappings from a index node to an entity type object
   */
 /* public Hashtable getNodeAndEntityTypeObjectMapping(){
    return nodeAndEntityTypeObjectMapping;
  }*/

  /**
   * get the hashtable which holds the mappings from a index node to an association type object
   * @return the hashtable which holds the mappings from a index node to an association type object
   */
  /*public Hashtable getNodeAndAssociationTypeObjectMapping(){
    return nodeAndAssociationTypeObjectMapping;
  }*/

  /**
   * get the entity type object indexed by the specified tree node
   * @param node teh index node
   * @return the entity type object indexed by the specified tree node
   */
  public PounamuMetaModelElement getEntityTypeObject(DefaultMutableTreeNode node){
    Object icon = getIcon(node);
    if(icon instanceof PounamuPanel){
      PounamuShape shape = ((PounamuPanel)icon).getPounamuShape();
      return (PounamuMetaModelElement)shape.getRelatedObject();
    }
    return null;
  }
  
  /**
   * get the association type object indexed by the specified tree node
   * @param node the index tree node
   * @return the association type object
   */
  public PounamuMetaModelElement getAssociationTypeObject(DefaultMutableTreeNode node){
    Object icon = getIcon(node);
    if(icon instanceof PounamuPanel){
      PounamuShape shape = ((PounamuPanel)icon).getPounamuShape();
      return (PounamuMetaModelElement)shape.getRelatedObject();
    }
    return null;
  }
    
  public Object getIcon(DefaultMutableTreeNode node){
    return nodeAndIconMapping.get(node);
  }
  
  public Vector getEntityTypeObjects(){
    return entityTypeObjects;
  }
  
  public Vector getAssociationTypeObjects(){
    return associationTypeObjects;
  }
  
  public PounamuMetaModelElement getEntityTypeObjectByName(String name){
    for(int i = 0; i < entityTypeObjects.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)entityTypeObjects.get(i);
      if(element.getName().equals(name))
        return element;
    }
    return null;
  }
  
  public PounamuMetaModelElement getAssociationTypeObjectByName(String name){
    for(int i = 0; i < associationTypeObjects.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)associationTypeObjects.get(i);
      if(element.getName().equals(name))
        return element;
    }
    return null;
  }
  
  public boolean existedEntityTypeObjectWithName(String name){
    for(int i = 0; i < entityTypeObjects.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)entityTypeObjects.get(i);
      if(element.getName().equals(name))
        return true;
    }
    return false;
  }
  
  public boolean existedAssociationTypeObjectWithName(String name){
    for(int i = 0; i < associationTypeObjects.size(); i++){
      PounamuMetaModelElement element = (PounamuMetaModelElement)associationTypeObjects.get(i);
      if(element.getName().equals(name))
        return true;
    }
    return false;
  }

  public void addEntityTypeObject(PounamuMetaModelElement entityTypeObject){
    entityTypeObject.setIconNumber(entityTypeObject.getIconNumber()+1);
    if(entityTypeObjects.contains(entityTypeObject))
      return;
    entityTypeObjects.add(entityTypeObject);
  }
  
  public void addAssociationTypeObject(PounamuMetaModelElement associationTypeObject){
    associationTypeObject.setIconNumber(associationTypeObject.getIconNumber()+1);
    if(associationTypeObjects.contains(associationTypeObject))
      return;
    associationTypeObjects.add(associationTypeObject);
  }
  
  public void removeEntityTypeObject(PounamuMetaModelElement entityTypeObject){
    entityTypeObject.setIconNumber(entityTypeObject.getIconNumber()-1);
    if(entityTypeObject.getIconNumber() == 0){
      entityTypeObjects.remove(entityTypeObject);
      String fullPath = "\""+getLocation()+fileSeparator+"metamodel"+fileSeparator+"entitytypes"+fileSeparator+entityTypeObject.getName()+".xml\"";
      //System.out.println("in class toolproject, method removeEntityTypeObject, the fullPath is " + fullPath);
      MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
      mfs.run();    
    }
      
  }
    
  public void removeAssociationTypeObject(PounamuMetaModelElement associationTypeObject){
    associationTypeObject.setIconNumber(associationTypeObject.getIconNumber()-1);
    if(associationTypeObject.getIconNumber() == 0){
      associationTypeObjects.remove(associationTypeObject);
      String fullPath = "\""+getLocation()+fileSeparator+"metamodel"+fileSeparator+"associationtypes"+fileSeparator+associationTypeObject.getName()+".xml\"";
      MaintainFileSystem mfs = new MaintainFileSystem(fullPath, pounamu, "deletefile");
      mfs.run();    
    }
  }
    
  /**
   * extends the super abstract method, not applicable for tool project
   * @param node the index node
   * @return null.
   */
  public PounamuModelElement getEntity(DefaultMutableTreeNode node){
    return null;
  }

  /**
   * extends the super abstract method, not applicable for tool project
   * @param node the index node
   * @return null.
   */
  public PounamuModelElement getAssociation(DefaultMutableTreeNode node){
    return null;
  }

  
  private void restorePropertyMappingFromAssociationTypeToIcon(){
    NodeList nl = root.getElementsByTagName("propertymappingfromassociationtypetoicon");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      propertyMappingFromAssociationTypeToIcon.put(key, value);
    }
  }

  private void restorePropertyMappingFromEntityTypeToIcon(){
    NodeList nl = root.getElementsByTagName("propertymappingfromentitytypetoicon");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      propertyMappingFromEntityTypeToIcon.put(key, value);
    }
  }

  private void restorePropertyMappingFromIconToAssociationType(){
    NodeList nl = root.getElementsByTagName("propertymappingfromicontoassociationtype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      propertyMappingFromIconToAssociationType.put(key, value);
    }
  }

  private void restorePropertyMappingFromIconToEntityType(){
    NodeList nl = root.getElementsByTagName("propertymappingfromicontoentitytype");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      m = ((Element)n).getElementsByTagName("value").item(0);
      String value = m.getFirstChild().getNodeValue();
      propertyMappingFromIconToEntityType.put(key, value);
    }
  }

  private void restoreRegisteredAssociationTypeProperty(){
    NodeList nl = root.getElementsByTagName("registeredassociationtypeproperty");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      registeredAssociationTypeProperty.put(key, v);
    }
  }

  private void restoreRegisteredEntityTypeProperty(){
    NodeList nl = root.getElementsByTagName("registeredentitytypeproperty");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      registeredEntityTypeProperty.put(key, v);
    }
  }
  private void restoreIconNameToTextAreaPropertiesMapping(){
    NodeList nl = root.getElementsByTagName("iconnametotextareapropertiesmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      iconNameToTextAreaPropertiesMapping.put(key, v);
    }
  }
  private void restoreIconNameToTextFieldPropertiesMapping(){
    NodeList nl = root.getElementsByTagName("iconnametotextfieldpropertiesmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      iconNameToTextFieldPropertiesMapping.put(key, v);
    }
  }

  private void restoreViewTypeAndAllowedVisualEventHandlersMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandallowedvisualeventhandlersmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        //System.out.println("in reload viewtype and handlers mapping viewtype is " + key + ", and handler name is " + value);
        v.add(value);
      }
      viewTypeAndAllowedVisualEventHandlersMapping.put(key, v);
    }
  }
  
  private void restoreViewTypeAndAllowedVisualUserHandlersMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandallowedvisualuserhandlersmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        //System.out.println("in reload viewtype and handlers mapping viewtype is " + key + ", and handler name is " + value);
        v.add(value);
      }
      viewTypeAndAllowedVisualUserHandlersMapping.put(key, v);
    }
  }


  private void restoreViewTypeAndAllowedEntityTypesMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandallowedentitytypesmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndAllowedEntityTypesMapping.put(key, v);
    }
  }
  
  private void restoreViewTypeAndAllowedAssociationTypesMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandallowedassociationtypesmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndAllowedAssociationTypesMapping.put(key, v);
    }
  }
  
  /*private void restoreViewTypeAndAllowedMetaModelTypesMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandallowedmetamodeltypesmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndAllowedMetaModelTypesMapping.put(key, v);
    }
  }*/
 /* private void restoreViewTypeAndMetaModelTypesAndIconMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandmetamodeltypesandiconmapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndMetaModelTypesAndIconMapping.put(key, v);
    }
  }*/
  private void restoreViewTypeAndEntityTypeAndShapeMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandentitytypeandshapemapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndEntityTypeAndShapeMapping.put(key, v);
    }
  }
  
  private void restoreViewTypeAndAssociationTypeAndConnectorMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandassociationtypeandconnectormapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndAssociationTypeAndConnectorMapping.put(key, v);
    }
  }

  private void restoreViewTypeAndPropertyMapping(){
    NodeList nl = root.getElementsByTagName("viewtypeandpropertymapping");
    for(int i = 0; i < nl.getLength(); i++){
      Node n = nl.item(i);
      Node m = ((Element)n).getElementsByTagName("key").item(0);
      String key = m.getFirstChild().getNodeValue();
      Vector v = new Vector();
      NodeList nll = ((Element)n).getElementsByTagName("value");
      for(int j = 0; j< nll.getLength(); j++){
        m = nll.item(j);
        String value = m.getFirstChild().getNodeValue();
        v.add(value);
      }
      viewTypeAndPropertyMapping.put(key, v);
    }
  }

  /**
   * get the xml representation of this project
   * @return the xml string of this project
   */
  public String getXMLRepresentation(){

    StringBuffer buf = new StringBuffer (400000);
    buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE tool SYSTEM \".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"tool.dtd\">\n");
    buf.append ("<tool>\n");
    buf.append (space+"<name>");
    buf.append (name);
    buf.append ("</name>\n");
    /*buf.append (space+"<location>");
    buf.append (location.substring(((String)pounamu.getProperties().get("pounamu")).length()+1));
    buf.append ("</location>\n");*/
    buf.append (space+"<description>");
    buf.append (description);
    buf.append ("</description>\n");
    buf.append (space+"<uniquenum>");
    buf.append (uniqueNum);
    buf.append ("</uniquenum>\n");
    buf.append (space+"<entitytypeicon>");
    buf.append (entityTypeIcon);
    buf.append ("</entitytypeicon>\n");
    buf.append (space+"<associationtypeicon>");
    buf.append (associationTypeIcon);
    buf.append ("</associationtypeicon>\n");
    getXMLForPropertyMappingFromEntityTypeToIcon(buf);
    getXMLForPropertyMappingFromIconToEntityType(buf);
    getXMLForPropertyMappingFromAssociationTypeToIcon(buf);
    getXMLForPropertyMappingFromIconToAssociationType(buf);
    getXMLForRegisteredShapes(buf);
    getXMLForRegisteredConnectors(buf);
    //getXMLForCurrentRegisteredModelHandlers(buf);
    getXMLForRegisteredModelEventHandlers(buf);
    getXMLForRegisteredModelUserHandlers(buf);
    getXMLForRegisteredVisualEventHandlers(buf);
    getXMLForRegisteredVisualUserHandlers(buf);
    getXMLForRegisteredEntityTypes(buf);
    getXMLForRegisteredAssociationTypes(buf);
    getXMLForRegisteredMetaModelViews(buf);
    getXMLForRegisteredViewTypes(buf);
    getXMLForIconNameToTextAreaPropertiesMapping(buf);
    getXMLForIconNameToTextFieldPropertiesMapping(buf);
    getXMLForRegisteredEntityTypeProperty(buf);
    getXMLForRegisteredAssociationTypeProperty(buf);
    //getXMLForViewTypeAndAllowedMetaModelTypesMapping(buf);
    getXMLForViewTypeAndAllowedEntityTypesMapping(buf);
    getXMLForViewTypeAndAllowedAssociationTypesMapping(buf);
    getXMLForViewTypeAndAllowedVisualEventHandlersMapping(buf);
    getXMLForViewTypeAndAllowedVisualUserHandlersMapping(buf);
    //getXMLForViewTypeAndMetaModelTypesAndIconMapping(buf);
    getXMLForViewTypeAndEntityTypeAndShapeMapping(buf);
    getXMLForViewTypeAndAssociationTypeAndConnectorMapping(buf);
    getXMLForViewTypeAndPropertyMapping(buf);
    buf.append ("</tool>\n");
    return buf.toString();
  }

  private void getXMLForPropertyMappingFromAssociationTypeToIcon(StringBuffer buf){
    Enumeration e = propertyMappingFromAssociationTypeToIcon.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<propertymappingfromassociationtypetoicon>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      String ss = (String)propertyMappingFromAssociationTypeToIcon.get(s);
      buf.append (space+space+"<value>"+ss+"</value>\n");
      buf.append (space+"</propertymappingfromassociationtypetoicon>\n");
    }
  }

  private void getXMLForPropertyMappingFromIconToAssociationType(StringBuffer buf){
    Enumeration e = propertyMappingFromIconToAssociationType.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<propertymappingfromicontoassociationtype>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      String ss = (String)propertyMappingFromIconToAssociationType.get(s);
      buf.append (space+space+"<value>"+ss+"</value>\n");
      buf.append (space+"</propertymappingfromicontoassociationtype>\n");
    }
  }

  private void getXMLForPropertyMappingFromEntityTypeToIcon(StringBuffer buf){
    Enumeration e = propertyMappingFromEntityTypeToIcon.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<propertymappingfromentitytypetoicon>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      String ss = (String)propertyMappingFromEntityTypeToIcon.get(s);
      buf.append (space+space+"<value>"+ss+"</value>\n");
      buf.append (space+"</propertymappingfromentitytypetoicon>\n");
    }
  }

  private void getXMLForPropertyMappingFromIconToEntityType(StringBuffer buf){
    Enumeration e = propertyMappingFromIconToEntityType.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<propertymappingfromicontoentitytype>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      String ss = (String)propertyMappingFromIconToEntityType.get(s);
      buf.append (space+space+"<value>"+ss+"</value>\n");
      buf.append (space+"</propertymappingfromicontoentitytype>\n");
    }
  }

  private void getXMLForIconNameToTextAreaPropertiesMapping(StringBuffer buf){

    Enumeration e = iconNameToTextAreaPropertiesMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<iconnametotextareapropertiesmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)iconNameToTextAreaPropertiesMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</iconnametotextareapropertiesmapping>\n");
    }
  }

  private void getXMLForIconNameToTextFieldPropertiesMapping(StringBuffer buf){
    Enumeration e = iconNameToTextFieldPropertiesMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<iconnametotextfieldpropertiesmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)iconNameToTextFieldPropertiesMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</iconnametotextfieldpropertiesmapping>\n");
    }
  }

  private void getXMLForRegisteredEntityTypeProperty(StringBuffer buf){
    Enumeration e = registeredEntityTypeProperty.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredentitytypeproperty>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)registeredEntityTypeProperty.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</registeredentitytypeproperty>\n");
    }
  }
  private void getXMLForRegisteredAssociationTypeProperty(StringBuffer buf){
    Enumeration e = registeredAssociationTypeProperty.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredassociationtypeproperty>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)registeredAssociationTypeProperty.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</registeredassociationtypeproperty>\n");
    }
  }
 
  private void getXMLForViewTypeAndAllowedEntityTypesMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAllowedEntityTypesMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandallowedentitytypesmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAllowedEntityTypesMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandallowedentitytypesmapping>\n");
    }
  }
  
  private void getXMLForViewTypeAndAllowedAssociationTypesMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAllowedAssociationTypesMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandallowedassociationtypesmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAllowedAssociationTypesMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandallowedassociationtypesmapping>\n");
    }
  }
  /* private void getXMLForViewTypeAndAllowedMetaModelTypesMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAllowedMetaModelTypesMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandallowedmetamodeltypesmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAllowedMetaModelTypesMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandallowedmetamodeltypesmapping>\n");
    }
  }*/
  private void getXMLForViewTypeAndAllowedVisualEventHandlersMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAllowedVisualEventHandlersMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandallowedvisualeventhandlersmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAllowedVisualEventHandlersMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandallowedvisualeventhandlersmapping>\n");
    }
  }
  
  private void getXMLForViewTypeAndAllowedVisualUserHandlersMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAllowedVisualUserHandlersMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandallowedvisualuserhandlersmapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAllowedVisualUserHandlersMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandallowedvisualuserhandlersmapping>\n");
    }
  }

  private void getXMLForViewTypeAndEntityTypeAndShapeMapping(StringBuffer buf){
    Enumeration e = viewTypeAndEntityTypeAndShapeMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandentitytypeandshapemapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndEntityTypeAndShapeMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandentitytypeandshapemapping>\n");
    }
  }
  
  private void getXMLForViewTypeAndAssociationTypeAndConnectorMapping(StringBuffer buf){
    Enumeration e = viewTypeAndAssociationTypeAndConnectorMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandassociationtypeandconnectormapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndAssociationTypeAndConnectorMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandassociationtypeandconnectormapping>\n");
    }
  }

  private void getXMLForViewTypeAndPropertyMapping(StringBuffer buf){
    Enumeration e = viewTypeAndPropertyMapping.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<viewtypeandpropertymapping>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Vector v = (Vector)viewTypeAndPropertyMapping.get(s);
      for(int i = 0; i < v.size(); i++){
        String ss = (String)v.get(i);
        buf.append (space+space+"<value>"+ss+"</value>\n");
      }
      buf.append (space+"</viewtypeandpropertymapping>\n");
    }
  }

  private void getXMLForRegisteredViewTypes(StringBuffer buf){
    for(int i = 0; i < registeredViewTypes.size(); i++){
      String temp = (String)registeredViewTypes.elementAt(i);
      buf.append (space+"<registeredviewtype>");
      buf.append (temp);
      buf.append ("</registeredviewtype>\n");
    }
  }

  private void getXMLForRegisteredShapes(StringBuffer buf){
    for(int i = 0; i < registeredShapes.size(); i++){
      String temp = (String)registeredShapes.elementAt(i);
      buf.append (space+"<registeredshape>");
      buf.append (temp);
      buf.append ("</registeredshape>\n");
    }
  }

  private void getXMLForRegisteredConnectors(StringBuffer buf){
    for(int i = 0; i < registeredConnectors.size(); i++){
      String temp = (String)registeredConnectors.elementAt(i);
      buf.append (space+"<registeredconnector>");
      buf.append (temp);
      buf.append ("</registeredconnector>\n");
    }
  }

  private void getXMLForCurrentRegisteredModelHandlers(StringBuffer buf){
    /*Enumeration e = currentRegisteredModelHandlers.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<currentregisteredmodelhandler>\n");
      buf.append (space+space+"<key>");
      String s = (String)e.nextElement();
      buf.append (s);
      buf.append ("</key>\n");
      buf.append (space+space+"<value>");
      String ss = (String)currentRegisteredModelHandlers.get(s);
      buf.append (ss+"</value>\n");
      buf.append (space+"</currentregisteredmodelhandler>\n");
    }*/
  }
  private void getXMLForRegisteredModelEventHandlers(StringBuffer buf){
    Enumeration e = registeredModelEventHandlers.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredmodeleventhandler>\n");
      buf.append (space+space+"<key>");
      String s = (String)e.nextElement();
      buf.append (s);
      buf.append ("</key>\n");
      buf.append (space+space+"<value>");
      String ss = (String)registeredModelEventHandlers.get(s);
      buf.append (ss+"</value>\n");
      buf.append (space+"</registeredmodeleventhandler>\n");
    }
  }
  
   private void getXMLForRegisteredModelUserHandlers(StringBuffer buf){
    Enumeration e = registeredModelUserHandlers.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredmodeluserhandler>\n");
      buf.append (space+space+"<key>");
      String s = (String)e.nextElement();
      buf.append (s);
      buf.append ("</key>\n");
      buf.append (space+space+"<value>");
      String ss = (String)registeredModelUserHandlers.get(s);
      buf.append (ss+"</value>\n");
      buf.append (space+"</registeredmodeluserhandler>\n");
    }
  }

  private void getXMLForRegisteredVisualEventHandlers(StringBuffer buf){
    Enumeration e = registeredVisualEventHandlers.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredvisualeventhandler>\n");
      buf.append (space+space+"<key>");
      String s = (String)e.nextElement();
      buf.append (s);
      buf.append ("</key>\n");
      buf.append (space+space+"<value>");
      String ss = (String)registeredVisualEventHandlers.get(s);
      buf.append (ss+"</value>\n");
      buf.append (space+"</registeredvisualeventhandler>\n");
    }
  }
  
  private void getXMLForRegisteredVisualUserHandlers(StringBuffer buf){
    Enumeration e = registeredVisualUserHandlers.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<registeredvisualuserhandler>\n");
      buf.append (space+space+"<key>");
      String s = (String)e.nextElement();
      buf.append (s);
      buf.append ("</key>\n");
      buf.append (space+space+"<value>");
      String ss = (String)registeredVisualUserHandlers.get(s);
      buf.append (ss+"</value>\n");
      buf.append (space+"</registeredvisualuserhandler>\n");
    }
  }

  private void getXMLForRegisteredEntityTypes(StringBuffer buf){
    Hashtable h = getRegisteredEntityTypeObjects();
    Enumeration en = h.keys();
    while(en.hasMoreElements()){
      String temp = (String)en.nextElement();
      buf.append (space+"<registeredentitytype>");
      buf.append (temp);
      buf.append ("</registeredentitytype>\n");
    }
  }

  private void getXMLForRegisteredAssociationTypes(StringBuffer buf){
    Hashtable h = getRegisteredAssociationTypeObjects();
    Enumeration en = h.keys();
    while(en.hasMoreElements()){
      String temp = (String)en.nextElement();
      buf.append (space+"<registeredassociationtype>");
      buf.append (temp);
      buf.append ("</registeredassociationtype>\n");
    }
  }

  private void getXMLForRegisteredMetaModelViews(StringBuffer buf){
    for(int i = 0; i < registeredMetaModelViews.size(); i++){
      String temp = (String)registeredMetaModelViews.get(i);
      buf.append(space+"<registeredmetamodelview>");
      buf.append(temp);
      buf.append("</registeredmetamodelview>\n");
    }
  }


  /**
   * save this project
   */
  public void save(){
    try{
      FileWriter fw = new FileWriter(getLocation()+fileSeparator+""+getName()+".xml");
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(getXMLRepresentation());
      bw.flush();
      fw.close();
    }
    catch(Exception ee){}
    manager.displayMessage(getName()+".xml" + " has been saved to " + getLocation()+fileSeparator+""+getName()+".xml");
  }

  public void updateStates(DefaultMutableTreeNode previousSelectedNode){
    //System.out.println("PounamuTooProject_updateStates visited 0");
    String s = (String)nodeAndRegisteredXMLStringMapping.get(previousSelectedNode);
    if(s == null)
      return;
    //System.out.println("PounamuTooProject_updateStates visited 1");
    if(!s.equals(getXMLRepresentation())){
      if(isRegistered())
        setWasRegistered(true);
      setRegistered(false);
    }
    //System.out.println("registered is now " + registered);
    //System.out.println("wasRegistered is now " + wasRegistered);
    //System.out.println("PounamuTooProject_updateStates visited 2");
    manager.getManagerTree().repaint();
    //System.out.println("PounamuTooProject_updateStates visited 3");
  }
}