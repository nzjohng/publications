/*
 * @(#)PounamuModelProject.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.data;
import pounamu.core.*;
import pounamu.event.*;
import pounamu.command.*;
import pounamu.visualcomp.*;
import javax.swing.tree.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/* Added by Akhil */
import pounamu.plugins.collaborate.*;
import pounamu.visualcomp.PounamuShape;
import pounamu.editor.*;
/**
 * Title: PounamuModelProject
 * Description:  defines a pounamu model project
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuModelProject extends PounamuProject{

    PounamuToolProject tool = null;
    Hashtable openedModelViews = new Hashtable();
    Hashtable nodeAndEntityMapping = new Hashtable();
    Hashtable nodeAndAssociationMapping = new Hashtable();
    Hashtable nodeAndSavedXMLStringMapping = new Hashtable();
    Hashtable viewTypeNameAndNodeMapping = new Hashtable();
    Hashtable tempHashForOpenModel = new Hashtable();
    Hashtable menuItemsAndModelUserHandlersMapping = new Hashtable();
    Hashtable menuItemsAndVisualUserHandlersMapping = new Hashtable();
    Hashtable entities = new Hashtable();
    Hashtable associations = new Hashtable();
    Vector modelEventHandlers = new Vector();
    Vector modelUserHandlers = new Vector();
    Vector registeredModelViews = new Vector();
    String toolName = null;
    String space = "            ";
    String fileSeparator = null;
    int viewCount = 0;
    int entityCount = 0;
    int associationCount = 0;
    Element root = null;

    /**
     * a constructor
     * @param name the name of this project
     * @param location the location this projet will be saved to
     * @param description the description of this project
     * @param manager the manager panel of the pounamu working instance
     */
    public PounamuModelProject(PounamuManagerPanel manager, String name, String location, String description, String toolName){
        super(manager, name, location, description);
        this.tool = manager.getCurrentTool();
        this.toolName = toolName;
        fileSeparator = System.getProperty("file.separator");
        nodeAndMenuItemsMapping.put(projectNode, initMenuItemsForModelProjectNode());
        nodeAndToolButtonsMapping.put(projectNode, initToolButtonsForModelProjectNode());
        nodeAndSavedXMLStringMapping.put(projectNode, "");
        init("new");
        initFolders();
        manager.addTreeNode(projectNode);
        manager.getNodeAndItsValueMapping().put(projectNode, name);
        manager.setSelectedNode(projectNode);
        //TreePath tp = new TreePath(projectNode.getPath());
        //manager.getManagerTree().setSelectionPath(tp);
        pounamu.setProjectTab(projectTab);
        registerModelEventHandlers();
        registerModelUserHandlers();
        initOpenedModelViews();
    }

    /**
     * a constructor
     * @param xmlDocument the xml document which represents a model project
     * @param manager the manager panel of the pounamu working instance
     */
    public PounamuModelProject(PounamuManagerPanel manager, Document xmlDocument){
        super();
        this.manager = manager;
        this.pounamu = manager.getPounamu();
        this.root = xmlDocument.getDocumentElement();
        fileSeparator = System.getProperty("file.separator");
        NodeList nll = root.getElementsByTagName("name");
        Node n = nll.item(0);
        String name = n.getFirstChild().getNodeValue();
        setName(name);
        nll = root.getElementsByTagName("description");
        n = nll.item(0);
        if(n != null && n.getFirstChild() != null)
            setDescription(n.getFirstChild().getNodeValue());
        else
            setDescription("");
        nll = root.getElementsByTagName("location");
        n = nll.item(0);
        setLocation(pounamu.getPounamuHome()+fileSeparator+(String)(n.getFirstChild().getNodeValue()));
        nll = root.getElementsByTagName("toolname");
        n = nll.item(0);
        toolName = n.getFirstChild().getNodeValue();
        if(manager.getRegisteredTools().get(toolName) == null){
            manager.setSelectedNode(manager.getToolProjectNode());
            //TreePath tp = new TreePath(manager.getToolProjectNode().getPath());
            //manager.getManagerTree().setSelectionPath(tp);
            if(manager.doOpenToolProject(toolName) == false)
                return;
            manager.setSelectedNode(manager.getModelProjectNode());
            //tp = new TreePath(manager.getModelProjectNode().getPath());
            //manager.getManagerTree().setSelectionPath(tp);
        }
        PounamuToolProject tool = (PounamuToolProject)manager.getRegisteredTools().get(toolName);
        manager.setCurrentTool(tool);
        this.tool = manager.getCurrentTool();
        this.managerTree = manager.getManagerTree();
        this.projectNode = new DefaultMutableTreeNode(name);
        this.projectTab = new PounamuTabbedPane(this);
        projectTab.setTabPlacement(JTabbedPane.BOTTOM);
        manager.getNodeAndProjectMapping().put(projectNode, this);
        manager.getNodeAndItsValueMapping().put(projectNode, name);
        nodeAndMenuItemsMapping.put(projectNode, initMenuItemsForModelProjectNode());
        nodeAndToolButtonsMapping.put(projectNode, initToolButtonsForModelProjectNode());
        init("open");
        manager.addTreeNode(projectNode);
        manager.setSelectedNode(projectNode);
        //TreePath tp = new TreePath(projectNode.getPath());
        //manager.getManagerTree().setSelectionPath(tp);
        pounamu.setProjectTab(projectTab);
        registerModelEventHandlers();
        registerModelUserHandlers();
        //initObjectTypeAndHashtableMapping();
        initOpenedModelViews();
        restoreViews();
        nodeAndSavedXMLStringMapping.put(projectNode, getXMLRepresentation());
        doSaveModelProject(projectNode);
    }

    private void restoreViews(){
        NodeList nll = root.getElementsByTagName("view");
        int i = 0;
        while(nll.item(i) != null){
            Node n = nll.item(i);
            i++;
            NodeList nl = ((Element)n).getElementsByTagName("viewname");
            Node m = nl.item(0);
            String viewName = m.getFirstChild().getNodeValue();
            //System.out.println("==="+viewName);
            nl = ((Element)n).getElementsByTagName("viewtype");
            m = nl.item(0);
            String viewType = m.getFirstChild().getNodeValue();
            //System.out.println("+++"+viewType);
            DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)viewTypeNameAndNodeMapping.get(viewType);
            manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
            manager.setSelectedNode(dmtn);
            //TreePath tp = new TreePath(dmtn.getPath());
            //manager.getManagerTree().setSelectionPath(tp);
            doOpenExistedModelView(viewType, viewName);
        }
    }

  /*private void initObjectTypeAndHashtableMapping(){
    Hashtable h = tool.getRegisteredAssociationTypeObjects();
    Enumeration en = h.keys();
    Vector v = new Vector();
    while(en.hasMoreElements())
      v.add(en.nextElement());
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.get(i);
      if(objectTypeAndHashtableMapping.get(s)==null){
        Hashtable hash = new Hashtable();
        objectTypeAndHashtableMapping.put(s, hash);
      }
      //System.out.println("association type "+s+" has been put into hash");

    }
    h = tool.getRegisteredEntityTypeObjects();
    en = h.keys();
    v = new Vector();
    while(en.hasMoreElements())
      v.add(en.nextElement());
    for(int i = 0; i < v.size(); i++){
      String s = (String)v.get(i);
      if(objectTypeAndHashtableMapping.get(s)==null){
        Hashtable hash = new Hashtable();
        objectTypeAndHashtableMapping.put(s, hash);
      }
      //System.out.println("entity type "+s+" has been put into hash");
    }
  }*/

    private void initOpenedModelViews(){
        Vector v = tool.getRegisteredViewTypes();
        for(int i = 0; i < v.size(); i++){
            String s = (String)v.get(i);
            if(openedModelViews.get(s)==null){
                Hashtable hash = new Hashtable();
                openedModelViews.put(s, hash);
            }
        }
    }

    /**
     * each node has a set of corresponding menu items
     * @param node the tree node severs as a index
     * @return a vector holds all menu items related to the node
     */
    public Vector getMenuItems(DefaultMutableTreeNode node){
        Vector temp = new Vector();
        Vector items = (Vector)nodeAndMenuItemsMapping.get(node);
        for(int i = 0; i < items.size(); i++){
            temp.add(items.get(i));
        }
        temp.add(null);
        Enumeration e = menuItemsAndModelUserHandlersMapping.keys();
        while(e.hasMoreElements()){
            temp.add(e.nextElement());
        }
        if(getView(node)!=null){
            PounamuView view  = getView(node);
            ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
            Vector v = panel.getVisualUserHandlers();
            if(v.size() != 0){
                temp.add(null);
                for(int i = 0; i < v.size(); i++){
                    PounamuVisualHandler handler = (PounamuVisualHandler)v.get(i);
                    String menuItemText = handler.getMenuItemText();
                    JMenuItem jmi = new JMenuItem(menuItemText);
                    jmi.setVisible(true);
                    temp.add(jmi);
                    menuItemsAndVisualUserHandlersMapping.put(jmi, handler);
                    jmi.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent ev){
                            JMenuItem item = (JMenuItem)ev.getSource();
                            PounamuUserTriggeringHandler ha = (PounamuUserTriggeringHandler)(menuItemsAndVisualUserHandlersMapping.get(item));
                            ha.execute();
                        }
                    });
                }
            }
        }
        return temp;
    }


    public Hashtable getMenuItemsAndModelUserHandlersMapping(){
        return menuItemsAndModelUserHandlersMapping;
    }
    /**
     * In pounamu model project, each created objects which has the same type will be put into a hashtable using its name as a "key" and the object itself as a "value". The the hashtable again
     * will be put into a big hashtable using the type as a key and the hashtable as a value.
     * @return the big hashtable
     */
  /*public Hashtable getObjectTypeAndHashtableMapping(){
    return objectTypeAndHashtableMapping;
  }*/

    private Vector initMenuItemsForModelProjectNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("rename this model");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("view event triggering model handlers registered for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ViewHandlerInformation vhi = new ViewHandlerInformation(pounamu, modelEventHandlers);
                vhi.setVisible(true);
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("view user triggering model handlers registered for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ViewHandlerInformation vhi = new ViewHandlerInformation(pounamu, modelUserHandlers);
                vhi.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("view xml file for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 600);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("save this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveModelProject(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("save this model as");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doSaveModelProject();
            }
        });

        //menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("close this model project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseModelProject(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);

        /*******************************************************/
        /* GUI related code Added by Akhil */
        /*******************************************************/

        CollaborativeEditing instance = CollaborativeEditing.getCollabrativePluginInstance();

        if( instance.getIsCollaborativeEditingOn() ) {
            final PounamuModelProject refProj = this;
            jmi = new JMenuItem("Select User");
            jmi.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent ev){
                    CollaborativeEditing instance = CollaborativeEditing.getCollabrativePluginInstance();
                    instance.selectUsers(refProj);

                }
            });
            menuItems.add(jmi);

        }

        /*******************************************************/
        /* End of code added by akhil */
        /*******************************************************/
        return menuItems;
    }

    private Vector initToolButtonsForModelProjectNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("rename this model");
        jmi.setToolTipText("function: " + "rename this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("view event triggering model handlers registered for this model");
        jmi.setToolTipText("function: " + "view event triggering model handlers regisered for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ViewHandlerInformation vhi = new ViewHandlerInformation(pounamu, modelEventHandlers);
                vhi.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("view user triggering model handlers registered for this model");
        jmi.setToolTipText("function: " + "view user triggering model handlers regisered for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ViewHandlerInformation vhi = new ViewHandlerInformation(pounamu, modelUserHandlers);
                vhi.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("view xml file for this model");
        jmi.setToolTipText("function: " + "view xml file for this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 600);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("save this model");
        jmi.setToolTipText("function: " + "save this model");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveModelProject(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
    /*jmi = new JButton("save this model as");
    jmi.setToolTipText("function: " + "save this model as");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveModelProject();
      }
    });
    toolButtons.add(jmi);*/
        toolButtons.add(null);
        jmi = new JButton("close this model project");
        jmi.setToolTipText("function: " + "close this model project");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCloseModelProject(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    public String getToolName(){
        return toolName;
    }

    public void setToolName(String toolName){
        this.toolName = toolName;
    }

    /**
     * get the tool which has been used to do this model project
     * @return the tool
     */
    public PounamuToolProject getTool(){
        return tool;
    }

    /**
     * set the tool used to do this model project
     * @param tool the tool used to do this project
     */
    public void setTool(PounamuToolProject tool){
        this.tool = tool;
    }

    public Hashtable getTempHashForOpenModel(){
        return tempHashForOpenModel;
    }

  /*public Hashtable getNodeAndRegisteredXMLStringMapping(){
    return nodeAndRegisteredXMLStringMapping;
  }*/
    public void doSaveAllViewsOfAViewType(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
            doSaveAView((DefaultMutableTreeNode)en.nextElement());
        }
    }

    public void doSaveAllEntitiesInAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
            doSaveAllEntitiesOfATypeInAView((DefaultMutableTreeNode)en.nextElement());
        }
    }

    public void doSaveAllEntitiesOfATypeInAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
            doSaveAnEntity((DefaultMutableTreeNode)en.nextElement());
        }
    }

    public void doSaveAnEntity(DefaultMutableTreeNode dmtn){
        PounamuModelElement pmme = (PounamuModelElement)getEntity(dmtn);
        pmme.setName((String)dmtn.getUserObject());
        pmme.save(getLocation()+fileSeparator+"entity_objects"+fileSeparator+pmme.getType()+fileSeparator+(String)dmtn.getUserObject()+".xml");
        pounamu.displayMessage((String)dmtn.getUserObject()+" has been saved to "+getLocation()+fileSeparator+"entity_objects"+fileSeparator+pmme.getType());
        pmme.setSaved(true);
        pmme.setWasSaved(true);
        //System.out.println("in class pounamuModelProject, save a entity works!");
        manager.getManagerTree().repaint();
        nodeAndSavedXMLStringMapping.put(dmtn, pmme.getXMLRepresentation());
        //System.out.println("in class pounamuModelProject, save a entity works!");
    }

    public void doSaveAnAssociation(DefaultMutableTreeNode dmtn){
        PounamuModelElement pmme = (PounamuModelElement)getAssociation(dmtn);
        pmme.setName((String)dmtn.getUserObject());
        pmme.save(getLocation()+""+fileSeparator+"association_objects"+fileSeparator+""+pmme.getType()+""+fileSeparator+""+(String)dmtn.getUserObject()+".xml");
        pounamu.displayMessage((String)dmtn.getUserObject()+" has been saved to "+getLocation()+""+fileSeparator+"association_objects"+fileSeparator+""+pmme.getType());
        pmme.setSaved(true);
        pmme.setWasSaved(true);
        //System.out.println("in class pounamuModelProject, save a entity works!");
        manager.getManagerTree().repaint();
        nodeAndSavedXMLStringMapping.put(dmtn, pmme.getXMLRepresentation());
        //System.out.println("in class pounamuModelProject, save a entity works!");
    }

    public void doSaveAllAssociationsInAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
            doSaveAllAssociationsOfATypeInAView((DefaultMutableTreeNode)en.nextElement());
        }
    }

    public void doSaveAllAssociationsOfATypeInAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
            doSaveAnAssociation((DefaultMutableTreeNode)en.nextElement());
        }
    }

    /**
     * save a model view
     */
    public void doSaveAView(DefaultMutableTreeNode dmtn){
        doSaveAllEntitiesInAView((DefaultMutableTreeNode)dmtn.getFirstChild());
        doSaveAllAssociationsInAView(((DefaultMutableTreeNode)dmtn.getFirstChild()).getNextSibling());
        PounamuView view = getView(dmtn);
        String name = (String)dmtn.getUserObject();
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setName(name);
        panel.save(name);
        view.setSaved(true);
        view.setWasSaved(true);
        manager.getManagerTree().repaint();
        nodeAndSavedXMLStringMapping.put(dmtn, view.getXMLRepresentation());
    }

    /**
     * save this model project
     */
    public void doSaveModelProject(DefaultMutableTreeNode dmtn){
      try{
        //System.out.println(getLocation()+fileSeparator+getName()+".xml");
        Enumeration en = dmtn.children();
        while(en.hasMoreElements()){
          doSaveAllViewsOfAViewType((DefaultMutableTreeNode)en.nextElement());
        }
        FileWriter fw = new FileWriter(getLocation()+fileSeparator+getName()+".xml");
        //FileWriter fw = new FileWriter(getLocation()+".xml");
        BufferedWriter bw = new BufferedWriter(fw, 40000);
        bw.write(getXMLRepresentation());
        bw.flush();
        fw.close();
        setSaved(true);
        setWasSaved(true);
        manager.getManagerTree().repaint();
        nodeAndSavedXMLStringMapping.put(dmtn, getXMLRepresentation());
        //System.out.println(getXMLRepresentation());
      }
      catch(Exception ee){}
      manager.displayMessage(getName()+".xml" + " has been saved to " + getLocation()+""+fileSeparator+""+getName()+".xml");
    }

    /**
     * get XML representation for tis project
     * @return the string which contains XML format porject information
     */
    public String getXMLRepresentation(){
        StringBuffer buf = new StringBuffer(400000);
        buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE model SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"model.dtd\">\n");
        buf.append("<model>\n");
        buf.append(space+"<name>");
        buf.append(name);
        buf.append("</name>\n");
        buf.append(space+"<location>");
        buf.append(location.substring(((String)pounamu.getPounamuHome()).length()+1));
        //buf.append (location);
        buf.append("</location>\n");
        buf.append(space+"<description>");
        buf.append(description);
        buf.append("</description>\n");
        buf.append(space+"<toolname>");
        buf.append(toolName);
        buf.append("</toolname>\n");
        //getXMLForObjectTypeAndHashtableMapping(buf);
        //getXMLForOpenedModelViews(buf);
        Enumeration e = openedModelViews.keys();
        while(e.hasMoreElements()){
            String s = (String)e.nextElement();
            Hashtable h = (Hashtable)openedModelViews.get(s);
            Enumeration en = h.keys();
            while(en.hasMoreElements()){
                String ss = (String)en.nextElement();
                PounamuView view = (PounamuView)h.get(ss);
                //ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                //panel.save(ss);
                //view.setSaved(true);
                //view.setWasSaved(true);
                buf.append(space+"<view>\n");
                buf.append(space+space+"<viewname>"+ss+"</viewname>\n");
                buf.append(space+space+"<viewtype>"+s+"</viewtype>\n");
                buf.append(space+"</view>\n");
            }
        }
        buf.append("</model>\n");
        return buf.toString();
    }

  /*private void getXMLForOpenedModelViews(StringBuffer buf){
    Enumeration e = openedModelViews.keys();
    while(e.hasMoreElements()){
      buf.append (space+"<openedmodelviews>\n");
      String s = (String)e.nextElement();
      buf.append (space+space+"<key>"+s+"</key>\n");
      Hashtable h = (Hashtable)openedModelViews.get(s);
      Enumeration en = h.keys();
      while(en.hasMoreElements()){
        buf.append (space+space+"<hash>\n");
        String ss = (String)en.nextElement();
        buf.append (space+space+space+"<hashkey>"+ss+"</hashkey>\n");
        String name = (String)h.get(s);
        buf.append (space+space+space+"<hashvalue>"+name+"</hashvalue>\n");
        buf.append (space+space+"</hash>\n");
      }
      buf.append (space+"</openedmodelviews>\n");
    }
  }*/

    private void getXMLForOpenedModelViews(StringBuffer buf){
    }
    /**
     * close this model project
     */
    public void doCloseModelProject(DefaultMutableTreeNode dmtn){}

    /**
     * return all registereed model views
     * @return a vector holds all registered model views
     */
    public Vector getRegisteredModelViews(){
        return registeredModelViews;
    }

    /**
     * register a defined metamodel view
     * @param name the name of the view
     */
    //public void registerModelView(String name){
    //registeredModelViews.add(name);
    //}
    public Hashtable getOpenedModelViews(){
        return openedModelViews;
    }


    private void init(String type){
        for(int i = 0; i < tool.getRegisteredViewTypes().size(); i++){
            String s = (String)tool.getRegisteredViewTypes().get(i);
            DefaultMutableTreeNode node = new DefaultMutableTreeNode(s);
            manager.getNodeAndItsValueMapping().put(node, node.getUserObject());
            projectNode.add(node);
            viewTypeNameAndNodeMapping.put(s, node);
            PounamuTabbedPane tab = new PounamuTabbedPane(this);
            nodeAndViewsTabMapping.put(node, tab);
            projectTab.addTab(s, tab);
            viewsTabAndNodeMapping.put(tab, node);
            nodeAndMenuItemsMapping.put(node, initMenuItemsForViewTypeNode(s));
            nodeAndToolButtonsMapping.put(node, initToolButtonsForViewTypeNode(s));
            manager.getNodeAndProjectMapping().put(node, this);
        }
    }

    /**
     * init menu items for a model view node
     * @param s the name of the model view
     * @return a vector holds all menu items related to this model view node
     */
    public Vector initMenuItemsForModelViewNode(String s){
        //System.out.println("S is " + s);
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("rename this view");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
    /*jmi = new JMenuItem("enter select state");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("select");
      }
    });
    menuItems.add(jmi);
    jmi = new JMenuItem("enter edit state");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("edit");
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
    /*jmi = new JMenuItem("save this view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveView();
        if(!registeredModelViews.contains((String)manager.getSelectedNode().getUserObject()))
          registerModelView((String)manager.getSelectedNode().getUserObject());
      }
    });
    menuItems.add(jmi);
    menuItems.add(null);*/
        jmi = new JMenuItem("show xml for this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuView view = getView(manager.getSelectedNode());
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(panel.getXML());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 600);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("save this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("remove this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAModelView(manager.getSelectedNode());
                //PounamuView view = getView(manager.getSelectedNode());
                //ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                //panel.setState("select");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        return menuItems;
    }

    /**
     * init menu items for a model view node
     * @param s the name of the model view
     * @return a vector holds all menu items related to this model view node
     */
    public Vector initToolButtonsForModelViewNode(String s){
        //System.out.println("S is " + s);
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("rename this view");
        jmi.setToolTipText("function: " + "rename this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                manager.getManagerTree().startEditingAtPath(manager.getManagerTree().getSelectionPath());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
    /*jmi = new JButton("enter select state");
    jmi.setToolTipText("function: " + "enter select state");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        panel.setState("select");
      }
    });
    toolButtons.add(jmi);
    toolButtons.add(null);
    jmi = new JButton("register this view");
    jmi.setToolTipText("function: " + "register this view");
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        doSaveView();
        if(!registeredModelViews.contains((String)manager.getSelectedNode().getUserObject()))
          registerModelView((String)manager.getSelectedNode().getUserObject());
      }
    });
    toolButtons.add(jmi);
    toolButtons.add(null);*/
        jmi = new JButton("show xml for this view");
        jmi.setToolTipText("function: " + "show xml for this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuView view = getView(manager.getSelectedNode());
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(panel.getXML());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 600);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("save this view");
        jmi.setToolTipText("function: " + "save this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("remove this view");
        jmi.setToolTipText("function: " + "remove this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAModelView(manager.getSelectedNode());
                //PounamuView view = getView(manager.getSelectedNode());
                //ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                //panel.setState("select");
            }
        });
        toolButtons.add(jmi);

        return toolButtons;
    }




    /**
     * create a new model object
     * @param type the type of the new object
     */
  /*public void doCreatNewModelObject(String type){
    PounamuView view = getView(manager.getSelectedNode());
    NewObjectDialogForModelView dialog = new NewObjectDialogForModelView(this, tool, view, type);
    dialog.setVisible(true);
  }*/
    public void doCreateNewEntity(String type){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        PounamuModelElement pme = new PounamuModelElement(type+"_"+entityCount, type, this);
        entityCount++;
        panel.setState("addentity");
        panel.setCurrentObject(pme);
    }

    public void doCreateNewAssociation(String type){
        //System.out.println("here visited in Modleerpanel");
        PounamuView view = getView(manager.getSelectedNode());
        //System.out.println("here visited in Modleerpanel");
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        //System.out.println("here visited in Modleerpanel");
        PounamuModelElement pme = new PounamuModelElement(type+"_"+associationCount, type, this);
        //System.out.println("here visited in Modleerpanel");
        associationCount++;
        panel.setState("addassociation");
        panel.setCurrentObject(pme);
        panel.setAllShapesSelected(true);
        panel.setIdleCursors();
    }


    /**
     * init menu items for the view type node
     * @param s the name of the view type
     * @return A vectoor holds all menu items related to the view type node
     */
    public Vector initMenuItemsForViewTypeNode(String s){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("create a new "+s+" view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCreatNewModelView();
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("open an existed "+s+" view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenExistedModelView();
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("remove all "+s+" views");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllModelViewsOfAType(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        return menuItems;
    }

    /**
     * init menu items for the view type node
     * @param s the name of the view type
     * @return A vectoor holds all menu items related to the view type node
     */
    public Vector initToolButtonsForViewTypeNode(String s){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("create a new "+s+" view");
        jmi.setToolTipText("function: " + "Open a new "+s+" view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doCreatNewModelView();
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("open an existed "+s+" view");
        jmi.setToolTipText("function: " + "Open an existed "+s+" view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doOpenExistedModelView();
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("remove all "+s+" views");
        jmi.setToolTipText("function: " + "remove all "+s+" views");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllModelViewsOfAType(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        return toolButtons;
    }

    /**
     * create a new model view
     */
    public void doCreatNewModelView(){
        String type = (String)((DefaultMutableTreeNode)manager.getSelectedNode()).getUserObject();
        Hashtable hash = (Hashtable)openedModelViews.get(type);
        String name = type+"_"+viewCount;
        viewCount++;
        PounamuView view = new PounamuView(type, name, this, pounamu);
        hash.put(name, view);
        //registerModelView(name);
        //openedModelViews.put(name,
        ModellerPanel mp = new ModellerPanel(this, "modelview", view);
        view.setDisplayPane(mp);
        registerVisualEventHandlers(view, type);
        registerVisualUserHandlers(view, type);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndItsValueMapping().put(dmtn, name);
        manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dmtn, view);
        nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelViewNode(type));
        nodeAndToolButtonsMapping.put(dmtn, initToolButtonsForModelViewNode(type));
        iconAndNodeMapping.put(mp, dmtn);
        getViewsTab(manager.getSelectedNode()).addTab(name, mp);
        getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
        viewTabAndNodeMapping.put(mp, dmtn);
        nodeAndIconMapping.put(dmtn, mp);
        ////////////////////////////////////////////////////////////////////
        DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity");
        manager.getNodeAndItsValueMapping().put(dm, "entity");
        manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dm, view);
        nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityNode());
        nodeAndToolButtonsMapping.put(dm, initToolButtonsForEntityNode());
        DefaultMutableTreeNode dn = new DefaultMutableTreeNode("association");
        manager.getNodeAndItsValueMapping().put(dn, "association");
        manager.getNodeAndProjectMapping().put(dn, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dn, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dn, view);
        nodeAndMenuItemsMapping.put(dn, initMenuItemsForAssociationNode());
        nodeAndToolButtonsMapping.put(dn, initToolButtonsForAssociationNode());
        dmtn.add(dm);
        dmtn.add(dn);
        //Vector allowedTypes = (Vector)tool.getViewTypeAndAllowedMetaModelTypesMapping().get(type);
        Vector allowedEntityTypes = (Vector)tool.getViewTypeAndAllowedEntityTypesMapping().get(type);
        Vector allowedAssociationTypes = (Vector)tool.getViewTypeAndAllowedAssociationTypesMapping().get(type);
        ///////////////////////////////////////////////////////////////////////
        for(int i = 0; i < allowedEntityTypes.size(); i++){
            DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedEntityTypes.get(i));
            manager.getNodeAndItsValueMapping().put(d, (String)allowedEntityTypes.get(i));
            manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
            nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
            nodeAndViewMapping.put(d, view);
            nodeAndMenuItemsMapping.put(d, initMenuItemsForEntityTypeNode());
            nodeAndToolButtonsMapping.put(d, initToolButtonsForEntityNode());
            dm.add(d);
        }
        for(int i = 0; i < allowedAssociationTypes.size(); i++){
            DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedAssociationTypes.get(i));
            manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
            manager.getNodeAndItsValueMapping().put(d, (String)allowedAssociationTypes.get(i));
            nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
            nodeAndViewMapping.put(d, view);
            nodeAndMenuItemsMapping.put(d, initMenuItemsForAssociationTypeNode());
            nodeAndToolButtonsMapping.put(d, initToolButtonsForAssociationTypeNode());
            dn.add(d);
        }
        manager.addTreeNode(dmtn);
        TreePath tp = new TreePath(dmtn.getPath());
        managerTree.setSelectionPath(tp);
        pounamu.validate();
    }

    public Vector initMenuItemsForEntityNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("remove all entities in this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllEntitiesFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    public Vector initToolButtonsForEntityNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("remove all entities in this view");
        jmi.setToolTipText("function: " + "close all entities in this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllEntitiesFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    public Vector initMenuItemsForAssociationNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("remove all associations in this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllAssociationsFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    public Vector initToolButtonsForAssociationNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("remove all associations in this view");
        jmi.setToolTipText("function: " + "remove all associations in this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllAssociationsFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    public Vector initToolButtonsForAssociationTypeNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("remove all associations of this type from this view");
        jmi.setToolTipText("function: " + "remove all associations of this type from this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllAssociationsOfATypeFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    public Vector initMenuItemsForAssociationTypeNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("remove all associations of this type from this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllAssociationsOfATypeFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    public Vector initToolButtonsForEntityTypeNode(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("remove all entities of this type from this view");
        jmi.setToolTipText("function: " + "remove all entities of this type from this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllEntitiesOfATypeFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        return toolButtons;
    }

    public Vector initMenuItemsForEntityTypeNode(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("remove all entities of this type from this view");
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAllEntitiesOfATypeFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        return menuItems;
    }

    public void registerModelEventHandlers(){
        //Hashtable h = tool.getCurrentRegisteredModelHandlers();
        Hashtable h = tool.getRegisteredModelEventHandlers();
        Enumeration e = h.keys();
        while (e.hasMoreElements()){
            try{
                String name = (String)e.nextElement();
                String encodedName = (String)h.get(name);
                Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.modelhandlers.eventtriggeringhandlers."+encodedName);
                PounamuModelHandler handler = (PounamuModelHandler)c.newInstance();
                handler.setModel(this);
                modelEventHandlers.add(handler);
            }
            catch(Exception ee){
                pounamu.displayMessage(ee.toString());
            }
        }
    }

    public void registerModelUserHandlers(){
        //Hashtable h = tool.getCurrentRegisteredModelHandlers();
        Hashtable h = tool.getRegisteredModelUserHandlers();
        Enumeration e = h.keys();
        while (e.hasMoreElements()){
            try{
                String name = (String)e.nextElement();
                String encodedName = (String)h.get(name);
                Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.modelhandlers.usertriggeringhandlers."+encodedName);
                PounamuModelHandler handler = (PounamuModelHandler)c.newInstance();
                handler.setModel(this);
                modelUserHandlers.add(handler);
                String menuItemText = handler.getMenuItemText();
                JMenuItem jmi = new JMenuItem(menuItemText);
                jmi.setVisible(true);
                menuItemsAndModelUserHandlersMapping.put(jmi, handler);
                jmi.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent ev){
                        JMenuItem item = (JMenuItem)ev.getSource();
                        PounamuUserTriggeringHandler ha = (PounamuUserTriggeringHandler)(menuItemsAndModelUserHandlersMapping.get(item));
                        ha.execute();
                    }
                });
            }
            catch(Exception ee){
                pounamu.displayMessage(ee.toString());
            }
        }
    }

    public void registerModelEventHandler(String name){
        //Hashtable h = tool.getCurrentRegisteredModelHandlers();
        Hashtable h = tool.getRegisteredModelEventHandlers();
        String encodedName = (String)h.get(name);
        try{
            Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.modelhandlers.eventtriggeringhandlers."+encodedName);
            PounamuModelHandler handler = (PounamuModelHandler)c.newInstance();
            handler.setModel(this);
            modelEventHandlers.add(handler);
        }
        catch(Exception e){
            pounamu.displayMessage(e.toString());
        }
    }

    public void registerModelUserHandler(String name){
        //Hashtable h = tool.getCurrentRegisteredModelHandlers();
        Hashtable h = tool.getRegisteredModelUserHandlers();
        String encodedName = (String)h.get(name);
        try{
            Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.modelhandlers.usertriggeringhandlers."+encodedName);
            PounamuModelHandler handler = (PounamuModelHandler)c.newInstance();
            handler.setModel(this);
            modelUserHandlers.add(handler);
        }
        catch(Exception e){
            pounamu.displayMessage(e.toString());
        }
    }


    /**
     * register all allowed visual event handlers to the specified modeller panel
     * @param panel the model panel the handlers will be registered to
     * @param type the view type of this panel
     */
    public void registerVisualEventHandlers(PounamuView view, String type){
        Vector v = tool.getAllowedVisualEventHandlers(type);
        for(int i = 0; i < v.size(); i++){
            try{
                String name = (String)v.get(i);
                String encodedName = (String)tool.getRegisteredVisualEventHandlers().get(name);
                Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.visualhandlers.eventtriggeringhandlers."+encodedName);
                PounamuVisualHandler handler = (PounamuVisualHandler)c.newInstance();
                handler.setView(view);
                ((ModellerPanel)view.getDisplayPanel()).addVisualEventHandler(handler);
            }
            catch(Exception e){
                pounamu.displayMessage(e.toString());
            }
        }
    }

    /**
     * register all allowed visual user handlers to the specified modeller panel
     * @param panel the model panel the handlers will be registered to
     * @param type the view type of this panel
     */
    public void registerVisualUserHandlers(PounamuView view, String type){
        Vector v = tool.getAllowedVisualUserHandlers(type);
        for(int i = 0; i < v.size(); i++){
            try{
                String name = (String)v.get(i);
                String encodedName = (String)tool.getRegisteredVisualUserHandlers().get(name);
                Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.visualhandlers.usertriggeringhandlers."+encodedName);
                PounamuVisualHandler handler = (PounamuVisualHandler)c.newInstance();
                handler.setView(view);
                ((ModellerPanel)view.getDisplayPanel()).addVisualUserHandler(handler);
            }
            catch(Exception e){
                pounamu.displayMessage(e.toString());
            }
        }
    }

    public void re_registerVisualEventHandlers(){
        //removeAllHandlers();
        for (Enumeration e = openedModelViews.keys() ; e.hasMoreElements() ;) {
            String key = (String)e.nextElement();
            Hashtable hash = (Hashtable)openedModelViews.get(key);
            for (Enumeration ee = hash.keys() ; ee.hasMoreElements() ;) {
                String keyy = (String)ee.nextElement();
                PounamuView view = (PounamuView)hash.get(keyy);
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                panel.removeAllVisualEventHandlers();
                String type = view.getType();
                Vector v = tool.getAllowedVisualEventHandlers(type);
                for(int i = 0; i < v.size(); i++){
                    try{
                        String name = (String)v.get(i);
                        String encodedName = (String)tool.getRegisteredVisualEventHandlers().get(name);
                        //System.out.println("name is "+ name);
                        //System.out.println("encodedName is "+ encodedName);
                        Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.visualhandlers.eventtriggeringhandlers."+encodedName);
                        PounamuVisualHandler handler = (PounamuVisualHandler)c.newInstance();
                        handler.setView(view);
                        //System.out.println("handler is " + handler.toString());
                        panel.addVisualEventHandler(handler);
              /*if(handler.getType().equals("model"))
                if(!eventHandlers.contains(handler))
                  eventHandlers.add(handler);*/
                    }
                    catch(Exception eeee){
                        pounamu.displayMessage(eeee.toString());
                    }
                }
            }
        }
    }

    public void re_registerVisualUserHandlers(){
        //removeAllHandlers();
        for (Enumeration e = openedModelViews.keys() ; e.hasMoreElements() ;) {
            String key = (String)e.nextElement();
            Hashtable hash = (Hashtable)openedModelViews.get(key);
            for (Enumeration ee = hash.keys() ; ee.hasMoreElements() ;) {
                String keyy = (String)ee.nextElement();
                PounamuView view = (PounamuView)hash.get(keyy);
                ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
                panel.removeAllVisualUserHandlers();
                String type = view.getType();
                Vector v = tool.getAllowedVisualUserHandlers(type);
                for(int i = 0; i < v.size(); i++){
                    try{
                        String name = (String)v.get(i);
                        String encodedName = (String)tool.getRegisteredVisualUserHandlers().get(name);
                        //System.out.println("name is "+ name);
                        //System.out.println("encodedName is "+ encodedName);
                        Class c = Class.forName("pounamu.tools."+tool.getName()+".handlers.visualhandlers.usertriggeringhandlers."+encodedName);
                        PounamuVisualHandler handler = (PounamuVisualHandler)c.newInstance();
                        handler.setView(view);
                        //System.out.println("handler is " + handler.toString());
                        panel.addVisualEventHandler(handler);
              /*if(handler.getType().equals("model"))
                if(!eventHandlers.contains(handler))
                  eventHandlers.add(handler);*/
                    }
                    catch(Exception eeee){
                        pounamu.displayMessage(eeee.toString());
                    }
                }
            }
        }
    }

    /**
     * open an existed model view
     */
    public void doOpenExistedModelView(){
    /*DefaultMutableTreeNode dmtn = manager.getSelectedNode();
    String type = (String)dmtn.getUserObject();
    Hashtable hash = (Hashtable)openedModelViews.get(type);
    File inputFile = null;
    pounamu.getFileChooser().setCurrentDirectory(new File(getLocation()+""+fileSeparator+"views"+fileSeparator+""));
    pounamu.getFileChooser().setFileSelectionMode(JFileChooser.FILES_ONLY);
    int returnVal = pounamu.getFileChooser().showDialog(pounamu, "Open this view");
    if(returnVal == JFileChooser.APPROVE_OPTION){
      inputFile = pounamu.getFileChooser().getSelectedFile();
    }
    else return;
    String fileName = inputFile.getName();
    if(!(fileName.startsWith(type)&&fileName.endsWith(".xml"))){
      pounamu.displayMessage("The file you chose is not a proper "+type+" view file! Please try another one!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    String name = fileName.substring(0, fileName.indexOf("."));
    if(hash.containsKey(name)){
      pounamu.displayMessage("A view with the same name already existed. Please choose another file of view!\n");
      Toolkit.getDefaultToolkit().beep();
      return;
    }
    PounamuView view = new PounamuView(type, name, this, pounamu);
    hash.put(name, view);
    registerModelView(name);
    LoadXMLFile lxf = new LoadXMLFile(inputFile);
    ModellerPanel mp = new ModellerPanel(this, "modelview", view);
    registerVisualHandlers(view, type);
    dmtn = new DefaultMutableTreeNode(name);
    view.setDisplayPane(mp);
    manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dmtn, view);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelViewNode(type));
    nodeAndToolButtonsMapping.put(dmtn, initToolButtonsForModelViewNode(type));
    getViewsTab(manager.getSelectedNode()).addTab(name, mp);
    getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
    viewTabAndNodeMapping.put(mp, dmtn);
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.validate();
    RestoreModelViewFromXML restore = new RestoreModelViewFromXML(lxf.getDocument(), mp);
    restore.restore();*/
    }

    /**
     * open an existed model view specified by view type and name.
     * @param type the type of the existed model view
     * @param name the name of the existed model view
     */
    public void doOpenExistedModelView(String type, String name){
        Hashtable hash = (Hashtable)openedModelViews.get(type);
        File inputFile = new File(getLocation()+""+fileSeparator+"views"+fileSeparator+""+type+""+fileSeparator+""+name+".xml");
        PounamuView view = new PounamuView(type, name, this, pounamu);
        //registerModelView(name);
        hash.put(name, view);
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        ModellerPanel mp = new ModellerPanel(this, "modelview", view);
        view.setDisplayPane(mp);
        registerVisualEventHandlers(view, type);
        registerVisualUserHandlers(view, type);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndItsValueMapping().put(dmtn, name);
        manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dmtn, view);
        nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelViewNode(type));
        nodeAndToolButtonsMapping.put(dmtn, initToolButtonsForModelViewNode(type));
        iconAndNodeMapping.put(mp, dmtn);
        getViewsTab(manager.getSelectedNode()).addTab(name, mp);
        getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
        viewTabAndNodeMapping.put(mp, dmtn);
        ///////////////////////////////////////////////////////////////////////////////////////////
        DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity");
        manager.getNodeAndItsValueMapping().put(dm, "entity");
        manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dm, view);
        nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityNode());
        nodeAndToolButtonsMapping.put(dm, initToolButtonsForEntityNode());
        DefaultMutableTreeNode dn = new DefaultMutableTreeNode("association");
        manager.getNodeAndItsValueMapping().put(dn, "association");
        manager.getNodeAndProjectMapping().put(dn, manager.getProject(manager.getSelectedNode()));
        nodeAndViewsTabMapping.put(dn, getViewsTab(manager.getSelectedNode()));
        nodeAndViewMapping.put(dn, view);
        nodeAndMenuItemsMapping.put(dn, initMenuItemsForAssociationNode());
        nodeAndToolButtonsMapping.put(dn, initToolButtonsForAssociationNode());
        dmtn.add(dm);
        dmtn.add(dn);
        Vector allowedEntityTypes = (Vector)tool.getViewTypeAndAllowedEntityTypesMapping().get(type);
        Vector allowedAssociationTypes = (Vector)tool.getViewTypeAndAllowedAssociationTypesMapping().get(type);
        ///////////////////////////////////////////////////////////////////////
        for(int i = 0; i < allowedEntityTypes.size(); i++){
            DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedEntityTypes.get(i));
            manager.getNodeAndItsValueMapping().put(d, (String)allowedEntityTypes.get(i));
            manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
            nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
            nodeAndViewMapping.put(d, view);
            nodeAndMenuItemsMapping.put(d, initMenuItemsForEntityNode());
            nodeAndToolButtonsMapping.put(d, initToolButtonsForEntityNode());
            //System.out.println("key for entity is " + view.getName()+"_"+(String)allowedEntityTypes.get(i));
            tempHashForOpenModel.put(view.getName()+"_"+(String)allowedEntityTypes.get(i), d);
            dm.add(d);
        }
        for(int i = 0; i < allowedAssociationTypes.size(); i++){
            DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedAssociationTypes.get(i));
            manager.getNodeAndItsValueMapping().put(d, (String)allowedAssociationTypes.get(i));
            manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
            nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
            nodeAndViewMapping.put(d, view);
            nodeAndMenuItemsMapping.put(d, initMenuItemsForAssociationNode());
            nodeAndToolButtonsMapping.put(d, initToolButtonsForAssociationNode());
            //System.out.println("key for association is " + view.getName()+"_"+(String)allowedAssociationTypes.get(i));
            tempHashForOpenModel.put(view.getName()+"_"+(String)allowedAssociationTypes.get(i), d);
            dn.add(d);
        }
        /////////////////////////////////////////////////////////////
        manager.addTreeNode(dmtn);
        TreePath tp = new TreePath(dmtn.getPath());
        managerTree.setSelectionPath(tp);
        pounamu.validate();
        RestoreModelViewFromXML restore = new RestoreModelViewFromXML(lxf.getDocument(), mp);
        restore.restore();
    }


    /**
     * close the meta model view specified by the node
     */
    public void doRemoveAModelView(DefaultMutableTreeNode dmtn){
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)dmtn.getFirstChild();
        doRemoveAllEntitiesFromAView(node);
        manager.removeTreeNode(dmtn);
        JTabbedPane tab = (JTabbedPane)getNodeAndViewsTabMapping().get(dmtn);
        PounamuView vi = (PounamuView)getNodeAndViewMapping().get(dmtn);
        tab.remove(vi.getDisplayPanel());
        //registeredModelViews.remove((String)dmtn.getUserObject());
        Hashtable hash = (Hashtable)openedModelViews.get(vi.getType());
        hash.remove((String)dmtn.getUserObject());
        manager.getNodeAndProjectMapping().remove(dmtn);
        this.getNodeAndViewsTabMapping().remove(dmtn);
        this.getNodeAndViewMapping().remove(dmtn);
        //this.getNodeAndEntityMapping().put(dmtn, pme);
        //this.getNodeAndIconMapping().put(dmtn, basePanel);
        this.getNodeAndMenuItemsMapping().remove(dmtn);
        this.getNodeAndToolButtonsMapping().remove(dmtn);
        //this.getIconAndNodeMapping().put(basePanel, dmtn);
        //this.getNodeAndSavedXMLStringMapping().remove(dmtn);
    }

    public void doRemoveAllModelViewsOfAType(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            doRemoveAModelView((DefaultMutableTreeNode)v.get(i));
        }
    /*manager.getNodeAndProjectMapping().remove(dmtn);
    this.getNodeAndViewsTabMapping().remove(dmtn);
    //this.getNodeAndViewMapping().remove(dmtn);
    //this.getNodeAndEntityMapping().put(dmtn, pme);
    //this.getNodeAndIconMapping().put(dmtn, basePanel);
    this.getNodeAndMenuItemsMapping().remove(dmtn);
    this.getNodeAndToolButtonsMapping().remove(dmtn);
    //this.getIconAndNodeMapping().put(basePanel, dmtn);
    //this.getNodeAndSavedXMLStringMapping().remove(dmtn); */
    }

    public void doRemoveAllEntitiesOfATypeFromAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            doRemoveAnEntityFromAView((DefaultMutableTreeNode)v.get(i));
        }
    /*manager.getNodeAndProjectMapping().remove(dmtn);
    this.getNodeAndViewsTabMapping().remove(dmtn);
    this.getNodeAndViewMapping().remove(dmtn);
    //this.getNodeAndEntityMapping().put(dmtn, pme);
    //this.getNodeAndIconMapping().put(dmtn, basePanel);
    this.getNodeAndMenuItemsMapping().remove(dmtn);
    this.getNodeAndToolButtonsMapping().remove(dmtn);
    //this.getIconAndNodeMapping().put(basePanel, dmtn);
    //this.getNodeAndSavedXMLStringMapping().remove(dmtn); */
    }

    public void doRemoveAllAssociationsOfATypeFromAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            doRemoveAnAssociationFromAView((DefaultMutableTreeNode)v.get(i));
        }
    /*manager.getNodeAndProjectMapping().remove(dmtn);
    this.getNodeAndViewsTabMapping().remove(dmtn);
    this.getNodeAndViewMapping().remove(dmtn);
    //this.getNodeAndEntityMapping().put(dmtn, pme);
    //this.getNodeAndIconMapping().put(dmtn, basePanel);
    this.getNodeAndMenuItemsMapping().remove(dmtn);
    this.getNodeAndToolButtonsMapping().remove(dmtn);
    //this.getIconAndNodeMapping().put(basePanel, dmtn);
    //this.getNodeAndSavedXMLStringMapping().remove(dmtn);  */
    }
    /**
     * extends the super abstract method, not applicable for modell project
     * @param node the index node
     * @return null.
     */
    public Component getComponent(DefaultMutableTreeNode node){
        return null;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @return null.
     */
    public Hashtable getNodeAndComponentMapping(){
        return null;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @return null.
     */
    public Hashtable getNodeAndIconMapping(){
        return nodeAndIconMapping;
    }

    public Hashtable getNodeAndSavedXMLStringMapping(){
        return nodeAndSavedXMLStringMapping;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @return null.
     */
    public Hashtable getNodeAndEntityTypeObjectMapping(){
        return null;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @return null.
     */
    public PounamuMetaModelElement getEntityTypeObject(DefaultMutableTreeNode node){
        return null;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @return null.
     */
    public Hashtable getNodeAndAssociationTypeObjectMapping(){
        return null;
    }

    /**
     * extends the super abstract method, not applicable for modell project
     * @param node the index node
     * @return null.
     */
    public PounamuMetaModelElement getAssociationTypeObject(DefaultMutableTreeNode node){
        return null;
    }

    public Vector getEntities(String entityType){
        return (Vector)entities.get(entityType);
    }

    public Vector getAssociations(String associationType){
        return (Vector)associations.get(associationType);
    }

    public void addEntity(PounamuModelElement entity){
        entity.setIconNumber(entity.getIconNumber()+1);
        String entityType = entity.getType();
        Vector  v = (Vector)entities.get(entityType);
        if(v != null){
            if(!(v.contains(entity)))
                v.add(entity);
            NewEntityEvent nee = new NewEntityEvent(this, entity);
            eventReceived(nee);
        }
        else{
            v = new Vector();
            v.add(entity);
            entities.put(entityType, v);
        }
    }

    public void addAssociation(PounamuModelElement association){
        association.setIconNumber(association.getIconNumber()+1);
        String associationType = association.getType();
        Vector  v = (Vector)associations.get(associationType);
        if(v != null){
            if(!(v.contains(association)))
                v.add(association);
        }
        else{
            v = new Vector();
            v.add(association);
            associations.put(associationType, v);
        }
    }


     public boolean existedEntityWithTypeAndKey(String type, String key){
        Vector v = (Vector)entities.get(type);
        if(v == null)
            return false;
        for(int i = 0; i < v.size(); i++){
            PounamuModelElement entity = (PounamuModelElement)v.get(i);
            if(entity.getKey().equals(key)){
                return true;
            }
        }
        return false;
    }

    public boolean existedAssociationWithTypeAndKey(String type, String key){
        Vector v = (Vector)associations.get(type);
        if(v == null)
            return false;
        for(int i = 0; i < v.size(); i++){
            PounamuModelElement association = (PounamuModelElement)v.get(i);
            if(association.getKey().equals(key)){
                return true;
            }
        }
        return false;
    }

    public PounamuModelElement getEntityByTypeAndKey(String type, String key){
        Vector v = (Vector)entities.get(type);
        if(v == null)
            return null;
        for(int i = 0; i < v.size(); i++){
            PounamuModelElement entity = (PounamuModelElement)v.get(i);
            if(entity.getKey().equals(key)){
                return entity;
            }
        }
        return null;
    }
    public PounamuModelElement getAssociationByTypeAndKey(String type, String key){
        Vector v = (Vector)associations.get(type);
        if(v == null)
            return null;
        for(int i = 0; i < v.size(); i++){
            PounamuModelElement association = (PounamuModelElement)v.get(i);
            if(association.getKey().equals(key)){
                return association;
            }
        }
        return null;
    }

    public void removeEntity(PounamuModelElement entity){
        entity.setIconNumber(entity.getIconNumber()-1);
        String entityType = entity.getType();
        Vector  v = (Vector)entities.get(entityType);
        if(v == null)
            return;
        if(v.contains(entity)&&entity.getIconNumber()==0){
            v.remove(entity);
            RemoveEntityEvent ree = new RemoveEntityEvent(this, entity);
            eventReceived(ree);
        }
        if(v.size() == 0)
            entities.remove(entityType);
    }

    public void removeAssociation(PounamuModelElement association){
        association.setIconNumber(association.getIconNumber()-1);
        String associationType = association.getType();
        Vector  v = (Vector)associations.get(associationType);
        if(v == null)
            return;
        if(v.contains(association)&&association.getIconNumber()==0){
            v.remove(association);
            RemoveAssociationEvent ree = new RemoveAssociationEvent(this, association);
            eventReceived(ree);
        }
        if(v.size() == 0)
            associations.remove(associationType);
    }


    /**
     * get the hashtable holds the mappings from the index node to the entity object
     * @return the hashtable holds the mappings from the index node to the entity object
     */
  /*public Hashtable getNodeAndEntityMapping(){
    return nodeAndEntityMapping;
  }*/

    /**
     * get an entity object indexed by the specified node
     * @param node the index node
     * @return the entity object indexed by the specified node
     */
    public PounamuModelElement getEntity(DefaultMutableTreeNode node){
        Object o = getNodeAndIconMapping().get(node);
        if(o instanceof PounamuPanel){
            PounamuShape shape = ((PounamuPanel)o).getPounamuShape();
            return (PounamuModelElement)shape.getRelatedObject();
        }
        else
            return null;
    }

    public PounamuModelElement getEntity(String type, String name){
        Vector v = (Vector)entities.get(type);
        if(v == null)
            return null;
        else{
            for(int i = 0; i < v.size(); i++){
                PounamuModelElement entity = (PounamuModelElement)v.get(i);
                if(entity.getName().equals(name))
                    return entity;
            }
            return null;
        }
    }

    public PounamuModelElement getAssociation(String type, String name){
        Vector v = (Vector)associations.get(type);
        if(v == null)
            return null;
        else{
            for(int i = 0; i < v.size(); i++){
                PounamuModelElement association = (PounamuModelElement)v.get(i);
                if(association.getName().equals(name))
                    return association;
            }
            return null;
        }
    }


    /**
     * get the hashtable holds the mappings from the index node to the association object
     * @return the hashtable holds the mappings from the index node to the association object
     */
  /*public Hashtable getNodeAndAssociationMapping(){
    return nodeAndAssociationMapping;
  }*/

    /**
     * get an association object indexed by the specified node
     * @param node the index node
     * @return the association object indexed by the specified node
     */
    public PounamuModelElement getAssociation(DefaultMutableTreeNode node){
        Object o = getNodeAndIconMapping().get(node);
        if(o instanceof PounamuConnector)
            return (PounamuModelElement)((PounamuConnector)o).getRelatedObject();
        else
            return null;
    }

    /**
     * accept the event and then pass them to all of the registered handlers
     * @param event
     */
    public void eventReceived(PounamuEvent event){
        Enumeration e = modelEventHandlers.elements();
        while(e.hasMoreElements()) {
            PounamuHandler handler = (PounamuHandler)e.nextElement();
            ((PounamuEventTriggeringHandler)handler).eventReceived(event);
        }
    }

    /**
     * add a new model event handler to the handler vector
     * @param object the new handler
     */
    public void addModelEventHandler(PounamuHandler object){
        modelEventHandlers.addElement(object);
    }

    /**
     * add a new model user handler to the handler vector
     * @param object the new handler
     */
    public void addModelUserHandler(PounamuHandler object){
        modelUserHandlers.addElement(object);
    }


    /**
     * remove a registered model event handler
     * @param object the handler to be removed
     */
    public void removeModelEventHandler(PounamuHandler object){
        modelEventHandlers.removeElement(object);
    }

    /**
     * remove a registered model user handler
     * @param object the handler to be removed
     */
    public void removeModelUserHandler(PounamuHandler object){
        modelUserHandlers.removeElement(object);
    }

    public void removeAllModelEventHandlers(){
        modelEventHandlers.removeAllElements();
    }

    public void removeAllModelUserHandlers(){
        modelUserHandlers.removeAllElements();
    }


    /**
     * init menu items for entity object
     * @return a vector holds all available menu items for this entity
     */
    public Vector initMenuItemsForEntity(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("map to an existed entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ExistedModelElementChooser chooser = new ExistedModelElementChooser(PounamuModelProject.this, manager.getSelectedNode(), "entity");
                chooser.setVisible(true);
            }
        });
        menuItems.add(jmi);
    /*jmi = new JMenuItem("open from a xml file");
    jmi.setVisible(true);
    jmi.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent ev){
        ExistedModelElementChooser chooser = new ExistedModelElementChooser(PounamuModelProject.this, manager.getSelectedNode(), "association");
        chooser.setVisible(true);
      }
    });
    menuItems.add(jmi);*/
        menuItems.add(null);
        jmi = new JMenuItem("view xml for this entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuModelElement object = getEntity(manager.getSelectedNode());
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(object.getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 400);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("save this entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAnEntity(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("save this entity as");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doRemoveEntity(manager.getSelectedNode());
            }
        });
        //menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("remove this entity from this view");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAnEntityFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("remove this entity from this model");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveEntityFromModel(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("bring to front");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "front");
            }
        });
        menuItems.add(jmi);
        //menuItems.add(null);
        jmi = new JMenuItem("push to back");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "back");
            }
        });
        menuItems.add(jmi);
        //menuItems.add(null);
        jmi = new JMenuItem("forward one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "forward");
            }
        });
        menuItems.add(jmi);
        //menuItems.add(null);
        jmi = new JMenuItem("down one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "backward");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        return menuItems;
    }

    /**
     * init menu items for entity object
     * @return a vector holds all available menu items for this entity
     */
    public Vector initToolButtonsForEntity(){
        Vector toolButtons = new Vector();
        // Icon icon = new ImageIcon(PounamuModelProjct.class.getResource(tool.getLocation()+""+fileSeparator+"images"+fileSeparator+"defaultnode.gif"));
        JButton jmi = new JButton("map to an existed entity");
        jmi.setToolTipText("function: " + "map to an existed entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                ExistedModelElementChooser chooser = new ExistedModelElementChooser(PounamuModelProject.this, manager.getSelectedNode(), "entity");
                chooser.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("view xml for this entity");
        jmi.setToolTipText("function: " + "view xml for this entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuModelElement object = getEntity(manager.getSelectedNode());
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(object.getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 400);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("save this entity");
        jmi.setToolTipText("function: " + "save this entity");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAnEntity(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("save this entity as");
        jmi.setToolTipText("function: " + "save this entity as");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doRemoveEntity(manager.getSelectedNode());
            }
        });
        //toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("remove this entity from this view");
        jmi.setToolTipText("function: " + "remove this entity from this view");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAnEntityFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("remove this entity from this model");
        jmi.setToolTipText("function: " + "remove this entity from this model");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveEntityFromModel(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("bring to front");
        jmi.setToolTipText("function: " + "bring to front");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "front");
            }
        });
        toolButtons.add(jmi);
        //toolButtons.add(null);
        jmi = new JButton("push to back");
        jmi.setToolTipText("function: " + "push to back");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "back");
            }
        });
        toolButtons.add(jmi);
        //toolButtons.add(null);
        jmi = new JButton("forward one level");
        jmi.setToolTipText("function: " + "forward one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "forward");
            }
        });
        toolButtons.add(jmi);
        //toolButtons.add(null);
        jmi = new JButton("down one level");
        jmi.setToolTipText("function: " + "down one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "backward");
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        return toolButtons;
    }

    public void changeIconPositionInZCoordinate(ActionEvent ev, String type){

        Object o = getIcon(manager.getSelectedNode());
        if(o instanceof PounamuShape){
            PounamuShape shape = (PounamuShape)o;
            if(type.equals("front"))
                shape.upToTop();
            else if(type.equals("back"))
                shape.downToBottom();
            else if(type.equals("forward"))
                shape.upOneLevel();
            else if(type.equals("backward"))
                shape.downOneLevel();
        }
        else if(o instanceof PounamuConnector){
            PounamuConnector connector = (PounamuConnector)o;
            if(type.equals("front"))
                connector.upToTop();
            else if(type.equals("back"))
                connector.downToBottom();
            else if(type.equals("forward"))
                connector.upOneLevel();
            else if(type.equals("backward"))
                connector.downOneLevel();
        }
    }

    public void displayMessage(String message){
        pounamu.displayMessage(message);
    }
    /**
     * init menu items for association object
     * @return a vector holds all available menu items for this association
     */
    public Vector initMenuItemsForAssociation(){
        Vector menuItems = new Vector();
        JMenuItem jmi = new JMenuItem("view xml for this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuModelElement object = getAssociation(manager.getSelectedNode());
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(object.getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 400);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("save this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAnAssociation(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        jmi = new JMenuItem("save this association as");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doRemoveEntity(manager.getSelectedNode());
            }
        });
        //menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("remove this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAnAssociationFromAView(manager.getSelectedNode());
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("bring to front");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "front");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("push to back");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "back");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("forward one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "forward");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        jmi = new JMenuItem("down one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "backward");
            }
        });
        menuItems.add(jmi);
        menuItems.add(null);
        return menuItems;
    }

    /**
     * init menu items for association object
     * @return a vector holds all available menu items for this association
     */
    public Vector initToolButtonsForAssociation(){
        Vector toolButtons = new Vector();
        JButton jmi = new JButton("view xml for this association");
        jmi.setToolTipText("function: " + "view xml for this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                PounamuModelElement object = getAssociation(manager.getSelectedNode());
                PounamuXMLViewingPanel xmlView = new PounamuXMLViewingPanel();
                xmlView.setXML(object.getXMLRepresentation());
                JDialog dialog = new JDialog(pounamu, "XML representation for "+(String)manager.getSelectedNode().getUserObject());
                dialog.setBounds(150, 100, 600, 400);
                dialog.getContentPane().add(new JScrollPane(xmlView));
                dialog.validate();
                dialog.setVisible(true);
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("save this association");
        jmi.setToolTipText("function: " + "save this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doSaveAnAssociation(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        jmi = new JButton("save this association as");
        jmi.setToolTipText("function: " + "save this association as");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                //doRemoveEntity(manager.getSelectedNode());
            }
        });
        //toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("remove this association");
        jmi.setToolTipText("function: " + "remove this association");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                doRemoveAnAssociationFromAView(manager.getSelectedNode());
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("bring to front");
        jmi.setToolTipText("function: " + "bring to front");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "front");
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("push to back");
        jmi.setToolTipText("function: " + "push to back");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "back");
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("forward one level");
        jmi.setToolTipText("function: " + "forward one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "forward");
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        jmi = new JButton("down one level");
        jmi.setToolTipText("function: " + "down one level");
        jmi.setVisible(true);
        jmi.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ev){
                changeIconPositionInZCoordinate(ev, "backward");
            }
        });
        toolButtons.add(jmi);
        toolButtons.add(null);
        return toolButtons;
    }

    /**
     * remove an entity object indexed by the node form the view
     * @param node the index node
     */
    public void doRemoveAnEntityFromAView(DefaultMutableTreeNode node){
        PounamuView view = getView(node);
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        //PounamuModelElement pmme = (PounamuModelElement)getEntity(node);
        PounamuPanel p = (PounamuPanel)getIcon(node);
        RemoveShape re = new RemoveShape(panel, p.getPounamuShape());
        re.excute();
        panel.getUndoStack().push(re);
    }

    /**
     * remove an entity object indexed by the node form the view
     * @param node the index node
     */
    public void doRemoveEntityFromModel(DefaultMutableTreeNode node){
        PounamuView view = getView(manager.getSelectedNode());
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        PounamuPanel p = (PounamuPanel)getIcon(node);
        //PounamuModelElement pmme = (PounamuModelElement)getEntity(manager.getSelectedNode());
        RemoveShape re = new RemoveShape(panel, p.getPounamuShape());
        re.excute();
        panel.getUndoStack().push(re);
    }

    /**
     * remove an association object indexed by the node form the view
     * @param node the index node
     */
    public void doRemoveAnAssociationFromAView(DefaultMutableTreeNode node){
        PounamuView view = getView(node);
        ModellerPanel panel = (ModellerPanel)view.getDisplayPanel();
        PounamuConnector connector = (PounamuConnector)getIcon(node);
        //PounamuModelElement pmme = (PounamuModelElement)getAssociation(node);
        RemoveConnector ra = new RemoveConnector(panel, connector);
        ra.excute();
        panel.getUndoStack().push(ra);
    }

    public void doRemoveAllAssociationsFromAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            doRemoveAllEntitiesOfATypeFromAView((DefaultMutableTreeNode)v.get(i));
        }
    /*manager.getNodeAndProjectMapping().remove(dmtn);
    this.getNodeAndViewsTabMapping().remove(dmtn);
    this.getNodeAndViewMapping().remove(dmtn);
    //this.getNodeAndEntityMapping().put(dmtn, pme);
    //this.getNodeAndIconMapping().put(dmtn, basePanel);
    this.getNodeAndMenuItemsMapping().remove(dmtn);
    this.getNodeAndToolButtonsMapping().remove(dmtn);
    //this.getIconAndNodeMapping().put(basePanel, dmtn);
    //this.getNodeAndSavedXMLStringMapping().remove(dmtn); */
    }
    public void doRemoveAllEntitiesFromAView(DefaultMutableTreeNode dmtn){
        Enumeration en = dmtn.children();
        Vector v = new Vector();
        while(en.hasMoreElements()){
            v.add((DefaultMutableTreeNode)en.nextElement());
        }
        for(int i = 0; i < v.size(); i++){
            doRemoveAllEntitiesOfATypeFromAView((DefaultMutableTreeNode)v.get(i));
        }
    /*manager.getNodeAndProjectMapping().remove(dmtn);
    this.getNodeAndViewsTabMapping().remove(dmtn);
    this.getNodeAndViewMapping().remove(dmtn);
    //this.getNodeAndEntityMapping().put(dmtn, pme);
    //this.getNodeAndIconMapping().put(dmtn, basePanel);
    this.getNodeAndMenuItemsMapping().remove(dmtn);
    this.getNodeAndToolButtonsMapping().remove(dmtn);
    //this.getIconAndNodeMapping().put(basePanel, dmtn);
    //this.getNodeAndSavedXMLStringMapping().remove(dmtn); */
    }

    public void initFolders(){
        //String fullPath = "\""+pounamu.getPounamuHome()+fileSeparator+"models"+fileSeparator+"using_"+toolName+fileSeparator+name+"\"";
        String fullPath = getLocation();;
        //create folder for this model
        MaintainFileSystem cf  = new MaintainFileSystem("\""+fullPath+"\"", pounamu, "createfolder");
        //new Thread(cf).start();
        cf.run();
        //create folder under model folder for entity_objects
        cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"entity_objects\"", pounamu, "createfolder");
        //new Thread(cf).start();
        cf.run();
        //create entity type folders under the entity_objects folder
        Vector v = tool.getEntityTypeObjects();
        for(int i = 0; i < v.size(); i++){
            String entityTypeName = ((PounamuMetaModelElement)v.get(i)).getName();
            //System.out.println("entity type is "+i+":"+entityTypeName);
            cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"entity_objects"+fileSeparator+entityTypeName+"\"", pounamu, "createfolder");
            cf.run();
        }
        //create folder under model folder for association_objects
        cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"association_objects\"", pounamu, "createfolder");
        //new Thread(cf).start();
        cf.run();
        //create association type folders under the association_objects folder
        Vector vv = tool.getAssociationTypeObjects();
        for(int i = 0; i < vv.size(); i++){
            String associationTypeName = ((PounamuMetaModelElement)vv.get(i)).getName();
            //System.out.println("association type is "+i+":"+associationTypeName);
            cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"association_objects"+fileSeparator+associationTypeName+"\"", pounamu, "createfolder");
            cf.run();
        }
        //create folder under model folder for model views
        cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"views\"", pounamu, "createfolder");
        //new Thread(cf).start();
        cf.run();
        //create view type folders under the views folder
        Vector viewTypes = tool.getRegisteredViewTypes();
        for(int i = 0; i < viewTypes.size(); i++){
            String viewTypeName = (String)viewTypes.get(i);
            cf  = new MaintainFileSystem("\""+fullPath+fileSeparator+"views"+fileSeparator+viewTypeName+"\"", pounamu, "createfolder");
            //new Thread(cf).start();
            cf.run();
        }

    }

    public void updateStates(DefaultMutableTreeNode previousSelectedNode){
        //System.out.println("PounamuTooProject_updateStates visited 0");
        String s = (String)nodeAndSavedXMLStringMapping.get(previousSelectedNode);
        if(s == null)
            return;
        //System.out.println("PounamuTooProject_updateStates visited 1");
        if(!s.equals(getXMLRepresentation())){
            if(isSaved())
                setWasSaved(true);
            setSaved(false);
        }
        //System.out.println("registered is now " + registered);
        //System.out.println("wasRegistered is now " + wasRegistered);
        //System.out.println("PounamuTooProject_updateStates visited 2");
        manager.getManagerTree().repaint();
        //System.out.println("PounamuTooProject_updateStates visited 3");
    }



    /* Code added by Akhil */

    public void incrementEntityCount() {
        entityCount++;
    }

    public void incrementAssociationCount() {
        associationCount++;
    }

    //Added by Penny
    /* return the tree node created for this model project
     */
    //has problems here, need to change
    public DefaultMutableTreeNode getCorrespondingTreeNode(){
      //DefaultMutableTreeNode modelProjectManagerNode=manager.getModelProjectNode();
      DefaultMutableTreeNode ToolNodeUnderModelProject = (DefaultMutableTreeNode)manager.getToolProjectNodeAndToolNodeUnderModelProjectMapping().get(tool.getProjectNode());
      Enumeration childNodes=ToolNodeUnderModelProject.children();
      DefaultMutableTreeNode targetProjectNode=null;
      while(childNodes.hasMoreElements()){
        DefaultMutableTreeNode tempNode=(DefaultMutableTreeNode)childNodes.nextElement();
        if(this.name.equals((String)tempNode.getUserObject())){
          targetProjectNode=tempNode;
          break;
        }
      }
      return targetProjectNode;
    }


    //Added by Penny
    /**
 * Called from remote plug-in to create a new PounamuView with name viewName and type viewType
 * @param viewType
 * @param viewName
 */
public void createNewModelView(String viewType, String viewName){
    String name=viewName;
    DefaultMutableTreeNode viewTypeNode=(DefaultMutableTreeNode)viewTypeNameAndNodeMapping.get(viewType);
    TreePath tempPath=new TreePath(viewTypeNode.getPath());
    manager.getManagerTree().setSelectionPath(tempPath);
    Hashtable hash = (Hashtable)openedModelViews.get(viewType);
    PounamuView view = new PounamuView(viewType, viewName, this, pounamu);
    hash.put(viewName, view);
    ModellerPanel mp = new ModellerPanel(this, "modelview", view);
    view.setDisplayPane(mp);
    registerVisualEventHandlers(view, viewType);
    registerVisualUserHandlers(view, viewType);

    DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
    manager.getNodeAndItsValueMapping().put(dmtn, name);
    manager.getNodeAndProjectMapping().put(dmtn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dmtn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dmtn, view);
    nodeAndMenuItemsMapping.put(dmtn, initMenuItemsForModelViewNode(viewType));
    nodeAndToolButtonsMapping.put(dmtn, initToolButtonsForModelViewNode(viewType));
    iconAndNodeMapping.put(mp, dmtn);
    getViewsTab(manager.getSelectedNode()).addTab(name, mp);
    getViewsTab(manager.getSelectedNode()).setSelectedComponent(mp);
    viewTabAndNodeMapping.put(mp, dmtn);
    nodeAndIconMapping.put(dmtn, mp);
    ////////////////////////////////////////////////////////////////////
    DefaultMutableTreeNode dm = new DefaultMutableTreeNode("entity");
    manager.getNodeAndItsValueMapping().put(dm, "entity");
    manager.getNodeAndProjectMapping().put(dm, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dm, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dm, view);
    nodeAndMenuItemsMapping.put(dm, initMenuItemsForEntityNode());
    nodeAndToolButtonsMapping.put(dm, initToolButtonsForEntityNode());
    DefaultMutableTreeNode dn = new DefaultMutableTreeNode("association");
    manager.getNodeAndItsValueMapping().put(dn, "association");
    manager.getNodeAndProjectMapping().put(dn, manager.getProject(manager.getSelectedNode()));
    nodeAndViewsTabMapping.put(dn, getViewsTab(manager.getSelectedNode()));
    nodeAndViewMapping.put(dn, view);
    nodeAndMenuItemsMapping.put(dn, initMenuItemsForAssociationNode());
    nodeAndToolButtonsMapping.put(dn, initToolButtonsForAssociationNode());
    dmtn.add(dm);
    dmtn.add(dn);
    //Vector allowedTypes = (Vector)tool.getViewTypeAndAllowedMetaModelTypesMapping().get(type);
    Vector allowedEntityTypes = (Vector)tool.getViewTypeAndAllowedEntityTypesMapping().get(viewType);
    Vector allowedAssociationTypes = (Vector)tool.getViewTypeAndAllowedAssociationTypesMapping().get(viewType);
    ///////////////////////////////////////////////////////////////////////
    for(int i = 0; i < allowedEntityTypes.size(); i++){
      DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedEntityTypes.get(i));
      manager.getNodeAndItsValueMapping().put(d, (String)allowedEntityTypes.get(i));
      manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
      nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
      nodeAndViewMapping.put(d, view);
      nodeAndMenuItemsMapping.put(d, initMenuItemsForEntityTypeNode());
      nodeAndToolButtonsMapping.put(d, initToolButtonsForEntityNode());
      dm.add(d);
    }
    for(int i = 0; i < allowedAssociationTypes.size(); i++){
      DefaultMutableTreeNode d = new DefaultMutableTreeNode((String)allowedAssociationTypes.get(i));
      manager.getNodeAndProjectMapping().put(d, manager.getProject(manager.getSelectedNode()));
      manager.getNodeAndItsValueMapping().put(d, (String)allowedAssociationTypes.get(i));
      nodeAndViewsTabMapping.put(d, getViewsTab(manager.getSelectedNode()));
      nodeAndViewMapping.put(d, view);
      nodeAndMenuItemsMapping.put(d, initMenuItemsForAssociationTypeNode());
      nodeAndToolButtonsMapping.put(d, initToolButtonsForAssociationTypeNode());
      dn.add(d);
    }
    manager.addTreeNode(dmtn);
    TreePath tp = new TreePath(dmtn.getPath());
    managerTree.setSelectionPath(tp);
    pounamu.validate();
  }

  /*Added by Penny*/
  public int getEntityCount(){
    return this.entityCount;
  }
  public int getAssociationCount(){
    return this.associationCount;
  }

}