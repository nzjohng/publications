/*
 * @(#)PounamuMetaModelElement.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.data;

import java.util.*;
import java.io.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import javax.swing.tree.*;
import javax.swing.*;
import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;

/**
 * Title: PounamuMetaModelElement
 * Description:  defines Pounamu metamodel element
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuMetaModelElement{

  String name = null;
  String type = null;
  String[] propertyNames = null;
  String[] propertyTypes = null;
  //Object icon = null;
  Vector properties = new Vector();
  Hashtable viewAndIconsMapping = new Hashtable();
  Document xmlDocument = null;
  PounamuToolProject tool = null;
  int iconNumber = 0;
  boolean registered = false;
  boolean wasRegistered = false;
  boolean saved = false;
  boolean wasSaved = false;
  String fileSeparator = null;

  /**
   * a constructor
   * @param xmlDocument an xml document which represents a pounamu metamodel element
   */
  public PounamuMetaModelElement(Document xmlDocument, PounamuToolProject tool){
    //System.out.println("PounamuMetaModelElement visited 0");
    this.xmlDocument = xmlDocument;
    this.tool = tool;
    fileSeparator = System.getProperty("file.separator");
    //System.out.println("PounamuMetaModelElement visited 1");
    Element root = xmlDocument.getDocumentElement();
    //System.out.println("PounamuMetaModelElement visited 11");
    NodeList nl = root.getElementsByTagName("name");
    //System.out.println("PounamuMetaModelElement visited 111");
    Node n = nl.item(0);
    //System.out.println(n.getNodeValue());
    
    //System.out.println("PounamuMetaModelElement visited 1111");
    //System.out.println(n.getFirstChild().getNodeValue());
    //System.out.println("PounamuMetaModelElement visited 11110");
    //setName(n.getFirstChild().getNodeValue());
    this.name = n.getFirstChild().getNodeValue();
    //System.out.println("PounamuMetaModelElement visited 11111");
    nl = root.getElementsByTagName("type");
    //System.out.println("PounamuMetaModelElement visited 111111");
    n = nl.item(0);
    //System.out.println("PounamuMetaModelElement visited 1111111");
    setType(n.getFirstChild().getNodeValue());
    //System.out.println("PounamuMetaModelElement visited 2");
    nl = root.getElementsByTagName("attribute");
    if(nl!=null){
      int i = 0;
      while(nl.item(i)!=null){
        Node m = nl.item(i);//node proprtyname
        String tempName = m.getFirstChild().getNodeValue();
        if(tempName != null && !tempName.equals(""))
          properties.add(tempName);
        i++;
      }
    }
    //System.out.println("in class PounamuMetaModelElement, 0");
    updateTreeNode();
    //System.out.println("in class PounamuMetaModelElement, 1");
  }

  /**
   * a constructor
   * @param name the name of this pounamu meta model element
   * @param type the type of this pounamu meta model element
   */
  public PounamuMetaModelElement(String name, String type, PounamuToolProject tool){
    this.name = name;
    this.type = type;
    this.tool = tool;
    fileSeparator = System.getProperty("file.separator");
  }

  /**
   * get the name of this pounamu meta model element
   * @return the name of this pounamu meta model element
   */
  public String getName(){
    return name;
  }

  /**
   * set the name of this pounamu meta model element
   * @param name the name to be set to this pounamu meta model element
   */
  public void setName(String newName){
    System.out.println("in class pounamumetamodelelement, method setname, the newname is " + newName);
      
    //if name not change
    if(name.equals(newName.trim()))
      return;
    //get Pounamu
    Pounamu pounamu = tool.getPounamu();
    //get the pounamu manager
    PounamuManagerPanel manager = tool.getManager();
    //getSelected node
    DefaultMutableTreeNode selectedNode = manager.getSelectedNode();
    //get the current meta model view
    PounamuView view = (PounamuView)tool.getNodeAndViewMapping().get(selectedNode);
    PounamuMetaModelElementSpecifier pmmes = null;
    //check if this name is a valid name
    String temp = newName.trim();
    if(temp.equals("pounamu")
              ||temp.equals("tool projects")
              ||temp.equals("model projects")
              ||temp.equals("entity")
              ||temp.equals("association")
              ||temp.equals("entity type")
              ||temp.equals("association type")
              ||temp.equals("icon_creator")
              ||temp.equals("shape_creator")
              ||temp.equals("connector_creator")
              ||temp.equals("handler_definer")
              ||temp.equals("model_handler_definer")
              ||temp.equals("model_event_handler_definer")
              ||temp.equals("model_user_handler_definer")
              ||temp.equals("visual_handler_definer")
              ||temp.equals("visual_event_handler_definer")
              ||temp.equals("visual_user_handler_definer")               
              ||temp.equals("meta_model_definer")
              ||temp.equals("view_type_definer")
              ||temp.startsWith("Using_")) {
              pmmes = new PounamuMetaModelElementSpecifier(tool.getIcon(selectedNode), view);
              pounamu.setPropertyPanel(pmmes);
              pmmes.ok_pressed();
              pounamu.displayMessage("The name you input is not valid for this node! Operation ignored!");
              return;
    }    
    //get old name
    String oldName = this.name;
    //the new entity type object after name changed
    PounamuMetaModelElement newEntity = null;
    //the new entity type object after name changed
    PounamuMetaModelElement newAssociation = null;
    //if this is a entity type object
    if((type.equals("entitytype")&&tool.existedEntityTypeObjectWithName(newName))
     ||(type.equals("associationtype")&&tool.existedAssociationTypeObjectWithName(newName))){
        //give warning to users
        Object[] options =  new Object[]{"Yes, please!", "No, thanks!"};
        int n = JOptionPane.showOptionDialog(pounamu,
                                           "The meta model element related to this selected icon will be replaced by another\n existed meta model elemnet. Do you want to do so? ",
                                           "Please make sure",
                                           JOptionPane.YES_NO_OPTION,
                                           JOptionPane.QUESTION_MESSAGE,
                                           null, options, options[1]);
        //if user give up, set back old name  
        if(n == 1){
          pounamu.displayMessage("operation to map meta model element type cancelled!");
          selectedNode.setUserObject(oldName);
          pmmes = new PounamuMetaModelElementSpecifier(tool.getIcon(manager.getSelectedNode()), view);
          pounamu.setPropertyPanel(pmmes);
          pmmes.ok_pressed();
          return;
        }
        //get the selected icon
        PounamuPanel pp = (PounamuPanel)tool.getIcon(selectedNode);
        //remove the selceted icon from this metamodel element
        removeIcon(view, pp);
        PounamuShape p = pp.getPounamuShape();
        if(type.equals("entitytype")){
          System.out.println("in class pounamumetamodelelement, method setname, here visited 0 " );
    
          //get the new entity type object
          newEntity = (PounamuMetaModelElement)tool.getEntityTypeObjectByName(newName);
          p.setRelatedObject(newEntity);
          //add icon
          newEntity.addIcon(view, pp);
          tool.addEntityTypeObject(newEntity);
          tool.removeEntityTypeObject(this);
          tool.doSaveEntityType(selectedNode);
          tool.doRegisterEntityType(selectedNode);
        }
        else{
                    System.out.println("in class pounamumetamodelelement, method setname, here visited 1 " );

          //get the new entity type object
          newAssociation = (PounamuMetaModelElement)tool.getAssociationTypeObjectByName(newName);
          p.setRelatedObject(newAssociation);
          //add icon
          newAssociation.addIcon(view, pp);
          tool.addAssociationTypeObject(newAssociation);
          tool.removeAssociationTypeObject(this);
          tool.doSaveAssociationType(selectedNode);
          tool.doRegisterAssociationType(selectedNode);
        } 
                  System.out.println("in class pounamumetamodelelement, method setname, here visited 2 " );

        selectedNode.setUserObject(newName);
        //change property table
        pmmes = new PounamuMetaModelElementSpecifier(pp, view);
        pounamu.setPropertyPanel(pmmes);
        pmmes.ok_pressed();
        manager.getNodeAndItsValueMapping().put(selectedNode, newName);
      }
      //the entity type with the new name not existed
      else{
                  System.out.println("in class pounamumetamodelelement, method setname, here visited 3 " );
        if(type.equals("entitytype")){
          tool.removeEntityTypeObject(this);
        }
        else{
          tool.removeAssociationTypeObject(this);
        }
        this.name = newName;
        updateTreeNode();
        pmmes = new PounamuMetaModelElementSpecifier(tool.getIcon(selectedNode), view);
        pounamu.setPropertyPanel(pmmes);
        if(type.equals("entitytype")){
                      System.out.println("in class pounamumetamodelelement, method setname, here visited 4 " );
          
          tool.addEntityTypeObject(this);
          tool.doSaveEntityType(selectedNode);
          tool.doRegisterEntityType(selectedNode);
        }
        else{
                      System.out.println("in class pounamumetamodelelement, method setname, here visited 5 " );
          
          tool.addAssociationTypeObject(this);
          tool.doSaveAssociationType(selectedNode);
          tool.doRegisterAssociationType(selectedNode);
        }
        manager.getNodeAndItsValueMapping().put(selectedNode, newName);
      }
  }
  
   /**
   * get the number of icons this model element has
   * @return the number of icons this model element has
   */
  public int getIconNumber(){
    return iconNumber;
  }
  /**
   * set the number of icons this model element has
   * @param iconNumber the new number of icons
   */
  public void setIconNumber(int iconNumber){
    this.iconNumber = iconNumber;
  }
  
  public Hashtable getViewAndIconsMapping(){
    return viewAndIconsMapping;
  }
  
  public void updateTreeNode(){
    Enumeration e = getViewAndIconsMapping().keys();
    while(e.hasMoreElements()){
      PounamuView key = (PounamuView)e.nextElement();
      Vector v = (Vector)getViewAndIconsMapping().get(key);
      for(int i = 0; i < v.size(); i++){
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)tool.getIconAndNodeMapping().get(v.get(i));
        if(node != null){
          node.setUserObject(getName());
          tool.getManager().getNodeAndItsValueMapping().put(node, getName());
          tool.getManager().repaint();
        }
        if(v.get(i) instanceof PounamuPanel){
          PounamuPanel panel = (PounamuPanel)v.get(i);
          panel.getPounamuShape().loadPropertiesFromModelElement();
        }
      }
    }
    /*//System.out.println("in class PounamuMetaModelElement, 2");
    Enumeration e = tool.getNodeAndEntityTypeObjectMapping().keys();
    //System.out.println("in class PounamuMetaModelElement, 3");
    while(e.hasMoreElements()){
      //System.out.println("in class PounamuMetaModelElement, 4");
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)e.nextElement();
      PounamuMetaModelElement element = (PounamuMetaModelElement)tool.getNodeAndEntityTypeObjectMapping().get(dmtn);
      //System.out.println("in class PounamuMetaModelElement, 5");
      if(element == this){
        dmtn.setUserObject(getName());
      }
    }
    //System.out.println("in class PounamuMetaModelElement, 6");
    e = tool.getNodeAndAssociationTypeObjectMapping().keys();
    while(e.hasMoreElements()){
      DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)e.nextElement();
      PounamuMetaModelElement element = (PounamuMetaModelElement)tool.getNodeAndAssociationTypeObjectMapping().get(dmtn);
      if(element == this){
        dmtn.setUserObject(getName());
      }
    }
    tool.getManager().getManagerTree().repaint();*/
  }

  /**
   * get the type of this pounamu meta model element
   * @return the type of this pounamu meta model element
   */
  public String getType(){
    return type;
  }

  /**
   * set the type of this pounamu meta model element
   * @param type the type to be set to this pounamu meta model element
   */
  public void setType(String type){
    this.type = type;
  }

  /**
   * there will be different icon when this metamodel element appear in different view.
   * THis method register the icon and view to this metamodel element
   * @param view the PounamuView object
   * @param object the icon to be shown in the view to represent this metamodel element
   */
  public void addIcon(PounamuView view, Object object){
    Vector v = (Vector)viewAndIconsMapping.get(view);
    if(v == null){
      v = new Vector();
      viewAndIconsMapping.put(view, v);
    }
    v.add(object);
  }
  
  public void removeIcon(PounamuView view, Object object){
    Vector v = (Vector)viewAndIconsMapping.get(view);
    v.remove(object);
    if(v.size() == 0)
      viewAndIconsMapping.remove(view);
  }
  
  public Vector getIcons(PounamuView view){
    return (Vector)viewAndIconsMapping.get(view);
  }


  /**
   * get the icon to represent this metamodel element in the view
   * @param view the PounamuView object
   * @return the icon which will appear in the view
   */
  
  /**
   * get the names of properties of this metamodel element
   * @return a array of property names of this metamodel element
   */
  public String[] getPropertyNames(){
    String[] temp = new String[properties.size()];
    for(int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      temp[i] = s.substring(0, s.indexOf(':'));
    }
    return temp;
  }

  
  /**
   * get the types of properties of this metamodel element
   * @return a array of property types of this metamodel element
   */
  public String[] getPropertyTypes(){
    String[] temp = new String[properties.size()];
    for(int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      temp[i] = s.substring(s.indexOf(':')+1, s.lastIndexOf(':'));
    }
    return temp;
  }

   /**
   * get the key informations of properties of this metamodel element
   * @return a array of property types of this metamodel element
   */
  public String[] getPropertyKeyInformations(){
    String[] temp = new String[properties.size()];
    for(int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      temp[i] = s.substring(s.lastIndexOf(':')+1);
    }
    return temp;
  }


  /**
   * get the vector which holds all property names of this metamodel element
   * @return this vector properties
   */
  public Vector getProperties(){
    return properties;
  }

  /**
   * set the vector which holds all property names of this metamodel element
   * @param properties the properties vector to be set for this metamodel element
   */
  public void setProperties(Vector properties){
    this.properties = properties;
    updateTreeNode();
  }

  /**
   * get the names of those properties which will be exported to the user
   * @return the name array
   */
  public String[] getExportedPropertyNames(){
    String[] temp = new String[properties.size()];
    for (int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      if (s.indexOf(':')>0)
        temp[i] = s.substring(0, s.indexOf(':'));
      else temp[i] = s;
    }
    return temp;
  }

  /**
   * get the types of those properties which will be exported to the user
   * @return the type array
   */
  public String[] getExportedPropertyTypes(){
    String[] temp = new String[properties.size()];
    for (int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      if (s.indexOf(':')>0)
        temp[i] = s.substring(s.indexOf(':')+1, s.lastIndexOf(':'));
      else temp[i] = "String";
    }
    return temp;
  }


  /**
   * get the types of those properties which will be exported to the user
   * @return the type array
   */
  public String[] getExportedPropertyKeyInformations(){
    String[] temp = new String[properties.size()];
    for (int i = 0; i < properties.size(); i++){
      String s = (String)properties.elementAt(i);
      if (s.indexOf(':')>0)
        temp[i] = s.substring(s.lastIndexOf(':')+1);
      else temp[i] = "nonkey";
    }
    return temp;
  }

  /**
   * register this metamodel element to the specified project
   * @param project to project this meta model element registers to
   */
  /*public void registerToProject(PounamuToolProject project){
    if(type.equals("entitytype")){
      if(!(project.getRegisteredEntityTypes().contains(name)))
        project.getRegisteredEntityTypes().add(name);
      project.getRegisteredEntityTypeProperty().put(name, properties);
    }
    else{
      if(!(project.getRegisteredAssociationTypes().contains(name)))
        project.getRegisteredAssociationTypes().add(name);
      project.getRegisteredAssociationTypeProperty().put(name, properties);
    }
  }*/

  /**
   * get the String of xml representation of this metamodel element
   * @return the xml string
   */
  public String getXMLRepresentation(){
    StringBuffer buf = new StringBuffer (400000);
    String space = "     ";
    buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE metamodelelement SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"metamodelelement.dtd\">\n");
    buf.append ("<metamodelelement>\n");
    buf.append (space+"<name>");
    buf.append (getName());
    buf.append ("</name>\n");
    buf.append (space+"<type>");
    buf.append (getType());
    buf.append ("</type>\n");
    if(properties.size() != 0){
      for(int i = 0 ; i < properties.size(); i++){
        if(properties.elementAt(i) !=null){
          if(!((String)properties.elementAt(i)).equals("")){
            buf.append (space+"<attribute>");
            buf.append ((String)properties.elementAt(i));
            buf.append (space+"</attribute>\n");
          }
        }
      }
    }
    buf.append ("</metamodelelement>\n");
    return buf.toString();
  }

  /**
   * save the string into a file
   * @param outputPath the output file path
   */
  public void save(String outputPath){
     try{
      FileWriter fw = new FileWriter(outputPath);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(getXMLRepresentation());
      bw.flush();
      fw.close();
    }
    catch(Exception ee){}
  }

   /**
   * to check if this project is registered
   * @return true is this project is registered
   */
  public boolean isRegistered(){
    return registered;
  }

  /**
   * if this project is registered, this varible will set to true
   * @param registered true if this project is registered
   */
  public void setRegistered(boolean registered){
    this.registered = registered;
  }
  
   /**
   * to check if this project is saved
   * @return true is this project is saved
   */
  public boolean isSaved(){
    return saved;
  }

  /**
   * if this project is saved, this varible will set to true
   * @param registered true if this project is saved
   */
  public void setSaved(boolean saved){
    this.saved = saved;
  }
  
  
  /**
   * to check if this project has been registered
   * @return true if this project has been registered
   */
  public boolean isWasRegistered(){
    return wasRegistered;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasRegistered(boolean wasRegistered){
    this.wasRegistered = wasRegistered;
  }
  
  /**
   * to check if this project has been saved
   * @return true if this project has been saved
   */
  public boolean isWasSaved(){
    return wasSaved;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasSaved(boolean wasSaved){
    this.wasSaved = wasSaved;
  }



}