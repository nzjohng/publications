/*
 * @(#)PounamuModelElement.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */
package pounamu.data;

import java.util.*;
import java.io.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.editor.*;
import javax.swing.tree.*;
import javax.swing.*;

/**
 * Title: PounamuModelElement
 * Description:  defines Pounamu model element
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuModelElement{

    String name = null;
    String type = null;
    String key = "";
    String[] attributeNameList = null;
    String[] attributeTypeList = null;
    String[] attributeKeyInformationList = null;
    Object[] attributeValueList = null;
    Hashtable viewAndIconsMapping = new Hashtable();
    Object object = null;
    Document xmlDocument = null;
    PounamuModelProject project = null;
    PounamuToolProject tool = null;
    int iconNumber = 0;
    boolean registered = false;
    boolean wasRegistered = false;
    boolean saved = false;
    boolean wasSaved = false;
    String fileSeparator = null;

    /**
     * a constructor
     * @param xmlDocument an xml document which represents a pounamu model element
     * @param project the model project this element belongs to
     */
    public PounamuModelElement(Document xmlDocument, PounamuModelProject project){
        this.xmlDocument = xmlDocument;
        this.project = project;
        this.tool = project.getTool();
        fileSeparator = System.getProperty("file.separator");
        Element root = xmlDocument.getDocumentElement();
        NodeList nl = root.getElementsByTagName("name");
        Node n = nl.item(0);
        setName(n.getFirstChild().getNodeValue());
        nl = root.getElementsByTagName("type");
        n = nl.item(0);
        setType(n.getFirstChild().getNodeValue());
        restoreAttributeList(root);
        this.key = name;
        //AttributeValue(root);
    }

    private void restoreAttributeList(Element root){
        NodeList nl = root.getElementsByTagName("attribute");
        String[] attributeName = new String[nl.getLength()];
        String[] attributeType = new String[nl.getLength()];
        String[] attributeKeyInformation = new String[nl.getLength()];
        Object[] attributeValue = new Object[nl.getLength()];
        for(int i = 0; i < nl.getLength(); i++){
            Node n = nl.item(i);
            NodeList nll = ((Element)n).getElementsByTagName("attributename");
            Node m = nll.item(0);
            attributeName[i] = m.getFirstChild().getNodeValue();
            nll = ((Element)n).getElementsByTagName("attributetype");
            m = nll.item(0);
            attributeType[i] = m.getFirstChild().getNodeValue();
            nll = ((Element)n).getElementsByTagName("attributekeyinformation");
            m = nll.item(0);
            attributeKeyInformation[i] = m.getFirstChild().getNodeValue();
            nll = ((Element)n).getElementsByTagName("attributevalue");
            m = nll.item(0);
            if(attributeType[i].equals("MultiLinesText")){
                Vector v = new Vector();
                NodeList nnll = ((Element)m).getElementsByTagName("item");
                if(nnll!=null){
                    for(int j = 0; j < nnll.getLength(); j++){
                        if(nnll.item(j)!=null && nnll.item(j).getFirstChild() !=null){
                            Node k = nnll.item(j);
                            v.add(k.getFirstChild().getNodeValue());
                        }
                    }
                }
                attributeValue[i] = v;
            }
            else{
                NodeList nnll = ((Element)m).getElementsByTagName("simplevalue");
                if(nnll.item(0)!=null && nnll.item(0).getFirstChild()!= null){
                    Node k = nnll.item(0);
                    attributeValue[i] = k.getFirstChild().getNodeValue();
                }
                else
                    attributeValue[i] = "";
            }
        }
        setAttributeNameList(attributeName);
        setAttributeTypeList(attributeType);
        setAttributeKeyInformationList(attributeKeyInformation);
        setAttributeValueList(attributeValue);
        setKey();
    }

    /**
     * a constructor
     * @param name the name of the pounamu model element
     * @param type the type of the pounamu model element
     * @param project the model project this element belongs to
     */
    public PounamuModelElement(String name, String type, PounamuModelProject project){
        this.project = project;
        this.tool = project.getTool();
        this.name = name;
        this.type = type;
        this.key = name;
        fileSeparator = System.getProperty("file.separator");
        initAttributeList();
    }

    private void initAttributeList(){
        Vector v = new Vector();
        if(tool.getRegisteredEntityTypeProperty().get(type)==null)
            v = (Vector)tool.getRegisteredAssociationTypeProperty().get(type);
        else
            v = (Vector)tool.getRegisteredEntityTypeProperty().get(type);
        String[] attributeName = new String[v.size()];
        String[] attributeType = new String[v.size()];
        String[] attributeKeyInformation = new String[v.size()];
        Object[] attributeValue = new Object[v.size()];
        for(int i = 0; i < v.size(); i++){
            String s = (String)v.get(i);
            //System.out.println("S is "+s);
            attributeName[i] = s.substring(0, s.indexOf(':'));
            attributeType[i] = s.substring(s.indexOf(':')+1, s.lastIndexOf(':'));
            attributeKeyInformation[i] = s.substring(s.lastIndexOf(':')+1);
            attributeValue [i] = null;
        }
        setAttributeNameList(attributeName);
        setAttributeTypeList(attributeType);
        setAttributeKeyInformationList(attributeKeyInformation);
        setAttributeValueList(attributeValue);
        setKey();
    }

    /**
     * get the name of this model element
     * @return the name of this model element
     */
    public String getName(){
        return name;
    }

    /**
     * set the name of this model elemnet
     * @param name the new name
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * get the type of this model element
     * @return the type of this model element
     */
    public String getType(){
        return type;
    }

    /**
     * setthe type of this model element
     * @param type the new type
     */
    public void setType(String type){
        this.type = type;
    }

    /**
     * get the type of this model element
     * @return the type of this model element
     */
    public String getKey(){
        return key;
    }

    /**
     * setthe type of this model element
     * @param type the new type
     */
    public boolean setKey(){

        //System.out.println("in class PounamuModelElement, setKey() method works 0");
        //keep the old key
        String oldKey = key;
        //get the new key
        String temp = type;
        //System.out.println("in class PounamuModelElement, temp is " + temp);
        //System.out.println("in class PounamuModelElement, oldKey is " + oldKey);
        //System.out.println("in class PounamuModelElement, key is " + key);
        for(int i = 0; i < attributeNameList.length; i++){
            if(attributeKeyInformationList[i].trim().equals("key")&&attributeValueList[i] != null&&!(attributeValueList[i].toString().equals(""))){
                temp = temp +"$"+ attributeValueList[i].toString();
            }
        }
        //System.out.println("in class PounamuModelElement, temp noew is " + temp);
        //if key has not been changed, do nothing
        if(temp.equals(oldKey))
            return true;
        //if the new key equals type, that means none of the key properties have been set, set the name to the key
        if(temp.equals(type)){
            this.key = name;
            updateTreeNode();
            return true;
        }
        //if the new key has been used by another object of the same type, do map object
        if(project.existedEntityWithTypeAndKey(type, temp)){
            return mapObject(temp);
        }
        //otherwise, set the new key, and update the tree node
        else{
            this.key = temp;
            updateTreeNode();
            return true;
        }
    }

    public boolean mapObject(String newKey){
        //panel is the icon for shape
        PounamuPanel panel = null;
        //connector is the icon for connector
        PounamuConnector connector = null;
        //get the pounamu manager
        PounamuManagerPanel manager = project.getManager();
        //get Pounamu
        Pounamu pounamu = manager.getPounamu();
        //get Pounamu view in which this icon appears
        PounamuView view = project.getView(manager.getSelectedNode());
        //get throws eicon from selected tree node
        if(project.getIcon(manager.getSelectedNode()) instanceof PounamuConnector){
            connector = (PounamuConnector)project.getIcon(manager.getSelectedNode());
        }
        else
            panel = (PounamuPanel)project.getIcon(manager.getSelectedNode());

        //commented by Penny
      //prepare the dialog asking user whether if they want to map this element
        /*
        Object[] options =  new Object[]{"Yes, please!", "No, thanks!"};
        int n = JOptionPane.showOptionDialog(pounamu,
        "The model element related to this selected icon will be replaced by another\n existed model elemnet. Do you want to do so? ",
        "Please make sure",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null, options, options[1]);
        //if user give up, set back old values
        if(n == 1){
            pounamu.displayMessage("operation to map model element type cancelled!");
            return false;
        }
        */
        //if this element is an association
        if(connector != null){
            removeIcon(view, connector);
            PounamuModelElement newAssociation = project.getAssociationByTypeAndKey(getType(), newKey);
            connector.setRelatedObject(newAssociation);
            newAssociation.addIcon(view, connector);
            project.addAssociation(newAssociation);
            project.removeAssociation(this);
            project.doSaveAnAssociation(manager.getSelectedNode());
            PounamuAssociationSpecifier pes = new PounamuAssociationSpecifier(connector, view);
            pounamu.setPropertyPanel(pes);
            pes.ok_pressed();
            newAssociation.updateTreeNode();
        }
        //if this element is an entity
        if(panel != null){
            removeIcon(view, panel);
            PounamuModelElement newEntity = project.getEntityByTypeAndKey(getType(), newKey);
            panel.getPounamuShape().setRelatedObject(newEntity);
            newEntity.addIcon(view, panel);
            project.addEntity(newEntity);
            project.removeEntity(this);
            project.doSaveAnEntity(manager.getSelectedNode());
            PounamuEntitySpecifier pes = new PounamuEntitySpecifier(panel.getPounamuShape(), view);
            pounamu.setPropertyPanel(pes);
            pes.ok_pressed();
            newEntity.updateTreeNode();
        }
        return true;
    }

    //update all tree nodes which represents all icons related to this specified model element
    public void updateTreeNode(){
        Enumeration e = getViewAndIconsMapping().keys();
        while(e.hasMoreElements()){
            PounamuView key = (PounamuView)e.nextElement();
            Vector v = (Vector)getViewAndIconsMapping().get(key);
            for(int i = 0; i < v.size(); i++){
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)project.getIconAndNodeMapping().get(v.get(i));
                if(node != null){
                    node.setUserObject(getKey());
                    project.getManager().getNodeAndItsValueMapping().put(node, getKey());
                    project.getManager().repaint();
                }
        /*if(v.get(i) instanceof PounamuPanel){
          PounamuPanel panel = (PounamuPanel)v.get(i);
          panel.getPounamuShape().loadPropertiesFromModelElement();
        }*/
            }
        }
    }

    public void updateIconInformation(){
        Enumeration e = getViewAndIconsMapping().keys();
        while(e.hasMoreElements()){
            PounamuView key = (PounamuView)e.nextElement();
            Vector v = (Vector)getViewAndIconsMapping().get(key);
            for(int i = 0; i < v.size(); i++){
                if(v.get(i) instanceof PounamuPanel){
                    PounamuPanel panel = (PounamuPanel)v.get(i);
                    panel.getPounamuShape().loadPropertiesFromModelElement();
                }
            }
        }
    }
    /**
     * get the number of icons this model element has
     * @return the number of icons this model element has
     */
    public int getIconNumber(){
        return iconNumber;
    }
    /**
     * set the number of icons this model element has
     * @param iconNumber the new number of icons
     */
    public void setIconNumber(int iconNumber){
        this.iconNumber = iconNumber;
    }

    /**
     * the model element has a different icon in each view it appears,
     * this method get the hashtable which holds the mapping from the view to the icon
     * @return the hashtable which holds the mapping from the view to the icon
     */
    public Hashtable getViewAndIconsMapping(){
        return viewAndIconsMapping;
    }

    /**
     * register teh icon (object) which has been added to the view
     * @param view the view the icon added to
     * @param object the icon
     */
    public void addIcon(PounamuView view, Object object){
        Vector v = (Vector)viewAndIconsMapping.get(view);
        if(v == null){
            v = new Vector();
            viewAndIconsMapping.put(view, v);
        }
        v.add(object);
    }

    public void removeIcon(PounamuView view, Object object){
        Vector v = (Vector)viewAndIconsMapping.get(view);
        v.remove(object);
        if(v.size() == 0)
            viewAndIconsMapping.remove(view);
    }

    /**
     * get the icon of this model element in this specified view
     * @param view the view the icon is in
     * @return the icon
     */
    public Vector getIcons(PounamuView view){
        return (Vector)viewAndIconsMapping.get(view);
    }

    /**
     * get the current attribute name list
     * @return the attribute name list
     */
    public String[] getAttributeNameList(){
        return attributeNameList;
    }

    /**
     * set the attribute name list
     * @param attributeNameList the new attribute name list
     */
    public void setAttributeNameList(String[] attributeNameList){
        this.attributeNameList = attributeNameList;
    }

    /**
     * get the current attribute type list
     * @return the current attribute type list
     */
    public String[] getAttributeTypeList(){
        return attributeTypeList;
    }

    /**
     * set the attribute type list
     * @param attributeTypeList the new attribute type list
     */
    public void setAttributeTypeList(String[] attributeTypeList){
        this.attributeTypeList = attributeTypeList;
    }

    /**
     * get the current attribute key information list
     * @return the current attribute key information list
     */
    public String[] getAttributeKeyInformationList(){
        return attributeKeyInformationList;
    }

    /**
     * set the key information list
     * @param attributeKeyInformationList the new key information list
     */
    public void setAttributeKeyInformationList(String[] attributeKeyInformationList){
        this.attributeKeyInformationList = attributeKeyInformationList;
    }

    /**
     * get the current attribute value list
     * @return the current attribute value list
     */
    public Object[] getAttributeValueList(){
        return attributeValueList;
    }

    /**
     * set the attribute value list
     * @param attributeValueList the new attribute value list
     */
    public void setAttributeValueList(Object[] attributeValueList){
        this.attributeValueList = attributeValueList;
    }

    /**
     * set the value of the specified property with the specified value
     * @param propertyName the property name
     * @param value the value of the property
     */
    public void setAttributeValue(String propertyName, Object value){
        for(int i = 0; i < attributeNameList.length; i++){
            if(attributeNameList[i].equals(propertyName)){
                attributeValueList[i] = value;
            }
        }
    }

    /**
     * get the value of an property specified by name
     * @param propertyName the name of a property
     * @return the value of the property
     */
    public Object getAttributeValue(String propertyName){
        for(int i = 0; i < attributeNameList.length; i++){
            if(attributeNameList[i].equals(propertyName)){
                return attributeValueList[i];
            }
        }
        return null;
    }

    /**
     * get the XML representation of this model element
     * @return the xml included string
     */
    public String getXMLRepresentation(){
        StringBuffer buf = new StringBuffer(400000);
        String space = "     ";
        //System.out.println("temp is nw 0 ");
        buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE modelelement SYSTEM \".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+".."+fileSeparator+"nonjavafiles"+fileSeparator+"modelelement.dtd\">\n");
        //System.out.println("temp is nw 1");
        buf.append("<modelelement>\n");
        //System.out.println("temp is nw 2");
        buf.append(space+"<name>");
        //System.out.println("temp is nw 3");
        buf.append(getName());
        //System.out.println("temp is nw 4");
        buf.append("</name>\n");
        //System.out.println("temp is nw 5");
        buf.append(space+"<type>");
        //System.out.println("temp is nw 6");
        buf.append(getType());
        //System.out.println("temp is nw 7");
        buf.append("</type>\n");
        //System.out.println("temp is nw 8");
        for(int i = 0 ; i < getAttributeNameList().length; i++){
            //System.out.println("temp is nw 9");
            buf.append(space+"<attribute>\n");
            //System.out.println("temp is nw 10");
            buf.append(space+space+"<attributename>");
            //System.out.println("temp is nw 11");
            buf.append(getAttributeNameList()[i]);
            //System.out.println("getAttributeNameList()[i]" +getAttributeNameList()[i]);
            buf.append("</attributename>\n");
            buf.append(space+space+"<attributetype>");
            buf.append(getAttributeTypeList()[i]);
            //System.out.println("getAttributeTypeList()[i]" +getAttributeTypeList()[i]);
            buf.append("</attributetype>\n");
            buf.append(space+space+"<attributekeyinformation>");
            buf.append(getAttributeKeyInformationList()[i]);
            //System.out.println("getAttributeKeyInformationList()[i]" +getAttributeKeyInformationList()[i]);
            buf.append("</attributekeyinformation>\n");
            buf.append(space+space+"<attributevalue>\n");
            if(getAttributeTypeList()[i].equals("MultiLinesText")){
                Vector temp = (Vector)getAttributeValueList()[i];
                //System.out.println("temp is nw " +temp);
                buf.append(space+space+space+"<vector>\n");
                if(temp!=null){
                    for(int j = 0; j < temp.size(); j++){
                        buf.append(space+space+space+space+"<item>");
                        buf.append((String)temp.elementAt(j)+"</item>\n");
                    }
                }
                buf.append(space+space+space+"</vector>\n");
            }
            else{
                buf.append(space+space+space+"<simplevalue>");
                //System.out.println("getAttributeValueList()[i].toString()" +getAttributeValueList()[i].toString());
                if(getAttributeValueList()[i] == null)
                    buf.append("");
                else
                    buf.append(getAttributeValueList()[i].toString());
                buf.append("</simplevalue>\n");
            }
            buf.append(space+space+"</attributevalue>\n");
            buf.append(space+"</attribute>\n");
        }
        buf.append("</modelelement>\n");
        //System.out.println(buf.toString());
        return buf.toString();
    }

    /**
     * save the string into a file
     * @param outputPath the output file path
     */
    public void save(String outputPath){
        try{
            FileWriter fw = new FileWriter(outputPath);
            BufferedWriter bw = new BufferedWriter(fw, 40000);
            //System.out.println("ttttttttttttttttttttttttttt");
            bw.write(getXMLRepresentation());
            //System.out.println("ggggggggggggggggggggggggggggggg");
            bw.flush();
            fw.close();
        }
        catch(Exception ee){}
    }

    /**
     * to check if this project is registered
     * @return true is this project is registered
     */
    public boolean isRegistered(){
        return registered;
    }

    /**
     * if this project is registered, this varible will set to true
     * @param registered true if this project is registered
     */
    public void setRegistered(boolean registered){
        this.registered = registered;
    }

    /**
     * to check if this project is saved
     * @return true is this project is saved
     */
    public boolean isSaved(){
        return saved;
    }

    /**
     * if this project is saved, this varible will set to true
     * @param registered true if this project is saved
     */
    public void setSaved(boolean saved){
        this.saved = saved;
    }


    /**
     * to check if this project has been registered
     * @return true if this project has been registered
     */
    public boolean isWasRegistered(){
        return wasRegistered;
    }

    /**
     * if this project was registered, this varible will set to true
     * @param wasRegistered true if this project was registered
     */
    public void setWasRegistered(boolean wasRegistered){
        this.wasRegistered = wasRegistered;
    }

    /**
     * to check if this project has been saved
     * @return true if this project has been saved
     */
    public boolean isWasSaved(){
        return wasSaved;
    }

    /**
     * if this project was registered, this varible will set to true
     * @param wasRegistered true if this project was registered
     */
    public void setWasSaved(boolean wasSaved){
        this.wasSaved = wasSaved;
    }


}