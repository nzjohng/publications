/*
 * @(#)PounamuView.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.data;

import java.util.*;
import javax.swing.*;
import pounamu.core.*;
import java.io.*;
import java.awt.*;

/**
 * Title: PounamuView
 * Description:  defines a pounamu view
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuView{

  String name = null;
  String type = null;
  Vector shapes = new Vector();
  Vector connectors = new Vector();
  Vector handlers = new Vector();
  PounamuProject project = null;
  Pounamu pounamu = null;
  JPanel displayPane = null;
  boolean registered = false;
  boolean wasRegistered = false;
  boolean saved = false;
  boolean wasSaved = false;

  /**
   * an empty constructor
   */
  public PounamuView(){}

  /**
   * constructor
   * @param type the type of the new view
   */
  public PounamuView(String type){
    this.type = type;
  }

  /**
   * constructor
   * @param type the type of the new view
   * @param name the name of the new view
   */
  public PounamuView(String type, String name){
    this.name = name;
    this.type = type;
  }

  /**
   * constructor
   * @param type the type of the new view
   * @param name the name of the new view
   * @param project the project this view belongs to, can be either model project or tool project
   * @param pouanmu the working instance of Pounamu
   */
  public PounamuView(String type, String name, PounamuProject project, Pounamu pounamu){
    this.name = name;
    this.type = type;
    this.project = project;
    this.pounamu = pounamu;
  }

  /**
   * get pounamu working instance
   * @return the pounamu working instance
   */
  public Pounamu getPounamu(){
    return pounamu;
  }

  /**
   * set pounamu instance
   * @param pounamu the new pounamu working instance
   */
  public void setPounamu(Pounamu pounamu){
    this.pounamu = pounamu;
  }

  /**
   * each view has a display panel to render its visual components
   * @return the panel this view uses
   */
  public JPanel getDisplayPanel(){
    return displayPane;
  }

  /**
   * set the display panel
   * @param displayPane the new display panel
   */
  public void setDisplayPane(JPanel displayPane){
    this.displayPane = displayPane;
  }

  /**
   * set the project this view belongs to
   * @param project the new project this view belongs to
   */
  public void setPounamuProject(PounamuProject project){
    this.project = project;
  }

  /**
   * get the current project this view belongs to
   * @return the current project
   */
  public PounamuProject getPounamuProject(){
    return project;
  }

  /**
   * get the name of this view
   * @return the name of this view
   */
  public String getName(){
    return name;
  }

  /**
   * set the name of this view
   * @param name the name of this view
   */
  public void setName(String name){
    this.name = name;
  }

  /**
   * get the type of this view
   * @return the type of this view
   */
  public String getType(){
    return type;
  }

  /**
   * set the type of this view
   * @param type the type of this view
   */
  public void setType(String type){
    this.type = type;
  }

  /**
   * get the xml representation of this view
   * @return the xml representation
   */
  public String getXMLRepresentation(){
    String s = "";
    if(displayPane instanceof IconDisplayPanel){
      s = ((IconDisplayPanel)displayPane).getXMLRepresentation();
    }
    else if(displayPane instanceof HandlerConfigurationPanel){
      s = ((HandlerConfigurationPanel)displayPane).getXML();  
    }
    else if(displayPane instanceof ViewTypeDefinerPanel){
      s = ((ViewTypeDefinerPanel)displayPane).getXML();  
    }
    else if(displayPane instanceof ModellerPanel){
      s = ((ModellerPanel)displayPane).getXML();
    }
    else{}
    return s;
      /*String space = "    ";
    StringBuffer buf = new StringBuffer (400000);
    buf.append("<?xml version=\"1.0\"?>\n<!DOCTYPE project SYSTEM \"project.dtd\">\n");
    buf.append ("<pounamuview>\n");
    buf.append (space+"<name>");
    buf.append (name);
    buf.append ("</name>\n");
    buf.append (space+"<type>");
    buf.append (type);
    buf.append ("</type>\n");
    buf.append ("</pounamuview>\n");
    return buf.toString();*/
  }

  /**
   * save this view
   */
  public void save(){
    String content = getXMLRepresentation();
    String path = "";//project.getLocation()+""+fileSeparator+""+getName()+".xml";
    try{
      FileWriter fw = new FileWriter(path);
      BufferedWriter bw = new BufferedWriter(fw, 40000);
      bw.write(content);
      bw.flush();
      fw.close();
    }
    catch(Exception ee){
      pounamu.displayMessage("Exception from PounamuView class: "+ee.toString());
      Toolkit.getDefaultToolkit().beep();
    }
    pounamu.displayMessage(getName()+".xml" + " has been saved to " + path);
  }
  
   /**
   * to check if this project is registered
   * @return true is this project is registered
   */
  public boolean isRegistered(){
    return registered;
  }

  /**
   * if this project is registered, this varible will set to true
   * @param registered true if this project is registered
   */
  public void setRegistered(boolean registered){
    this.registered = registered;
  }
  
   /**
   * to check if this project is saved
   * @return true is this project is saved
   */
  public boolean isSaved(){
    return saved;
  }

  /**
   * if this project is saved, this varible will set to true
   * @param registered true if this project is saved
   */
  public void setSaved(boolean saved){
    this.saved = saved;
  }
  
  
  /**
   * to check if this project has been registered
   * @return true if this project has been registered
   */
  public boolean isWasRegistered(){
    return wasRegistered;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasRegistered(boolean wasRegistered){
    this.wasRegistered = wasRegistered;
  }
  
  /**
   * to check if this project has been saved
   * @return true if this project has been saved
   */
  public boolean isWasSaved(){
    return wasSaved;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasSaved(boolean wasSaved){
    this.wasSaved = wasSaved;
  }


}