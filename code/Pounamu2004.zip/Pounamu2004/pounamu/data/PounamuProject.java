/*
 * @(#)PounamuProject.java	1.0 01/04/03
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.data;

import pounamu.core.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
/**
 * Title: PounamuProject
 * Description:  a super class for both pounamu tool project and pounamu model project
 * Copyright:    Copyright (c) 2002
 * Company:      Auckland UniServices Limited
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public abstract class PounamuProject{

  String name = null;
  String location = null;
  String description = null;
  boolean registered = false;
  boolean wasRegistered = false;
  boolean saved = false;
  boolean wasSaved = false;
  PounamuManagerPanel manager = null;
  Pounamu pounamu = null;
  PounamuTabbedPane projectTab = null;
  DefaultMutableTreeNode projectNode = null;
  JTree managerTree = new JTree();
  Hashtable nodeAndViewMapping = new Hashtable();
  Hashtable nodeAndViewsTabMapping = new Hashtable();
  Hashtable nodeAndIconMapping = new Hashtable();
  Hashtable nodeAndMenuItemsMapping = new Hashtable();
  Hashtable nodeAndToolButtonsMapping = new Hashtable();
  //Hashtable nodeAndSpecifierMapping = new Hashtable();
  Hashtable viewsTabAndNodeMapping = new Hashtable();
  Hashtable viewTabAndNodeMapping = new Hashtable();
  Hashtable iconAndNodeMapping = new Hashtable();
  /**
   * an empty constructor
   */
  public PounamuProject(){}


  /**
   * a constructor
   * @param name the name of this project
   */
  public PounamuProject(String name){
    this.name = name;
  }

  /**
   * a constructor
   * @param name the name of this project
   * @param location the location this projet will be saved to
   * @param description the description of this project
   */
  public PounamuProject(String name, String location, String description){
    this.name = name;
    this.location = location;
    this.description = description;
  }

  /**
   * a constructor
   * @param name the name of this project
   * @param location the location this projet will be saved to
   * @param description the description of this project
   * @param manager the manager panel of the pounamu working instance
   */
  public PounamuProject(PounamuManagerPanel manager, String name, String location, String description){
    this.name = name;
    this.location = location;
    this.description = description;
    this.manager = manager;
    this.pounamu = manager.getPounamu();
    this.managerTree = manager.getManagerTree();
    this.projectNode = new DefaultMutableTreeNode(name);
    this.projectTab = new PounamuTabbedPane(this);
    projectTab.setTabPlacement(JTabbedPane.BOTTOM);
    manager.getNodeAndProjectMapping().put(projectNode, this);
  }

  /**
   * get the name of this project
   * @return the name of this project
   */
  public String getName(){
    return name;
  }

  /**
   * set the name of this project
   * @param name the name for this project
   */
  public void setName(String name){
    this.name = name;
  }

  /**
   * get the location of this project
   * @return the location of this project
   */
  public String getLocation(){
    return location;
  }

  /**
   * set the location of this project
   * @param location the location of this project
   */
  public void setLocation(String location){
    this.location = location;
  }
  
   /**
   * to check if this project is registered
   * @return true is this project is registered
   */
  public boolean isRegistered(){
    return registered;
  }

  /**
   * if this project is registered, this varible will set to true
   * @param registered true if this project is registered
   */
  public void setRegistered(boolean registered){
    this.registered = registered;
  }
  
   /**
   * to check if this project is saved
   * @return true is this project is saved
   */
  public boolean isSaved(){
    return saved;
  }

  /**
   * if this project is saved, this varible will set to true
   * @param registered true if this project is saved
   */
  public void setSaved(boolean saved){
    this.saved = saved;
  }
  
  
  /**
   * to check if this project has been registered
   * @return true if this project has been registered
   */
  public boolean isWasRegistered(){
    return wasRegistered;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasRegistered(boolean wasRegistered){
    this.wasRegistered = wasRegistered;
  }
  
  /**
   * to check if this project has been saved
   * @return true if this project has been saved
   */
  public boolean isWasSaved(){
    return wasSaved;
  }

  /**
   * if this project was registered, this varible will set to true
   * @param wasRegistered true if this project was registered
   */
  public void setWasSaved(boolean wasSaved){
    this.wasSaved = wasSaved;
  }

  /**
   * get the description of this project
   * @return the description of this project
   */
  public String getDescription(){
    return description;
  }

  /**
   * set the description of this project
   * @param description the location of this project
   */
  public void setDescription(String description){
    this.description = description;
  }

  /**
   * get the manager tree of pounamu instance
   * @return the manager tree of the pounamu instance
   */
  public JTree getManagerTree(){
    return managerTree;
  }

  /**
   * get the manager panel of pounamu instance
   * @return the manager panel of the pounamu instance
   */
  public PounamuManagerPanel getManager(){
    return manager;
  }

  /**
   * get pounamu instance which will be used to do thia project
   * @return the pounamu instance which will be used to do thia project
   */
  public Pounamu getPounamu(){
    return pounamu;
  }

  /**
   * each project has a tabbed pane to hold all of its visual components. This metthod returns the tabbed pane for this project
   * @return the tabbed pane for this project
   */
  public PounamuTabbedPane getProjectTab(){
    return projectTab;
  }

  /**
   * each project has a unique corresponding node in the manager tree. This method returns that node.
   * @return the project node
   */
  public DefaultMutableTreeNode getProjectNode(){
    return projectNode;
  }

  /**
   * each sub tabbbed pane in a project tabbed pane has a corresponding node in the tree. This method returns that node.
   * @param tab the sub tabbed pane in the project tabbed pane
   * @return the node for this sub tabbed pane.
   */
  public DefaultMutableTreeNode getViewsTabNode(Component tab){
    return (DefaultMutableTreeNode)viewsTabAndNodeMapping.get(tab);
  }

  /**
   * ruturn the mapping between views tabbed pane an dits corresponding tree node
   * @return the hashtable holds the the mapping between views tabbed pane an dits corresponding tree node
   */
  public Hashtable getViewsTabAndNodeMapping(){
    return viewsTabAndNodeMapping;
  }

  /**
   * each icon will have a tree node in the tree. This method returns the hashtable holds the mapping between the tree node and the icon
   * @return the hashtable holds the mapping between the tree node and the icon
   */
  public Hashtable getIconAndNodeMapping(){
    return iconAndNodeMapping;
  }
  
  public Object getIcon(DefaultMutableTreeNode node){
    return nodeAndIconMapping.get(node);
  }

  /**
   * each views tabbed pane (a tabbed pane inside a project tabbbed pane) has a unique tree node in the manager tree which serves as an index
   * @param node the tree node as an index
   * @return the tabbed pane this node indexed
   */
  public PounamuTabbedPane getViewsTab(DefaultMutableTreeNode node){
    return (PounamuTabbedPane)nodeAndViewsTabMapping.get(node);
  }

  /**
   * return the hashtable holds the mapping from tree node to views tabbed pane.
   * @return the hashtable holds the mapping from tree node to views tabbed pane.
   */
  public Hashtable getNodeAndViewsTabMapping(){
    return nodeAndViewsTabMapping;
  }

  /**
   * each view has a unique tree node in the manager tree
   * @param tab the display panel of a view
   * @return the tree node for this view panel
   */
  public DefaultMutableTreeNode getViewTabNode(Component tab){
    return (DefaultMutableTreeNode)viewTabAndNodeMapping.get(tab);
  }

  /**
   * return the hatshtable which holds the mapping between the view panel and the tree node
   * @return the hatshtable which holds the mapping between the view panel and the tree node
   */
  public Hashtable getViewTabAndNodeMapping(){
    return viewTabAndNodeMapping;
  }

  /**
   * each view has a unique tree node in the manager tree serves as an index.
   * @param node the node as an index
   * @return the view this node indexed
   */
  public PounamuView getView(DefaultMutableTreeNode node){
    return (PounamuView)nodeAndViewMapping.get(node);
  }

  /**
   * get the hashtable holds mapping from the tree node to a view
   * @return the hashtable holds mapping from the tree node to a view
   */
  public Hashtable getNodeAndViewMapping(){
    return nodeAndViewMapping;
  }

  /**
   * each component has a corresponding node in the tree which serves as an index.
   * @param node the node in this tree
   * @return the component this node indexed.
   */
  public abstract Component getComponent(DefaultMutableTreeNode node);
  /**
   * each component has a corresponding node in the tree which serves as an index.
   * @return the hashtable holds the mapping from the tree node to the component
   */
  public abstract Hashtable getNodeAndComponentMapping();
  /**
   * return the hashtable holds the mapping from the tree node to the icon
   * @return the hashtable holds the mapping from the tree node to the icon
   */
  public abstract Hashtable getNodeAndIconMapping();
  /**
   * each entity type object has a corresponding node in the tree which serves as an index
   * @return the hashtable holds the mapping from the tree node to entity type object.
   */
  //public abstract Hashtable getNodeAndEntityTypeObjectMapping();
  /**
   * each entity type object has a corresponding node in the tree which serves as an index
   * @param node the node for the enitity type object which serves as an index
   * @return th eentity type object the node indexed
   */
  public abstract PounamuMetaModelElement getEntityTypeObject(DefaultMutableTreeNode node);
  /**
   * each entity object has a corresponding node in the tree which serves as an index
   * @return the hashtable holds the mapping from the tree node to entity object.
   */
  public abstract PounamuModelElement getEntity(DefaultMutableTreeNode node);
  /**
   * each association object has a corresponding node in the tree which serves as an index
   * @return the hashtable holds the mapping from the tree node to association object.
   */
  public abstract PounamuModelElement getAssociation(DefaultMutableTreeNode node);
  /**
   * each association type object has a corresponding node in the tree which serves as an index
   * @return the hashtable holds the mapping from the tree node to association type object.
   */
  //public abstract Hashtable getNodeAndAssociationTypeObjectMapping();
  /**
   * each association type object has a corresponding node in the tree which serves as an index
   * @param node the node for the association type object which serves as an index
   * @return th association type object the node indexed
   */
  public abstract PounamuMetaModelElement getAssociationTypeObject(DefaultMutableTreeNode node);
  
  /**
   * each node has a set of corresponding menu items
   * @param node the tree node severs as a index
   * @return a vector holds all menu items related to the node
   */
  public Vector getMenuItems(DefaultMutableTreeNode node){
    return (Vector)nodeAndMenuItemsMapping.get(node);
  }

  /**
   * each node has a set of corresponding menu items
   * @return the hashtable which holds all node and menu items set mapping
   */
  public Hashtable getNodeAndMenuItemsMapping(){
    return nodeAndMenuItemsMapping;
  }
  
   /**
   * each node has a set of corresponding menu items
   * @param node the tree node severs as a index
   * @return a vector holds all menu items related to the node
   */
  public Vector getToolButtons(DefaultMutableTreeNode node){
    return (Vector)nodeAndToolButtonsMapping.get(node);
  }

  /**
   * each node has a set of corresponding menu items
   * @return the hashtable which holds all node and menu items set mapping
   */
  public Hashtable getNodeAndToolButtonsMapping(){
    return nodeAndToolButtonsMapping;
  }

  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }

}