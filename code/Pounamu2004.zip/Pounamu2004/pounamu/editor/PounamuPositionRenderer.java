/*
 * @(#)PounamuHorizontalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuPositionRenderer
 * Description:  A JComboBox to render the position property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuPositionRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuPositionRenderer(){
    super(new String[]{"CENTER", "EAST", "NORTH", "SOUTH", "WEST"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get HorizontalAlignment
   * @return the int which represent the alignment
   */
  public String getPosition(){
    if(getSelectedIndex()==0)
      return BorderLayout.CENTER;
    else if(getSelectedIndex()==1)
      return BorderLayout.EAST;
    else if(getSelectedIndex()==2)
      return BorderLayout.NORTH;
    else if(getSelectedIndex()==3)
      return BorderLayout.SOUTH;
    else
      return BorderLayout.WEST;
  }

  /**
   * set Horizontal Alignment
   * @param i the int which represent the alignment
   */
  public void setPosition(String s){
    if(s.equals(BorderLayout.CENTER))
      setSelectedIndex(0);
    else if(s.equals(BorderLayout.EAST))
      setSelectedIndex(1);
    else if(s.equals(BorderLayout.NORTH))
      setSelectedIndex(2);
    else if(s.equals(BorderLayout.SOUTH))
      setSelectedIndex(3);
    else
      setSelectedIndex(4);
  }
}