/*
 * @(#)PounamuLayoutEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.util.Vector;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import pounamu.visualcomp.*;

/**
 * Title: PounamuLayoutEditor
 * Description:  A JDialog to edit layout property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuLayoutRenderer extends JPanel  {

  PounamuPanel target = null;
  JLabel jl1 = new JLabel("hgap");
  JLabel jl2 = new JLabel("vgap");
  JLabel jl3 = new JLabel("rows");
  JLabel jl4 = new JLabel("cols");
  JTextField jtf1 = new JTextField(2);
  JTextField jtf2 = new JTextField(2);
  JTextField jtf3 = new JTextField(2);
  JTextField jtf4 = new JTextField(2);
  Vector labels = new Vector();
  Vector textFields = new Vector();
  PounamuFlowLayoutHorizontalAlignmentRenderer phar = new PounamuFlowLayoutHorizontalAlignmentRenderer();
  JRadioButton nullL  = new JRadioButton("null", true);
  JRadioButton flowL  = new JRadioButton("Flow", false);
  JRadioButton vFlowL = new JRadioButton("V_Flow", false);
  JRadioButton borderL  = new JRadioButton("Border", false);
  JRadioButton gridL  = new JRadioButton("Grid", false);
  JRadioButton gridBagL  = new JRadioButton("GridBag", false);
  ButtonGroup bg = new ButtonGroup();

  /**
   * constructor
   * @param um the JFrame
   */
  public PounamuLayoutRenderer() {
      // Using Non-Modal dialogs, because editors may be heavy-weight
    super();
  }

  public void init(){
    labels.add(jl1);
    labels.add(jl2);
    labels.add(jl3);
    labels.add(jl4);
    textFields.add(jtf1);
    textFields.add(jtf2);
    textFields.add(jtf3);
    textFields.add(jtf4);
    JPanel specifier = new JPanel();
    JPanel selector = new JPanel();//etched, raisedbevel, loweredbevel, empty;
    JPanel jp1 = new JPanel();
    jp1.setLayout(new GridLayout(2, 4, 2, 2));

    jp1.add(jl1);
    jp1.add(jtf1);
    jp1.add(jl2);
    jp1.add(jtf2);
    jp1.add(jl3);
    jp1.add(jtf3);
    jp1.add(jl4);
    jp1.add(jtf4);
    JPanel jp2 = new JPanel();
    JLabel jl5 = new JLabel("alignment");
    ((FlowLayout)jp2.getLayout()).setHgap(4);
    jp2.add(jl5);
    jp2.add(phar);
    specifier.setLayout(new VerticalFlowLayout());
    specifier.add(jp1);
    specifier.add(jp2);
    bg.add(nullL);
    bg.add(flowL);
    bg.add(vFlowL);
    bg.add(borderL);
    bg.add(gridL);
    bg.add(gridBagL);
    selector.setLayout(new GridLayout(3, 2));
    selector.add(nullL);
    selector.add(flowL);
    selector.add(vFlowL);
    selector.add(borderL);
    selector.add(gridL);
    selector.add(gridBagL);
    nullL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{}, false);
       }
    });
    flowL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{0, 1}, true);
       }
    });
    vFlowL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{1}, false);
       }
    });
    borderL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{0, 1}, false);
       }
    });
    gridL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{0, 1, 2, 3}, false);
       }
    });
    gridBagL.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
           setEnabledComponents(new int[]{}, false);
       }
    });
    this.setLayout(new VerticalFlowLayout());
    this.add(selector);
    this.add(specifier);
    //this.pack();
    this.validate();
    //this.setBounds(200, 300, 300, 270);
  }

    /**
     * set initial state of each component
     * @param num the int array
     * @param comb a boolean
     */
    public void setEnabledComponents(int[] num, boolean combo){
      jl1.setEnabled(false);
      jl2.setEnabled(false);
      jl3.setEnabled(false);
      jl4.setEnabled(false);
      jtf1.setEnabled(false);
      jtf2.setEnabled(false);
      jtf3.setEnabled(false);
      jtf4.setEnabled(false);
      phar.setEnabled(combo);
      for(int i = 0; i < num.length; i++){
        int k = num[i];
        ((JLabel)labels.elementAt(k)).setEnabled(true);
        ((JTextField)textFields.elementAt(k)).setEnabled(true);
      }
    }

    /**
     * set properties
     */
    public void setLayoutParameters(LayoutManager lm){
      init();
      if(lm == null){
        nullL.setSelected(true);
        setEnabledComponents(new int[]{}, false);
      }
      else if(lm instanceof FlowLayout){
        jtf1.setText(""+((FlowLayout)lm).getHgap());
        jtf2.setText(""+((FlowLayout)lm).getVgap());
        phar.setHorizontalAlignment(((FlowLayout)lm).getAlignment());
        flowL.setSelected(true);
        setEnabledComponents(new int[]{0, 1}, true);
      }
      else if(lm instanceof VerticalFlowLayout){
        jtf2.setText(""+((VerticalFlowLayout)lm).getVGap());
        vFlowL.setSelected(true);
        setEnabledComponents(new int[]{1}, false);
      }
      else if(lm instanceof BorderLayout){
        jtf1.setText(""+((BorderLayout)lm).getHgap());
        jtf2.setText(""+((BorderLayout)lm).getVgap());
        borderL.setSelected(true);
        setEnabledComponents(new int[]{0, 1}, false);
      }
      else if(lm instanceof GridLayout){
        jtf1.setText(""+((GridLayout)lm).getHgap());
        jtf2.setText(""+((GridLayout)lm).getVgap());
        jtf3.setText(""+((GridLayout)lm).getRows());
        jtf4.setText(""+((GridLayout)lm).getColumns());
        gridL.setSelected(true);
        setEnabledComponents(new int[]{0, 1, 2, 3}, false);
      }
      else{
        gridBagL.setSelected(true);
        setEnabledComponents(new int[]{}, false);
      }
    }

   /**
   * get LayoutParameters
   * @return the layoutManager
   */
  public LayoutManager getLayoutParameters(){
      LayoutManager lm = null;
      String layout = "null";
      if(flowL.isSelected()){
        int vgap;
        int hgap;
        if(jtf2.getText()==null||jtf1.getText()==null
           ||jtf2.getText().equals("")||jtf1.getText().equals("")){
          JOptionPane.showMessageDialog(this, "Please specify the vgap and hgap values");
          return new FlowLayout();
        }
        try{
          vgap = Integer.parseInt(jtf2.getText());
          hgap = Integer.parseInt(jtf1.getText());
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(this, "vgap and hgap must be int values");
          return new FlowLayout();
        }
        int align = phar.getHorizontalAlignment();
        lm = new FlowLayout(align, hgap, vgap);
        //layout = "FlowLayout("+align+", "+hgap+", "+vgap+")";
      }
      else if(vFlowL.isSelected()){
        int vgap;
        if(jtf2.getText()==null||jtf2.getText().equals("")){
          JOptionPane.showMessageDialog(this, "Please specify the vgap value");
          return new VerticalFlowLayout(2);
        }
        try{
          vgap = Integer.parseInt(jtf2.getText());
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(this, "vgap must be int values");
          return new VerticalFlowLayout(2);
        }
        lm = new VerticalFlowLayout(vgap);
        //layout = "VerticalFlowLayout("+vgap+")";
      }
      else if(borderL.isSelected()){
        int vgap;
        int hgap;
        if(jtf2.getText()==null||jtf1.getText()==null
           ||jtf2.getText().equals("")||jtf1.getText().equals("")){
          JOptionPane.showMessageDialog(this, "Please specify the vgap and hgap values");
          return new BorderLayout(2, 2);
        }
        try{
          vgap = Integer.parseInt(jtf2.getText());
          hgap = Integer.parseInt(jtf1.getText());
        }
         catch(Exception e){
          JOptionPane.showMessageDialog(this, "vgap and hgap must be int values");
          return new BorderLayout(2, 2);
        }
        lm = new BorderLayout(hgap, vgap);
        //layout = "BorderLayout("+hgap+", "+vgap+")";
      }
      else if(gridL.isSelected()){
        int vgap;
        int hgap;
        int cols;
        int rows;
        if(jtf2.getText()==null||jtf1.getText()==null
           ||jtf2.getText().equals("")||jtf1.getText().equals("")
           ||jtf3.getText()==null||jtf4.getText()==null
           ||jtf3.getText().equals("")||jtf4.getText().equals("")){
           JOptionPane.showMessageDialog(this, "Please specify the vgap,hgap,cols and rows values");
           return new GridLayout(2, 2, 2, 2);
        }
        try{
          vgap = Integer.parseInt(jtf2.getText());
          hgap = Integer.parseInt(jtf1.getText());
          cols = Integer.parseInt(jtf4.getText());
          rows = Integer.parseInt(jtf3.getText());
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(this, "vgap,hgap,cols and rows must be int values");
          return new GridLayout(2, 2, 2, 2);
        }
        //int align = phar.getHorizontalAlignment();
        lm = new GridLayout(rows, cols, hgap, vgap);
        //layout = "GridLayout("+rows+", "+cols+", "+hgap+", "+vgap+")";
      }
      else if(gridBagL.isSelected()){
        lm = new GridBagLayout();
        //layout = "GridBagLayout()";
      }
      else{
        lm = null;
        //layout = "null";
      }
      return lm;
    }
  }