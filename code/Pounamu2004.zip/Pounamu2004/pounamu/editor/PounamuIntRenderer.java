/*
 * @(#)PounamuIntRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuIntRenderer
 * Description:  A JTextField to render int property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuIntRenderer extends JTextField{
  /**
   * constructor
   */
  public PounamuIntRenderer(){
    super("", 11);
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get Int Value
   * @return the int value
   */
  public int getIntValue(){
    return Integer.parseInt(getText());
  }

  /**
   * set int value
   * @param value the int value
   */
  public void setStringValue(int value){
    setText(""+value);
  }
}