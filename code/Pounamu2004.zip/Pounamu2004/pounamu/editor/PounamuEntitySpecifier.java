/*
 * @(#)PounamuEntitySpecifier.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import pounamu.editor.*;
import pounamu.visualcomp.*;
import pounamu.command.*;
import pounamu.data.*;
import pounamu.core.*;
/**
 * Title: PounamuEntitySpecifier
 * Description:  A panel to specify any pounamu entity
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuEntitySpecifier extends JPanel{

  PounamuModelElement target;
  ModellerPanel panel = null;
  PounamuModelProject project = null;
  PounamuToolProject tool = null;
  PounamuView view = null;
  PounamuShape shape = null;
  String viewType = null;
  String modelType = null;
  String iconType = null;
  public String[] propertyNames;
  public String[] propertyTypes;
  public String[] componentPaths;
  public String[] propertyOldNames;
  public String[] visualPropertyNames;
  public String[] visualPropertyTypes;
  public String[] visualComponentPaths;
  public String[] visualPropertyOldNames;
  public String[] modelPropertyNames;
  public String[] modelPropertyTypes;
  public String[] modelComponentPaths;
  public String[] modelPropertyOldNames;
  public String[] modelPropertyKeyInformations;
  public Object[] modelPropertyValues;
  public Hashtable rendererType = new Hashtable();
  public Hashtable rendererComp = new Hashtable();
  /**
   * constructor
   * 1) initial renderers
   * 2) initial interface
   * 3) set properties in the interface
   * @param target the PounamuMetaModelElement to be specified
   * @param view the view the PounamuMetaModelElement is in
   */
  public PounamuEntitySpecifier(PounamuShape shape, PounamuView view){
    this.target = (PounamuModelElement)shape.getRelatedObject();
    this.view = view;
    this.shape = shape;
    this.project = (PounamuModelProject)view.getPounamuProject();
    this.tool = project.getTool();
    this.panel = (ModellerPanel)view.getDisplayPanel();
    this.modelType = target.getType();
    this.viewType = view.getType();
    this.iconType = tool.getShapeType(modelType, viewType);
    //project.displayMessage("What is happened here in class PounamuEntityspecifier 0");
    readInProperties();
    //project.displayMessage("What is happened here in class PounamuEntityspecifier 1");
    /*modelPropertyNames = target.getAttributeNameList();
    modelPropertyTypes = target.getAttributeTypeList();
    modelPropertyValues = target.getAttributeValueList();
    modelPropertyKeyInformations = target.getAttributeKeyInformationList();*/
    propertyNames = shape.getExportedPropertyNames();
    propertyTypes = shape.getExportedPropertyTypes();
    componentPaths = shape.getExportedComponentPath();
    propertyOldNames = shape.getExportedPropertyOldNames();
    //project.displayMessage("What is happened here in class PounamuEntityspecifier 2");
    getPropertyList();
    //project.displayMessage("What is happened here in class PounamuEntityspecifier 3");
    try {
      initHashtables();
      //project.displayMessage("What is happened here in class PounamuEntityspecifier 4");
      initInterface();
      //project.displayMessage("What is happened here in class PounamuEntityspecifier 5");
      loadPropertiesFromEntity();
      //project.displayMessage("What is happened here in class PounamuEntityspecifier 6");
      setProperties();
      //project.displayMessage("What is happened here in class PounamuEntityspecifier 7");
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  
  public void readInProperties(){
    modelPropertyNames = target.getAttributeNameList();
    modelPropertyTypes = target.getAttributeTypeList();
    modelPropertyValues = target.getAttributeValueList();
    modelPropertyKeyInformations = target.getAttributeKeyInformationList();
  }
  /**
   * set up the values of all editors in this panel with teh value loaded from the entity
   */
  public void loadPropertiesFromEntity(){
    for(int i = 0; i < modelPropertyNames.length; i++){
      String iconPropertyName = tool.getIconPropertyName(viewType, modelType, iconType, modelPropertyNames[i]);
      shape.setProperty(iconPropertyName, modelPropertyValues[i]);
    }
  }


  private void getPropertyList(){
   
    visualPropertyNames = new String[propertyNames.length];
    visualPropertyTypes = new String[propertyNames.length];
    visualComponentPaths = new String[propertyNames.length];
    visualPropertyOldNames = new String[propertyNames.length];
    modelComponentPaths = new String[modelPropertyNames.length];
    modelPropertyOldNames = new String[modelPropertyNames.length];
    for(int k = 0; k < propertyNames.length; k++){
      visualPropertyNames[k] = propertyNames[k];
      visualPropertyTypes[k] = propertyTypes[k];
      visualComponentPaths[k] = componentPaths[k];
      visualPropertyOldNames[k] = propertyOldNames[k];
    }
    for(int i = 0; i < modelPropertyNames.length; i++){
      String temp = tool.getIconPropertyName(viewType, modelType, iconType, modelPropertyNames[i]);
      if(temp != null && !temp.equals("")){
        for(int j = 0; j < propertyNames.length; j++){
          if(propertyNames[j].equals(temp)){
            modelComponentPaths[i] = componentPaths[j];
            modelPropertyOldNames[i] = propertyOldNames[j];
            visualPropertyNames[j] = null;
            visualPropertyTypes[j] = null;
            visualComponentPaths[j] = null;
            visualPropertyOldNames[j] = null;
            break;
          }
         }
       }
       else{
         modelComponentPaths[i] = null;
         modelPropertyOldNames[i] = null;
       }
     }

  }

  public PounamuShape getShape(){
    return shape;
  }
  
 
  private String[] getPropertyTypes(){
    return propertyTypes;
  }

  private String[] getPropertyNames(){
    return propertyNames;
  }

  private String[] getComponentPaths(){
    return componentPaths;
  }

  private String[] getPropertyOldNames(){
    return propertyOldNames;
  }

  public Hashtable getRendererComp(){
    return rendererComp;
  }

  /**
   * assign the renderers to their correspnding types
   */
  private void initHashtables(){
    rendererType.put("int", "PounamuIntRenderer");
    rendererType.put("float", "PounamuFloatRenderer");
    rendererType.put("boolean", "PounamuBooleanRenderer");
    rendererType.put("String", "PounamuStringRenderer");
    rendererType.put("Font", "PounamuFontRenderer");
    rendererType.put("Border", "PounamuBorderRenderer");
    rendererType.put("Color", "PounamuColorRenderer");
    rendererType.put("HorizontalAlignment", "PounamuHorizontalAlignmentRenderer");
    rendererType.put("VerticalAlignment", "PounamuVerticalAlignmentRenderer");
    rendererType.put("LayoutParameters", "PounamuLayoutRenderer");
    rendererType.put("MultiLinesText", "PounamuMultiLinesTextRenderer");
    rendererType.put("GridBagConstraints", "PounamuGridBagConstraintsRenderer");
    rendererType.put("Position", "PounamuPositionRenderer");
    rendererType.put("BasicStroke", "PounamuBasicStrokeRenderer");
    rendererType.put("Insets", "PounamuInsetsRenderer");
    rendererType.put("ShapeType", "PounamuShapeTypeRenderer");
    rendererType.put("Size", "PounamuSizeRenderer");
    rendererType.put("Location", "PounamuLocationRenderer");
    rendererType.put("ArrowShape", "PounamuArrowShapeRenderer");
  }

  /**
   * initial visual interface
   */
  private void initInterface(){

    /*if(propertyNames==null){
      JOptionPane.showMessageDialog(this, "The current pounamu shape has no property to be specified!");
      return;
    }*/
    this.setLayout(new BorderLayout());
    JPanel okPanel = new JPanel();
    JButton ok = new JButton("OK");
    okPanel.add(ok);
    ok.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
      }
    });
    this.add(okPanel, BorderLayout.SOUTH);
    /////////////////////////////////////////////////////////////////////////////////////
    JPanel configurationPanel = new JPanel();
    configurationPanel.setLayout(new VerticalFlowLayout());
    JPanel visiblePanel = new JPanel();
    visiblePanel.setLayout(new VerticalFlowLayout());
    visiblePanel.setBorder(BorderFactory.createTitledBorder("Visible model props"));
    JPanel invisiblePanel = new JPanel();
    invisiblePanel.setLayout(new VerticalFlowLayout());
    invisiblePanel.setBorder(BorderFactory.createTitledBorder("Invisible model props"));
    for(int i = 0; i < modelPropertyNames.length; i++){
      String propertyName = modelPropertyNames[i];
      String propertyType = modelPropertyTypes[i];
      JPanel jp = new JPanel();
      try{
        Class c = Class.forName("pounamu.editor."+rendererType.get(propertyType));
        Component newEditor = (Component)c.newInstance();
        jp.add(newEditor);
        jp.setBorder(BorderFactory.createTitledBorder(propertyName+":"+propertyType));
        rendererComp.put(propertyName, newEditor);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
      if(modelComponentPaths[i]!=null)
        visiblePanel.add(jp);
      else
        invisiblePanel.add(jp);
    }
    configurationPanel.add(visiblePanel);
    configurationPanel.add(invisiblePanel);
    /////////////////////////////////////////////////////////////////////////////////////////
    JPanel specificationPanel = new JPanel();
    if(view!=null){
      specificationPanel.setLayout(new VerticalFlowLayout());
      specificationPanel.setBorder(BorderFactory.createTitledBorder("Specify visual properties"));
      for(int i = 0; i < visualPropertyNames.length; i++){
        String propertyName = visualPropertyNames[i];
        String propertyType = visualPropertyTypes[i];
        if(propertyName!=null){
          try{
            Class c = Class.forName("pounamu.editor."+rendererType.get(propertyType));
            Component newEditor = (Component)c.newInstance();
            JPanel jp = new JPanel();
            jp.add(newEditor);
            jp.setBorder(BorderFactory.createTitledBorder(propertyName));
            specificationPanel.add(jp);
            rendererComp.put(propertyName, newEditor);
          }
          catch(Exception e){
            e.printStackTrace(System.out);
          }
        }
      }
    }
    JTabbedPane upper = new JTabbedPane();
    JScrollPane jsp = new JScrollPane(configurationPanel);
    jsp.setPreferredSize(new Dimension(200, 510));
    upper.add("model props", jsp);
    if(view!=null){
      jsp = new JScrollPane(specificationPanel);
      jsp.setPreferredSize(new Dimension(200, 510));
      upper.add("visual props", jsp);
    }
    this.add(upper, BorderLayout.NORTH);
    this.validate();
  }

  /**
   * set up properties
   */
  private void setProperties(){

    for(int i = 0; i < modelPropertyNames.length; i++){
      //System.out.println("setProperties visited 0");
      String propertyName = modelPropertyNames[i];
      String type = modelPropertyTypes[i];
      Object value = modelPropertyValues[i];
      String componentPath = modelComponentPaths[i];
      String propertyOldName = modelPropertyOldNames[i];
      Component renderer = (Component)rendererComp.get(propertyName);
      //System.out.println(propertyName + " " +type+ " " +componentPath+ " " +propertyOldName);
      setProperty(propertyName, type, value, renderer);
    }
    for(int i = 0; i < visualPropertyNames.length; i++){
      String propertyName = visualPropertyNames[i];
      String type = visualPropertyTypes[i];
      String componentPath = visualComponentPaths[i];
      String propertyOldName = visualPropertyOldNames[i];
      if(propertyName!=null)
        setProperty(propertyName, type, componentPath, propertyOldName);
     }
  }

  private void setProperty(String propertyName, String type, Object value, Component renderer){
    if(value == null)
      return;
    if(type.equals("int"))
      ((PounamuIntRenderer)renderer).setText(""+((Integer)value).intValue());
    else if(type.equals("boolean"))
      ((PounamuBooleanRenderer)renderer).setBooleanValue(((Boolean)value).booleanValue());
    else if(type.equals("MultiLinesText"))
      ((PounamuMultiLinesTextRenderer)renderer).setMultiLinesText((Vector)value);
    else
      ((PounamuStringRenderer)renderer).setText((String)value);
  }

  private void setProperty(String propertyName, String type, String componentPath, String propertyOldName){
      Object comp;
      String methodName = null;
      if (componentPath == null){
        comp = target;
        propertyOldName = propertyName;
      }
      else  if (shape instanceof PounamuShape)
        comp = ((PounamuShape)shape).pathComponentMapping.get(componentPath);
      else comp = shape;
      Class c = comp.getClass();
      if(type.equals("boolean"))
        methodName = "is"+capitalizeFirstLetter(propertyOldName);
      else
        methodName = "get"+capitalizeFirstLetter(propertyOldName);
      try{
        Method m = c.getMethod(methodName, new Class[]{});
        Object value = m.invoke(comp, new Object[]{});
        Component renderer = (Component)rendererComp.get(propertyName);
        if(type.equals("int"))
          ((PounamuIntRenderer)renderer).setText(""+((Integer)value).intValue());
        else if(type.equals("boolean"))
          ((PounamuBooleanRenderer)renderer).setBooleanValue(((Boolean)value).booleanValue());
        else if(type.equals("Font"))
          ((PounamuFontRenderer)renderer).setFont((Font)value);
        else if(type.equals("Border"))
          ((PounamuBorderRenderer)renderer).setBorder((Border)value);
        else if(type.equals("Color"))
          ((PounamuColorRenderer)renderer).setColor((Color)value);
        else if(type.equals("HorizontalAlignment"))
          ((PounamuHorizontalAlignmentRenderer)renderer).setHorizontalAlignment(((Integer)value).intValue());
        else if(type.equals("VerticalAlignment"))
          ((PounamuVerticalAlignmentRenderer)renderer).setVerticalAlignment(((Integer)value).intValue());
        else if(type.equals("LayoutParameters"))
          ((PounamuLayoutRenderer)renderer).setLayoutParameters((LayoutManager)value);
        else if(type.equals("MultiLinesText"))
          ((PounamuMultiLinesTextRenderer)renderer).setMultiLinesText((Vector)value);
        else if(type.equals("GridBagConstraints"))
          ((PounamuGridBagConstraintsRenderer)renderer).setGridBagConstraints((GridBagConstraints)value);
        else if(type.equals("Position"))
          ((PounamuPositionRenderer)renderer).setPosition((String)value);
        else if(type.equals("BasicStroke"))
          ((PounamuBasicStrokeRenderer)renderer).setBasicStroke((BasicStroke)value);
        else if(type.equals("Insets"))
          ((PounamuInsetsRenderer)renderer).setInsets((Insets)value);
        else if(type.equals("ShapeType"))
          ((PounamuShapeTypeRenderer)renderer).setShapeType((String)value);
        else if(type.equals("Size"))
          ((PounamuSizeRenderer)renderer).setMinimumSize((Dimension)value);
        else if(type.equals("Location"))
          ((PounamuLocationRenderer)renderer).setLocation((Point)value);
        else if(type.equals("ArrowShape"))
          ((PounamuArrowShapeRenderer)renderer).setArrowShape((String)value);
        else
          ((PounamuStringRenderer)renderer).setText((String)value);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }

  }

  /**
   * to configure the shape
   */
  public void ok_pressed(){
    ChangeProperty cp = new ChangeProperty(target, view, this, "entity");
    cp.excute();
    panel.getUndoStack().push(cp);
  }

  /**
   * set each property of the shape
   */
  private void setTargetProperties(){
    for(int i = 0; i < modelPropertyNames.length; i++){
      //System.out.println("setProperties visited 0");
      String propertyName = modelPropertyNames[i];
      String type = modelPropertyTypes[i];
      String componentPath = modelComponentPaths[i];
      String propertyOldName = modelPropertyOldNames[i];
      Component renderer = (Component)rendererComp.get(propertyName);
      setTargetProperty(propertyName, type, renderer);
      //System.out.println(propertyName + " " +type+ " " +componentPath+ " " +propertyOldName);
      if(componentPath!=null)
        setTargetProperty(propertyName, type, componentPath, propertyOldName);
    }
    for(int i = 0; i < visualPropertyNames.length; i++){
      String propertyName = visualPropertyNames[i];
      String type = visualPropertyTypes[i];
      String componentPath = visualComponentPaths[i];
      String propertyOldName = visualPropertyOldNames[i];
      if(propertyName!=null)
        setTargetProperty(propertyName, type, componentPath, propertyOldName);
    }
  }

   private void setTargetProperty(String propertyName, String type, Component renderer){
     Object value = null;
     if(type.equals("int")){
       value = new Integer(((PounamuIntRenderer)renderer).getText());
     }
     else if(type.equals("boolean")){
       value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
     }
     else if(type.equals("MultiLinesText")){
       value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
     }
     else{
       value = ((PounamuStringRenderer)renderer).getText();
     }
     target.setAttributeValue(propertyName, value);
   }

   private void setTargetProperty(String propertyName, String type, String componentPath, String propertyOldName){
      Object comp;
      if (shape instanceof PounamuShape)
        comp = ((PounamuShape)shape).pathComponentMapping.get(componentPath);
      else comp = shape;
      Class c = comp.getClass();
      String methodName = "set"+capitalizeFirstLetter(propertyOldName);
      Component renderer = (Component)rendererComp.get(propertyName);
      try{
        if(type.equals("int")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuIntRenderer)renderer).getText());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("boolean")){
          Method m = c.getMethod(methodName, new Class[]{boolean.class});
          Boolean value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Font")){
          Method m = c.getMethod(methodName, new Class[]{Font.class});
          Font value = ((PounamuFontRenderer)renderer).getFont();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Border")){
          Method m = c.getMethod(methodName, new Class[]{Border.class});
          Border value = ((PounamuBorderRenderer)renderer).getBorder();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Color")){
          Method m = c.getMethod(methodName, new Class[]{Color.class});
          Color value = ((PounamuColorRenderer)renderer).getColor();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("HorizontalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuHorizontalAlignmentRenderer)renderer).getHorizontalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("VerticalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuVerticalAlignmentRenderer)renderer).getVerticalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("LayoutParameters")){
          Method m = c.getMethod(methodName, new Class[]{LayoutManager.class});
          LayoutManager value = ((PounamuLayoutRenderer)renderer).getLayoutParameters();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("MultiLinesText")){
          Method m = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("GridBagConstraints")){
          Method m = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
          GridBagConstraints value = ((PounamuGridBagConstraintsRenderer)renderer).getGridBagConstraints();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Position")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuPositionRenderer)renderer).getPosition();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("BasicStroke")){
          Method m = c.getMethod(methodName, new Class[]{BasicStroke.class});
          BasicStroke value = ((PounamuBasicStrokeRenderer)renderer).getBasicStroke();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Insets")){
          Method m = c.getMethod(methodName, new Class[]{Insets.class});
          Insets value = ((PounamuInsetsRenderer)renderer).getInsets();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("ShapeType")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuShapeTypeRenderer)renderer).getShapeType();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Size")){
          Method m = c.getMethod(methodName, new Class[]{Dimension.class});
          Dimension value = ((PounamuSizeRenderer)renderer).getMinimumSize();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Location")){
          Method m = c.getMethod(methodName, new Class[]{Point.class});
          Point value = ((PounamuLocationRenderer)renderer).getLocation();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("ArrowShape")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuArrowShapeRenderer)renderer).getArrowShape();
          m.invoke(target, new Object[]{value});
        }
        else{
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuStringRenderer)renderer).getText();
          m.invoke(comp, new Object[]{value});
        }
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
  }



  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }

   /* Added by akhil */
    
    public String[] getVisualPropertyNames() {
        return visualPropertyNames;
    }

    public String[] getVisualPropertyTypes() {
        return visualPropertyTypes;
    }
}