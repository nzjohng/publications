/*
 * @(#)PounamuImageResourceRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import pounamu.visualcomp.*;

/**
 * Title: PounamuImageResourceRenderer
 * Description:  A JButton to render ImageResource property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuImageResourceRenderer extends JButton{
  PounamuComponentSpecifier pse;
  String imageResource = "Null";
  /**
   * constructor
   */
  public PounamuImageResourceRenderer(){
    setText(imageResource);
    this.pse = pse;
    setBorderPainted(true);
    setMargin(new Insets(0,0,0,0));
    setPreferredSize(new Dimension(120, 20));
    addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        PounamuImageResourceEditor pfe = new PounamuImageResourceEditor((PounamuImageResourceRenderer)e.getSource(), null);
        pfe.setVisible(true);
      }
    });
  }
  
  public void setPounamuComponentSpecifier(PounamuComponentSpecifier pse){
    this.pse = pse;
  }
  
  public PounamuComponentSpecifier getPounamuComponentSpecifier(){
    return pse;
  }
  
  public PounamuLabel getPounamuLabel(){
    Object ob = pse.getTarget();
    if(ob instanceof PounamuLabel)
      return (PounamuLabel)ob;
    return null;
  }
   /**
   * get image resource
   * @return the image resource
   */
  public String getImageResource(){
    return imageResource;
  }

  /**
   * set the basicStroke
   * @param basicStroke the value to set
   */
  public void setImageResource(String imageResource){
    this.imageResource = imageResource;
    this.setText(imageResource);
    this.repaint();
  }

}