/*
 * @(#)PounamuHorizontalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuOrientationRenderer
 * Description:  A JComboBow to render the orientation property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuOrientationRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuOrientationRenderer(){
    super(new String[]{"CENTER", "EAST", "NORTH", "SOUTH", "WEST"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get HorizontalAlignment
   * @return the int which represent the alignment
   */
  public String getOrientation(){
    if(getSelectedIndex()==0)
      return BorderLayout.CENTER;
    else if(getSelectedIndex()==1)
      return BorderLayout.EAST;
    else if(getSelectedIndex()==2)
      return BorderLayout.NORTH;
    else if(getSelectedIndex()==3)
      return BorderLayout.SOUTH;
    else
      return BorderLayout.WEST;
  }

  /**
   * set Horizontal Alignment
   * @param i the int which represent the alignment
   */
  public void setOrientation(String s){
    if(s==BorderLayout.CENTER)
      setSelectedIndex(0);
    else if(s==BorderLayout.EAST)
      setSelectedIndex(1);
    else if(s==BorderLayout.NORTH)
      setSelectedIndex(2);
    else if(s==BorderLayout.SOUTH)
      setSelectedIndex(3);
    else
      setSelectedIndex(4);
  }
}