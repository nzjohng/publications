/*
 * @(#)PounamuBasicStrokeRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuBasicStrokeRenderer
 * Description:  A JButton to render the BasicStroke property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuBasicStrokeRenderer extends JButton{
  BasicStroke basicStroke = null;
  /**
   * constructor
   */
  public PounamuBasicStrokeRenderer(){
    super();
    setOpaque(true);
    setPreferredSize(new Dimension(120, 20));
    addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        PounamuBasicStrokeEditor pbse = new PounamuBasicStrokeEditor((PounamuBasicStrokeRenderer)e.getSource());
        pbse.setVisible(true);
      }
    });
  }

  /**
   * get BasicStroke
   * @return the basicStroke
   */
  public BasicStroke getBasicStroke(){
    return basicStroke;
  }

  /**
   * set the basicStroke
   * @param basicStroke the value to set
   */
  public void setBasicStroke(BasicStroke basicStroke){
    this.basicStroke = basicStroke;
    this.repaint();
  }

  /**
   * show the baic stroke by painting
   * a line using it
   */
  public void paint(Graphics g){
    super.paint(g);
    Graphics2D g2d = (Graphics2D)g;
    g2d.setStroke(basicStroke);
    java.awt.geom.Line2D l = new java.awt.geom.Line2D.Double(10, 10, 110, 10);
    g2d.draw(l);
  }

}