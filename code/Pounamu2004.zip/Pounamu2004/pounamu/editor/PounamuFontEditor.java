/*
 * @(#)PounamuFontEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */


package pounamu.editor;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

/**
 * Title: PounamuFontEditor
 * Description:  a Jdialog used to editor Font property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuFontEditor extends JDialog implements ActionListener {

  JButton button = null;
  Font newFont = null;
  JButton preview = new JButton("AaBbCcDdEeFfGg");
  JButton doneButton = new JButton("OK");
  JComboBox  nameBox = new JComboBox(new String[]{"Dialog", "SansSerif", "Serif", "Monospaced", "DialodInput"});
  JComboBox  styleBox = new JComboBox(new String[]{"plain", "bold", "italic"});
  JComboBox  sizeBox = new JComboBox(new String[]{"3", "5", "8", "10", "12", "14", "18", "24", "36", "48", "72"});

  /**
   * constructor
   * @param button the Font renderer
   * @param um a JFrame
   */
  public PounamuFontEditor(JButton button, JFrame um) {
      // Using Non-Modal dialogs, because editors may be heavy-weight
    super(um, "Pounamu Font Editor", false);
    this.button = button;
    JPanel upper = new JPanel();
    nameBox.setSelectedItem(button.getFont().getName());
    styleBox.setSelectedIndex(button.getFont().getStyle());
    sizeBox.setSelectedItem(""+button.getFont().getSize());
    newFont = new Font(button.getFont().getFamily(), button.getFont().getStyle(),button.getFont().getSize());
    nameBox.addActionListener(this);
    styleBox.addActionListener(this);
    sizeBox.addActionListener(this);
    upper.setBorder(BorderFactory.createTitledBorder("Specify here"));
    upper.add(nameBox);
    upper.add(styleBox);
    upper.add(sizeBox);
    JPanel middle = new JPanel();
    middle.add(preview);
    middle.setBorder(BorderFactory.createTitledBorder("Preview here"));
    preview.setBorderPainted(false);
    preview.setFont(newFont);
    JPanel lower = new JPanel();
    lower.add(doneButton);
    doneButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
        //this.dispose();
      }
    }
    );
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(upper, BorderLayout.NORTH);
    getContentPane().add(middle, BorderLayout.CENTER);
    getContentPane().add(lower, BorderLayout.SOUTH);
    this.setBounds(200, 300, 350, 250);
  }

    /**
     *  preview the font.
     */
    public void actionPerformed(ActionEvent evt) {
      String name= (String)nameBox.getSelectedItem();
      int style= styleBox.getSelectedIndex();
      String size= (String)sizeBox.getSelectedItem();
      newFont = new Font(name, style, Integer.parseInt(size));
      preview.setFont(newFont);
      this.validate();
    }

    /**
     * inform the FontCellRenderer of the final value.
     */
    public void ok_pressed(){
      button.setFont(newFont);
      button.repaint();
      this.dispose();
    }
  }