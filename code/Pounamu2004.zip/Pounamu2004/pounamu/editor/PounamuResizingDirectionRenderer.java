/*
 * @(#)PounamuVerticalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuResizingDirectionRenderer
 * Description:  to render ResizingDirection property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuResizingDirectionRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuResizingDirectionRenderer(){
    super(new String[]{"NONE", "BOTH", "HORIZONTAL", "VERTICAL"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get Vertical Alignment
   * @return Vertical Alignment
   */
  public int getResizingDirection(){
    if(getSelectedIndex()==0)
      return GridBagConstraints.NONE;
    else if(getSelectedIndex()==1)
      return GridBagConstraints.BOTH;
    else if(getSelectedIndex()==2)
      return GridBagConstraints.HORIZONTAL;
    else
      return GridBagConstraints.VERTICAL;
  }

  /**
   * set Vertical Alignment
   * @param i the int which represent the vertical alignment
   */
  public void setResizingDirection(int i){
    if(i==GridBagConstraints.NONE)
      setSelectedIndex(0);
    else if(i==GridBagConstraints.BOTH)
      setSelectedIndex(1);
    else if(i==GridBagConstraints.HORIZONTAL)
      setSelectedIndex(2);
    else
      setSelectedIndex(3);
  }
}