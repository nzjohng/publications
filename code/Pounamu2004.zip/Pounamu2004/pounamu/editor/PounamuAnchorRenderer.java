/*
 * @(#)PounamuVerticalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuAnchorRenderer
 * Description:  to render anchor property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuAnchorRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuAnchorRenderer(){
    super(new String[]{"CENTER", "NORTH", "NORTHEAST", "EAST", "SOUTHEAST", "SOUTH", "SOUTHWEST", "WEST", "NORTHWEST", "PAGE_START", "PAGE_END", "LINE_START", "LINE_END", "FIRST_LINE_START", "FIRST_LINE_END", "LAST_LINE_START", "LAST_LINE_END"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get anchor
   * @return anchor
   */
  public int getAnchor(){
    if(getSelectedIndex()==0)
      return GridBagConstraints.CENTER;
    else if(getSelectedIndex()==1)
      return GridBagConstraints.NORTH;
    else if(getSelectedIndex()==2)
      return GridBagConstraints.NORTHEAST;
    else if(getSelectedIndex()==3)
      return GridBagConstraints.EAST;
    else if(getSelectedIndex()==4)
      return GridBagConstraints.SOUTHEAST;
    else if(getSelectedIndex()==5)
      return GridBagConstraints.SOUTH;
    else if(getSelectedIndex()==6)
      return GridBagConstraints.SOUTHWEST;
    else if(getSelectedIndex()==7)
      return GridBagConstraints.WEST;
    else if(getSelectedIndex()==8)
      return GridBagConstraints.NORTHWEST;
    else if(getSelectedIndex()==9)
      return GridBagConstraints.PAGE_START;
    else if(getSelectedIndex()==10)
      return GridBagConstraints.PAGE_END;
    else if(getSelectedIndex()==11)
      return GridBagConstraints.LINE_START;
    else if(getSelectedIndex()==12)
      return GridBagConstraints.LINE_END;
    else if(getSelectedIndex()==13)
      return GridBagConstraints.FIRST_LINE_START;
    else if(getSelectedIndex()==14)
      return GridBagConstraints.FIRST_LINE_END;
    else if(getSelectedIndex()==15)
      return GridBagConstraints.LAST_LINE_START;
    else
      return GridBagConstraints.LAST_LINE_END;
  }

  /**
   * set anchor
   * @param i the int which represent the anchor
   */
  public void setAnchor(int i){
    if(i==GridBagConstraints.CENTER)
      setSelectedIndex(0);
    else if(i==GridBagConstraints.NORTH)
      setSelectedIndex(1);
    else if(i==GridBagConstraints.NORTHEAST)
      setSelectedIndex(2);
    else if(i==GridBagConstraints.EAST)
      setSelectedIndex(3);
    else if(i==GridBagConstraints.SOUTHEAST)
      setSelectedIndex(4);
    else if(i==GridBagConstraints.SOUTH)
      setSelectedIndex(5);
    else if(i==GridBagConstraints.SOUTHWEST)
      setSelectedIndex(6);
    else if(i==GridBagConstraints.WEST)
      setSelectedIndex(7);
    else if(i==GridBagConstraints.NORTHWEST)
      setSelectedIndex(8);
    else if(i==GridBagConstraints.PAGE_START)
      setSelectedIndex(9);
    else if(i==GridBagConstraints.PAGE_END)
      setSelectedIndex(10);
    else if(i==GridBagConstraints.LINE_START)
      setSelectedIndex(11);
    else if(i==GridBagConstraints.LINE_END)
      setSelectedIndex(12);
    else if(i==GridBagConstraints.FIRST_LINE_START)
      setSelectedIndex(13);
    else if(i==GridBagConstraints.FIRST_LINE_END)
      setSelectedIndex(14);
    else if(i==GridBagConstraints.LAST_LINE_START)
      setSelectedIndex(15);
    else
      setSelectedIndex(16);
  }
}