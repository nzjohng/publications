/*
 * @(#)PounamuMultiLinesTextRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.text.*;

/**
 * Title: PounamuMultiLinesTextRenderer
 * Description:  A JButton to render PounamuMultiLinesText property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuMultiLinesTextRenderer extends JScrollPane{

  PTextArea jta = new PTextArea();

  /**
   * constructor
   */
  public PounamuMultiLinesTextRenderer(){
    super();
    setPreferredSize(new Dimension(120, 40));
    setBounds(0, 0, 120, 40);
    setViewportView(jta);
    this.validate();
  }

  /**
   * get multiLinesText
   * @return Vector
   */
  public Vector getMultiLinesText(){
    return jta.getLines();
  }

  /**
   * set MultiLinesText
   * @param text the Vector value
   */
  public void setMultiLinesText(Vector text){
  	String s = new String();
  	if(text.size()>0) s = (String)text.get(0);
  	for(int i=1; i<text.size(); i++){
  		s += "\n"+(String)text.get(i);
  	}
		jta.setText(s);
  }

	class PTextArea extends JTextArea{

		public PTextArea(){}

		public String getLine(int line){
			try{
				if( line<0 || line>getLineCount()) return null;
				String s = super.getText();
				s = s.substring(getLineStartOffset(line), getLineEndOffset(line));
				return s.replaceAll("\n", "");
	  	}catch(BadLocationException ble){return null;}
		}

		public Vector getLines(){
			Vector s = new Vector();
			for(int i=0; i<getLineCount(); i++){
				s.add(getLine(i));
			}
			return s;
		}
	}

}