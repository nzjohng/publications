/*
 * @(#)PounamuLayoutRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import pounamu.visualcomp.*;



/**
 * Title: PounamuInsetsRenderer
 * Description:  A JPanel to render the insets property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */

public class PounamuInsetsRenderer extends JPanel{

  JLabel jl1 = new JLabel("top");
  JLabel jl2 = new JLabel("bottom");
  JLabel jl3 = new JLabel("left");
  JLabel jl4 = new JLabel("right");
  JTextField jtf1 = new JTextField(5);
  JTextField jtf2 = new JTextField(5);
  JTextField jtf3 = new JTextField(5);
  JTextField jtf4 = new JTextField(5);

  Insets insets = null;
  /**
   * constructor
   */
  public PounamuInsetsRenderer(){
    super();
    setPreferredSize(new Dimension(120, 120));
    setToolTipText("reset shape inserts");
    insets = new Insets(0, 0, 0, 0);
	  setLayout(new GridLayout(4, 2, 4, 4));
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jl3);
		add(jtf3);
		add(jl4);
		add(jtf4);
	}

  /**
   * set LayoutParameters
   * @param lm the layoutManager value
   */
  public void setInsets(Insets insets){
		jtf1.setText(""+insets.top);
		jtf2.setText(""+insets.bottom);
		jtf3.setText(""+insets.left);
  	jtf4.setText(""+insets.right);
  }

  /**
   * get LayoutParameters
   * @return the layoutManager
   */
  public Insets getInsets(){
    try{
			insets.top = Integer.parseInt(jtf1.getText());
			insets.bottom = Integer.parseInt(jtf2.getText());
			insets.left = Integer.parseInt(jtf3.getText());
			insets.right = Integer.parseInt(jtf4.getText());
	    return insets;
    }catch(Exception e){
      JOptionPane.showMessageDialog(this, "Insets parameters must be int values");
		  return insets;
    }
  }
}