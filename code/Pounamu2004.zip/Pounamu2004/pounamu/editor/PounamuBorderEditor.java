/*
 * @(#)PounamuBorderEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */


package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Title: PounamuBorderEditor
 * Description:  A JDialog to edit the Border properrty
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuBorderEditor extends JDialog  {

  JButton button = null;
  Font newFont = null;
  JButton preview = new JButton("see my border, is it you want?");
  JButton doneButton = new JButton("OK");
    /**
   * constructor
   * @param button the PounamuBorderRenderer
   * @param un the JFrame
   */
  public PounamuBorderEditor(JButton button, JFrame um) {
      // Using Non-Modal dialogs, because editors may be heavy-weight
    super(um, "Pounamu Border Editor", false);
    this.button = button;
    JTabbedPane upper = new JTabbedPane();
    JPanel simple = new JPanel();
    JPanel matte = new JPanel();
    JPanel titled = new JPanel();
    JPanel compound = new JPanel();
    upper.add(simple, "simple");
    upper.add(matte, "matte");
    upper.add(titled, "titled");
    upper.add(compound, "compound");
    JPanel selector = new JPanel();//etched, raisedbevel, loweredbevel, empty;
    JRadioButton noBorder  = new JRadioButton("null", true);
    JRadioButton line  = new JRadioButton("line border", false);
    JRadioButton etched  = new JRadioButton("etched border", false);
    JRadioButton raisedbevel  = new JRadioButton("raisedbevel border", false);
    JRadioButton loweredbevel  = new JRadioButton("loweredbevel border", false);
    JRadioButton empty  = new JRadioButton("empty border", false);
    ButtonGroup bg = new ButtonGroup();
    bg.add(noBorder);
    bg.add(line);
    bg.add(etched);
    bg.add(raisedbevel);
    bg.add(loweredbevel);
    bg.add(empty);
    selector.add(noBorder);
    selector.add(line);
    selector.add(etched);
    selector.add(raisedbevel);
    selector.add(loweredbevel);
    selector.add(empty);
    simple.add(selector);
    noBorder.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(null);
         PounamuBorderEditor.this.validate();
       }
    });

    line.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(BorderFactory.createLineBorder(Color.black));
         PounamuBorderEditor.this.validate();
       }
    });

    etched.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(BorderFactory.createEtchedBorder());
         PounamuBorderEditor.this.validate();
       }
    });

    raisedbevel.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(BorderFactory.createRaisedBevelBorder());
         PounamuBorderEditor.this.validate();
       }
    });

    loweredbevel.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(BorderFactory.createLoweredBevelBorder());
         PounamuBorderEditor.this.validate();
       }
    });

    empty.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         PounamuBorderEditor.this.preview.setBorder(BorderFactory.createEmptyBorder());
         PounamuBorderEditor.this.validate();
       }
    });

    upper.setBorder(BorderFactory.createTitledBorder("Specify here"));
    JPanel middle = new JPanel();
    middle.add(preview);
    middle.setBorder(BorderFactory.createTitledBorder("Preview here"));
    preview.setBorder(BorderFactory.createEmptyBorder());
    preview.setBorderPainted(true);
    preview.setFont(newFont);
    JPanel lower = new JPanel();
    lower.add(doneButton);
    doneButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
      }
    }
    );
    Border b = button.getBorder();
    //System.out.println("0 Border is " + b);
    if(b == null){
      noBorder.setSelected(true);
      preview.setBorder(null);
    }
    else if(b instanceof EmptyBorder){
      empty.setSelected(true);
      preview.setBorder(BorderFactory.createEmptyBorder());
    }
    else if(b instanceof LineBorder){
      line.setSelected(true);
      preview.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    else if(b instanceof EtchedBorder){
      etched.setSelected(true);
      preview.setBorder(BorderFactory.createEtchedBorder());
    }
    else if(b instanceof BevelBorder){
      //System.out.println("1 b is BevelBorder");
      if(((BevelBorder)b).getBevelType()==BevelBorder.RAISED){
        //System.out.println("2 b is BevelBorder.RAISED");
        raisedbevel.setSelected(true);
        preview.setBorder(BorderFactory.createRaisedBevelBorder());
      }
      else{
        //System.out.println("2 b is BevelBorder.LOWERED");
        loweredbevel.setSelected(true);
        preview.setBorder(BorderFactory.createLoweredBevelBorder());
      }
    }
    
    else {
      noBorder.setSelected(true);
      preview.setBorder(null);
    }
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(upper, BorderLayout.NORTH);
    getContentPane().add(middle, BorderLayout.CENTER);
    getContentPane().add(lower, BorderLayout.SOUTH);
    this.setBounds(200, 340, 650, 250);
  }


     /**
      * infom the renderer to set up the final Border value
      */
    public void ok_pressed(){
      button.setBorder(preview.getBorder());
      button.getParent().validate();
      button.repaint();
      button.getParent().repaint();
      this.dispose();
    }
  }