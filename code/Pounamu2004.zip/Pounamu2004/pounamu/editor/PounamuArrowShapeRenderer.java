/*
 * @(#)PounamuArrowShapeRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuArrowShapeRenderer
 * Description:  A JComboBox to render the PounamuArrowShape property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuArrowShapeRenderer extends JComboBox{
  PounamuComponentSpecifier pse;
  ImageIcon[] imageIcons = new ImageIcon[9];
  String[] imageNames = new String[]{"noshape", "halfopen", "fullopen", "halfclosedempty", "halfclosedfill", "fullclosedempty", "fullclosedfill", "diamondempty", "diamondfill"};
  String shape = "noshape";
  /**
   * constructor
   */
  public PounamuArrowShapeRenderer(){
    super();
    this.pse = pse;
    initialThisBox();
    ComboBoxRenderer renderer= new ComboBoxRenderer();
    renderer.setPreferredSize(new Dimension(100, 20));
    this.setRenderer(renderer);
  }
  /**
   * set Arrow Shape
   * @param shape the string which represent the shape
   */
  public void setArrowShape(String shape){
    for(int i = 0; i < imageNames.length; i++){
      if(imageNames[i].equals(shape)){
        this.setSelectedIndex(i);
        return;
      }
    }
  }

  /**
   * get Arrow Shape
   * @return the sected arrow shape
   */
  public String getArrowShape(){
    return imageNames[this.getSelectedIndex()];
  }

  /**
   * intialthis renderer
   */
  public void initialThisBox(){
    try{
      for(int i = 0; i <imageNames.length; i++){
        String s = "..\\image\\" + imageNames[i] +".gif";
        imageIcons[i] = new ImageIcon(PounamuArrowShapeRenderer.class.getResource(s));
        this.addItem(imageIcons[i]);
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * an renderer to render a image in the JComboBox
   */
   class ComboBoxRenderer extends JLabel implements ListCellRenderer {
        public ComboBoxRenderer() {
            setOpaque(true);
            setHorizontalAlignment(CENTER);
            setVerticalAlignment(CENTER);
        }

        public Component getListCellRendererComponent(
                                           JList list,
                                           Object value,
                                           int index,
                                           boolean isSelected,
                                           boolean cellHasFocus) {
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }

            ImageIcon icon = (ImageIcon)value;
            //setText(icon.getDescription());
            setIcon(icon);
            return this;
        }
    }
}