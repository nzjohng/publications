/*
 * @(#)PounamuHorizontalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.

editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuShapeTypeRenderer
 * Description:  A JComboBox to render the available shape primitives
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuShapeTypeRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuShapeTypeRenderer(){
    super(new String[]{"Rectangle", "RoundRectangle", "Oval", "Rhomb", "Trapezium", "Parallelogram", "Pentagon", "Hexagon"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get HorizontalAlignment
   * @return the int which represent the alignment
   */
  public String getShapeType(){
    if(getSelectedIndex()==0)
      return "Rectangle";
    else if(getSelectedIndex()==1)
      return "RoundRectangle";
    else if(getSelectedIndex()==2)
      return "Oval";
    else if(getSelectedIndex()==3)
      return "Rhomb";
    else if(getSelectedIndex()==4)
      return "Trapezium";
    else if(getSelectedIndex()==5)
      return "Parallelogram";
    else if(getSelectedIndex()==6)
      return "Pentagon";
    else
      return "Hexagon";
  }

  /**
   * set Horizontal Alignment
   * @param i the int which represent the alignment
   */
  public void setShapeType(String s){
    if(s.equals("Rectangle"))
      setSelectedIndex(0);
    else if(s.equals("RoundRectangle"))
      setSelectedIndex(1);
    else if(s.equals("Oval"))
      setSelectedIndex(2);
    else if(s.equals("Rhomb"))
      setSelectedIndex(3);
    else if(s.equals("Trapezium"))
      setSelectedIndex(4);
    else if(s.equals("Parallelogram"))
      setSelectedIndex(5);
    else if(s.equals("Pentagon"))
      setSelectedIndex(6);
    else
      setSelectedIndex(7);
  }
}