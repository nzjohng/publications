/*
 * @(#)PounamuBooleanRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuBooleanRenderer
 * Description:  A JComboBox to render the boolean property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuBooleanRenderer extends JComboBox{

  /**
   * the constructor
   */
  public PounamuBooleanRenderer(){
    super(new String[]{"true", "false"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get the Boolean Value
   * @return the selected boolean value
   */
  public boolean getBooleanValue(){
    if(getSelectedIndex()==0)
      return true;
    else
      return false;
  }

  /**
   * set boolean value
   * @param value the boolean value to set
   */
  public void setBooleanValue(boolean value){
    if(value == true)
      setSelectedIndex(0);
    else
      setSelectedIndex(1);
  }
}