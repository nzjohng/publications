/*
 * @(#)PounamuImageResourceEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */


package pounamu.editor;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import java.io.*;
import pounamu.visualcomp.*;

/**
 * Title: PounamuImageResourceEditor
 * Description:  a Jdialog used to editor Font property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuImageResourceEditor extends JDialog /*implements ActionListener*/ {

  PounamuImageResourceRenderer button = null;
  Font newFont = null;
  JLabel preview = new JLabel("No Preview available", null, JLabel.CENTER);
  JButton doneButton = new JButton("OK");
  JTextField source = new JTextField(30);
  JButton browser = new JButton("browser");
  JFileChooser fileChooser = new JFileChooser();
  PounamuLabel label = null;
  String fileSeparator = System.getProperty("file.separator");
  String imageHome = null;
  String imageName = null;
  
  /**
   * constructor
   * @param button the Pounamu Image Resource renderer
   * @param um a JFrame
   */
  public PounamuImageResourceEditor(PounamuImageResourceRenderer button, JFrame um) {
    super(um, "Pounamu Image Resource Editor", false);
    this.button = button;
    this.label = button.getPounamuLabel();
    this.imageHome = label.getTool().getLocation()+fileSeparator+"images"+fileSeparator+"forlabels";
    JPanel upper = new JPanel();
    imageName = button.getImageResource(); 
    source.setText(imageName);
    
    if(!(source.getText().equals("Null")))
      getPreview();
    source.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        getPreview();  
      }
    });   
    browser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setCurrentDirectory(new File(imageHome));
        int returnVal = fileChooser.showOpenDialog(PounamuImageResourceEditor.this);
        if(returnVal == JFileChooser.APPROVE_OPTION){
          File inputFile = fileChooser.getSelectedFile().getAbsoluteFile();
          String path = inputFile.getPath();
          System.out.println("in class PIRE, path is " +path);
          if(!path.startsWith(imageHome)){
            imageName = "Null";
            label.getTool().getPounamu().displayMessage("the image you chosen is not in the default folder");
          }
          else if(path.endsWith(".jpeg")||path.endsWith(".gif")||path.endsWith(".JPEG")||path.endsWith(".GIF"))
            imageName = inputFile.getName();
          else
            imageName = "Null";
          source.setText(imageName);
          getPreview();
        }
        else {
          return;
        }
      }
    });
    upper.setBorder(BorderFactory.createTitledBorder("Specify image source here"));
    upper.add(source);
    upper.add(browser);    
    JPanel middle = new JPanel();
    middle.add(preview);
    middle.setBorder(BorderFactory.createTitledBorder("Preview here"));
    //preview.setBorderPainted(false);
    //preview.setFont(newFont);
    JPanel lower = new JPanel();
    lower.add(doneButton);
    doneButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
        //this.dispose();
      }
    }
    );
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(upper, BorderLayout.NORTH);
    getContentPane().add(middle, BorderLayout.CENTER);
    getContentPane().add(lower, BorderLayout.SOUTH);
    //this.setBounds(200, 300, 350, 250);
    this.pack();
  }

    /**
     *  preview the font.
     */
    public void getPreview() {
      if(imageName.equals("Null")){
        preview.setText("No preview available");
      }
      else if(!(imageName.endsWith(".jpg")||imageName.endsWith(".gif")||imageName.endsWith(".JPEG")||imageName.endsWith(".GIF"))){
        imageName = "Null";
        source.setText(imageName);
        preview.setText("No preview available");
      }
      else{
        ImageIcon image = createImageIcon(imageHome+fileSeparator+imageName, "image for JLabel");
        if(image == null){
          preview.setText("No preview available");
          preview.setIcon(null);
          source.setText("Null");
          imageName = "Null";
        }
        else{
          preview.setText("");
          preview.setIcon(image);  
        }
      }
      preview.repaint();
      this.validate();
      this.pack();
   }
   
    /** Returns an ImageIcon, or null if the path was invalid. */
    protected static ImageIcon createImageIcon(String path, String description) {
      try{
        java.net.URL imgURL = new java.net.URL("file://localhost/"+path);      
        if (imgURL != null) {
          return new ImageIcon(imgURL, description);
        } 
        else {
          return null;
        }
      }
      catch(Exception e){
        return null;
      }
    }


    /**
     * inform the FontCellRenderer of the final value.
     */
    public void ok_pressed(){
      button.setImageResource(imageName);
      button.repaint();
      this.dispose();
    }
  }