/*
 * @(#)PounamuLayoutEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;
import java.awt.*;
import java.util.Vector;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import pounamu.visualcomp.*;

/**
 * Title: PounamuLayoutEditor
 * Description:  A JDialog to edit GridBagConstraints property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */
public class PounamuGridBagConstraintsEditor extends JDialog  {

  JLabel lGridx = new JLabel("gridx");
  JLabel lGridy = new JLabel("gridy");
  JLabel lGridwidth = new JLabel("gridwidth");
  JLabel lGridheight = new JLabel("gridheight");
  JLabel lIpadx = new JLabel("ipadx");
  JLabel lIpady = new JLabel("ipady");
  JLabel lWeightx = new JLabel("weightx");
  JLabel lWeighty = new JLabel("weighty");
  JTextField tGridx = new JTextField(6);
  JTextField tGridy = new JTextField(6);
  JTextField tGridwidth = new JTextField(6);
  JTextField tGridheight = new JTextField(6);
  JTextField tIpadx = new JTextField(6);
  JTextField tIpady = new JTextField(6);
  JTextField tWeightx = new JTextField(6);
  JTextField tWeighty = new JTextField(6);

  JLabel lBottom = new JLabel("bottom");
  JLabel lLeft = new JLabel("left");
  JLabel lRight = new JLabel("right");
  JLabel lTop = new JLabel("top");
  JTextField tBottom = new JTextField(6);
  JTextField tLeft = new JTextField(6);
  JTextField tRight = new JTextField(6);
  JTextField tTop = new JTextField(6);

  JLabel jRd = new JLabel("Resizing direction");
  PounamuResizingDirectionRenderer rd = new PounamuResizingDirectionRenderer();

  JLabel jAnchor = new JLabel("Anchor");
  PounamuAnchorRenderer anchor = new PounamuAnchorRenderer();

  JButton doneButton = new JButton("OK");
  PounamuGridBagConstraintsRenderer jb = null;

  /**
   * constructor
   * @param um the JFrame
   */
  public PounamuGridBagConstraintsEditor(PounamuGridBagConstraintsRenderer jb, JFrame um) {
      // Using Non-Modal dialogs, because editors may be heavy-weight
    super(um, "Pounamu GridBagConstraints Editor", true);
    this.jb = jb;

    JPanel num = new JPanel();
    num.setBorder(BorderFactory.createTitledBorder("Please input the constraint parameters here"));
    num.setLayout(new GridLayout(4, 4, 10, 4));
    num.add(lGridx);
    num.add(tGridx);
    num.add(lGridy);
    num.add(tGridy);
    num.add(lGridwidth);
    num.add(tGridwidth);
    num.add(lGridheight);
    num.add(tGridheight);
    num.add(lIpadx);
    num.add(tIpadx);
    num.add(lIpady);
    num.add(tIpady);
    num.add(lWeightx);
    num.add(tWeightx);
    num.add(lWeighty);
    num.add(tWeighty);

    JPanel selector = new JPanel();
    selector.setBorder(BorderFactory.createTitledBorder("Please select the constraint parameters here"));
    selector.setLayout(new GridLayout(2, 4, 10, 4));
    selector.add(jRd);
    selector.add(rd);
    selector.add(jAnchor);
    selector.add(anchor);

    JPanel insets = new JPanel();
    insets.setBorder(BorderFactory.createTitledBorder("Please input the insets parameters here"));
    insets.setLayout(new GridLayout(2, 4, 10, 4));
    insets.add(lBottom);
    insets.add(tBottom);
    insets.add(lLeft);
    insets.add(tLeft);
    insets.add(lRight);
    insets.add(tRight);
    insets.add(lTop);
    insets.add(tTop);

    JPanel ok = new JPanel();
    ok.add(doneButton);
    doneButton.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
      }
    }
    );
    setProperties();
    getContentPane().setLayout(new VerticalFlowLayout());
    getContentPane().add(num);
    getContentPane().add(selector);
    getContentPane().add(insets);
    getContentPane().add(ok);
    this.validate();
    this.setBounds(200, 300, 300, 350);
  }

	/**
	 * set properties
	 */
    public void setProperties(){
      GridBagConstraints gc = jb.getGridBagConstraints();
	  tGridx.setText(String.valueOf(gc.gridx));
	  tGridy.setText(String.valueOf(gc.gridy));
	  tGridwidth.setText(String.valueOf(gc.gridwidth));
	  tGridheight.setText(String.valueOf(gc.gridheight));
	  tIpadx.setText(String.valueOf(gc.ipadx));
	  tIpady.setText(String.valueOf(gc.ipady));
	  tWeightx.setText(String.valueOf(gc.weightx));
	  tWeighty.setText(String.valueOf(gc.weighty));
	  Insets i = gc.insets;
	  tBottom.setText(String.valueOf(i.bottom));
	  tLeft.setText(String.valueOf(i.left));
	  tRight.setText(String.valueOf(i.right));
	  tTop.setText(String.valueOf(i.top));
	  rd.setResizingDirection(gc.fill);
	  anchor.setAnchor(gc.anchor);
    }

    /**
     * inform the renderer the final value of the payout property
     */
    public void ok_pressed(){
      GridBagConstraints gc = new GridBagConstraints();
        try{
		  gc.gridx = Integer.parseInt(tGridx.getText());
		  gc.gridy = Integer.parseInt(tGridy.getText());
		  gc.gridwidth = Integer.parseInt(tGridwidth.getText());
		  gc.gridheight = Integer.parseInt(tGridheight.getText());
		  gc.ipadx = Integer.parseInt(tIpadx.getText());
		  gc.ipady = Integer.parseInt(tIpady.getText());
		  Insets i = new Insets(0,0,0,0);
		  i.bottom = Integer.parseInt(tBottom.getText());
		  i.left = Integer.parseInt(tLeft.getText());
		  i.right = Integer.parseInt(tRight.getText());
		  i.top = Integer.parseInt(tTop.getText());
		  gc.insets = i;
	    }catch(Exception e){
	      JOptionPane.showMessageDialog(this, "gridx, gridy, gridwidth, gridheight, ipadx, ipady and insets parameters must be int values");
	      return;
	    }
        try{
		  gc.weightx = Double.parseDouble(tWeightx.getText());
		  gc.weighty = Double.parseDouble(tWeighty.getText());
	    }catch(Exception e){
	      JOptionPane.showMessageDialog(this, "weightx and weighty must be double values");
	      return;
	    }
	  gc.fill = rd.getResizingDirection();
	  gc.anchor = anchor.getAnchor();
      jb.setGridBagConstraints(gc);
      //button.setLayout(lm);
      //String s = layout.substring(0, layout.indexOf("Layout"));
      //((PounamuLayoutRenderer)panel).text.setText(s);
      //button.setToolTipText(layout);
      //button.validate();
      //button.repaint();
      //this.setVisible(false);
      this.dispose();
    }
  }