/*
 * @(#)PounamuComponentSpecifier.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import pounamu.visualcomp.*;
import pounamu.core.*;

/**
 * Title: PounamuComponentSpecifier
 * Description:  A JFrame to specify any pounamu component
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuComponentSpecifier extends JPanel {

  Object target;
  String[] properties;
  String[] types;
  String[] flags;
  Hashtable rendererType = new Hashtable();
  Hashtable rendererComp = new Hashtable();
  Hashtable exportRadio = new Hashtable();
  Hashtable exportTextField = new Hashtable();
  Hashtable radioLabel = new Hashtable();
  Hashtable radioTextField = new Hashtable();

  /**
   * constructor
   * 1) initial renderers
   * 2) initial interface
   * 3) set properties in the interface
   * 4) set exported properties
   * @param target the shape to be specified
   * @param properties the property name list
   * @param types the property type list
   */
  public PounamuComponentSpecifier(Object target){
    //super(target.getClass().getName());
    this.target = target;
    this.properties = ((Configurable)target).propertyNameList();
    this.types = ((Configurable)target).propertyTypeList();
    this.flags = ((Configurable)target).propertyFlagList();
    try {
      initHashtables();
      initInterface();
      setProperties();
      setExportedProperties();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  
  public void setTarget(Object target){
    this.target = target;
  }
  
  public Object getTarget(){
    return target;
  }

  /**
   * assign the renderers to their correspnding types
   */
  private void initHashtables(){
    rendererType.put("int", "PounamuIntRenderer");
    rendererType.put("float", "PounamuFloatRenderer");
    rendererType.put("boolean", "PounamuBooleanRenderer");
    rendererType.put("String", "PounamuStringRenderer");
    rendererType.put("Font", "PounamuFontRenderer");
    rendererType.put("Border", "PounamuBorderRenderer");
    rendererType.put("Color", "PounamuColorRenderer");
    rendererType.put("HorizontalAlignment", "PounamuHorizontalAlignmentRenderer");
    rendererType.put("VerticalAlignment", "PounamuVerticalAlignmentRenderer");
    rendererType.put("LayoutParameters", "PounamuLayoutRenderer");
    rendererType.put("MultiLinesText", "PounamuMultiLinesTextRenderer");
    rendererType.put("GridBagConstraints", "PounamuGridBagConstraintsRenderer");
    rendererType.put("Position", "PounamuPositionRenderer");
    rendererType.put("BasicStroke", "PounamuBasicStrokeRenderer");
    rendererType.put("Insets", "PounamuInsetsRenderer");
    rendererType.put("ShapeType", "PounamuShapeTypeRenderer");
    rendererType.put("Size", "PounamuSizeRenderer");
    rendererType.put("Location", "PounamuLocationRenderer");
    rendererType.put("ImageResource", "PounamuImageResourceRenderer");
  }

   /**
   * initial visual interface
   */
  private void initInterface(){
    this.setLayout(new BorderLayout());
    JPanel okPanel = new JPanel();
     JButton ok = new JButton("OK");
     okPanel.add(ok);
     ok.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         ok_pressed();
       }
     });
    this.add(okPanel, BorderLayout.SOUTH);
    //int count1 = types.length;
    //int count2 = (1+count1)/2;
    JPanel specificationPanel = new JPanel();
    //specificationPanel.setLayout(new GridLayout(count2,2));
    specificationPanel.setLayout(new VerticalFlowLayout());
    specificationPanel.setBorder(BorderFactory.createTitledBorder("Please specify properties here"));
    for(int i = 0; i < properties.length; i++){
      String propertyName = properties[i];
      String type = types[i];
      String flag = flags[i];
      try{
        Class c = Class.forName("pounamu.editor."+rendererType.get(type));
        Component newEditor = (Component)c.newInstance();
        if(newEditor instanceof PounamuImageResourceRenderer)
          ((PounamuImageResourceRenderer)newEditor).setPounamuComponentSpecifier(this);
        JPanel jp = new JPanel();
        jp.add(newEditor);
        jp.setBorder(BorderFactory.createTitledBorder(propertyName));
        specificationPanel.add(jp);
        rendererComp.put(propertyName, newEditor);
        //System.out.println("+++++++++++++++++++++pounamu.editor."+rendererType.get(type)+"+++ ok  +++");
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
    }
    JPanel selectionPanel = new JPanel();
    //selectionPanel.setLayout(new GridLayout(types.length,2));
    selectionPanel.setLayout(new VerticalFlowLayout());
    selectionPanel.setBorder(BorderFactory.createTitledBorder("Please export properties here"));
    for(int i = 0; i < properties.length; i++){
      JRadioButton jrb = new JRadioButton(properties[i]);
      JLabel jl = new JLabel("will be exported as", JLabel.CENTER);
      jl.setEnabled(false);
      JTextField jtf = new JTextField("", 6);
      jtf.setEnabled(false);
      JPanel temp = new JPanel();
      temp.setLayout(new GridLayout(1,2));
      temp.add(jrb);
      temp.add(jtf);
      selectionPanel.add(temp);
      //selectionPanel.add(jrb);
      //selectionPanel.add(jl);
      //selectionPanel.add(jtf);
      //radioLabel.put(jrb, jl);
      radioTextField.put(jrb, jtf);
      exportRadio.put(properties[i], jrb);
      exportTextField.put(properties[i], jtf);
      jrb.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          JRadioButton jrb = (JRadioButton)e.getSource();
          if(jrb.isSelected()){
            //((JLabel)radioLabel.get(jrb)).setEnabled(true);
            ((JTextField)radioTextField.get(jrb)).setEnabled(true);
          }
          else{
            //((JLabel)radioLabel.get(jrb)).setEnabled(false);
            ((JTextField)radioTextField.get(jrb)).setEnabled(false);
          }
        }
      });
     }

     JTabbedPane upper = new JTabbedPane();
     this.setLayout(new BorderLayout());
     JScrollPane jsp1 = new JScrollPane(specificationPanel);
     jsp1.setPreferredSize(new Dimension(240, 490));
     JScrollPane jsp2 = new JScrollPane(selectionPanel);
     jsp2.setPreferredSize(new Dimension(240, 490));
     upper.add("Properties", jsp1);
     upper.add("exported props", jsp2);
     this.add(upper, BorderLayout.NORTH);
     this.add(okPanel, BorderLayout.SOUTH);
     this.validate();
  }

  /**
   * set up properties
   */
  private void setProperties(){
    for(int i = 0; i < properties.length; i++){
      String propertyName = properties[i];
      String type = types[i];
      String methodName = "";
      Class c = target.getClass();
      if(type.equals("boolean"))
        methodName = "is"+capitalizeFirstLetter(propertyName);
      else
        methodName = "get"+capitalizeFirstLetter(propertyName);
      try{
        Method m = c.getMethod(methodName, new Class[]{});
        Object value = m.invoke(target, new Object[]{});
        Component renderer = (Component)rendererComp.get(propertyName);
        if(type.equals("int"))
          ((PounamuIntRenderer)renderer).setText(""+((Integer)value).intValue());
        else if(type.equals("boolean"))
          ((PounamuBooleanRenderer)renderer).setBooleanValue(((Boolean)value).booleanValue());
        else if(type.equals("Font"))
          ((PounamuFontRenderer)renderer).setFont((Font)value);
        else if(type.equals("Border"))
          ((PounamuBorderRenderer)renderer).setBorder((Border)value);
        else if(type.equals("Color"))
          ((PounamuColorRenderer)renderer).setColor((Color)value);
        else if(type.equals("HorizontalAlignment"))
          ((PounamuHorizontalAlignmentRenderer)renderer).setHorizontalAlignment(((Integer)value).intValue());
        else if(type.equals("VerticalAlignment"))
          ((PounamuVerticalAlignmentRenderer)renderer).setVerticalAlignment(((Integer)value).intValue());
        else if(type.equals("LayoutParameters"))
          ((PounamuLayoutRenderer)renderer).setLayoutParameters((LayoutManager)value);
        else if(type.equals("MultiLinesText"))
          ((PounamuMultiLinesTextRenderer)renderer).setMultiLinesText((Vector)value);
        else if(type.equals("GridBagConstraints"))
          ((PounamuGridBagConstraintsRenderer)renderer).setGridBagConstraints((GridBagConstraints)value);
        else if(type.equals("Position"))
          ((PounamuPositionRenderer)renderer).setPosition((String)value);
        else if(type.equals("BasicStroke"))
          ((PounamuBasicStrokeRenderer)renderer).setBasicStroke((BasicStroke)value);
        else if(type.equals("Insets"))
          ((PounamuInsetsRenderer)renderer).setInsets((Insets)value);
        else if(type.equals("ShapeType"))
          ((PounamuShapeTypeRenderer)renderer).setShapeType((String)value);
        else if(type.equals("Size"))
          ((PounamuSizeRenderer)renderer).setMinimumSize((Dimension)value);
        else if(type.equals("Location"))
          ((PounamuLocationRenderer)renderer).setLocation((Point)value);
        else if(type.equals("ImageResource"))
          ((PounamuImageResourceRenderer)renderer).setImageResource((String)value);
        else
          ((PounamuStringRenderer)renderer).setText((String)value);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
    }
  }

  /**
   * set target exported properties
   */
  private void setExportedProperties(){
    String[] oldNames = ((Configurable)target).getExportedPropertyOldNames();
    String[] newnames = ((Configurable)target).getExportedPropertyNames();
    if(oldNames==null)
      return;
    for(int i = 0; i < oldNames.length; i++){
      if(exportRadio.get(oldNames[i])!=null)
        ((JRadioButton)(exportRadio.get(oldNames[i]))).setSelected(true);
      if(exportTextField.get(oldNames[i])!=null)
        ((JTextField)(exportTextField.get(oldNames[i]))).setText(newnames[i]);
      if(exportTextField.get(oldNames[i])!=null)
        ((JTextField)(exportTextField.get(oldNames[i]))).setEnabled(true);
    }
  }

  /**
   * to configure the target
   */
  public void ok_pressed(){
    setTargetProperties();
    setTargetExportedPropertis();
    ((Component)target).repaint();
  }

  /**
   * set each property of the target
   */
  private void setTargetProperties(){
    for(int i = 0; i < properties.length; i++){
      String propertyName = properties[i];
      String type = types[i];
      Class c = target.getClass();
      String methodName = "set"+capitalizeFirstLetter(propertyName);
      Component renderer = (Component)rendererComp.get(propertyName);
      try{
        if(type.equals("int")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuIntRenderer)renderer).getText());
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("boolean")){
          Method m = c.getMethod(methodName, new Class[]{boolean.class});
          Boolean value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Font")){
          Method m = c.getMethod(methodName, new Class[]{Font.class});
          Font value = ((PounamuFontRenderer)renderer).getFont();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Border")){
          Method m = c.getMethod(methodName, new Class[]{Border.class});
          Border value = ((PounamuBorderRenderer)renderer).getBorder();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Color")){
          Method m = c.getMethod(methodName, new Class[]{Color.class});
          Color value = ((PounamuColorRenderer)renderer).getColor();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("HorizontalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuHorizontalAlignmentRenderer)renderer).getHorizontalAlignment());
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("VerticalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuVerticalAlignmentRenderer)renderer).getVerticalAlignment());
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("LayoutParameters")){
          Method m = c.getMethod(methodName, new Class[]{LayoutManager.class});
          LayoutManager value = ((PounamuLayoutRenderer)renderer).getLayoutParameters();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("MultiLinesText")){
          Method m = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("GridBagConstraints")){
          Method m = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
          GridBagConstraints value = ((PounamuGridBagConstraintsRenderer)renderer).getGridBagConstraints();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Position")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuPositionRenderer)renderer).getPosition();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("BasicStroke")){
          Method m = c.getMethod(methodName, new Class[]{BasicStroke.class});
          BasicStroke value = ((PounamuBasicStrokeRenderer)renderer).getBasicStroke();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Insets")){
          Method m = c.getMethod(methodName, new Class[]{Insets.class});
          Insets value = ((PounamuInsetsRenderer)renderer).getInsets();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("ShapeType")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuShapeTypeRenderer)renderer).getShapeType();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Size")){
          Method m = c.getMethod(methodName, new Class[]{Dimension.class});
          Dimension value = ((PounamuSizeRenderer)renderer).getMinimumSize();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("Location")){
          Method m = c.getMethod(methodName, new Class[]{Point.class});
          Point value = ((PounamuLocationRenderer)renderer).getLocation();
          m.invoke(target, new Object[]{value});
        }
        else if(type.equals("ImageResource")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuImageResourceRenderer)renderer).getImageResource();
          m.invoke(target, new Object[]{value});
        }
        else{
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuStringRenderer)renderer).getText();
          m.invoke(target, new Object[]{value});
        }        
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
    }
    }

  /**
   * set exported target properties
   */
  private void setTargetExportedPropertis(){
    Vector exportedProperties = new Vector();
    Vector exportedPropertiesWithOldNames = new Vector();
    Vector exportedTypes = new Vector();
    Vector exportedFlags = new Vector();
    for(int i = 0; i < properties.length; i++){
      String oldPropertyName = properties[i];
      String type = types[i];
      String flag = flags[i];
      JRadioButton jrb = (JRadioButton)exportRadio.get(oldPropertyName);
      if(jrb.isSelected()){
        String newPropertyName = ((JTextField)radioTextField.get(jrb)).getText();
        if(newPropertyName!=null&&!newPropertyName.equals("")){
          exportedProperties.add(newPropertyName);
          exportedPropertiesWithOldNames.add(oldPropertyName);
          exportedTypes.add(type);
          exportedFlags.add(flag);
        }
        else{
          JOptionPane.showMessageDialog(this, "Please input the export name for property "+oldPropertyName);
          return;
        }
      }
    }
    String[] sa1= new String[exportedProperties.size()];
    String[] sa2= new String[exportedProperties.size()];
    String[] sa3= new String[exportedProperties.size()];
    String[] sa4= new String[exportedProperties.size()];
    for(int i = 0; i < exportedProperties.size(); i++){
      sa1[i] = (String)exportedProperties.elementAt(i);
      sa2[i] = (String)exportedPropertiesWithOldNames.elementAt(i);
      sa3[i] = (String)exportedTypes.elementAt(i);
      sa4[i] = (String)exportedFlags.elementAt(i);
    }
    ((Configurable)target).setExportedPropertyNames(sa1);
    ((Configurable)target).setExportedPropertyOldNames(sa2);
    ((Configurable)target).setExportedPropertyTypes(sa3);
    ((Configurable)target).setExportedPropertyFlags(sa4);
  }

  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }

}