/*
 * @(#)PounamuShapeSpecifier.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import pounamu.visualcomp.*;
import pounamu.core.*;
import pounamu.data.*;
import java.io.*;

/**
 * Title: PounamuShapeSpecifier
 * Description:  A JFrame to specify any pounamu shape
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuShapeSpecifier extends JPanel {

  PounamuShape target;
  String[] propertyNames;
  String[] propertyTypes;
  String[] componentPaths;
  String[] propertyOldNames;
  String[] propertyFlags;
  Hashtable rendererType = new Hashtable();
  Hashtable rendererComp = new Hashtable();
  Hashtable exportRadio = new Hashtable();
  Hashtable exportTextField = new Hashtable();
  Hashtable radioLabel = new Hashtable();
  Hashtable radioTextField = new Hashtable();

  /**
   * constructor
   * 1) initial renderers
   * 2) initial interface
   * 3) set properties in the interface
   * @param target the shape to be specified
   */
  public PounamuShapeSpecifier(PounamuShape target){
    //super(target.getClass().getName());
    this.target = target;
    propertyNames = target.getExportedPropertyNames();
    propertyTypes = target.getExportedPropertyTypes();
    componentPaths = target.getExportedComponentPath();
    propertyOldNames = target.getExportedPropertyOldNames();
    propertyFlags = target.getExportedPropertyFlags();
    try {
      initHashtables();
      initInterface();
      setProperties();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Constructor
   * @param pp the IconDisplayPanel where the target is on
   */
  public PounamuShapeSpecifier(IconDisplayPanel pp){
    pp.save();
    File file = new File(pp.getOutputPath());
    LoadXMLFile load = new LoadXMLFile(file);
    target = new PounamuShape(pp.getName(), load.getDocument(), pp.getProject(), new PounamuView());
    //System.out.println(target.getName());
    propertyNames = target.getExportedPropertyNames();
    //System.out.println(propertyNames.length);
    propertyTypes = target.getExportedPropertyTypes();
    //System.out.println(propertyTypes.length);
    componentPaths = target.getExportedComponentPath();
    //System.out.println(componentPaths.length);
    propertyOldNames = target.getExportedPropertyOldNames();
    propertyFlags = target.getExportedPropertyFlags();
    try {
      initHashtables();
      initInterface();
      setProperties();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**
   * assign the renderers to their corresponding types
   */
  private void initHashtables(){
    rendererType.put("int", "PounamuIntRenderer");
    rendererType.put("float", "PounamuFloatRenderer");
    rendererType.put("boolean", "PounamuBooleanRenderer");
    rendererType.put("String", "PounamuStringRenderer");
    rendererType.put("Font", "PounamuFontRenderer");
    rendererType.put("Border", "PounamuBorderRenderer");
    rendererType.put("Color", "PounamuColorRenderer");
    rendererType.put("HorizontalAlignment", "PounamuHorizontalAlignmentRenderer");
    rendererType.put("VerticalAlignment", "PounamuVerticalAlignmentRenderer");
    rendererType.put("LayoutParameters", "PounamuLayoutRenderer");
    rendererType.put("MultiLinesText", "PounamuMultiLinesTextRenderer");
    rendererType.put("GridBagConstraints", "PounamuGridBagConstraintsRenderer");
    rendererType.put("Position", "PounamuPositionRenderer");
    rendererType.put("BasicStroke", "PounamuBasicStrokeRenderer");
    rendererType.put("Insets", "PounamuInsetsRenderer");
    rendererType.put("ShapeType", "PounamuShapeTypeRenderer");
    rendererType.put("Size", "PounamuSizeRenderer");
    rendererType.put("Location", "PounamuLocationRenderer");
    rendererType.put("ArrowShape", "PounamuArrowShapeRenderer");
  }

  /**
   * initial visual interface
   */
  private void initInterface(){
    if(propertyNames==null){
      JOptionPane.showMessageDialog(this, "The current pounamu shape has no property to be specified!");
      return;
    }
    this.setLayout(new BorderLayout());
    JPanel okPanel = new JPanel();
     JButton ok = new JButton("OK");
     okPanel.add(ok);
     ok.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         ok_pressed();
       }
     });
    //getContentPane().add(okPanel, BorderLayout.SOUTH);
    this.add(okPanel, BorderLayout.SOUTH);
    //int count1 = propertyNames.length;
    //int count2 = (1+count1)/2;
    JPanel specificationPanel = new JPanel();
    //specificationPanel.setLayout(new GridLayout(count2,2));
    specificationPanel.setLayout(new VerticalFlowLayout());
    specificationPanel.setBorder(BorderFactory.createTitledBorder("Please specify properties here"));
    for(int i = 0; i < propertyNames.length; i++){
      String propertyName = propertyNames[i];
      String propertyType = propertyTypes[i];
      String propertyFlag = propertyFlags[i];
      try{
        Class c = Class.forName("pounamu.editor."+rendererType.get(propertyType));
        Component newEditor = (Component)c.newInstance();
        JPanel jp = new JPanel();
        jp.add(newEditor);
        jp.setBorder(BorderFactory.createTitledBorder(propertyName+":"+propertyFlag));
        specificationPanel.add(jp);
        rendererComp.put(propertyName, newEditor);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
        //pounamu.displayMessage("Exception in class PounamuShapeSpecifier "+e.toString());
      }
    }
     JTabbedPane upper = new JTabbedPane();
     JScrollPane jsp = new JScrollPane(specificationPanel);
     jsp.setPreferredSize(new Dimension(220, 490));
     upper.add("properties", jsp);
     this.add(upper, BorderLayout.NORTH);
     this.validate();
  }

  /**
   * set up properties
   */
  private void setProperties(){
    String methodName;
    if(propertyNames==null){
      JOptionPane.showMessageDialog(this, "The current pounamu shape has no property to be specified!");
      return;
    }
    for(int i = 0; i < propertyNames.length; i++){
      String propertyName = propertyNames[i];
      String type = propertyTypes[i];
      String componentPath = componentPaths[i];
      String propertyOldName = propertyOldNames[i];
      Object comp = target.pathComponentMapping.get(componentPath);
      Class c = comp.getClass();
      if(type.equals("boolean"))
        methodName = "is"+capitalizeFirstLetter(propertyOldName);
      else
        methodName = "get"+capitalizeFirstLetter(propertyOldName);
     // System.out.println("methodName is " + methodName);
       try{
        Method m = c.getMethod(methodName, new Class[]{});
       // System.out.println("methodName is 0 " + methodName);
        Object value = m.invoke(comp, new Object[]{});
       // System.out.println("methodName is 1 " + methodName);
        Component renderer = (Component)rendererComp.get(propertyName);
       // System.out.println("methodName is 2 " + methodName);
        if(type.equals("int"))
          ((PounamuIntRenderer)renderer).setText(""+((Integer)value).intValue());
        else if(type.equals("boolean"))
          ((PounamuBooleanRenderer)renderer).setBooleanValue(((Boolean)value).booleanValue());
        else if(type.equals("Font"))
          ((PounamuFontRenderer)renderer).setFont((Font)value);
        else if(type.equals("Border"))
          ((PounamuBorderRenderer)renderer).setBorder((Border)value);
        else if(type.equals("Color"))
          ((PounamuColorRenderer)renderer).setColor((Color)value);
        else if(type.equals("HorizontalAlignment"))
          ((PounamuHorizontalAlignmentRenderer)renderer).setHorizontalAlignment(((Integer)value).intValue());
        else if(type.equals("VerticalAlignment"))
          ((PounamuVerticalAlignmentRenderer)renderer).setVerticalAlignment(((Integer)value).intValue());
        else if(type.equals("LayoutParameters"))
          ((PounamuLayoutRenderer)renderer).setLayoutParameters((LayoutManager)value);
        else if(type.equals("MultiLinesText"))
          ((PounamuMultiLinesTextRenderer)renderer).setMultiLinesText((Vector)value);
        else if(type.equals("GridBagConstraints"))
          ((PounamuGridBagConstraintsRenderer)renderer).setGridBagConstraints((GridBagConstraints)value);
        else if(type.equals("Position"))
          ((PounamuPositionRenderer)renderer).setPosition((String)value);
        else if(type.equals("BasicStroke"))
          ((PounamuBasicStrokeRenderer)renderer).setBasicStroke((BasicStroke)value);
        else if(type.equals("Insets"))
          ((PounamuInsetsRenderer)renderer).setInsets((Insets)value);
        else if(type.equals("ShapeType"))
          ((PounamuShapeTypeRenderer)renderer).setShapeType((String)value);
        else if(type.equals("Size"))
          ((PounamuSizeRenderer)renderer).setMinimumSize((Dimension)value);
        else if(type.equals("Location"))
          ((PounamuLocationRenderer)renderer).setLocation((Point)value);
        else
          ((PounamuStringRenderer)renderer).setText((String)value);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
        //pounamu.displayMessage("Exception in class PounamuShapeSpecifier "+e.toString());
      }
    }
  }

/*  public void setExportedProperties(){
    String[] oldNames = ((Configurable)target).getExportedPropertiesWithOldNames();
    String[] newnames = ((Configurable)target).getExportedProperties();
    if(oldNames==null)
      return;
    for(int i = 0; i < oldNames.length; i++){
      ((JRadioButton)(exportRadio.get(oldNames[i]))).setSelected(true);
      ((JTextField)(exportTextField.get(oldNames[i]))).setText(newnames[i]);
      ((JTextField)(exportTextField.get(oldNames[i]))).setEnabled(true);
    }
  }*/

  /**
   * do nothing
   */
  public void ok_pressed(){}

  /**
   * set each property of the target
   */
  private void setTargetProperties(){
    for(int i = 0; i < propertyNames.length; i++){
      String propertyName = propertyNames[i];
      String type = propertyTypes[i];
      String componentPath = componentPaths[i];
      String propertyOldName = propertyOldNames[i];
      Object comp = target.pathComponentMapping.get(componentPath);
      Class c = comp.getClass();
      String methodName = "set"+capitalizeFirstLetter(propertyOldName);
      Component renderer = (Component)rendererComp.get(propertyName);
      try{
        if(type.equals("int")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuIntRenderer)renderer).getText());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("boolean")){
          Method m = c.getMethod(methodName, new Class[]{boolean.class});
          Boolean value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Font")){
          Method m = c.getMethod(methodName, new Class[]{Font.class});
          Font value = ((PounamuFontRenderer)renderer).getFont();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Border")){
          Method m = c.getMethod(methodName, new Class[]{Border.class});
          Border value = ((PounamuBorderRenderer)renderer).getBorder();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Color")){
          Method m = c.getMethod(methodName, new Class[]{Color.class});
          Color value = ((PounamuColorRenderer)renderer).getColor();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("HorizontalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuHorizontalAlignmentRenderer)renderer).getHorizontalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("VerticalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuVerticalAlignmentRenderer)renderer).getVerticalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("LayoutParameters")){
          Method m = c.getMethod(methodName, new Class[]{LayoutManager.class});
          LayoutManager value = ((PounamuLayoutRenderer)renderer).getLayoutParameters();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("MultiLinesText")){
          Method m = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("GridBagConstraints")){
          Method m = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
          GridBagConstraints value = ((PounamuGridBagConstraintsRenderer)renderer).getGridBagConstraints();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Position")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuPositionRenderer)renderer).getPosition();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("BasicStroke")){
          Method m = c.getMethod(methodName, new Class[]{BasicStroke.class});
          BasicStroke value = ((PounamuBasicStrokeRenderer)renderer).getBasicStroke();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Insets")){
          Method m = c.getMethod(methodName, new Class[]{Insets.class});
          Insets value = ((PounamuInsetsRenderer)renderer).getInsets();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("ShapeType")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuShapeTypeRenderer)renderer).getShapeType();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Size")){
          Method m = c.getMethod(methodName, new Class[]{Dimension.class});
          Dimension value = ((PounamuSizeRenderer)renderer).getMinimumSize();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Location")){
          Method m = c.getMethod(methodName, new Class[]{Point.class});
          Point value = ((PounamuLocationRenderer)renderer).getLocation();
          m.invoke(comp, new Object[]{value});
        }
        else{
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuStringRenderer)renderer).getText();
          m.invoke(comp, new Object[]{value});
        }
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }
    }
    }

  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }

}