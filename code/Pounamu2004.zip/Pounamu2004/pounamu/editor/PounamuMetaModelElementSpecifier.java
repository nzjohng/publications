/*
 * @(#)PounamuShapeSpecifier.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import pounamu.editor.*;
import pounamu.visualcomp.*;
import pounamu.command.*;
import pounamu.data.*;
import pounamu.core.*;

/**
 * Title: PounamuShapeSpecifier
 * Description:  A JFrame to specify any pounamu shape
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuMetaModelElementSpecifier extends JPanel{

  PounamuMetaModelElement target;
  ModellerPanel panel = null;
  PounamuView view = null;
  PounamuProject project = null;
  PounamuShape shape = null;
  PounamuConnector connector = null;
  String viewType = null;
  String modelType = null;
  String iconType = null;
  String[] propertyNames;
  String[] propertyTypes;
  String[] componentPaths;
  String[] propertyOldNames;
  String[] visualPropertyNames;
  String[] visualPropertyTypes;
  String[] visualComponentPaths;
  String[] visualPropertyOldNames;
  String[] modelPropertyNames;
  String[] modelPropertyTypes;
  String[] modelComponentPaths;
  String[] modelPropertyOldNames;
  Hashtable rendererType = new Hashtable();
  Hashtable rendererComp = new Hashtable();
  Object icon = null;
  /**
   * constructor
   * 1) initial renderers
   * 2) initial interface
   * 3) set properties in the interface
   * @param target the PounamuMetaModelElement to be specified
   * @param view the view the PounamuMetaModelElement is in
   */
  public PounamuMetaModelElementSpecifier(Object icon, PounamuView view){
    this.icon = icon;
    this.view = view;
    if(view==null){
      this.panel = null;
      this.shape = null;
    }
    else{
      this.project = view.getPounamuProject();
      this.panel = (ModellerPanel)view.getDisplayPanel();
      this.icon = icon;
      if(icon instanceof PounamuPanel){
        this.shape = (PounamuShape)((PounamuPanel)icon).getPounamuShape();
        this.target = (PounamuMetaModelElement)shape.getRelatedObject();
      }
      else{
        this.connector = (PounamuConnector)icon;
        this.target = (PounamuMetaModelElement)connector.getRelatedObject();
      }
      propertyNames = shape.getExportedPropertyNames();
      propertyTypes = shape.getExportedPropertyTypes();
      componentPaths = shape.getExportedComponentPath();
      propertyOldNames = shape.getExportedPropertyOldNames();
      getPropertyLists();
    }
    try {
      initHashtables();
      initInterface();
      loadPropertiesFromMetaModel();
      setProperties();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void loadPropertiesFromMetaModel(){

    String iconPropertyName = (String)((PounamuToolProject)project).getPropertyMappingFromEntityTypeToIcon().get("name");
    shape.setProperty(iconPropertyName, target.getName());
    iconPropertyName = (String)((PounamuToolProject)project).getPropertyMappingFromEntityTypeToIcon().get("property");
    if(iconPropertyName != null && !iconPropertyName.equals(""))
      shape.setProperty(iconPropertyName, target.getProperties());
  }

  public void getPropertyLists(){
    String[] modelTypeModelProperties = new String[]{"name", "property"};
    visualPropertyNames = new String[propertyNames.length];
    visualPropertyTypes = new String[propertyNames.length];
    visualComponentPaths = new String[propertyNames.length];
    visualPropertyOldNames = new String[propertyNames.length];
    modelPropertyNames = new String[modelTypeModelProperties.length];
    modelPropertyTypes = new String[modelTypeModelProperties.length];
    modelComponentPaths = new String[modelTypeModelProperties.length];
    modelPropertyOldNames = new String[modelTypeModelProperties.length];
    for(int k = 0; k < propertyNames.length; k++){
      visualPropertyNames[k] = propertyNames[k];
      visualPropertyTypes[k] = propertyTypes[k];
      visualComponentPaths[k] = componentPaths[k];
      visualPropertyOldNames[k] = propertyOldNames[k];
    }
    for(int i = 0; i < modelTypeModelProperties.length; i++){
      String    temp = (String)((PounamuToolProject)project).getPropertyMappingFromEntityTypeToIcon().get(modelTypeModelProperties[i]);
      //String temp = project.getIconPropertyName(modelType, iconType, modelTypeModelProperties[i]);
      if(temp != null && !temp.equals("")){
        for(int j = 0; j < propertyNames.length; j++){
          if(propertyNames[j].equals(temp)){
            modelPropertyNames[i] = modelTypeModelProperties[i];
            modelPropertyTypes[i] = propertyTypes[j];
            modelComponentPaths[i] = componentPaths[j];
            modelPropertyOldNames[i] = propertyOldNames[j];
            visualPropertyNames[j] = null;
            visualPropertyTypes[j] = null;
            visualComponentPaths[j] = null;
            visualPropertyOldNames[j] = null;
            break;
          }
         }
       }
       else{
         modelPropertyNames[i] = modelTypeModelProperties[i];
         modelPropertyTypes[i] = null;
         modelComponentPaths[i] = null;
         modelPropertyOldNames[i] = null;
       }
     }
  }

  /**
   * get the property type array
   * @return the property type array
   */
  public String[] getPropertyTypes(){
    return propertyTypes;
  }

  /**
   * get the property name array
   * @return the property name array
   */
  public String[] getPropertyNames(){
    return propertyNames;
  }

  /**
   * get the property component path array
   * @return the property component path array
   */
  public String[] getComponentPaths(){
    return componentPaths;
  }

  /**
   * get the property old name array
   * @return the property old name array
   */
  public String[] getPropertyOldNames(){
    return propertyOldNames;
  }

  /**
   * get the compoent to render the property value
   * @return the component used to render the property value
   */
  public Hashtable getRendererComp(){
    return rendererComp;
  }


  /**
   * assign the renderers to their correspnding types
   */
  public void initHashtables(){
    rendererType.put("int", "PounamuIntRenderer");
    rendererType.put("float", "PounamuFloatRenderer");
    rendererType.put("boolean", "PounamuBooleanRenderer");
    rendererType.put("String", "PounamuStringRenderer");
    rendererType.put("Font", "PounamuFontRenderer");
    rendererType.put("Border", "PounamuBorderRenderer");
    rendererType.put("Color", "PounamuColorRenderer");
    rendererType.put("HorizontalAlignment", "PounamuHorizontalAlignmentRenderer");
    rendererType.put("VerticalAlignment", "PounamuVerticalAlignmentRenderer");
    rendererType.put("LayoutParameters", "PounamuLayoutRenderer");
    rendererType.put("MultiLinesText", "PounamuPropertyRenderer");
    rendererType.put("GridBagConstraints", "PounamuGridBagConstraintsRenderer");
    rendererType.put("Position", "PounamuPositionRenderer");
    rendererType.put("BasicStroke", "PounamuBasicStrokeRenderer");
    rendererType.put("Insets", "PounamuInsetsRenderer");
    rendererType.put("ShapeType", "PounamuShapeTypeRenderer");
    rendererType.put("Size", "PounamuSizeRenderer");
    rendererType.put("Location", "PounamuLocationRenderer");
    rendererType.put("ArrowShape", "PounamuArrowShapeRenderer");
  }

  /**
   * initial visual interface
   */
  public void initInterface(){
    this.setLayout(new BorderLayout());
    JPanel okPanel = new JPanel();
     JButton ok = new JButton("OK");
     okPanel.add(ok);
     ok.addActionListener(new ActionListener(){
       public void actionPerformed(ActionEvent e){
         ok_pressed();
       }
     });
    this.add(okPanel, BorderLayout.SOUTH);
    JPanel modelPropertyPanel = new JPanel();
    modelPropertyPanel.setLayout(new VerticalFlowLayout());
    modelPropertyPanel.setBorder(BorderFactory.createTitledBorder("Please specify metamodel properties here"));
    for(int i = 0; i < modelPropertyNames.length; i++){
      String propertyName = modelPropertyNames[i];
      String propertyType = modelPropertyTypes[i];
      if(propertyType!=null){
        try{
          Class c =null;
            if(propertyName.equals("property"))
              c = Class.forName("pounamu.editor.PounamuPropertyRenderer");
            else
              c = Class.forName("pounamu.editor."+rendererType.get(propertyType));
          Component newEditor = (Component)c.newInstance();
          JPanel jp = new JPanel();
          jp.add(newEditor);
          jp.setBorder(BorderFactory.createTitledBorder(propertyName));
          modelPropertyPanel.add(jp);
          rendererComp.put(propertyName, newEditor);
        }
        catch(Exception e){
          e.printStackTrace(System.out);
        }
      }
    }
    /////////////////////////////////////////////////////////////////////////////////////////
    JPanel visualPropertyPanel = new JPanel();
    if(view!=null){
      visualPropertyPanel.setLayout(new VerticalFlowLayout());
      visualPropertyPanel.setBorder(BorderFactory.createTitledBorder("Please specify visual properties here"));
      for(int i = 0; i < visualPropertyNames.length; i++){
        String propertyName = visualPropertyNames[i];
        String propertyType = visualPropertyTypes[i];
        if(propertyName!=null){
          try{
            Class c =null;
            c = Class.forName("pounamu.editor."+rendererType.get(propertyType));
            Component newEditor = (Component)c.newInstance();
            JPanel jp = new JPanel();
            jp.add(newEditor);
            jp.setBorder(BorderFactory.createTitledBorder(propertyName));
            visualPropertyPanel.add(jp);
            rendererComp.put(propertyName, newEditor);
          }
          catch(Exception e){
            e.printStackTrace(System.out);
          }
        }
       }
     }
     JTabbedPane upper = new JTabbedPane();
     JScrollPane jsp = new JScrollPane(modelPropertyPanel);
     jsp.setPreferredSize(new Dimension(200, 510));
     upper.add("metamodel prop", jsp);
     if(view!=null){
       jsp = new JScrollPane(visualPropertyPanel);
       jsp.setPreferredSize(new Dimension(200, 510));
       upper.add("visual prop", jsp);
     }
     this.add(upper, BorderLayout.NORTH);
     this.validate();
  }

  /**
   * set up properties
   */
  public void setProperties(){

    for(int i = 0; i < modelPropertyNames.length; i++){
      String propertyName = modelPropertyNames[i];
      String type = modelPropertyTypes[i];
      String componentPath = modelComponentPaths[i];
      String propertyOldName = modelPropertyOldNames[i];
      if(componentPath!=null)
        setProperty(propertyName, type, componentPath, propertyOldName);
    }
    for(int i = 0; i < visualPropertyNames.length; i++){
      String propertyName = visualPropertyNames[i];
      String type = visualPropertyTypes[i];
      String componentPath = visualComponentPaths[i];
      String propertyOldName = visualPropertyOldNames[i];
      if(propertyName!=null)
        setProperty(propertyName, type, componentPath, propertyOldName);
     }
  }


  public void setProperty(String propertyName, String type, String componentPath, String propertyOldName){
      Object comp;
      String methodName;
      if (shape instanceof PounamuShape)
        comp = ((PounamuShape)shape).pathComponentMapping.get(componentPath);
      else comp = shape;
      Class c = comp.getClass();
      if(type.equals("boolean"))
        methodName = "is"+capitalizeFirstLetter(propertyOldName);
      else
        methodName = "get"+capitalizeFirstLetter(propertyOldName);
      try{
        Method m = c.getMethod(methodName, new Class[]{});
        Object value = m.invoke(comp, new Object[]{});
        Component renderer = (Component)rendererComp.get(propertyName);
        if(type.equals("int"))
          ((PounamuIntRenderer)renderer).setText(""+((Integer)value).intValue());
        else if(type.equals("boolean"))
          ((PounamuBooleanRenderer)renderer).setBooleanValue(((Boolean)value).booleanValue());
        else if(type.equals("Font"))
          ((PounamuFontRenderer)renderer).setFont((Font)value);
        else if(type.equals("Border"))
          ((PounamuBorderRenderer)renderer).setBorder((Border)value);
        else if(type.equals("Color"))
          ((PounamuColorRenderer)renderer).setColor((Color)value);
        else if(type.equals("HorizontalAlignment"))
          ((PounamuHorizontalAlignmentRenderer)renderer).setHorizontalAlignment(((Integer)value).intValue());
        else if(type.equals("VerticalAlignment"))
          ((PounamuVerticalAlignmentRenderer)renderer).setVerticalAlignment(((Integer)value).intValue());
        else if(type.equals("LayoutParameters"))
          ((PounamuLayoutRenderer)renderer).setLayoutParameters((LayoutManager)value);
        else if(type.equals("MultiLinesText"))
          ((PounamuPropertyRenderer)renderer).setMultiLinesText((Vector)value);
        else if(type.equals("GridBagConstraints"))
          ((PounamuGridBagConstraintsRenderer)renderer).setGridBagConstraints((GridBagConstraints)value);
        else if(type.equals("Position"))
          ((PounamuPositionRenderer)renderer).setPosition((String)value);
        else if(type.equals("BasicStroke"))
          ((PounamuBasicStrokeRenderer)renderer).setBasicStroke((BasicStroke)value);
        else if(type.equals("Insets"))
          ((PounamuInsetsRenderer)renderer).setInsets((Insets)value);
        else if(type.equals("ShapeType"))
          ((PounamuShapeTypeRenderer)renderer).setShapeType((String)value);
        else if(type.equals("Size"))
          ((PounamuSizeRenderer)renderer).setMinimumSize((Dimension)value);
        else if(type.equals("Location"))
          ((PounamuLocationRenderer)renderer).setLocation((Point)value);
        else if(type.equals("ArrowShape"))
          ((PounamuArrowShapeRenderer)renderer).setArrowShape((String)value);
        else
          ((PounamuStringRenderer)renderer).setText((String)value);
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }

  }

  /**
   * to configure the shape
   */
  public void ok_pressed(){
    setTargetProperties();
    shape.getBasePanel().repaint();
    //updateAllOtherIcons();
  }

  /*public void updateAllOtherIcons(){
    Hashtable hash  = ((PounamuMetaModelElement)target).getViewAndIconMapping();
    Enumeration e = hash.keys();
    while(e.hasMoreElements()){
      PounamuView view = (PounamuView)e.nextElement();
      PounamuShape shape = (PounamuShape)hash.get(view);
      System.out.println(shape.getType());
      System.out.println(view.getType());
      String iconPropertyName = (String)((PounamuToolProject)project).getPropertyMappingFromEntityTypeToIcon().get("property");
      System.out.println(iconPropertyName);
      if(iconPropertyName != null && !iconPropertyName.equals(""))
        shape.setProperty(iconPropertyName, ((PounamuMetaModelElement)target).getProperties());
    }
  }*/

  /**
   * set each property of the shape
   */
  public void setTargetProperties(){
    for(int i = 0; i < modelPropertyNames.length; i++){
      String propertyName = modelPropertyNames[i];
      String type = modelPropertyTypes[i];
      String componentPath = modelComponentPaths[i];
      String propertyOldName = modelPropertyOldNames[i];
      if(componentPath!=null)
        setTargetProperty(propertyName, type, componentPath, propertyOldName);
    }
    for(int i = 0; i < visualPropertyNames.length; i++){
      String propertyName = visualPropertyNames[i];
      String type = visualPropertyTypes[i];
      String componentPath = visualComponentPaths[i];
      String propertyOldName = visualPropertyOldNames[i];
      if(propertyName!=null)
        setTargetProperty(propertyName, type, componentPath, propertyOldName);
    }
  }

  public void setTargetProperty(String propertyName, String type, String componentPath, String propertyOldName){
      Object comp;
      if (shape instanceof PounamuShape)
        comp = ((PounamuShape)shape).pathComponentMapping.get(componentPath);
      else comp = shape;
      Class c = comp.getClass();
      String methodName = "set"+capitalizeFirstLetter(propertyOldName);
      Component renderer = (Component)rendererComp.get(propertyName);
      try{
        if(type.equals("int")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuIntRenderer)renderer).getText());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("boolean")){
          Method m = c.getMethod(methodName, new Class[]{boolean.class});
          Boolean value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Font")){
          Method m = c.getMethod(methodName, new Class[]{Font.class});
          Font value = ((PounamuFontRenderer)renderer).getFont();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Border")){
          Method m = c.getMethod(methodName, new Class[]{Border.class});
          Border value = ((PounamuBorderRenderer)renderer).getBorder();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Color")){
          Method m = c.getMethod(methodName, new Class[]{Color.class});
          Color value = ((PounamuColorRenderer)renderer).getColor();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("HorizontalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuHorizontalAlignmentRenderer)renderer).getHorizontalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("VerticalAlignment")){
          Method m = c.getMethod(methodName, new Class[]{int.class});
          Integer value = new Integer(((PounamuVerticalAlignmentRenderer)renderer).getVerticalAlignment());
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("LayoutParameters")){
          Method m = c.getMethod(methodName, new Class[]{LayoutManager.class});
          LayoutManager value = ((PounamuLayoutRenderer)renderer).getLayoutParameters();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("MultiLinesText")){
          Method m = c.getMethod(methodName, new Class[]{Vector.class});
          Vector value = ((PounamuPropertyRenderer)renderer).getMultiLinesText();
          m.invoke(comp, new Object[]{value});
          if(propertyName.equals("property")){
            target.setProperties(value);
          }
        }
        else if(type.equals("GridBagConstraints")){
          Method m = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
          GridBagConstraints value = ((PounamuGridBagConstraintsRenderer)renderer).getGridBagConstraints();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Position")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuPositionRenderer)renderer).getPosition();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("BasicStroke")){
          Method m = c.getMethod(methodName, new Class[]{BasicStroke.class});
          BasicStroke value = ((PounamuBasicStrokeRenderer)renderer).getBasicStroke();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Insets")){
          Method m = c.getMethod(methodName, new Class[]{Insets.class});
          Insets value = ((PounamuInsetsRenderer)renderer).getInsets();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("ShapeType")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuShapeTypeRenderer)renderer).getShapeType();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Size")){
          Method m = c.getMethod(methodName, new Class[]{Dimension.class});
          Dimension value = ((PounamuSizeRenderer)renderer).getMinimumSize();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("Location")){
          Method m = c.getMethod(methodName, new Class[]{Point.class});
          Point value = ((PounamuLocationRenderer)renderer).getLocation();
          m.invoke(comp, new Object[]{value});
        }
        else if(type.equals("ArrowShape")){
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuArrowShapeRenderer)renderer).getArrowShape();
          m.invoke(comp, new Object[]{value});
        }
        else{
          Method m = c.getMethod(methodName, new Class[]{String.class});
          String value = ((PounamuStringRenderer)renderer).getText();
          m.invoke(comp, new Object[]{value});
          if(propertyName.equals("name")){
            target.setName(value);
          }
        }
      }
      catch(Exception e){
        e.printStackTrace(System.out);
      }

  }


  /**
   * a help method to Change the first letter of a String to Capital
   * @param s the string to be changed
   * @return the changed string
   */
  protected String capitalizeFirstLetter(String s) {
    char chars[] = s.toCharArray();
    if(chars[0]>='a'&&chars[0]<='z')
      chars[0] = (char)(chars[0]-('a' - 'A'));
    return new String(chars);
  }

}