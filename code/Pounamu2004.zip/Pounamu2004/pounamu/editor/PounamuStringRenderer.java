/*
 * @(#)PounamuStringRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuStringRenderer
 * Description:  a JTextField to render preoperties which are string
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuStringRenderer extends JTextField{
  /**
   * constructor
   */
  public PounamuStringRenderer(){
    super("", 11);
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get the string
   * @return getText()
   */
  public String getStringValue(){
    return getText();
  }

  /**
   * set the string
   * @param value the value to be set to this renderer
   */
  public void setStringValue(String value){
    if(value!=null)
      setText(value);
  }
}