/*
 * @(#)PounamuBasicStrokeEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.Hashtable;
import javax.swing.*;

/**
 * Title: PounamuBasicStrokeEditor
 * Description:  A JDialog to edit the PounamuBasicStroke property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuBasicStrokeEditor extends JDialog implements ActionListener, ItemListener {

    PounamuBasicStrokeRenderer renderer = null;
    BasicStroke basicStroke;
    float[] f = new float[4];
    JLabel jl1 = new JLabel("width"), jl2 = new JLabel("end caps"), jl3 = new JLabel("line joints"), jl4 = new JLabel("dash attributes"), jl5 = new JLabel("miterlimit"), jl6 = new JLabel("dashphase");
    JTextField tf0 = new JTextField(4), tf1 = new JTextField(4), tf2 = new JTextField(4),tf3 = new JTextField(4), tf4 = new JTextField(4), tf5 = new JTextField(4), tf6 = new JTextField(4);
    String[] w = new String[30];

    private JComboBox width = null;

    String[] ec = new String[]{"CAP_BUTT", "CAP_ROUND", "CAP_SQUARE"};
    private JComboBox endcaps = new JComboBox(ec);
    String[] lj = new String[]{"JOIN_MITER", "JOIN_ROUND", "JOIN_BEVEL"};
    private JComboBox linejoints = new JComboBox(lj);
    /**
     * constructor
     * @param renderer the PounamuBasicStrokeRenderer instance
     */
    public PounamuBasicStrokeEditor(PounamuBasicStrokeRenderer renderer) {
      super();
      this.renderer = renderer;
      this.basicStroke = renderer.getBasicStroke();
      for (int i = 0; i<w.length; i++){
        w[i] = ""+i;
      }
      width = new JComboBox(w);
      width.addItemListener(new ItemListener(){
        public void itemStateChanged(ItemEvent e){
          tf0.setText((String)e.getItem());
        }
      });
      JPanel configure = new JPanel();
      configure.setLayout(new BorderLayout());
      JPanel j1 = new JPanel();
      JPanel j2 = new JPanel();
      j1.add(jl1);
      j1.add(tf0);
      j1.add(width);
      j1.add(jl2);
      j1.add(endcaps);
      j1.add(jl3);
      j1.add(linejoints);
      j2.add(jl5);
      j2.add(tf5);
      j2.add(jl4);
      j2.add(tf1);
      j2.add(tf2);
      j2.add(tf3);
      j2.add(tf4);
      j2.add(jl6);
      j2.add(tf6);
      tf1.addActionListener(this);
      tf2.addActionListener(this);
      tf3.addActionListener(this);
      tf4.addActionListener(this);
      tf5.addActionListener(this);
      tf6.addActionListener(this);
      endcaps.addItemListener(this);
      linejoints.addItemListener(this);
      width.addItemListener(this);
      configure.add(j1, BorderLayout.NORTH);
      configure.add(j2, BorderLayout.SOUTH);
      configure.setBorder(BorderFactory.createTitledBorder("Please specifify this BasicStoke here"));
      JButton ok = new JButton("ok");
      JPanel okPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      okPanel.add(ok);
      ok.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          PounamuBasicStrokeEditor.this.renderer.setBasicStroke(basicStroke);
          PounamuBasicStrokeEditor.this.setVisible(false);
        }
      });
      this.getContentPane().setLayout(new BorderLayout());
      this.getContentPane().add(configure, BorderLayout.NORTH);
      this.getContentPane().add(okPanel, BorderLayout.SOUTH);
      this.setBounds(300, 300, 550, 200);
      setBasicStroke();
      repaint();
    }

    /**
     * implements action listener
     * @param e the action event
     */
    public void actionPerformed(ActionEvent e){
      repaint();
    }

    /**
     * implements item listener
     * @param e the item event
     */
    public void itemStateChanged(ItemEvent e){
      repaint();
    }

    /**
     * set Basic Stroke
     */
    public void setBasicStroke(){
      tf0.setText(""+basicStroke.getLineWidth());
      endcaps.setSelectedItem(ec[basicStroke.getEndCap()]);
      linejoints.setSelectedItem(lj[basicStroke.getLineJoin()]);
      f = basicStroke.getDashArray();
      tf1.setText(""+f[0]);
      tf2.setText(""+f[1]);
      tf3.setText(""+f[2]);
      tf4.setText(""+f[3]);
      tf5.setText(""+basicStroke.getMiterLimit());
      tf6.setText(""+basicStroke.getDashPhase());
    }

    /**
     * get Basic Stroke
     * @return the Basic Stroke
     */
    public BasicStroke getBasicStroke() {
      f[0]=new Float(tf1.getText()).floatValue();
      f[1]=new Float(tf2.getText()).floatValue();
      f[2]=new Float(tf3.getText()).floatValue();
      f[3]=new Float(tf4.getText()).floatValue();
      String s = (String)endcaps.getSelectedItem();
      int temp = 0;
      if (s.equals("CAP_BUTT"))
        temp = BasicStroke.CAP_BUTT;
      else if (s.equals("CAP_ROUND"))
        temp = BasicStroke.CAP_ROUND;
      else
        temp = BasicStroke.CAP_SQUARE;
      s = (String)linejoints.getSelectedItem();
      int temp1 = 0;
      if (s.equals("JOIN_BEVEL"))
        temp1 = BasicStroke.JOIN_BEVEL;
      else if (s.equals("JOIN_MITER"))
        temp1 = BasicStroke.JOIN_MITER;
      else
        temp1 = BasicStroke.JOIN_ROUND;
      return new BasicStroke(new Float(tf0.getText()).floatValue(),
                             temp, temp1,new Float(tf5.getText()).floatValue(),
                             f, new Float(tf6.getText()).floatValue());
    }

    /**
     * paint a line which use the basic stroke
     * @param g the Graphcs instance
     */
    public void paint(Graphics g) {
      basicStroke = getBasicStroke();
      this.paintComponents(g);
      Graphics2D g2d = (Graphics2D)g;
      g2d.setStroke(basicStroke);
      java.awt.geom.Line2D l = new java.awt.geom.Line2D.Double(175, 145, 375, 145);
      g2d.draw(l);
      this.validate();
    }
}

