/*
 * @(#)PounamuHorizontalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuFlowLayoutHorizontalAlignmentRenderer
 * Description:  A JComboBow to render the horizontal alignment property for some JComponents.
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuFlowLayoutHorizontalAlignmentRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuFlowLayoutHorizontalAlignmentRenderer(){
    super(new String[]{"CENTER", "LEFT", "RIGHT", "LEADING", "TRAILING"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get HorizontalAlignment
   * @return the int which represent the alignment
   */
  public int getHorizontalAlignment(){
    if(getSelectedIndex()==0)
      return FlowLayout.CENTER;
    else if(getSelectedIndex()==1)
      return FlowLayout.LEFT;
    else if(getSelectedIndex()==2)
      return FlowLayout.RIGHT;
    else if(getSelectedIndex()==3)
      return FlowLayout.LEADING;
    else
      return FlowLayout.TRAILING;
  }

  /**
   * set Horizontal Alignment
   * @param i the int which represent the alignment
   */
  public void setHorizontalAlignment(int i){
    if(i==FlowLayout.CENTER)
      setSelectedIndex(0);
    else if(i==FlowLayout.LEFT)
      setSelectedIndex(1);
    else if(i==FlowLayout.RIGHT)
      setSelectedIndex(2);
    else if(i==FlowLayout.LEADING)
      setSelectedIndex(3);
    else
      setSelectedIndex(4);
  }
}