/*
 * @(#)PounamuLayoutRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import pounamu.visualcomp.*;



/**
 * Title: PounamuLayoutRenderer
 * Description:  A JButton to rendeer the Layout property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */

public class PounamuLocationRenderer extends JPanel{

  JLabel jl1 = new JLabel("x");
  JLabel jl2 = new JLabel("y");
  JTextField jtf1 = new JTextField(4);
  JTextField jtf2 = new JTextField(4);
	Point p;

  /**
   * constructor
   */
  public PounamuLocationRenderer(){
    super();
    super.setPreferredSize(new Dimension(120, 50));
    setToolTipText("reset locaton parameters");
    setLayout(new GridLayout(2, 2, 4, 4));
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
  }

  /**
   * set Location Parameters
   * @param p the point value
   */
  public void setLocation(Point p){
		jtf1.setText(""+p.x);
		jtf2.setText(""+p.y);
		this.p = p;
  }

  /**
   * get Location Parameters
   * @return a point
   */
  public Point getLocation(){
    try{
			int x = Integer.parseInt(jtf1.getText());
			int y = Integer.parseInt(jtf2.getText());
	    return new Point(x, y);
    }catch(Exception e){
      JOptionPane.showMessageDialog(this, "Location parameters must be int values");
		  return p;
    }
  }

}