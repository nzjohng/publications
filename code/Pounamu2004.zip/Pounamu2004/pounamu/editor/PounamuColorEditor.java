/*
 * @(#)PounamuColorEditor.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import javax.swing.event.*;
import javax.swing.colorchooser.*;

/**
 * Title: PounamuColorEditor
 * Description:  A JDialog to edit the color property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuColorEditor extends JDialog{

  JButton button = null;
  Color newColor = null;
  JColorChooser tcc = new JColorChooser(Color.black);

  /**
   * constructor
   * @param button the PounamuColorRenderer
   * @param um the JFrame
   */
  public PounamuColorEditor(JButton button, JFrame um){
    super(um, "Pounamu Color Editor", false);
    this.button=button;
    JButton ok = new JButton("OK");
    ok.addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        ok_pressed();
      }
    });
    JPanel jp = new JPanel();
    jp.add(ok);

    tcc.getSelectionModel().addChangeListener(
      new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          state_changed();
        }
      }
    );
    tcc.setColor(button.getBackground());
    newColor = button.getBackground();
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(tcc, BorderLayout.NORTH);
    getContentPane().add(jp, BorderLayout.SOUTH);
    getContentPane().validate();
    this.setBounds(200, 100, 450, 450);
  }

  /**
   * inform th erenderer to set up the final value
   */
  public void ok_pressed(){
    button.setBackground(newColor);
    //System.out.println("Color is "+newColor);
    PounamuColorEditor.this.setVisible(false);
    this.dispose();
  }

  /**
   * assign the choosed color to newColor
   */
  public void state_changed() {
     newColor = tcc.getColor();
    // System.out.println("Color here is "+newColor);
   // button.setForeground(tcc.getColor());
 }
 }