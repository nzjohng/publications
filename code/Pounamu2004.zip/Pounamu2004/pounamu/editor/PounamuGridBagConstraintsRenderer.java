/*
 * @(#)PounamuLayoutRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuLayoutRenderer
 * Description:  A JButton to render the GridBagConstraints property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */

public class PounamuGridBagConstraintsRenderer extends JButton{

  GridBagConstraints gc = null;
  /**
   * constructor
   */
  public PounamuGridBagConstraintsRenderer(){
    super();
    setPreferredSize(new Dimension(120, 20));
    setMargin(new Insets(0, 0, 0, 0));
    setText("GridBagConstraints");
    setToolTipText("Define the GridBagConstraints");
    addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        PounamuGridBagConstraintsEditor pgc = new PounamuGridBagConstraintsEditor(PounamuGridBagConstraintsRenderer.this, null);
        pgc.setVisible(true);
      }
    });
	gc = new GridBagConstraints();
    this.validate();
  }

  /**
   * set Layout
   * @param lm the layoutManager value
   */
  public void setGridBagConstraints(GridBagConstraints gc){
    this.gc = gc;
  }

  /**
   * get Layout
   * @return the layotumanager
   */
  public GridBagConstraints getGridBagConstraints(){
    return gc;
  }

}