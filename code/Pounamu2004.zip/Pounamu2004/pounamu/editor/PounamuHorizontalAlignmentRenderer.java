/*
 * @(#)PounamuHorizontalAlignmentRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuHorizontalAlignmentRenderer
 * Description:  A JComboBow to render the horizontal alignment property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuHorizontalAlignmentRenderer extends JComboBox{
  /**
   * constructor
   */
  public PounamuHorizontalAlignmentRenderer(){
    super(new String[]{"CENTER", "LEFT", "RIGHT", "LEADING", "TRAILING"});
    this.setPreferredSize(new Dimension(120, 20));
  }

  /**
   * get HorizontalAlignment
   * @return the int which represent the alignment
   */
  public int getHorizontalAlignment(){
    if(getSelectedIndex()==0)
      return JLabel.CENTER;
    else if(getSelectedIndex()==1)
      return JLabel.LEFT;
    else if(getSelectedIndex()==2)
      return JLabel.RIGHT;
    else if(getSelectedIndex()==3)
      return JLabel.LEADING;
    else
      return JLabel.TRAILING;
  }

  /**
   * set Horizontal Alignment
   * @param i the int which represent the alignment
   */
  public void setHorizontalAlignment(int i){
    if(i==JLabel.CENTER)
      setSelectedIndex(0);
    else if(i==JLabel.LEFT)
      setSelectedIndex(1);
    else if(i==JLabel.RIGHT)
      setSelectedIndex(2);
    else if(i==JLabel.LEADING)
      setSelectedIndex(3);
    else
      setSelectedIndex(4);
  }
}