/*
 * @(#)PounamuLayoutRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import pounamu.visualcomp.*;



/**
 * Title: PounamuLayoutRenderer
 * Description:  A JButton to rendeer the Layout property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */

public class PounamuPropertyRenderer extends JPanel{

  DefaultListModel listModel=new DefaultListModel();
  JList list = new JList(listModel);
  JButton addButton = new JButton("add");
  JButton deleteButton = new JButton("delete");;
  JTextField newAttribute = new JTextField(5);
  JComboBox newType = new JComboBox(new String[]{"String", "MultiLinesText"});
  JComboBox isKey = new JComboBox(new String[]{"key", "nonkey"});
  /**
   * constructor
   */
  public PounamuPropertyRenderer(){
    list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    list.addListSelectionListener(new ListSelectionListener(){
      public void valueChanged(ListSelectionEvent e){
        if(e.getValueIsAdjusting() == false){
          if(list.getSelectedIndex() == -1){
            //No selection, disable delete button.
            deleteButton.setEnabled(false);
            newAttribute.setText("");
          }
          else{
            //Selection, update text field.
            deleteButton.setEnabled(true);
            String name = list.getSelectedValue().toString();
            if(name.indexOf(':')<0){
              newAttribute.setText("");
              newAttribute.setEnabled(false);
              newType.setEnabled(false);//.setSelectedItem("");
              isKey.setEnabled(false);
            }
            else{
              newAttribute.setEnabled(true);
              newType.setEnabled(true);//.setSelectedItem("");
              isKey.setEnabled(true);
              newAttribute.setText(name.substring(0, name.indexOf(':')));
              newType.setSelectedItem(name.substring(name.indexOf(':')+1, name.lastIndexOf(':')));
              isKey.setSelectedItem(name.substring(name.lastIndexOf(':')+1));
            }
          }
        }
      }
    });
    JScrollPane listScrollPane = new JScrollPane(list);
    listScrollPane.setPreferredSize(new Dimension(160, 200));
    addButton.addActionListener(new AddListener());
    if(list.getSelectedIndex()<0)
      deleteButton.setEnabled(false);
    deleteButton.addActionListener(new DeleteListener());
    JPanel listPanel = new JPanel();
    listPanel.add(listScrollPane);
    listPanel.setBorder(BorderFactory.createTitledBorder("The current attributes list"));
    JPanel operationPane = new JPanel(new VerticalFlowLayout());
    JPanel fieldPane = new JPanel(new GridLayout(3, 2));
    operationPane.setBorder(BorderFactory.createTitledBorder("Add or delete attribute here"));
    fieldPane.add(new JLabel("attribute name"));
    fieldPane.add(newAttribute);
    fieldPane.add(new JLabel("attribute type"));
    fieldPane.add(newType);
    fieldPane.add(new JLabel("is a key or not"));
    fieldPane.add(isKey);
    JPanel buttonPane = new JPanel();
    buttonPane.add(addButton);
    buttonPane.add(deleteButton);
    operationPane.add(fieldPane);
    operationPane.add(buttonPane);
    this.setLayout(new VerticalFlowLayout());
    this.add(listPanel);
    this.add(operationPane);
  }

  /**
   * get multiLinesText
   * @return Vector
   */
  public Vector getMultiLinesText(){
    Vector v  = new Vector();
    for(int index = 0; index<listModel.getSize(); index++){
        String temp = (String)listModel.elementAt(index);
        if(!temp.equals(""))
          v.add(temp);
    }
    return v;
  }

  /**
   * set MultiLinesText
   * @param text the Vector value
   */
  public void setMultiLinesText(Vector text){
    DefaultListModel lm=new DefaultListModel();
    for(int i=0; i<text.size(); i++){
      String temp = (String)text.elementAt(i);
      lm.addElement(temp);
    }
    this.listModel = lm;
    list.setModel(listModel);
  }

  //public void ok_pressed(){}

  class DeleteListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      int index = list.getSelectedIndex();
      listModel.remove(index);
      int size = listModel.getSize();
      if(size == 0){
        deleteButton.setEnabled(false);
      }
      else{
        if(index == listModel.getSize())//removed item in last position
          index--;
        list.setSelectedIndex(index);   //otherwise select same index
      }
    }
  }

  class AddListener implements ActionListener{
     public void actionPerformed(ActionEvent e){
       if(newAttribute.getText().equals("")){
         Toolkit.getDefaultToolkit().beep();
         return;
       }
       String temp = "";
       if(newType.getSelectedItem().equals("MultiLinesText")){
         temp = newAttribute.getText()+":"+newType.getSelectedItem()+":nonkey";
         isKey.setSelectedItem("nonkey");
       }
       else
         temp = newAttribute.getText()+":"+newType.getSelectedItem()+":"+isKey.getSelectedItem();
       int size = listModel.getSize();
       int index;
       for(index = 0; index<size; index++){
         if(((String)listModel.elementAt(index)).compareTo(temp)>0)
         break;
       }
       listModel.insertElementAt(temp, index);
       list.setSelectedIndex(index);
     }
   }

}