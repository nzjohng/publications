/*
 * @(#)PounamuLayoutRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import pounamu.visualcomp.*;



/**
 * Title: PounamuLayoutRenderer
 * Description:  A JButton to rendeer the Layout property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Xiaomin (Simon) Tian
 * @version 1.0
 */

public class PounamuSizeRenderer extends JPanel{

  JLabel jl1 = new JLabel("width");
  JLabel jl2 = new JLabel("height");
  JTextField jtf1 = new JTextField(4);
  JTextField jtf2 = new JTextField(4);
	Dimension size;

  /**
   * constructor
   */
  public PounamuSizeRenderer(){
    super();
    super.setPreferredSize(new Dimension(120, 50));
    setToolTipText("reset size parameters");
    setLayout(new GridLayout(2, 2, 4, 4));
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
  }

/*  public void setSize(Dimension size){
		jtf1.setText(""+size.width);
		jtf2.setText(""+size.height);
		this.size = size;
  }

  public Dimension getSize(){
    try{
			int w = Integer.parseInt(jtf1.getText());
			int h = Integer.parseInt(jtf2.getText());
	    return new Dimension(w, h);
    }catch(Exception e){
      JOptionPane.showMessageDialog(this, "Size parameters must be int values");
		  return size;
    }
  }

  public void setPreferredSize(Dimension size){
		setSize(size);
  }

  public Dimension getPreferredSize(){
    return getSize();
  }

  public void setMinimumSize(Dimension size){
		setSize(size);
  }

  public Dimension getMinimumSize(){
    return getSize();
  }

  public void setMaximumSize(Dimension size){
		setSize(size);
  }

  public Dimension getMaximumSize(){
    return getSize();
  }*/

  public void setMinimumSize(Dimension size){
		jtf1.setText(""+size.width);
		jtf2.setText(""+size.height);
		this.size = size;
  }

  public Dimension getMinimumSize(){
    try{
			int w = Integer.parseInt(jtf1.getText());
			int h = Integer.parseInt(jtf2.getText());
	    return new Dimension(w, h);
    }catch(Exception e){
      JOptionPane.showMessageDialog(this, "Size parameters must be int values");
		  return size;
    }
  }

}