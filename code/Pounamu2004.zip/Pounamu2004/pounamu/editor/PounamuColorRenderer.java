/*
 * @(#)PounamuColorRenderer.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Title: PounamuColorRenderer
 * Description:  a JButton to render color property
 * Copyright:    Copyright (c) 2002
 * Company:      FCP
 * @author       Nianping (Patrick) Zhu
 * @version 1.0
 */
public class PounamuColorRenderer extends JButton{
  PounamuComponentSpecifier pse;

  /**
   * constructor
   */
  public PounamuColorRenderer(){
    super();
    this.pse = pse;
    setBorderPainted(true);
    setMargin(new Insets(0,0,0,0));
    setPreferredSize(new Dimension(120, 20));
    addActionListener(new ActionListener(){
      public void actionPerformed(ActionEvent e){
        PounamuColorEditor pce = new PounamuColorEditor((JButton)e.getSource(), null);
        pce.setVisible(true);
      }
    });
  }
  /**
   * nothing will be set to the text
   * @param s the text to be set
   */
  public void setText(String s){}
  /**
   * set color
   * @param c the color value
   */
  public void setColor(Color c){
    setBackground(c);
    this.repaint();
  }
  /**
   * get color
   * @return the background of this button
   */
  public Color getColor(){
    return getBackground();
  }

}