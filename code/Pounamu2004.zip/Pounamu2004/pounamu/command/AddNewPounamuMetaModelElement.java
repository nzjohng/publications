/*
 * @(#)AddNewEntityType.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import javax.swing.tree.*;
/**
 * an command to add a new entity type to the drawing canvas.
 */
public class AddNewPounamuMetaModelElement implements PounamuCommand{

   ModellerPanel panel = null;
   PounamuShape shape = null;
   PounamuPanel icon = null;
   PounamuMetaModelElement object = null;
   PounamuManagerPanel manager = null;
   PounamuView view = null;
   PounamuToolProject project = null;
   String name = null;
   /**
    * constructor
    * @param panel the drawing panel where the entity type is adding to
    * @param shape the new shape
    */
   public AddNewPounamuMetaModelElement(ModellerPanel panel, PounamuPanel icon){
     this.panel = panel;
     this.view = panel.getView();
     this.icon = icon;
     this.shape = (PounamuShape)icon.getPounamuShape();
     this.object = (PounamuMetaModelElement)shape.getRelatedObject();
     this.manager = panel.getManager();
     this.project = (PounamuToolProject)panel.getProject();
     this.name = object.getName();
   }
   /**
    * excute this command
    */
   public void excute(){
     panel.add(icon);
     //panel.getShapes().add(shape.getBasePanel());
     panel.validate();
     panel.repaint();
     DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
     manager.getNodeAndItsValueMapping().put(dmtn, name);
     manager.getNodeAndProjectMapping().put(dmtn, project);
     project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
     project.getNodeAndViewMapping().put(dmtn, view);
     project.getNodeAndIconMapping().put(dmtn, icon);
     if(object.getType().equals("entitytype")){
       //project.getNodeAndEntityTypeObjectMapping().put(dmtn, object);
       project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForEntityTypeObject());
       project.getNodeAndToolButtonsMapping().put(dmtn, project.initToolIconsForEntityTypeObject());
     }
     else{
       //project.getNodeAndAssociationTypeObjectMapping().put(dmtn, object);
       project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForAssociationTypeObject());
       project.getNodeAndToolButtonsMapping().put(dmtn, project.initToolIconsForAssociationTypeObject());
       
     }
     project.getIconAndNodeMapping().put(icon, dmtn);
     manager.addTreeNode(dmtn);
     TreePath path = new TreePath(dmtn.getPath());
     manager.getManagerTree().setSelectionPath(path);
     //object.setIconNumber(object.getIconNumber()+1);
     if(object.getType().equals("entitytype")){
       project.addEntityTypeObject(object);
       project.registerEntityType(manager.getSelectedNode());
     }
     else{
       project.addAssociationTypeObject(object);
       project.registerAssociationType(manager.getSelectedNode());
     }
   }
   /**
    * undo this command
    */
   public void undo(){
     /*DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)(manager.getVisualCompAndNodeMapping().get(shape));
     TreePath path = new TreePath(dmtn.getPath());
     manager.getManagerTree().setSelectionPath(path);
     panel.remove(shape);
     panel.getShapes().remove(shape);
     panel.repaint();
     panel.validate();
     panel.getPounamu().setPropertyPanel(null);
     manager.removeCurrentNode();
     manager.getNodeAndTabbedPaneMapping().remove(dmtn);
     manager.getNodeAndViewMapping().remove(dmtn);
     manager.getVisualCompAndNodeMapping().remove(shape);
     manager.getNameAndNodeMapping().remove(name);
     if(name.startsWith("entity"))
       project.removeEntityTypeObject(name);
     else
       project.removeAssociationTypeObject(name);
     DeleteShapeEvent dse = new DeleteShapeEvent(panel, shape);
     panel.getPounamu().eventReceived(dse);
     panel.notifyCommandPerformed(this, PounamuCommand.UNDO);*/
   }

   /**
    * redo this command
    */
   public void redo(){
     excute();
   }
   /**
    * get the description of this command
    * @return the string decribing this command
    */
   public String getDescription(){
     return "add a new entity type";
   }
}