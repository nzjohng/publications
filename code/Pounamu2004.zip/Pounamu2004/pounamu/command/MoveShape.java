/*
 * @(#)MoveShape.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import java.util.Hashtable;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
/**
 * an command to move a shape on the drawing canvas.
 */
public class MoveShape implements PounamuCommand{

    PounamuPanel shape = null;
    ModellerPanel panel = null;
    int oldX = 0;
    int oldY = 0;
    int newX = 0;
    int newY = 0;
    int startX = 0;
    int startY = 0;
    PounamuModelElement object = null;
    //added bu Penny
    boolean remoteFlag=false;
    /**
     * constructor
     * @param panel the drawing panel where this shape is moving on
     * @param shape the shape to be moved
     * @param oldX the coordinate x of the mouse caret when mouse pressed down
     * @param oldY the coordinate y of the mouse caret when mouse release
     * @param newX the coordinate x of the mouse caret when mouse pressed down
     * @param newY the coordinate y of the mouse caret when mouse release
     */
    public MoveShape(ModellerPanel panel, PounamuPanel shape, int oldX, int oldY, int newX, int newY, int startX, int startY){
        this.shape = shape;
        this.panel = panel;
        this.oldX = oldX;
        this.oldY = oldY;
        this.newX = newX;
        this.newY = newY;
        this.startX = startX;
        this.startY = startY;
        PounamuModelProject project = (PounamuModelProject)panel.getProject();
        PounamuManagerPanel manager = project.getManager();
        this.object = project.getEntity(manager.getSelectedNode());
    }

    public MoveShape(PounamuModelProject project, String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, int oldX, int oldY, int newX, int newY,
    int startX, int startY, String rootID){


        /* Get File Seperator */
        String fileSeparator = System.getProperty("file.separator");



        /* ***************  Get Modeller Pannel  ******************/

        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);

        //DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndEntityMapping(),shapeName);


        /* Get Modeller Pannel */
        ModellerPanel mp = (ModellerPanel) tempView.getDisplayPanel();
        PounamuShape shape1 = mp.getShapeByID(rootID);
        object = (PounamuModelElement)shape1.getRelatedObject();
        this.shape = shape1.getBasePanel();
        this.panel = mp;
        this.oldX = oldX;
        this.oldY = oldY;
        this.newX = newX;
        this.newY = newY;
        this.startX = startX;
        this.startY = startY;

    }


    public DefaultMutableTreeNode returnNode(Hashtable hastableToPrint, String name) {

        if( hastableToPrint != null ) {
            java.util.Enumeration enum1 = hastableToPrint.keys();
            while(enum1.hasMoreElements()) {
                DefaultMutableTreeNode dfmt = (DefaultMutableTreeNode)enum1.nextElement();
                if(dfmt.toString().equals(name)) {
                    return dfmt;
                }
            }
        }

        return null;
    }


    /**
     * execute this command
     */
    public void excute(){
        shape.setLocation(shape.getBounds().x-oldX+newX, shape.getBounds().y-oldY+newY);
        panel.repaint();
        MoveShapeEvent mse = new MoveShapeEvent(panel, shape, startX, startY, newX, newY);
        mse.setElement(object);
        panel.eventReceived(mse);
        //panel.notifyCommandPerformed(this, PounamuCommand.EXCUTE);

        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }

    /**
     * undo this command
     */
    public void undo(){
        shape.setLocation(shape.getBounds().x+startX-newX, shape.getBounds().y+startY-newY);
        panel.repaint();
        MoveShapeEvent mse = new MoveShapeEvent(panel, shape, newX, newY, startX, startY);
        panel.eventReceived(mse);
        //panel.notifyCommandPerformed(this, PounamuCommand.UNDO);
    }

    /**
     * redo this command
     */
    public void redo(){
        shape.setLocation(shape.getBounds().x-startX+newX, shape.getBounds().y-startY+newY);
        panel.repaint();
        MoveShapeEvent mse = new MoveShapeEvent(panel, shape, startX, startY, newX, newY);
        panel.eventReceived(mse);
    }

    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return  "one shape has been moved!";
    }

    public ModellerPanel getModellerPanel() {
        return panel;
    }

    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }

}