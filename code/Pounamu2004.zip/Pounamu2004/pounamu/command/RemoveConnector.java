/*
 * @(#)RemoveConnector.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import javax.swing.tree.*;
import java.util.*;
/**
 * an command to remove a association.
 */
public class RemoveConnector implements PounamuCommand{

    ModellerPanel panel = null;
    PounamuConnector connector = null;
    PounamuModelElement object = null;
    PounamuManagerPanel manager = null;
    PounamuView view = null;
    PounamuModelProject project = null;
    PounamuToolProject tool = null;
    DefaultMutableTreeNode parent = null;
    String name = "";
    //added by Penny
    boolean remoteFlag=false;

    /**
     * constructor
     * @param panel the drawing panel where the shape is adding to
     * @param object the assocaition to be removed
     */
    public RemoveConnector(ModellerPanel panel, PounamuConnector object){
        this.panel = panel;
        this.connector = object;
        this.object = (PounamuModelElement)connector.getRelatedObject();
        this.view = panel.getView();

        this.project = (PounamuModelProject)panel.getProject();
        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
        this.parent = (DefaultMutableTreeNode)(manager.getSelectedNode().getParent());
    }
    public RemoveConnector(PounamuModelProject project, String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, String rootID){


        /* Get File Seperator */
        String fileSeparator = System.getProperty("file.separator");


        /* set the PounamuModelProject */
        this.project = project;

        /* Get the Pounamu Tool Project */
        PounamuToolProject tool = null;
        if(project instanceof PounamuModelProject){
            tool = ((PounamuModelProject)project).getTool();
        }


        /* ***************  Get Modeller Pannel  ******************/

        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);
        this.view = tempView;


        /* Get Modeller Pannel */
        ModellerPanel mp = (ModellerPanel) tempView.getDisplayPanel();
        this.panel = mp;

        this.connector = mp.getConnectorByID(rootID);
        //DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndAssociationMapping(),shapeName);
        this.object = (PounamuModelElement)connector.getRelatedObject() ;

        this.tool = ((PounamuModelProject)project).getTool();

        this.name = object.getName();

        this.manager = project.getManager();
        //this.parent = manager.getSelectedNode();




    }

    public DefaultMutableTreeNode returnNode(Hashtable hastableToPrint, String name) {

        if( hastableToPrint != null ) {

            java.util.Enumeration enum1 = hastableToPrint.keys();
            while(enum1.hasMoreElements()) {

                DefaultMutableTreeNode dfmt = (DefaultMutableTreeNode)enum1.nextElement();
                System.out.println( "DFMT" + dfmt.toString());
                System.out.println( "Name" + name);

                if(dfmt.toString().equals(name)) {
                    return dfmt;
                }

            }
        }
        return null;

    }
    /**
     * execute this command
     */
    public void excute(){
        panel.remove(connector);
        panel.validate();
        panel.repaint();
        project.removeAssociation(object);
        DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)project.getIconAndNodeMapping().get(connector);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        manager.removeCurrentNode();
        manager.getNodeAndProjectMapping().remove(dmtn);
        project.getNodeAndViewsTabMapping().remove(dmtn);
        project.getNodeAndViewMapping().remove(dmtn);
        //project.getNodeAndEntityMapping().remove(dmtn);
        project.getNodeAndIconMapping().remove(dmtn);
        project.getNodeAndMenuItemsMapping().remove(dmtn);
        project.getIconAndNodeMapping().remove(connector);
        RemoveConnectorEvent rce = new RemoveConnectorEvent(panel, connector);
        rce.setElement(object);
        panel.eventReceived(rce);

        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }

    /**
     * undo this command
     */
    public void undo(){
     /*TreePath path1 = new TreePath(parent.getPath());
     manager.getManagerTree().setSelectionPath(path1);
     String type = object.getType();
     Hashtable hash = project.getObjectHashtable(type);*/
        panel.setSelected(false);
        connector.setSelected(true);
        panel.add(connector);
        //panel.getConnectors().add(connector);
        panel.validate();
        panel.repaint();
        //hash.put(name, object);
     /*if(object.getIconNumber() == 0){//new entity
       hash.put(name, object);
       NewAssociationEvent nae = new NewAssociationEvent(project, object);
       project.eventReceived(nae);
     }
     object.setIconNumber(object.getIconNumber()+1);;*/
        //DefaultMutableTreeNode dmtn = manager.addObject(name);
        project.addAssociation(object);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, project);
        project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        project.getNodeAndViewMapping().put(dmtn, view);
        //project.getNodeAndAssociationMapping().put(dmtn, object);
        project.getNodeAndIconMapping().put(dmtn, connector);
        project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForAssociation());
        project.getIconAndNodeMapping().put(connector, dmtn);
        manager.addTreeNode(dmtn);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        NewConnectorEvent nce = new NewConnectorEvent(panel, connector);
        panel.eventReceived(nce);
    }

    /**
     * redo this command
     */
    public void redo(){
        excute();
    }
    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return "remove association: " + name;
    }

    public ModellerPanel getModellerPanel() {
        return panel;
    }
    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }


}