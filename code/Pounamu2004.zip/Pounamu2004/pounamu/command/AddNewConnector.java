/*
 * @(#)AddNewConnector.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import javax.swing.tree.*;
import java.util.*;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.File;
/**
 * an command to add a new connector to the drawing canvas.
 */
public class AddNewConnector implements PounamuCommand{

    ModellerPanel panel = null;
    PounamuConnector connector = null;
    PounamuModelElement object = null;
    PounamuManagerPanel manager = null;
    PounamuView view = null;
    PounamuModelProject project = null;
    PounamuToolProject tool = null;
    DefaultMutableTreeNode parent = null;
    String name = "";
    DefaultMutableTreeNode associationNode = null;

    //added by Penny
    boolean remoteFlag=false;
    /**
     * constructor
     * @param panel the drawing panel where the shape is adding to
     * @param connector the new connector
     */
    public AddNewConnector(ModellerPanel panel, PounamuConnector connector){
        this.panel = panel;
        this.object = (PounamuModelElement)connector.getRelatedObject();
        this.view = panel.getView();
        this.connector = connector;
        this.project = (PounamuModelProject)panel.getProject();
        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
        this.parent = manager.getSelectedNode();
    }

    public DefaultMutableTreeNode returnNode(Hashtable hastableToPrint, String name) {

        if( hastableToPrint != null ) {

            java.util.Enumeration enum1 = hastableToPrint.keys();
            while(enum1.hasMoreElements()) {
                DefaultMutableTreeNode dfmt = (DefaultMutableTreeNode)enum1.nextElement();
                if(dfmt.toString().equals(name)) {
                    return dfmt;
                }
            }
        }
        return null;

    }

    /**
     * constructor
     * @param ProjectName The name of the project where to add the Entity
     */

    public AddNewConnector(PounamuModelProject project, int firstHandlerPoint, int secondHandlerPoint, String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, String viewTypeObject, String rootID,
    String shape1RootID, String shape2RootID){
        /* Get File Seperator */
        String fileSeparator = System.getProperty("file.separator");

        /* set the PounamuModelProject */
        this.project = project;

        /* Get the Pounamu Tool Project */
        PounamuToolProject tool = null;

        if(project instanceof PounamuModelProject){
            tool = ((PounamuModelProject)project).getTool();
        }

        /* ***************  Get Modeller Pannel  ******************/
        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);
        this.view = tempView;

        /* Get Modeller Pannel */
        ModellerPanel mp = (ModellerPanel) tempView.getDisplayPanel();
        this.panel = mp;

        /* Get the various handlers */

        PounamuHandle firstHandler = null;
        PounamuHandle secondHandler = null;
        PounamuShape shape1 = mp.getShapeByID(shape1RootID);
        PounamuShape shape2 = mp.getShapeByID(shape2RootID);

        PounamuHandle []shape1Handle = shape1.getBasePanel().getHandlers();
        PounamuHandle []shape2Handle = shape2.getBasePanel().getHandlers();

        System.out.println ("The size of the Shapes is" + mp.getShapes().size());
        firstHandler = shape1Handle[firstHandlerPoint];
        secondHandler = shape2Handle[secondHandlerPoint];

        /* hopefully this workd */
        this.object = new PounamuModelElement(shapeName,modelType, project);
        //object.setRootID(rootID);
        //this.project.incrementAssociationCount();


        /* Create a new file and make it work */
        File inputFile = new File(tool.getLocation()+""+fileSeparator+"icons"+fileSeparator+"connectors"+fileSeparator+""+iconType+".xml");
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuConnector pc = new PounamuConnector(name);
        pc.setRelatedObject(object);
        pc.setType(iconType);
        pc.setHandlers(firstHandler, secondHandler);
        pc.setXMLDocument(lxf.getDocument());
        pc.setRootID(rootID);



        ((PounamuModelElement)object).addIcon(view, pc);
        this.connector = pc;

        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
        //this.parent = manager.getSelectedNode();

        DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndViewMapping(),viewName);
        Enumeration enum = dfmt.children();
        DefaultMutableTreeNode parentNode = null;
        while(enum.hasMoreElements()) {
            DefaultMutableTreeNode tempDfmt = (DefaultMutableTreeNode)enum.nextElement();
            if(tempDfmt.toString().equals("association")) {
                parentNode =   tempDfmt;
                break;
            }
        }

        Enumeration enumEntity = parentNode.children();
        while(enumEntity.hasMoreElements()) {
            DefaultMutableTreeNode tempDfmt = (DefaultMutableTreeNode)enumEntity.nextElement();
            System.out.println("Temp DFMT" + tempDfmt);
            System.out.println("ViewTypeObject" + viewTypeObject);
            if(tempDfmt.toString().equals(viewTypeObject)) {
                associationNode =   tempDfmt;
                break;
            }
        }
        System.out.println("The Value of the Association Node is" + associationNode);
    }

    /**
     * excute this command
     */
    public void excute(){
        panel.setSelected(false);
        connector.setSelected(true);
        panel.add(connector);
        panel.validate();
        panel.repaint();
        object.addIcon(view, connector);
        project.addAssociation(object);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, project);
        if( associationNode == null)
            project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        else
            project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(associationNode));

        project.getNodeAndViewMapping().put(dmtn, view);
        project.getNodeAndIconMapping().put(dmtn, connector);
        project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForAssociation());
        project.getNodeAndToolButtonsMapping().put(dmtn, project.initToolButtonsForAssociation());
        project.getIconAndNodeMapping().put(connector, dmtn);
        project.getNodeAndSavedXMLStringMapping().put(dmtn, object.getXMLRepresentation());
        manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());

        if( associationNode == null)
            manager.addTreeNode(dmtn);
        else
            manager.addTreeNode(associationNode,dmtn);

        /*Original Code*/
        //manager.addTreeNode(dmtn);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        NewConnectorEvent nce = new NewConnectorEvent(panel, connector);
        nce.setStartHandler(connector.getStartHandler());
        nce.setEndHandler(connector.getEndHandler());
        panel.eventReceived(nce);
        //added by Penny

        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }

    /**
     * undo this command
     */
    public void undo(){
        panel.remove(connector);
        panel.validate();
        panel.repaint();
        object.removeIcon(view, connector);
        project.removeAssociation(object);
        DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)project.getIconAndNodeMapping().get(connector);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        manager.removeCurrentNode();
        manager.getNodeAndProjectMapping().remove(dmtn);
        project.getNodeAndViewsTabMapping().remove(dmtn);
        project.getNodeAndViewMapping().remove(dmtn);
        project.getNodeAndIconMapping().remove(dmtn);
        project.getNodeAndMenuItemsMapping().remove(dmtn);
        project.getNodeAndToolButtonsMapping().remove(dmtn);
        project.getIconAndNodeMapping().remove(connector);
        project.getNodeAndSavedXMLStringMapping().remove(dmtn);
        manager.getNodeAndItsValueMapping().remove(dmtn);
        RemoveConnectorEvent rce = new RemoveConnectorEvent(panel, connector);
        panel.eventReceived(rce);
        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }
    }

    /**
     * redo this command
     */
    public void redo(){
        TreePath path = new TreePath(parent.getPath());
        manager.getManagerTree().setSelectionPath(path);
        excute();
    }
    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return "add association: " + name;
    }

    public ModellerPanel getModellerPanel() {
        return panel;
    }

    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }
}