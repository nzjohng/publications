/*
 * @(#)ClearAll.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.editor.*;
import java.util.*;
import javax.swing.JPanel;
/**
 * an command to clear all shapes and connectors on a drawing canvas.
 */
public class ClearAll implements PounamuCommand{

   ModellerPanel panel = null;
   Vector removedConnectors = new Vector();
   Vector removedShapes = new Vector();
   JPanel selectedShape = null;

   /**
    * constructor
    * @param panel the panel on where the shapes and connectors are
    */
   public ClearAll(ModellerPanel panel){
     this.panel = panel;
   }

   /**
    * excute this command
    */
   public void excute(){
     /*selectedShape = panel.getSelectedShape();
     for (int i = 0; i < panel.getConnectors().size(); i++){
       panel.getDrawingPanel().remove((PounamuConnector)(panel.getConnectors().elementAt(i)));
       removedConnectors.add(panel.getConnectors().elementAt(i));
       DeleteConnectorEvent dce = new DeleteConnectorEvent(panel, (PounamuConnector)panel.getConnectors().elementAt(i));
       panel.getPounamu().eventReceived(dce);
     }
     panel.getConnectors().removeAllElements();
     for (int i = 0; i < panel.getShapes().size(); i++){
       panel.getDrawingPanel().remove((PounamuShape)panel.getShapes().elementAt(i));
       removedShapes.add(panel.getShapes().elementAt(i));
       DeleteShapeEvent dse = new DeleteShapeEvent(this, (PounamuShape)panel.getShapes().elementAt(i));
       panel.getPounamu().eventReceived(dse);
     }
     panel.getShapes().removeAllElements();
     panel.repaint();
     panel.getPounamu().setPropertyPanel(null);
     panel.notifyCommandPerformed(this, PounamuCommand.EXCUTE);*/
   }

   /**
    * undo this command
    */
   public void undo(){
     /*for(int i = 0; i < removedShapes.size(); i++){
       panel.getDrawingPanel().add((PounamuShape)(removedShapes.elementAt(i)));
       panel.getShapes().add(removedShapes.elementAt(i));
       NewShapeEvent nse = new NewShapeEvent(panel, (PounamuShape)removedShapes.elementAt(i));
       panel.getPounamu().eventReceived(nse);
     }
     for (int i = 0; i < removedConnectors.size(); i++){
       panel.getDrawingPanel().add((PounamuConnector)removedConnectors.elementAt(i));
       panel.getConnectors().add(removedConnectors.elementAt(i));
       NewConnectorEvent nce = new NewConnectorEvent(panel, (PounamuConnector)removedConnectors.elementAt(i));
       panel.getPounamu().eventReceived(nce);
     }
     if(selectedShape!=null){
       panel.setSelectedShape(selectedShape);
       if(selectedShape instanceof PounamuShape){
         PounamuIconSpecifier pss =
           (PounamuIconSpecifier)(panel.getCompEditorMapping().get((PounamuShape)selectedShape));
         panel.getPounamu().setPropertyPanel(pss);
       }
       else{
         PounamuIconSpecifier pcs =
           (PounamuIconSpecifier)(panel.getCompEditorMapping().get((PounamuConnector)selectedShape));
         panel.getPounamu().setPropertyPanel(pcs);
       }
     }
     panel.repaint();
     panel.notifyCommandPerformed(this, PounamuCommand.UNDO);*/
   }

   /**
    * redo this command
    */
   public void redo(){
     excute();
   }
   /**
    * get the description of this command
    * @return the string decribing this command
    */
   public String getDescription(){
     return "delete all shapes and connector on this drawing panel";
   }
}