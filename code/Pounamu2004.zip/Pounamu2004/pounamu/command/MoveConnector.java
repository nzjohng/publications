package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import java.util.Hashtable;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;

/**
 * Title: MoveConnector
 * Description:  an command to move a Pounamu connector remotely.
 * Copyright:    Copyright (c) 2003
 * Company:      Auckland UniServices Limited
 * @author       Penny Cao
 * @version 1.0
 */


public class MoveConnector implements PounamuCommand {
  PounamuConnector pc = null;
  ModellerPanel panel = null;
  Point firstHandler = null;
  Point secondHandler = null;
  int firstHandleNo = -100;
  int secondHandleNo = -100;
  boolean remoteFlag=false;
  String replacePos = null;
  PounamuModelProject project = null;

  public MoveConnector(ModellerPanel panel, PounamuConnector pc,Point firstHandler, Point secondHandler) {
    this.panel = panel;
    this.project = (PounamuModelProject) panel.getProject();
    this.pc = pc;
    this.firstHandler = firstHandler;
    this.secondHandler = secondHandler;
  }

  public MoveConnector(ModellerPanel panel,PounamuConnector pc, int firstHandleNo, int secondHandleNo){
      this.panel = panel;
      this.project = (PounamuModelProject) panel.getProject();
      this.pc = pc;
      this.firstHandleNo = firstHandleNo;
      this.secondHandleNo = secondHandleNo;
    }

    public void excute() {
      PounamuHandle replaceHandler = null;
      if ( ( (PounamuConnector) pc).getHandlerToBeReplaced().equals("start")) {
        PounamuPanel shape = (PounamuPanel) pc.getStartHandler().getParent();
        PounamuHandle[] handles = shape.getHandlers();
        replaceHandler=handles[this.secondHandleNo];
        ( (PounamuConnector) pc).setStartHandler(replaceHandler);
      }
      else if ( ( (PounamuConnector) pc).getHandlerToBeReplaced().equals("end")) {
        PounamuPanel shape = (PounamuPanel) pc.getEndHandler().getParent();
        PounamuHandle[] handles = shape.getHandlers();
        replaceHandler=handles[this.secondHandleNo];
        ( (PounamuConnector) pc).setEndHandler(replaceHandler);
      }
      else {}
      ( (PounamuConnector) pc).repaint();
      panel.setSelected(false);
      ( (PounamuConnector) pc).setSelected(true);

      //changed to save this model project
      DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
      project.doSaveModelProject(projectDmtn);
    }

    public void undo() {};

    public void redo() {};

    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription() {
      return "Remote move connector handler: ";
    }

    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }



}