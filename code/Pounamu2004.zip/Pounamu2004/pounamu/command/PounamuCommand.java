/*
 * @(#)PounamuCommand.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

/**
 * an interface for implementing undo/redo.
 */
public interface PounamuCommand{
   /**
    * represent the action type is excute
    */
   public final int EXCUTE = 0;
   /**
    * represent the action type is undo
    */
   public final int UNDO = 1;
    /**
    * represent the action type is redo
    */
   public final int REDO = 2;
   /**
    * excute this command
    */
   public void excute();
   /**
    * undo this command
    */
   public void undo();
   /**
    * redo this command
    */
   public void redo();
   /**
    * get the description of this command
    * @return the string decribing this command
    */
   public String getDescription();
}