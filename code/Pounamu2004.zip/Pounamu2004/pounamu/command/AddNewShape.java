/*
 * @(#)AddNewShape.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import javax.swing.tree.*;
import java.util.*;
import java.awt.*;
import java.io.File;
/**
 * an command to add a new shape to the drawing canvas.
 */
public class AddNewShape implements PounamuCommand{

    ModellerPanel panel = null;
    PounamuShape shape = null;
    PounamuModelElement object = null;
    PounamuManagerPanel manager = null;
    PounamuView view = null;
    PounamuModelProject project = null;
    DefaultMutableTreeNode parent = null;
    PounamuToolProject tool = null;
    String name = "";
    DefaultMutableTreeNode entityNode = null;
    //Added by Penny
    boolean remoteFlag=false;
    /**
     * constructor
     * @param panel the drawing panel where the shape is adding to
     */
    public AddNewShape(ModellerPanel panel, PounamuShape shape){
        this.panel = panel;
        //this.object = (PounamuModelElement)panel.getObject();
        //changed by Penny
        this.object=(PounamuModelElement)shape.getRelatedObject();
        this.view = panel.getView();
        this.shape = shape;
        this.project = (PounamuModelProject)panel.getProject();
        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
    }

    /**
     * constructor
     * @param ProjectName The name of the project where to add the Entity
     */

    public AddNewShape(PounamuModelProject project, int cmdExePointX, int cmdExePointY,String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, String viewTypeObject, String rootID){


        /* Initialize Point P */

        Point p = new Point(cmdExePointX,cmdExePointY);

        /* Get File Seperator */
        String fileSeparator = System.getProperty("file.separator");


        /* set the PounamuModelProject */
        this.project = project;

        /* Get the Pounamu Tool Project */
        PounamuToolProject tool = null;
        if(project instanceof PounamuModelProject){
            tool = ((PounamuModelProject)project).getTool();
        }


        /* ***************  Get Modeller Pannel  ******************/

        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);
        this.view = tempView;

        /* Get Modeller Pannel */
        ModellerPanel mp = (ModellerPanel) tempView.getDisplayPanel();
        this.panel = mp;

        /* Set the current object ot be added in mp pannel for this view.*/
        //mp.setCurrentObject(new PounamuModelElement(shapeName,modelType, project));

        /* hopefully this workd */
        this.object = new PounamuModelElement(shapeName,modelType, project);
        /* root ID  to be kept aside temporeraly */
        //     object.setRootID(rootID);
        //this.project.incrementEntityCount();

        /* Create a new file and make it work */
        File inputFile = new File(tool.getLocation()+fileSeparator+"icons"+fileSeparator+"shapes"+fileSeparator+iconType+".xml");
        System.out.println(inputFile.getAbsolutePath());
        LoadXMLFile lxf = new LoadXMLFile(inputFile);
        PounamuShape pp = new PounamuShape(name, lxf.getDocument(), this.project, view,rootID);
        pp.setType(iconType);
        pp.setRelatedObject(object);
        object.addIcon(view, pp);
        pp.getBasePanel().setLocation(p);

        this.shape =pp; //(PounamuShape)object.getIcon(view);

        this.tool = ((PounamuModelProject)project).getTool();

        this.name = object.getName();

        System.out.println("The name of the object is:" + name);
        this.manager = project.getManager();

        //this.parent = manager.getSelectedNode();

        System.out.println("Done Dan Dan Done");


        DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndViewMapping(),viewName);

        Enumeration enum = dfmt.children();
        DefaultMutableTreeNode parentNode = null;
        while(enum.hasMoreElements()) {
            DefaultMutableTreeNode tempDfmt = (DefaultMutableTreeNode)enum.nextElement();
            if(tempDfmt.toString().equals("entity")) {
                parentNode = tempDfmt;
                break;
            }
        }


        Enumeration enumEntity = parentNode.children();
        System.out.println("The NoODE is " + viewTypeObject);
        while(enumEntity.hasMoreElements()) {
            DefaultMutableTreeNode tempDfmt = (DefaultMutableTreeNode)enumEntity.nextElement();
            if(tempDfmt.toString().equals(viewTypeObject)) {
                entityNode = tempDfmt;
                break;
            }
        }

        System.out.println("The Value of the Entity Node is" + entityNode);

    }

    public DefaultMutableTreeNode returnNode(Hashtable hastableToPrint, String name) {

        if( hastableToPrint != null ) {

            java.util.Enumeration enum1 = hastableToPrint.keys();
            while(enum1.hasMoreElements()) {
                DefaultMutableTreeNode dfmt = (DefaultMutableTreeNode)enum1.nextElement();
                if(dfmt.toString().equals(name)) {
                    return dfmt;
                }
            }
        }
        return null;

    }


    /**
     * excute this command
     */
    public void excute(){
        panel.setSelected(false);
        shape.getBasePanel().setSelected(true);
        shape.getBasePanel().addMouseListeners(panel);
        panel.add(shape.getBasePanel());
        panel.validate();
        panel.repaint();
        object.addIcon(view, shape.getBasePanel());
        project.addEntity(object);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, project);

        if( entityNode == null) {
            project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        }
        else {
            project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(entityNode));
        }


        project.getNodeAndViewMapping().put(dmtn, view);

        project.getNodeAndIconMapping().put(dmtn, shape.getBasePanel());
        project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForEntity());
        project.getNodeAndToolButtonsMapping().put(dmtn, project.initToolButtonsForEntity());
        project.getIconAndNodeMapping().put(shape.getBasePanel(), dmtn);
        project.getNodeAndSavedXMLStringMapping().put(dmtn, object.getXMLRepresentation());

        if( entityNode == null) {
            System.out.println("Entity Node is Null ");
            manager.addTreeNode(dmtn);

        }
        else {
            System.out.println("Adding entity the other way");
            manager.addTreeNode(entityNode,dmtn);
        }

        /* Original code */
        //manager.addTreeNode(dmtn);
        manager.getNodeAndItsValueMapping().put(dmtn, dmtn.getUserObject());
        parent = (DefaultMutableTreeNode)dmtn.getParent();
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        NewShapeEvent nse = new NewShapeEvent(panel, shape);
        panel.eventReceived(nse);
        /* Added by Akhil */
        panel.paintImmediately(panel.getBounds(new Rectangle()));

        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }


    /**
     * undo this command
     */
    public void undo(){
        panel.remove(shape.getBasePanel());
        panel.validate();
        panel.repaint();
        object.removeIcon(view, shape);
        project.removeEntity(object);
        DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)project.getIconAndNodeMapping().get(shape.getBasePanel());
        manager.removeTreeNode(dmtn);
        manager.getNodeAndProjectMapping().remove(dmtn);
        manager.getNodeAndItsValueMapping().remove(dmtn);
        project.getNodeAndViewsTabMapping().remove(dmtn);
        project.getNodeAndViewMapping().remove(dmtn);
        project.getNodeAndIconMapping().remove(dmtn);
        project.getNodeAndMenuItemsMapping().remove(dmtn);
        project.getNodeAndToolButtonsMapping().remove(dmtn);
        project.getIconAndNodeMapping().remove(shape.getBasePanel());
        project.getNodeAndSavedXMLStringMapping().remove(dmtn);
        RemoveShapeEvent rse = new RemoveShapeEvent(panel, shape);
        panel.eventReceived(rse);
    }
    /**
     * redo this command
     */
    public void redo(){
        TreePath path = new TreePath(parent.getPath());
        manager.getManagerTree().setSelectionPath(path);
        excute();
    }
    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return "add entity: " + name;
    }

    public ModellerPanel getModellerPanel() {
        return panel;
    }

    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }

}