/*
 * @(#)ChangeProperty.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.editor.*;
import pounamu.data.*;
import java.lang.reflect.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import java.util.*;
/**
 * an command to change properties of a selected entity, association, shape or connector.
 */
public class ChangeProperty implements PounamuCommand{
    PounamuModelElement target;
    String type = null;
    ModellerPanel panel = null;
    PounamuModelProject project = null;
    PounamuToolProject tool = null;
    PounamuView view = null;
    PounamuShape shape = null;
    PounamuConnector connector = null;
    PounamuEntitySpecifier pes = null;
    PounamuAssociationSpecifier pas = null;
    Object[] oldModelPropertyValue = null;
    Object[] oldIconPropertyValue = null;
    Object[] newModelPropertyValue = null;
    Object[] newIconPropertyValue = null;
    
    /**
     * constructor
     * @param target the object whose properties changed
     * @param view the pounamu view the target's icon is in
     * @param type to specify the target is an entity or association
     * @param specifier the property specification panel for this target
     */
    public ChangeProperty(PounamuModelElement target, PounamuView view, Object specifier, String type){
        this.type = type;
        this.view = view;
        this.panel = (ModellerPanel)view.getDisplayPanel();
        this.target = target;
        this.project = (PounamuModelProject)panel.getProject();
        this.oldModelPropertyValue = new Object[target.getAttributeValueList().length];
        for(int i = 0; i < oldModelPropertyValue.length; i++)
            oldModelPropertyValue[i] = target.getAttributeValueList()[i];
        if(type.equals("entity")){
            this.pes = (PounamuEntitySpecifier)specifier;
            this.shape = pes.getShape();
            this.oldIconPropertyValue = new Object[shape.getExportedPropertyNames().length];
            this.newIconPropertyValue = new Object[shape.getExportedPropertyNames().length];
            for(int i = 0; i < shape.getExportedPropertyNames().length; i++){
                String propertyName = shape.getExportedPropertyNames()[i];
                oldIconPropertyValue[i] = shape.getProperty(propertyName);
            }
        }
        else{
            this.pas = (PounamuAssociationSpecifier)specifier;
            this.connector = pas.getConnector();
            this.oldIconPropertyValue = new Object[connector.getExportedPropertyNames().length];
            this.newIconPropertyValue = new Object[connector.getExportedPropertyNames().length];
            for(int i = 0; i < connector.getExportedPropertyNames().length; i++){
                String propertyName = connector.getExportedPropertyNames()[i];
                oldIconPropertyValue[i] = connector.getProperty(propertyName);
            }
        }
    }
    
    public ChangeProperty(PounamuModelProject project, String type, String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, String propertyValue[], String rootID, String[] visualProperties){
        
        for(int t=0; t < visualProperties.length; t++ ) {
            
            System.out.println( "Number " + t + " " + visualProperties[t]);
        }
        
        
        this.newIconPropertyValue = visualProperties;
        this.project = project;
        this.type = type;
        
        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);
        this.view = tempView;
        
        this.panel = (ModellerPanel) tempView.getDisplayPanel();
        
        System.out.println("the Name and stuff" + shapeName);
        //DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndEntityMapping(),shapeName);
        
        //this.target = project.getEntity(dfmt);
        PounamuShape tempShape = panel.getShapeByID(rootID);
        this.target = (PounamuModelElement)tempShape.getRelatedObject();
        
        //if(this.target == null)
        //		this.target = project.getAssociation(dfmt);
        
        
        String[] values = propertyValue;
        String[] types = this.target.getAttributeTypeList();
        String[] names = this.target.getAttributeNameList();
        
        for(int i=0; i < values.length; i++) {
            
            String propertyName = names[i];
            String propType = types[i];
            Object value = null;
            if(propType.equals("int")){
                value = new Integer(values[i]);
            }
            else if(propType.equals("boolean")){
                value = new Boolean(values[i]);
            }
            else if(propType.equals("MultiLinesText")){
                String text = values[i];
                StringTokenizer st = new StringTokenizer(text,"\n");
                value = new Vector();
                while(st.hasMoreTokens() )
                    ((Vector)value).add(st.nextToken());
                
            }
            else{
                value = values[i];
            }
            this.target.setAttributeValue(propertyName, value);
            
        }
        
        
        Object specifier = null;
        
        if(type.equals("entity") )
            specifier = new PounamuEntitySpecifier(this.panel.getShapeByID(rootID) , this.view);
        else
            specifier = new PounamuAssociationSpecifier(this.panel.getConnectorByID(rootID), this.view);
        
        
        this.oldModelPropertyValue = new Object[target.getAttributeValueList().length];
        for(int i = 0; i < oldModelPropertyValue.length; i++)
            oldModelPropertyValue[i] = target.getAttributeValueList()[i];
        if(type.equals("entity")){
            this.pes = (PounamuEntitySpecifier)specifier;
            this.shape = this.panel.getShapeByID(rootID);
            this.oldIconPropertyValue = new Object[shape.getExportedPropertyNames().length];
            this.newIconPropertyValue = new Object[shape.getExportedPropertyNames().length];
            this.newIconPropertyValue = this.setVisualProperties(visualProperties, pes.getVisualPropertyTypes());
            for(int i = 0; i < shape.getExportedPropertyNames().length; i++){
                String propertyName = shape.getExportedPropertyNames()[i];
                oldIconPropertyValue[i] = shape.getProperty(propertyName);
            }
        }
        else{
            this.pas = (PounamuAssociationSpecifier)specifier;
            this.connector = this.panel.getConnectorByID(rootID);
            this.oldIconPropertyValue = new Object[connector.getExportedPropertyNames().length];
            this.newIconPropertyValue = new Object[connector.getExportedPropertyNames().length];
            this.newIconPropertyValue = this.setVisualProperties(visualProperties, pas.getVisualPropertyTypes());
            for(int i = 0; i < connector.getExportedPropertyNames().length; i++){
                String propertyName = connector.getExportedPropertyNames()[i];
                oldIconPropertyValue[i] = connector.getProperty(propertyName);
            }
        }
    }
    
    
    
    /**
     * excute this command
     */
    public void excute(){
        ChangePropertyEvent cpe = null;
        if(type.equals("entity")){
            for(int i = 0; i < pes.modelPropertyNames.length; i++){
                //System.out.println("setProperties visited 0");
                String propertyName = pes.modelPropertyNames[i];
                String type = pes.modelPropertyTypes[i];
                String componentPath = pes.modelComponentPaths[i];
                String propertyOldName = pes.modelPropertyOldNames[i];
                Component renderer = (Component)pes.rendererComp.get(propertyName);
                setTargetProperty(propertyName, type, renderer);
                //System.out.println(propertyName + " " +type+ " " +componentPath+ " " +propertyOldName);
                if(componentPath!=null)
                    setTargetProperty(propertyName, type, componentPath, propertyOldName);
            }
            for(int i = 0; i < pes.visualPropertyNames.length; i++){
                String propertyName = pes.visualPropertyNames[i];
                String type = pes.visualPropertyTypes[i];
                String componentPath = pes.visualComponentPaths[i];
                String propertyOldName = pes.visualPropertyOldNames[i];
                if(propertyName!=null)
                    setTargetProperty(propertyName, type, componentPath, propertyOldName);
            }
        }
        else{
            for(int i = 0; i < pas.modelPropertyNames.length; i++){
                //System.out.println("setProperties visited 0");
                String propertyName = pas.modelPropertyNames[i];
                String type = pas.modelPropertyTypes[i];
                String componentPath = pas.modelComponentPaths[i];
                String propertyOldName = pas.modelPropertyOldNames[i];
                Component renderer = (Component)pas.rendererComp.get(propertyName);
                setTargetProperty(propertyName, type, renderer);
                //System.out.println(propertyName + " " +type+ " " +componentPath+ " " +propertyOldName);
                if(componentPath!=null)
                    setTargetProperty(propertyName, type, componentPath, propertyOldName);
            }
            for(int i = 0; i < pas.visualPropertyNames.length; i++){
                String propertyName = pas.visualPropertyNames[i];
                String type = pas.visualPropertyTypes[i];
                String componentPath = pas.visualComponentPaths[i];
                String propertyOldName = pas.visualPropertyOldNames[i];
                if(propertyName!=null)
                    setTargetProperty(propertyName, type, componentPath, propertyOldName);
            }
        }
        this.newModelPropertyValue = target.getAttributeValueList();
        if(type.equals("entity")){
            for(int i = 0; i < pes.propertyNames.length; i++){
                String propertyName = pes.propertyNames[i];
                newIconPropertyValue[i] = shape.getProperty(propertyName);
            }
            cpe = new ChangePropertyEvent(panel, target, shape, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "entity");
            cpe.setPounamuSpecifier(pes);
        }
        else{
            for(int i = 0; i < pas.propertyNames.length; i++){
                String propertyName = pas.propertyNames[i];
                newIconPropertyValue[i] = connector.getProperty(propertyName);
            }
            cpe = new ChangePropertyEvent(panel, target, connector, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "association");
            cpe.setPounamuSpecifier(pas);
        }
        //cpe = new ChangePropertyEvent(panel, target, shape, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue);
        panel.eventReceived(cpe);
        if(!target.setKey())
            undo();
        target.updateIconInformation();
    }
    
    /**
     * undo this command
     */
    public void undo(){
        
        target.setAttributeValueList(oldModelPropertyValue);
        if(type.equals("entity")){
            for(int i = 0; i < shape.getExportedPropertyNames().length; i++){
                String propertyName = shape.getExportedPropertyNames()[i];
                shape.setProperty(propertyName, oldIconPropertyValue[i]);
            }
            PounamuEntitySpecifier pes = new PounamuEntitySpecifier(shape, view);
            project.getPounamu().setPropertyPanel(pes);
            ChangePropertyEvent cpe = new ChangePropertyEvent(panel, target, shape, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "entity");
            panel.eventReceived(cpe);
        }
        else{
            for(int i = 0; i < connector.getExportedPropertyNames().length; i++){
                String propertyName = connector.getExportedPropertyNames()[i];
                connector.setProperty(propertyName, oldIconPropertyValue[i]);
            }
            PounamuAssociationSpecifier pas = new PounamuAssociationSpecifier(connector, view);
            project.getPounamu().setPropertyPanel(pas);
            ChangePropertyEvent cpe = new ChangePropertyEvent(panel, target, connector, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "association");
            panel.eventReceived(cpe);
        }
        target.setKey();
    }
    
    /**
     * redo this command
     */
    public void redo(){
        
        target.setAttributeValueList(newModelPropertyValue);
        if(type.equals("entity")){
            for(int i = 0; i < shape.getExportedPropertyNames().length; i++){
                String propertyName = shape.getExportedPropertyNames()[i];
                shape.setProperty(propertyName, newIconPropertyValue[i]);
            }
            PounamuEntitySpecifier p = new PounamuEntitySpecifier(shape, view);
            project.getPounamu().setPropertyPanel(p);
            ChangePropertyEvent cpe = new ChangePropertyEvent(panel, target, shape, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "entity");
            panel.eventReceived(cpe);
        }
        else{
            for(int i = 0; i < connector.getExportedPropertyNames().length; i++){
                String propertyName = connector.getExportedPropertyNames()[i];
                connector.setProperty(propertyName, newIconPropertyValue[i]);
            }
            PounamuAssociationSpecifier p = new PounamuAssociationSpecifier(connector, view);
            project.getPounamu().setPropertyPanel(p);
            ChangePropertyEvent cpe = new ChangePropertyEvent(panel, target, connector, newModelPropertyValue, oldModelPropertyValue, newIconPropertyValue, oldIconPropertyValue, "association");
            panel.eventReceived(cpe);
        }
        target.setKey();
    }
    
    private void setTargetProperty(String propertyName, String propertyType, Component renderer){
        Object value = null;
        if(propertyType.equals("int")){
            value = new Integer(((PounamuIntRenderer)renderer).getText());
        }
        else if(propertyType.equals("boolean")){
            value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
        }
        else if(propertyType.equals("MultiLinesText")){
            value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
        }
        else{
            value = ((PounamuStringRenderer)renderer).getText();
        }
        target.setAttributeValue(propertyName, value);
    }
    
    private void setTargetProperty(String propertyName, String propertyType, String componentPath, String propertyOldName){
        Object comp = null;
        Component renderer = null;
        if(type.equals("entity")){
            if (shape instanceof PounamuShape)
                comp = ((PounamuShape)shape).pathComponentMapping.get(componentPath);
            else comp = shape;
        }
        else
            comp =connector;
        Class c = comp.getClass();
        String methodName = "set"+capitalizeFirstLetter(propertyOldName);
        if(type.equals("entity"))
            renderer = (Component)pes.rendererComp.get(propertyName);
        else
            renderer = (Component)pas.rendererComp.get(propertyName);
        try{
            if(propertyType.equals("int")){
                Method m = c.getMethod(methodName, new Class[]{int.class});
                Integer value = new Integer(((PounamuIntRenderer)renderer).getText());
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("boolean")){
                Method m = c.getMethod(methodName, new Class[]{boolean.class});
                Boolean value = new Boolean(((PounamuBooleanRenderer)renderer).getBooleanValue());
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Font")){
                Method m = c.getMethod(methodName, new Class[]{Font.class});
                Font value = ((PounamuFontRenderer)renderer).getFont();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Border")){
                Method m = c.getMethod(methodName, new Class[]{Border.class});
                Border value = ((PounamuBorderRenderer)renderer).getBorder();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Color")){
                Method m = c.getMethod(methodName, new Class[]{Color.class});
                Color value = ((PounamuColorRenderer)renderer).getColor();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("HorizontalAlignment")){
                Method m = c.getMethod(methodName, new Class[]{int.class});
                Integer value = new Integer(((PounamuHorizontalAlignmentRenderer)renderer).getHorizontalAlignment());
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("VerticalAlignment")){
                Method m = c.getMethod(methodName, new Class[]{int.class});
                Integer value = new Integer(((PounamuVerticalAlignmentRenderer)renderer).getVerticalAlignment());
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("LayoutParameters")){
                Method m = c.getMethod(methodName, new Class[]{LayoutManager.class});
                LayoutManager value = ((PounamuLayoutRenderer)renderer).getLayoutParameters();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("MultiLinesText")){
                Method m = c.getMethod(methodName, new Class[]{Vector.class});
                Vector value = ((PounamuMultiLinesTextRenderer)renderer).getMultiLinesText();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("GridBagConstraints")){
                Method m = c.getMethod(methodName, new Class[]{GridBagConstraints.class});
                GridBagConstraints value = ((PounamuGridBagConstraintsRenderer)renderer).getGridBagConstraints();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Position")){
                Method m = c.getMethod(methodName, new Class[]{String.class});
                String value = ((PounamuPositionRenderer)renderer).getPosition();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("BasicStroke")){
                Method m = c.getMethod(methodName, new Class[]{BasicStroke.class});
                BasicStroke value = ((PounamuBasicStrokeRenderer)renderer).getBasicStroke();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Insets")){
                Method m = c.getMethod(methodName, new Class[]{Insets.class});
                Insets value = ((PounamuInsetsRenderer)renderer).getInsets();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("ShapeType")){
                Method m = c.getMethod(methodName, new Class[]{String.class});
                String value = ((PounamuShapeTypeRenderer)renderer).getShapeType();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Size")){
                Method m = c.getMethod(methodName, new Class[]{Dimension.class});
                Dimension value = ((PounamuSizeRenderer)renderer).getMinimumSize();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("Location")){
                Method m = c.getMethod(methodName, new Class[]{Point.class});
                Point value = ((PounamuLocationRenderer)renderer).getLocation();
                m.invoke(comp, new Object[]{value});
            }
            else if(propertyType.equals("ArrowShape")){
                Method m = c.getMethod(methodName, new Class[]{String.class});
                String value = ((PounamuArrowShapeRenderer)renderer).getArrowShape();
                m.invoke(target, new Object[]{value});
            }
            else{
                Method m = c.getMethod(methodName, new Class[]{String.class});
                String value = ((PounamuStringRenderer)renderer).getText();
                m.invoke(comp, new Object[]{value});
            }
        }
        catch(Exception e){
            e.printStackTrace(System.out);
        }
    }
    
    
    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return "properties of " + target.getName() + "has been changed";
    }
    
    /**
     * a help method to Change the first letter of a String to Capital
     * @param s the string to be changed
     * @return the changed string
     */
    protected String capitalizeFirstLetter(String s) {
        char chars[] = s.toCharArray();
        if(chars[0]>='a'&&chars[0]<='z')
            chars[0] = (char)(chars[0]-('a' - 'A'));
        return new String(chars);
    }
    
    public ModellerPanel getModellerPanel() {
        return panel;
    }
    
    public Object[] setVisualProperties( String []remoteVisualProps, String []visualPropertyType) {
        
        int length = visualPropertyType.length;
        Object []newIconValues = new Object[length];
        for(int i = 0; i < length; i++ ) {
            String propertyType = visualPropertyType[i];
            try{
                
                if(propertyType.equals("int")){
                    newIconValues[i] = new Integer(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("boolean")){
                    newIconValues[i] = new Boolean(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("String")||propertyType.equals("ArrowShape")){
                    newIconValues[i] = new String(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("Color")){
                    String tokenValue[] = tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new Color(Integer.parseInt(tokenValue[0]),
                    Integer.parseInt(tokenValue[1]),
                    Integer.parseInt(tokenValue[2]));
                }
                else if(propertyType.equals("Font")){
                    String tokenValue[] = tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new Font(tokenValue[0],
                    Integer.parseInt(tokenValue[1]),
                    Integer.parseInt(tokenValue[2]));
                }
                else if(propertyType.equals("Border")){
                    
                    newIconValues[i] = BorderFactory.createEmptyBorder();
                    if(remoteVisualProps[i]==null||remoteVisualProps[i].equals("")){
                        newIconValues[i] = BorderFactory.createEmptyBorder();
                    }
                    else{
                        String border = remoteVisualProps[i];
                        if(border.equals("EmptyBorder"))
                            newIconValues[i] = BorderFactory.createEmptyBorder();
                        else if(border.equals("LineBorder"))
                            newIconValues[i] = BorderFactory.createLineBorder(Color.black);
                        else if(border.equals("EtchedBorder"))
                            newIconValues[i] = BorderFactory.createEtchedBorder();
                        else if(border.equals("SharedRaisedBevel"))
                            newIconValues[i] = BorderFactory.createRaisedBevelBorder();
                        else if(border.equals("SharedLoweredBevel"))
                            newIconValues[i] = BorderFactory.createLoweredBevelBorder();
                        else{}
                    }
                    
                }
                else if(propertyType.equals("LayoutParameters")){
                    
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    String layouttype = tokens[0] ;
                    if(layouttype.equals("null"))
                        newIconValues[i] = null;
                    else if(layouttype.equals("FlowLayout")){
                        newIconValues[i] = new FlowLayout(Integer.parseInt(tokens[1]),
                        Integer.parseInt(tokens[2]),
                        Integer.parseInt(tokens[3]));
                    }
                    else if(layouttype.equals("VerticalFlowLayout")){
                        newIconValues[i] = new VerticalFlowLayout(Integer.parseInt(tokens[1]));
                    }
                    else if(layouttype.equals("BorderLayout")){
                        
                        newIconValues[i] = new BorderLayout(Integer.parseInt(tokens[1]),
                        Integer.parseInt(tokens[2]));
                    }
                    else if(layouttype.equals("GridLayout")){
                        newIconValues[i] = new GridLayout(Integer.parseInt(tokens[1]),
                        Integer.parseInt(tokens[2]),
                        Integer.parseInt(tokens[3]),
                        Integer.parseInt(tokens[4]));
                    }
                    else if(layouttype.equals("GridBagLayout")){
                        newIconValues[i] = new GridBagLayout();
                    }
                    else{}
                    
                }
                else if(propertyType.equals("HorizontalAlignment")||propertyType.equals("VerticalAlignment")){
                    newIconValues[i] = new Integer(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("MultiLinesText")){
                    newIconValues[i] = new Vector();//value
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    for(int j=0; j < tokens.length ; j++ )
                        ((Vector)newIconValues[i]).add(tokens[j]);
                }
                else if(propertyType.equals("GridBagConstraints")){
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new GridBagConstraints();
                    ((GridBagConstraints)newIconValues[i]).gridx = new Integer(tokens[0]).intValue();
                    ((GridBagConstraints)newIconValues[i]).gridy = new Integer(tokens[1]).intValue();
                    ((GridBagConstraints)newIconValues[i]).gridwidth = new Integer(tokens[2]).intValue();
                    ((GridBagConstraints)newIconValues[i]).gridheight = new Integer(tokens[3]).intValue();
                    ((GridBagConstraints)newIconValues[i]).ipadx = new Integer(tokens[4]).intValue();
                    ((GridBagConstraints)newIconValues[i]).ipady = new Integer(tokens[5]).intValue();
                    ((GridBagConstraints)newIconValues[i]).weightx = new Double(tokens[6]).doubleValue();
                    ((GridBagConstraints)newIconValues[i]).weighty = new Double(tokens[7]).doubleValue();
                    ((GridBagConstraints)newIconValues[i]).insets.top = new Integer(tokens[8]).intValue();
                    ((GridBagConstraints)newIconValues[i]).insets.bottom = new Integer(tokens[9]).intValue();
                    ((GridBagConstraints)newIconValues[i]).insets.left = new Integer(tokens[10]).intValue();
                    ((GridBagConstraints)newIconValues[i]).insets.right = new Integer(tokens[11]).intValue();
                    ((GridBagConstraints)newIconValues[i]).fill = new Integer(tokens[12]).intValue();
                    ((GridBagConstraints)newIconValues[i]).anchor = new Integer(tokens[13]).intValue();
                    
                }
                else if(propertyType.equals("Insets")){
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new Insets(0, 0, 0, 0);
                    ((Insets)newIconValues[i]).top = new Integer(tokens[0]).intValue();
                    ((Insets)newIconValues[i]).bottom = new Integer(tokens[1]).intValue();
                    ((Insets)newIconValues[i]).left = new Integer(tokens[2]).intValue();
                    ((Insets)newIconValues[i]).right = new Integer(tokens[3]).intValue();
                    
                }
                else if(propertyType.equals("Position")){
                    newIconValues[i] = new String(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("ShapeType")){
                    newIconValues[i] = new String(remoteVisualProps[i]);//value
                }
                else if(propertyType.equals("Location")){
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new Point();
                    ((Point)newIconValues[i]).x = new Integer(tokens[0]).intValue();
                    ((Point)newIconValues[i]).y = new Integer(tokens[1]).intValue();
                    
                }
                else if(propertyType.equals("Size")){
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    newIconValues[i] = new Dimension();
                    
                    ((Dimension)newIconValues[i]).width = new Integer(tokens[0]).intValue();
                    ((Dimension)newIconValues[i]).height = new Integer(tokens[1]).intValue();
                    
                    /* if(comp instanceof PounamuPanel){
                        ((PounamuPanel)comp).setSize(value);
                        ((PounamuPanel)comp).setPreferredSize(value);
                    } */
                }
                else if(propertyType.equals("BasicStroke")){
                    String tokens [] = this.tokenizeString(remoteVisualProps[i],"$");
                    
                    float linewidth = new Float(tokens[0]).floatValue();
                    int endcaps = new Integer(tokens[1]).intValue();
                    int linejoints = new Integer(tokens[2]).intValue();
                    String dashArrayTokens[] = tokenizeString(tokens[3],"#");
                    float dasharray0 = new Float(dashArrayTokens[0]).floatValue();
                    float dasharray1 = new Float(dashArrayTokens[1]).floatValue();
                    float dasharray2 = new Float(dashArrayTokens[2]).floatValue();
                    float dasharray3 = new Float(dashArrayTokens[3]).floatValue();
                    float miterlimit = new Float(tokens[4]).floatValue();
                    float dashphase = new Float(tokens[5]).floatValue();
                    float[] dash = new float[]{dasharray0, dasharray1, dasharray2, dasharray3};
                    newIconValues[i] = new BasicStroke(linewidth, endcaps, linejoints, miterlimit, dash, dashphase);
                    
                }
                else{}
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        
        return newIconValues;
    }
    
    public String[] tokenizeString(String value, String token) {
        StringTokenizer stk = new StringTokenizer(value,token);
        int length = (stk.countTokens()+1);
        String []tokens = new String[length];
        int i = 0;
        while( stk.hasMoreElements() ) {
            tokens[i] = (String)stk.nextElement();
            i++;
        }
        return tokens;
    }
    
}