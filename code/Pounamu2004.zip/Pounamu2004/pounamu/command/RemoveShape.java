/*
 * @(#)RemoveShape.java	1.0 20/04/02
 *
 * Copyright 2002 Auckland UniServices Limited. All Rights Reserved.
 *
 * This software is the proprietary information of Auckland UniServices Limited.
 * Use is subject to license terms.
 *
 */

package pounamu.command;

import pounamu.core.*;
import pounamu.visualcomp.*;
import pounamu.event.*;
import pounamu.data.*;
import javax.swing.tree.*;
import java.util.*;
/**
 * an command to remove an shape
 */
public class RemoveShape implements PounamuCommand{

    ModellerPanel panel = null;
    PounamuShape shape = null;
    PounamuModelElement object = null;
    PounamuManagerPanel manager = null;
    PounamuView view = null;
    PounamuModelProject project = null;
    DefaultMutableTreeNode parent = null;
    PounamuToolProject tool = null;
    String name = "";
    boolean remoteFlag=false;

    /**
     * constructor
     * @param panel the drawing panel where the entity is adding to
     * @param object the entity to be removed
     */
    public RemoveShape(ModellerPanel panel, PounamuShape shape){
        this.panel = panel;
        this.object = (PounamuModelElement)shape.getRelatedObject();
        this.view = panel.getView();
        this.shape = shape;
        this.project = (PounamuModelProject)panel.getProject();
        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
    }

    /**
     * constructor
     * @param ProjectName The name of the project where to add the Entity
     */

    public RemoveShape(PounamuModelProject project, String iconType, String modelProjectName,String modelType,
    String shapeName, String viewName,String viewType, String rootID){

        /* Get File Seperator */
        String fileSeparator = System.getProperty("file.separator");


        /* set the PounamuModelProject */
        this.project = project;

        /* Get the Pounamu Tool Project */
        PounamuToolProject tool = null;
        if(project instanceof PounamuModelProject){
            tool = ((PounamuModelProject)project).getTool();
        }

        /* ***************  Get Modeller Pannel  ******************/
        /* Get the appropriate view */
        Hashtable hashTableTemp = (Hashtable)((project.getOpenedModelViews()).get(viewType));
        PounamuView tempView = (PounamuView) hashTableTemp.get(viewName);
        this.view = tempView;

        /* Get Modeller Pannel */
        ModellerPanel mp = (ModellerPanel) tempView.getDisplayPanel();
        this.panel = mp;
        this.shape = (PounamuShape)mp.getShapeByID(rootID);
        //DefaultMutableTreeNode dfmt = returnNode(project.getNodeAndEntityMapping(),shapeName);
        this.object = (PounamuModelElement)shape.getRelatedObject();
        this.tool = ((PounamuModelProject)project).getTool();
        this.name = object.getName();
        this.manager = project.getManager();
        //this.parent = manager.getSelectedNode();

    }


    public DefaultMutableTreeNode returnNode(Hashtable hastableToPrint, String name) {
        if( hastableToPrint != null ) {
            java.util.Enumeration enum1 = hastableToPrint.keys();
            while(enum1.hasMoreElements()) {

                DefaultMutableTreeNode dfmt = (DefaultMutableTreeNode)enum1.nextElement();
                System.out.println( "DFMT" + dfmt.toString());
                System.out.println( "Name" + name);

                if(dfmt.toString().equals(name)) {
                    return dfmt;
                }
            }
        }
        return null;
    }
    /**
     * execute this command
     */
    public void excute(){
        panel.remove(shape.getBasePanel());
        panel.validate();
        panel.repaint();
        project.removeEntity(object);
        DefaultMutableTreeNode dmtn = (DefaultMutableTreeNode)project.getIconAndNodeMapping().get(shape.getBasePanel());
        parent = (DefaultMutableTreeNode)dmtn.getParent();
        manager.removeTreeNode(dmtn);
        manager.getNodeAndProjectMapping().remove(dmtn);
        project.getNodeAndViewsTabMapping().remove(dmtn);
        project.getNodeAndViewMapping().remove(dmtn);
        project.getNodeAndIconMapping().remove(dmtn);
        project.getNodeAndMenuItemsMapping().remove(dmtn);
        project.getNodeAndToolButtonsMapping().remove(dmtn);
        project.getIconAndNodeMapping().remove(shape.getBasePanel());
        project.getNodeAndSavedXMLStringMapping().remove(dmtn);
        manager.getPounamu().setPropertyPanel(null);
        RemoveShapeEvent rse = new RemoveShapeEvent(panel, shape);
        rse.setElement(object);
        panel.eventReceived(rse);
        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }
    /**
     * undo this command
     */
    public void undo(){
        TreePath path1 = new TreePath(parent.getPath());
        manager.getManagerTree().setSelectionPath(path1);
        //String type = object.getType();
        //Hashtable hash = project.getObjectHashtable(type);
        panel.setSelected(false);
        shape.getBasePanel().setSelected(true);
        panel.add(shape.getBasePanel());
        //panel.getShapes().add(shape.getBasePanel());
        panel.validate();
        panel.repaint();
        project.addEntity(object);
        //hash.put(name, object);
     /*if(object.getIconNumber() == 0){//new entity
       hash.put(name, object);
       NewEntityEvent nee = new NewEntityEvent(project, object);
       project.eventReceived(nee);
     }
     object.setIconNumber(object.getIconNumber()+1);*/
        //DefaultMutableTreeNode dmtn = manager.addObject(name);
        DefaultMutableTreeNode dmtn = new DefaultMutableTreeNode(name);
        manager.getNodeAndProjectMapping().put(dmtn, project);
        project.getNodeAndViewsTabMapping().put(dmtn, project.getNodeAndViewsTabMapping().get(manager.getSelectedNode()));
        project.getNodeAndViewMapping().put(dmtn, view);
        project.getNodeAndIconMapping().put(dmtn, shape.getBasePanel());
        project.getNodeAndMenuItemsMapping().put(dmtn, project.initMenuItemsForEntity());
        project.getNodeAndToolButtonsMapping().put(dmtn, project.initToolButtonsForEntity());
        project.getIconAndNodeMapping().put(shape.getBasePanel(), dmtn);
        project.getNodeAndSavedXMLStringMapping().put(dmtn, object.getXMLRepresentation());
        //manager.addTreeNode(dmtn);
        manager.addTreeNode(parent, dmtn);
        TreePath path = new TreePath(dmtn.getPath());
        manager.getManagerTree().setSelectionPath(path);
        NewShapeEvent nse = new NewShapeEvent(panel, shape);

        panel.eventReceived(nse);
        //added by Penny
        if(remoteFlag){
          PounamuModelProject project = (PounamuModelProject)panel.getProject();
          PounamuManagerPanel manager = project.getManager();
          DefaultMutableTreeNode projectDmtn=project.getCorrespondingTreeNode();
          project.doSaveModelProject(projectDmtn);
        }

    }
    /**
     * redo this command
     */
    public void redo(){
        excute();
    }
    /**
     * get the description of this command
     * @return the string decribing this command
     */
    public String getDescription(){
        return "remove shape: " + name;
    }

    public ModellerPanel getModellerPanel() {
        return panel;
    }

    //added by Penny
    public void setRemoteFlag(boolean isRemoteExecution){
      this.remoteFlag=isRemoteExecution;
    }

}